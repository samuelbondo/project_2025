<?php
// Gmail SMTP Configuration - FREE FOREVER (500 emails/day)
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'samuelbondo917@gmail.com'); // Your Gmail
define('SMTP_PASSWORD', 'htyeamixakdffspj'); // Your app password
define('SMTP_SECURE', 'tls');

// Organization details
define('ORG_NAME', 'REACH Organization');
define('ORG_EMAIL', 'info@reach.org');
define('ORG_REPLY_TO', 'info@reach.org');

// Email subjects
define('EMAIL_ADMIN_SUBJECT', 'New Contact Form Submission - REACH Organization');
define('EMAIL_AUTO_REPLY_SUBJECT', 'Thank You for Contacting REACH Organization');

// Debug mode
define('SMTP_DEBUG', 0);
?>