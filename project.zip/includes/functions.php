<?php
/**
 * REACH Organization - Utility Functions
 * Contains helper functions used throughout the application
 */

// Make sure session is started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Get application status color
 */
if (!function_exists('getApplicationStatusColor')) {
    function getApplicationStatusColor($status) {
        $colors = [
            'draft' => 'secondary',
            'submitted' => 'warning',
            'pending' => 'warning',
            'under_review' => 'info',
            'approved' => 'success',
            'rejected' => 'danger',
            'waitlisted' => 'primary'
        ];
        return $colors[$status] ?? 'secondary';
    }
}

/**
 * Get activity icon based on action
 */
if (!function_exists('getActivityIcon')) {
    function getActivityIcon($action) {
        $icons = [
            'login' => 'sign-in-alt',
            'logout' => 'sign-out-alt',
            'create' => 'plus-circle',
            'update' => 'edit',
            'delete' => 'trash',
            'view' => 'eye',
            'approve' => 'check-circle',
            'reject' => 'times-circle',
            'upload' => 'upload',
            'download' => 'download',
            'register' => 'user-plus',
            'password_reset' => 'key',
            'email_verification' => 'envelope'
        ];
        return $icons[$action] ?? 'circle';
    }
}

/**
 * Get time elapsed string
 */
if (!function_exists('time_elapsed_string')) {
    function time_elapsed_string($datetime, $full = false) {
        $now = new DateTime;
        $ago = new DateTime($datetime);
        $diff = $now->diff($ago);

        $diff->w = floor($diff->d / 7);
        $diff->d -= $diff->w * 7;

        $string = array(
            'y' => 'year',
            'm' => 'month',
            'w' => 'week',
            'd' => 'day',
            'h' => 'hour',
            'i' => 'minute',
            's' => 'second',
        );
        
        foreach ($string as $k => &$v) {
            if ($diff->$k) {
                $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
            } else {
                unset($string[$k]);
            }
        }

        if (!$full) $string = array_slice($string, 0, 1);
        return $string ? implode(', ', $string) . ' ago' : 'just now';
    }
}

/**
 * Get story type color
 */
if (!function_exists('getStoryTypeColor')) {
    function getStoryTypeColor($type) {
        $colors = [
            'student' => 'primary',
            'project' => 'success', 
            'achievement' => 'warning',
            'community' => 'info',
            'news' => 'secondary'
        ];
        return $colors[$type] ?? 'secondary';
    }
}

/**
 * Get project status color
 */
if (!function_exists('getProjectStatusColor')) {
    function getProjectStatusColor($status) {
        $colors = [
            'planning' => 'secondary',
            'in_progress' => 'primary',
            'completed' => 'success',
            'on_hold' => 'warning',
            'cancelled' => 'danger'
        ];
        return $colors[$status] ?? 'secondary';
    }
}

/**
 * Generate a random string
 */
if (!function_exists('generateRandomString')) {
    function generateRandomString($length = 10) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }
}

/**
 * Format file size in human readable format
 */
if (!function_exists('formatFileSize')) {
    function formatFileSize($bytes) {
        if ($bytes >= 1073741824) {
            return number_format($bytes / 1073741824, 2) . ' GB';
        } elseif ($bytes >= 1048576) {
            return number_format($bytes / 1048576, 2) . ' MB';
        } elseif ($bytes >= 1024) {
            return number_format($bytes / 1024, 2) . ' KB';
        } else {
            return $bytes . ' bytes';
        }
    }
}

/**
 * Get the current user's information - FIXED VERSION using global PDO
 */
if (!function_exists('getCurrentUser')) {
    function getCurrentUser() {
        if (!isset($_SESSION['user_id'])) {
            return null;
        }
        
        // Use global PDO connection instead of Database class
        global $pdo;
        try {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
            $stmt->execute([$_SESSION['user_id']]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error getting current user: " . $e->getMessage());
            return null;
        }
    }
}

/**
 * Check if user has specific role - FIXED: Use correct session key
 */
if (!function_exists('hasRole')) {
    function hasRole($role) {
        return isset($_SESSION['user_role']) && $_SESSION['user_role'] === $role;
    }
}

/**
 * Check if user has any of the specified roles - FIXED: Use correct session key
 */
if (!function_exists('hasAnyRole')) {
    function hasAnyRole($roles) {
        if (!isset($_SESSION['user_role'])) {
            return false;
        }
        return in_array($_SESSION['user_role'], (array)$roles);
    }
}

/**
 * Get user's display name
 */
if (!function_exists('getDisplayName')) {
    function getDisplayName($user) {
        if (is_array($user)) {
            return $user['full_name'] ?? ($user['first_name'] ?? '') . ' ' . ($user['last_name'] ?? '');
        }
        return 'User';
    }
}

/**
 * Format date for display
 */
if (!function_exists('formatDate')) {
    function formatDate($date, $format = 'F j, Y') {
        if (empty($date) || $date === '0000-00-00' || $date === '0000-00-00 00:00:00') return '';
        try {
            $datetime = new DateTime($date);
            return $datetime->format($format);
        } catch (Exception $e) {
            return '';
        }
    }
}

/**
 * Format date with time
 */
if (!function_exists('formatDateTime')) {
    function formatDateTime($date, $format = 'F j, Y g:i A') {
        if (empty($date) || $date === '0000-00-00' || $date === '0000-00-00 00:00:00') return '';
        try {
            $datetime = new DateTime($date);
            return $datetime->format($format);
        } catch (Exception $e) {
            return '';
        }
    }
}

/**
 * Get relative time (e.g., "2 hours ago")
 */
if (!function_exists('getRelativeTime')) {
    function getRelativeTime($date) {
        if (empty($date) || $date === '0000-00-00' || $date === '0000-00-00 00:00:00') return '';
        
        try {
            $time = strtotime($date);
            $timeDiff = time() - $time;
            
            if ($timeDiff < 60) {
                return 'just now';
            } elseif ($timeDiff < 3600) {
                $minutes = round($timeDiff / 60);
                return $minutes . ' minute' . ($minutes > 1 ? 's' : '') . ' ago';
            } elseif ($timeDiff < 86400) {
                $hours = round($timeDiff / 3600);
                return $hours . ' hour' . ($hours > 1 ? 's' : '') . ' ago';
            } elseif ($timeDiff < 2592000) {
                $days = round($timeDiff / 86400);
                return $days . ' day' . ($days > 1 ? 's' : '') . ' ago';
            } else {
                return formatDate($date);
            }
        } catch (Exception $e) {
            return '';
        }
    }
}

/**
 * Get current URL
 */
if (!function_exists('getCurrentUrl')) {
    function getCurrentUrl() {
        $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
        return $protocol . "://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    }
}

/**
 * Get base URL
 */
if (!function_exists('getBaseUrl')) {
    function getBaseUrl() {
        $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
        $path = dirname($_SERVER['SCRIPT_NAME']);
        $baseUrl = $protocol . "://" . $_SERVER['HTTP_HOST'] . $path;
        return rtrim($baseUrl, '/');
    }
}

/**
 * Get client IP address
 */
if (!function_exists('getClientIp')) {
    function getClientIp() {
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            return $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            return $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            return $_SERVER['REMOTE_ADDR'];
        }
    }
}

/**
 * Log activity
 */
if (!function_exists('logActivity')) {
    function logActivity($action, $details = '') {
        global $pdo;
        
        if (!isset($_SESSION['user_id'])) {
            return false;
        }
        
        try {
            // Try activity_log table first (new structure)
            $stmt = $pdo->prepare("INSERT INTO activity_log (user_id, action, description, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([
                $_SESSION['user_id'],
                $action,
                $details,
                getClientIp(),
                $_SERVER['HTTP_USER_AGENT'] ?? ''
            ]);
            return true;
        } catch (Exception $e) {
            try {
                // Fallback to activity_logs table (old structure)
                $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, action, details, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([
                    $_SESSION['user_id'],
                    $action,
                    $details,
                    getClientIp(),
                    $_SERVER['HTTP_USER_AGENT'] ?? ''
                ]);
                return true;
            } catch (Exception $e2) {
                error_log("Error logging activity: " . $e2->getMessage());
                return false;
            }
        }
    }
}

/**
 * Get notification count for current user
 */
if (!function_exists('getNotificationCount')) {
    function getNotificationCount() {
        global $pdo;
        
        if (!isset($_SESSION['user_id'])) {
            return 0;
        }
        
        try {
            $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0");
            $stmt->execute([$_SESSION['user_id']]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return $result['count'] ?? 0;
        } catch (Exception $e) {
            error_log("Error getting notification count: " . $e->getMessage());
            return 0;
        }
    }
}

/**
 * Add success message
 */
if (!function_exists('addSuccessMessage')) {
    function addSuccessMessage($message) {
        if (!isset($_SESSION['success_messages'])) {
            $_SESSION['success_messages'] = [];
        }
        $_SESSION['success_messages'][] = $message;
    }
}

/**
 * Add error message
 */
if (!function_exists('addErrorMessage')) {
    function addErrorMessage($message) {
        if (!isset($_SESSION['error_messages'])) {
            $_SESSION['error_messages'] = [];
        }
        $_SESSION['error_messages'][] = $message;
    }
}

/**
 * Add warning message
 */
if (!function_exists('addWarningMessage')) {
    function addWarningMessage($message) {
        if (!isset($_SESSION['warning_messages'])) {
            $_SESSION['warning_messages'] = [];
        }
        $_SESSION['warning_messages'][] = $message;
    }
}

/**
 * Add info message
 */
if (!function_exists('addInfoMessage')) {
    function addInfoMessage($message) {
        if (!isset($_SESSION['info_messages'])) {
            $_SESSION['info_messages'] = [];
        }
        $_SESSION['info_messages'][] = $message;
    }
}

/**
 * Get and clear success messages
 */
if (!function_exists('getSuccessMessages')) {
    function getSuccessMessages() {
        $messages = $_SESSION['success_messages'] ?? [];
        unset($_SESSION['success_messages']);
        return $messages;
    }
}

/**
 * Get and clear error messages
 */
if (!function_exists('getErrorMessages')) {
    function getErrorMessages() {
        $messages = $_SESSION['error_messages'] ?? [];
        unset($_SESSION['error_messages']);
        return $messages;
    }
}

/**
 * Get and clear warning messages
 */
if (!function_exists('getWarningMessages')) {
    function getWarningMessages() {
        $messages = $_SESSION['warning_messages'] ?? [];
        unset($_SESSION['warning_messages']);
        return $messages;
    }
}

/**
 * Get and clear info messages
 */
if (!function_exists('getInfoMessages')) {
    function getInfoMessages() {
        $messages = $_SESSION['info_messages'] ?? [];
        unset($_SESSION['info_messages']);
        return $messages;
    }
}

/**
 * Display flash messages
 */
if (!function_exists('displayFlashMessages')) {
    function displayFlashMessages() {
        $html = '';
        
        // Success messages
        foreach (getSuccessMessages() as $message) {
            $html .= '<div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="fas fa-check-circle me-2"></i>' . sanitizeOutput($message) . '
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>';
        }
        
        // Error messages
        foreach (getErrorMessages() as $message) {
            $html .= '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="fas fa-exclamation-circle me-2"></i>' . sanitizeOutput($message) . '
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>';
        }
        
        // Warning messages
        foreach (getWarningMessages() as $message) {
            $html .= '<div class="alert alert-warning alert-dismissible fade show" role="alert">
                <i class="fas fa-exclamation-triangle me-2"></i>' . sanitizeOutput($message) . '
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>';
        }
        
        // Info messages
        foreach (getInfoMessages() as $message) {
            $html .= '<div class="alert alert-info alert-dismissible fade show" role="alert">
                <i class="fas fa-info-circle me-2"></i>' . sanitizeOutput($message) . '
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>';
        }
        
        return $html;
    }
}

/**
 * Check if string starts with specific text
 */
if (!function_exists('startsWith')) {
    function startsWith($string, $startString) {
        $len = strlen($startString);
        return substr($string, 0, $len) === $startString;
    }
}

/**
 * Check if string ends with specific text
 */
if (!function_exists('endsWith')) {
    function endsWith($string, $endString) {
        $len = strlen($endString);
        if ($len == 0) {
            return true;
        }
        return substr($string, -$len) === $endString;
    }
}

/**
 * Truncate text with ellipsis
 */
if (!function_exists('truncateText')) {
    function truncateText($text, $maxLength = 100) {
        if (strlen($text) <= $maxLength) {
            return $text;
        }
        return substr($text, 0, $maxLength) . '...';
    }
}

/**
 * Get file extension
 */
if (!function_exists('getFileExtension')) {
    function getFileExtension($filename) {
        return strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    }
}

/**
 * Check if file is an image
 */
if (!function_exists('isImageFile')) {
    function isImageFile($filename) {
        $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'svg'];
        return in_array(getFileExtension($filename), $allowedExtensions);
    }
}

/**
 * Check if file is a document
 */
if (!function_exists('isDocumentFile')) {
    function isDocumentFile($filename) {
        $allowedExtensions = ['pdf', 'doc', 'docx', 'txt', 'rtf', 'odt'];
        return in_array(getFileExtension($filename), $allowedExtensions);
    }
}

/**
 * Sanitize output - prevent XSS
 */
if (!function_exists('sanitizeOutput')) {
    function sanitizeOutput($data) {
        if (is_array($data)) {
            return array_map('sanitizeOutput', $data);
        }
        return htmlspecialchars($data ?? '', ENT_QUOTES, 'UTF-8');
    }
}

/**
 * Redirect to another page
 */
if (!function_exists('redirect')) {
    function redirect($url) {
        if (!headers_sent()) {
            header("Location: " . $url);
        }
        exit();
    }
}

/**
 * Check if request is AJAX
 */
if (!function_exists('isAjaxRequest')) {
    function isAjaxRequest() {
        return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
               strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
    }
}

/**
 * Get current page name
 */
if (!function_exists('getCurrentPage')) {
    function getCurrentPage() {
        return basename($_SERVER['PHP_SELF']);
    }
}

/**
 * Validate email address
 */
if (!function_exists('isValidEmail')) {
    function isValidEmail($email) {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }
}

/**
 * Generate CSRF token
 */
if (!function_exists('generateCsrfToken')) {
    function generateCsrfToken() {
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            $_SESSION['csrf_token_time'] = time();
        }
        return $_SESSION['csrf_token'];
    }
}

/**
 * Verify CSRF token
 */
if (!function_exists('verifyCsrfToken')) {
    function verifyCsrfToken($token) {
        return isset($_SESSION['csrf_token']) && 
               hash_equals($_SESSION['csrf_token'], $token);
    }
}

/**
 * Check if user is logged in - FIXED: Use correct session keys
 */
if (!function_exists('isLoggedIn')) {
    function isLoggedIn() {
        return isset($_SESSION['user_id']) && isset($_SESSION['user_role']);
    }
}

/**
 * Require authentication
 */
if (!function_exists('requireAuth')) {
    function requireAuth() {
        if (!isLoggedIn()) {
            $_SESSION['redirect_url'] = getCurrentUrl();
            header('Location: /public/login.php');
            exit;
        }
    }
}

/**
 * Require specific role - FIXED: Use correct session key
 */
if (!function_exists('requireRole')) {
    function requireRole($requiredRole) {
        requireAuth();
        
        $roleHierarchy = [
            'super_admin' => 100,
            'admin' => 90,
            'staff' => 80,
            'reviewer' => 70,
            'partner' => 60,
            'sponsor' => 50,
            'volunteer' => 40,
            'student' => 30
        ];
        
        $userRoleLevel = $roleHierarchy[$_SESSION['user_role']] ?? 0;
        $requiredRoleLevel = $roleHierarchy[$requiredRole] ?? 0;
        
        if ($userRoleLevel < $requiredRoleLevel) {
            if (!headers_sent()) {
                header('HTTP/1.1 403 Forbidden');
            }
            die("<div style='text-align: center; padding: 50px; font-family: Arial, sans-serif;'>
                    <h1>Access Denied</h1>
                    <p>You don't have permission to access this page.</p>
                    <a href='" . getDashboardUrl($_SESSION['user_role']) . "' style='color: #3498db;'>Return to Dashboard</a>
                </div>");
        }
    }
}

/**
 * Get dashboard URL based on role
 */
if (!function_exists('getDashboardUrl')) {
    function getDashboardUrl($role) {
        $dashboards = [
            'super_admin' => '/admin/dashboard.php',
            'admin' => '/admin/dashboard.php',
            'staff' => '/portal/staff/dashboard.php',
            'student' => '/portal/student/dashboard.php',
            'sponsor' => '/portal/sponsor/dashboard.php',
            'partner' => '/portal/partner/dashboard.php',
            'volunteer' => '/portal/volunteer/dashboard.php',
            'reviewer' => '/portal/reviewer/dashboard.php'
        ];
        
        return $dashboards[$role] ?? '/public/login.php';
    }
}

/**
 * Sanitize input data
 */
if (!function_exists('sanitizeInput')) {
    function sanitizeInput($data) {
        if (is_array($data)) {
            return array_map('sanitizeInput', $data);
        }
        
        return htmlspecialchars(trim($data ?? ''), ENT_QUOTES, 'UTF-8');
    }
}

/**
 * Get organization information
 */
if (!function_exists('getOrganizationInfo')) {
    function getOrganizationInfo() {
        return [
            'name' => 'REACH Organization',
            'acronym' => 'REACH',
            'full_name' => 'Recognizing Each Action Can Help',
            'email' => 'info@reach.org',
            'phone' => '+250 788 123 456',
            'address' => 'Kigali, Rwanda',
            'founders' => 'Mr. Philip B. Suah Jr. & Mrs. Hawa Suah',
            'mission' => 'To empower underprivileged students and communities through comprehensive educational support and sustainable development programs.',
            'vision' => 'A world where every individual has access to quality education and opportunities for growth',
            'contact_email' => 'no-reply@youngdevsofficial.com',
            'website' => 'https://reach.org',
            'year_founded' => '2024'
        ];
    }
}

/**
 * Validate file upload
 */
if (!function_exists('validateFileUpload')) {
    function validateFileUpload($file, $allowedTypes = [], $maxSize = null) {
        $errors = [];
        
        if ($file['error'] !== UPLOAD_ERR_OK) {
            $uploadErrors = [
                UPLOAD_ERR_INI_SIZE => 'The uploaded file exceeds the upload_max_filesize directive in php.ini.',
                UPLOAD_ERR_FORM_SIZE => 'The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form.',
                UPLOAD_ERR_PARTIAL => 'The uploaded file was only partially uploaded.',
                UPLOAD_ERR_NO_FILE => 'No file was uploaded.',
                UPLOAD_ERR_NO_TMP_DIR => 'Missing a temporary folder.',
                UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk.',
                UPLOAD_ERR_EXTENSION => 'A PHP extension stopped the file upload.'
            ];
            $errors[] = $uploadErrors[$file['error']] ?? 'Unknown upload error: ' . $file['error'];
            return $errors;
        }
        
        $maxSize = $maxSize ?? (5 * 1024 * 1024); // 5MB default
        
        if ($file['size'] > $maxSize) {
            $errors[] = 'File size exceeds maximum allowed size of ' . formatFileSize($maxSize);
        }
        
        $extension = getFileExtension($file['name']);
        if (!empty($allowedTypes) && !in_array($extension, $allowedTypes)) {
            $errors[] = 'File type not allowed. Allowed types: ' . implode(', ', $allowedTypes);
        }
        
        return $errors;
    }
}

/**
 * Check if file type is allowed
 */
if (!function_exists('isAllowedFileType')) {
    function isAllowedFileType($filename, $allowedTypes) {
        $extension = getFileExtension($filename);
        return in_array($extension, $allowedTypes);
    }
}

/**
 * Generate application code
 */
if (!function_exists('generateApplicationCode')) {
    function generateApplicationCode($prefix = 'APP') {
        return $prefix . '-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -6));
    }
}

/**
 * Redirect with message
 */
if (!function_exists('redirectWithMessage')) {
    function redirectWithMessage($url, $type, $message) {
        if ($type === 'success') {
            addSuccessMessage($message);
        } else {
            addErrorMessage($message);
        }
        if (!headers_sent()) {
            header("Location: $url");
        }
        exit;
    }
}

/**
 * Get user by ID
 */
if (!function_exists('getUserById')) {
    function getUserById($userId) {
        global $pdo;
        
        try {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
            $stmt->execute([$userId]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Get user failed: " . $e->getMessage());
            return null;
        }
    }
}

/**
 * Validate CSRF token with timeout
 */
if (!function_exists('validateCsrfToken')) {
    function validateCsrfToken($token) {
        if (!isset($_SESSION['csrf_token']) || !isset($_SESSION['csrf_token_time'])) {
            return false;
        }
        
        if (!hash_equals($_SESSION['csrf_token'], $token)) {
            return false;
        }
        
        // Token expires after 1 hour
        if (time() - $_SESSION['csrf_token_time'] > 3600) {
            unset($_SESSION['csrf_token']);
            unset($_SESSION['csrf_token_time']);
            return false;
        }
        
        return true;
    }
}

/**
 * Send email
 */
if (!function_exists('sendEmail')) {
    function sendEmail($to, $subject, $body, $isHTML = true) {
        $fromEmail = 'no-reply@reach.org';
        $fromName = 'REACH Organization';
        
        $headers = [];
        $headers[] = "From: " . $fromName . " <" . $fromEmail . ">";
        $headers[] = "Reply-To: " . $fromEmail;
        $headers[] = "X-Mailer: PHP/" . phpversion();
        
        if ($isHTML) {
            $headers[] = "MIME-Version: 1.0";
            $headers[] = "Content-Type: text/html; charset=UTF-8";
            
            // Wrap in HTML template
            $body = '<!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8">
                <style>
                    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                    .header { background: #3498db; color: white; padding: 20px; text-align: center; }
                    .content { background: #f9f9f9; padding: 20px; }
                    .footer { background: #34495e; color: white; padding: 10px; text-align: center; font-size: 12px; }
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="header">
                        <h1>REACH Organization</h1>
                    </div>
                    <div class="content">' . $body . '</div>
                    <div class="footer">
                        <p>&copy; ' . date('Y') . ' REACH Organization. All rights reserved.</p>
                    </div>
                </div>
            </body>
            </html>';
        }
        
        $headerString = implode("\r\n", $headers);
        
        try {
            $result = mail($to, $subject, $body, $headerString);
            
            if (!$result) {
                error_log("Email sending failed to: $to, Subject: $subject");
                logEmail($to, $subject, $body, 'FAILED');
                return false;
            }
            
            logEmail($to, $subject, $body, 'SENT');
            return true;
            
        } catch (Exception $e) {
            error_log("Email exception: " . $e->getMessage());
            logEmail($to, $subject, $body, 'ERROR: ' . $e->getMessage());
            return false;
        }
    }
}

/**
 * Log email activity
 */
if (!function_exists('logEmail')) {
    function logEmail($to, $subject, $body, $status = 'SENT') {
        $logMessage = "[" . date('Y-m-d H:i:s') . "] EMAIL $status:\n";
        $logMessage .= "To: $to\n";
        $logMessage .= "Subject: $subject\n";
        $logMessage .= "Body Length: " . strlen($body) . " characters\n";
        $logMessage .= "Status: $status\n";
        $logMessage .= "------------------------\n";
        
        $logDir = __DIR__ . '/../logs/';
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
        
        file_put_contents($logDir . 'email.log', $logMessage, FILE_APPEND | LOCK_EX);
    }
}

/**
 * Get user role display name
 */
if (!function_exists('getRoleDisplayName')) {
    function getRoleDisplayName($role) {
        $roles = [
            'super_admin' => 'Super Administrator',
            'admin' => 'Administrator',
            'staff' => 'Staff Member',
            'student' => 'Student',
            'sponsor' => 'Sponsor',
            'partner' => 'Partner',
            'volunteer' => 'Volunteer',
            'reviewer' => 'Reviewer'
        ];
        return $roles[$role] ?? ucfirst(str_replace('_', ' ', $role));
    }
}

/**
 * Get country name from code
 */
if (!function_exists('getCountryName')) {
    function getCountryName($code) {
        $countries = [
            'RW' => 'Rwanda',
            'UG' => 'Uganda',
            'TZ' => 'Tanzania',
            'KE' => 'Kenya',
            'US' => 'United States',
            'UK' => 'United Kingdom',
            'CA' => 'Canada'
        ];
        return $countries[$code] ?? $code;
    }
}

/**
 * Format currency
 */
if (!function_exists('formatCurrency')) {
    function formatCurrency($amount, $currency = 'USD') {
        $formats = [
            'USD' => '$',
            'EUR' => '€',
            'GBP' => '£',
            'RWF' => 'FRw'
        ];
        
        $symbol = $formats[$currency] ?? $currency . ' ';
        return $symbol . number_format($amount, 2);
    }
}

/**
 * Get program type display name
 */
if (!function_exists('getProgramTypeDisplay')) {
    function getProgramTypeDisplay($type) {
        $types = [
            'scholarship' => 'Scholarship Program',
            'housing' => 'Housing Support',
            'community' => 'Community Project',
            'training' => 'Training Program',
            'mentorship' => 'Mentorship Program'
        ];
        return $types[$type] ?? ucfirst($type);
    }
}

/**
 * Generate pagination HTML
 */
if (!function_exists('generatePagination')) {
    function generatePagination($currentPage, $totalPages, $urlPattern) {
        if ($totalPages <= 1) return '';
        
        $html = '<nav aria-label="Page navigation"><ul class="pagination">';
        
        // Previous button
        if ($currentPage > 1) {
            $html .= '<li class="page-item"><a class="page-link" href="' . sprintf($urlPattern, $currentPage - 1) . '">Previous</a></li>';
        } else {
            $html .= '<li class="page-item disabled"><span class="page-link">Previous</span></li>';
        }
        
        // Page numbers
        $start = max(1, $currentPage - 2);
        $end = min($totalPages, $start + 4);
        
        for ($i = $start; $i <= $end; $i++) {
            if ($i == $currentPage) {
                $html .= '<li class="page-item active"><span class="page-link">' . $i . '</span></li>';
            } else {
                $html .= '<li class="page-item"><a class="page-link" href="' . sprintf($urlPattern, $i) . '">' . $i . '</a></li>';
            }
        }
        
        // Next button
        if ($currentPage < $totalPages) {
            $html .= '<li class="page-item"><a class="page-link" href="' . sprintf($urlPattern, $currentPage + 1) . '">Next</a></li>';
        } else {
            $html .= '<li class="page-item disabled"><span class="page-link">Next</span></li>';
        }
        
        $html .= '</ul></nav>';
        return $html;
    }
}

/**
 * Get user initials
 */
if (!function_exists('getUserInitials')) {
    function getUserInitials($user) {
        if (is_array($user)) {
            $name = $user['full_name'] ?? '';
            if (empty($name)) {
                $name = ($user['first_name'] ?? '') . ' ' . ($user['last_name'] ?? '');
            }
        } else {
            $name = (string)$user;
        }
        
        $names = explode(' ', trim($name));
        $initials = '';
        
        foreach ($names as $name) {
            if (!empty($name)) {
                $initials .= strtoupper($name[0]);
            }
        }
        
        return substr($initials, 0, 2);
    }
}

/**
 * Check if password is strong
 */
if (!function_exists('isPasswordStrong')) {
    function isPasswordStrong($password) {
        if (strlen($password) < 8) {
            return false;
        }
        
        if (!preg_match('/[A-Z]/', $password)) {
            return false;
        }
        
        if (!preg_match('/[a-z]/', $password)) {
            return false;
        }
        
        if (!preg_match('/[0-9]/', $password)) {
            return false;
        }
        
        if (!preg_match('/[^A-Za-z0-9]/', $password)) {
            return false;
        }
        
        return true;
    }
}

/**
 * Get user status badge
 */
if (!function_exists('getUserStatusBadge')) {
    function getUserStatusBadge($status) {
        $badges = [
            'active' => '<span class="badge bg-success">Active</span>',
            'inactive' => '<span class="badge bg-secondary">Inactive</span>',
            'suspended' => '<span class="badge bg-danger">Suspended</span>',
            'pending' => '<span class="badge bg-warning">Pending</span>'
        ];
        return $badges[$status] ?? '<span class="badge bg-secondary">' . ucfirst($status) . '</span>';
    }
}

/**
 * Get user role badge
 */
if (!function_exists('getUserRoleBadge')) {
    function getUserRoleBadge($role) {
        $badges = [
            'super_admin' => '<span class="badge bg-danger">Super Admin</span>',
            'admin' => '<span class="badge bg-primary">Admin</span>',
            'staff' => '<span class="badge bg-info">Staff</span>',
            'student' => '<span class="badge bg-success">Student</span>',
            'sponsor' => '<span class="badge bg-warning">Sponsor</span>',
            'partner' => '<span class="badge bg-secondary">Partner</span>',
            'volunteer' => '<span class="badge bg-light text-dark">Volunteer</span>',
            'reviewer' => '<span class="badge bg-dark">Reviewer</span>'
        ];
        return $badges[$role] ?? '<span class="badge bg-secondary">' . getRoleDisplayName($role) . '</span>';
    }
}

/**
 * Get pending applications count for sidebar
 */
if (!function_exists('getPendingApplicationsCount')) {
    function getPendingApplicationsCount() {
        global $pdo;
        try {
            $stmt = $pdo->query("SELECT COUNT(*) as count FROM applications WHERE status IN ('submitted', 'pending', 'under_review')");
            $result = $stmt->fetch();
            return $result['count'] ?? 0;
        } catch (Exception $e) {
            return 0;
        }
    }
}

/**
 * Get total students count for sidebar
 */
if (!function_exists('getTotalStudentsCount')) {
    function getTotalStudentsCount() {
        global $pdo;
        try {
            $stmt = $pdo->query("SELECT COUNT(*) as count FROM users WHERE role = 'student' AND (status = 'active' OR status IS NULL)");
            $result = $stmt->fetch();
            return $result['count'] ?? 0;
        } catch (Exception $e) {
            return 0;
        }
    }
}

/**
 * Get active partners count for sidebar
 */
if (!function_exists('getActivePartnersCount')) {
    function getActivePartnersCount() {
        global $pdo;
        try {
            $stmt = $pdo->query("SELECT COUNT(*) as count FROM partners WHERE status = 'active'");
            $result = $stmt->fetch();
            return $result['count'] ?? 0;
        } catch (Exception $e) {
            return 0;
        }
    }
}

/**
 * Get total users count for sidebar
 */
if (!function_exists('getTotalUsersCount')) {
    function getTotalUsersCount() {
        global $pdo;
        try {
            $stmt = $pdo->query("SELECT COUNT(*) as count FROM users WHERE status = 'active' OR status IS NULL");
            $result = $stmt->fetch();
            return $result['count'] ?? 0;
        } catch (Exception $e) {
            return 0;
        }
    }
}

/**
 * Get unread notifications count for sidebar
 */
if (!function_exists('getUnreadNotificationsCount')) {
    function getUnreadNotificationsCount() {
        global $pdo;
        try {
            $stmt = $pdo->query("SELECT COUNT(*) as count FROM notifications WHERE is_read = 0");
            $result = $stmt->fetch();
            return $result['count'] ?? 0;
        } catch (Exception $e) {
            return 0;
        }
    }
}

/**
 * Check if current page is in active section for sidebar
 */
if (!function_exists('isActiveSection')) {
    function isActiveSection($section) {
        $current_page = basename($_SERVER['PHP_SELF']);
        $current_directory = basename(dirname($_SERVER['PHP_SELF']));
        
        $section_pages = [
            'dashboard' => ['dashboard.php'],
            'applications' => ['applications/index.php', 'applications/view.php', 'applications/edit.php', 'applications/review.php'],
            'students' => ['students/index.php', 'students/view.php', 'students/edit.php', 'students/profile.php'],
            'finances' => ['finances/index.php', 'finances/transactions.php', 'finances/reports.php'],
            'partners' => ['partners/index.php', 'partners/view.php', 'partners/edit.php'],
            'stories' => ['stories/index.php', 'stories/view.php', 'stories/edit.php', 'stories/create.php', 'manage-stories.php'],
            'reports' => ['reports/index.php', 'reports/generate.php', 'reports/analytics.php'],
            'users' => ['users/index.php', 'users/view.php', 'users/edit.php', 'users/create.php'],
            'settings' => ['settings.php', 'profile.php', 'system-settings.php']
        ];
        
        // Check if current page matches any in the section
        foreach ($section_pages[$section] ?? [] as $page) {
            if (strpos($page, '/') !== false) {
                // Handle directory-based pages
                if ($current_directory . '/' . $current_page === $page) {
                    return true;
                }
            } else {
                // Handle direct pages
                if ($current_page === $page) {
                    return true;
                }
            }
        }
        
        return false;
    }
}

/**
 * Get dashboard statistics - ADDED MISSING FUNCTION
 */
if (!function_exists('getDashboardStats')) {
    function getDashboardStats() {
        global $pdo;
        
        try {
            $stats = [];
            
            // Total users
            $stmt = $pdo->query("SELECT COUNT(*) as total_users FROM users WHERE deleted = 0");
            $stats['total_users'] = $stmt->fetch(PDO::FETCH_ASSOC)['total_users'] ?? 0;
            
            // Active users (last 30 days) - fallback if user_sessions table doesn't exist
            try {
                $stmt = $pdo->query("SELECT COUNT(DISTINCT user_id) as active_users FROM user_sessions WHERE last_activity >= DATE_SUB(NOW(), INTERVAL 30 DAY)");
                $stats['active_users'] = $stmt->fetch(PDO::FETCH_ASSOC)['active_users'] ?? 0;
            } catch (Exception $e) {
                // Fallback: count users who logged in last 30 days
                $stmt = $pdo->query("SELECT COUNT(*) as active_users FROM users WHERE last_login >= DATE_SUB(NOW(), INTERVAL 30 DAY) AND deleted = 0");
                $stats['active_users'] = $stmt->fetch(PDO::FETCH_ASSOC)['active_users'] ?? 0;
            }
            
            // Total projects
            $stmt = $pdo->query("SELECT COUNT(*) as total_projects FROM student_projects WHERE approved = 1");
            $stats['total_projects'] = $stmt->fetch(PDO::FETCH_ASSOC)['total_projects'] ?? 0;
            
            // Pending projects
            $stmt = $pdo->query("SELECT COUNT(*) as pending_projects FROM student_projects WHERE approved = 0");
            $stats['pending_projects'] = $stmt->fetch(PDO::FETCH_ASSOC)['pending_projects'] ?? 0;
            
            // Total stories
            $stmt = $pdo->query("SELECT COUNT(*) as total_stories FROM stories WHERE status = 'published'");
            $stats['total_stories'] = $stmt->fetch(PDO::FETCH_ASSOC)['total_stories'] ?? 0;
            
            // Total achievements
            $stmt = $pdo->query("SELECT COUNT(*) as total_achievements FROM student_achievements WHERE verified = 1");
            $stats['total_achievements'] = $stmt->fetch(PDO::FETCH_ASSOC)['total_achievements'] ?? 0;
            
            // Pending approvals
            $stmt = $pdo->query("SELECT COUNT(*) as pending_approvals FROM student_projects WHERE approved = 0");
            $stats['pending_approvals'] = $stmt->fetch(PDO::FETCH_ASSOC)['pending_approvals'] ?? 0;
            
            // New users this month
            $stmt = $pdo->query("SELECT COUNT(*) as new_users_month FROM users WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) AND deleted = 0");
            $stats['new_users_month'] = $stmt->fetch(PDO::FETCH_ASSOC)['new_users_month'] ?? 0;
            
            // User growth percentage
            $lastMonth = date('Y-m-d', strtotime('-1 month'));
            $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM users WHERE created_at < ? AND deleted = 0");
            $stmt->execute([$lastMonth]);
            $lastMonthUsers = $stmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 1;
            
            if ($lastMonthUsers > 0) {
                $stats['growth_percentage'] = round((($stats['total_users'] - $lastMonthUsers) / $lastMonthUsers) * 100, 2);
            } else {
                $stats['growth_percentage'] = 100;
            }
            
            return $stats;
            
        } catch (Exception $e) {
            error_log("Dashboard stats error: " . $e->getMessage());
            return [
                'total_users' => 0,
                'active_users' => 0,
                'total_projects' => 0,
                'pending_projects' => 0,
                'total_stories' => 0,
                'total_achievements' => 0,
                'pending_approvals' => 0,
                'new_users_month' => 0,
                'growth_percentage' => 0
            ];
        }
    }
}

/**
 * Get recent activity - ADDED MISSING FUNCTION
 */
if (!function_exists('getRecentActivity')) {
    function getRecentActivity($limit = 10) {
        global $pdo;
        
        try {
            $activities = [];
            
            // Check if audit_logs table exists, if not return empty array
            $stmt = $pdo->query("SHOW TABLES LIKE 'audit_logs'");
            if (!$stmt->fetch()) {
                return $activities;
            }
            
            $sql = "SELECT al.*, u.full_name, u.email 
                    FROM audit_logs al 
                    LEFT JOIN users u ON al.user_id = u.id 
                    ORDER BY al.created_at DESC 
                    LIMIT ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$limit]);
            $activities = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // If no audit logs, get recent user registrations as fallback
            if (empty($activities)) {
                $sql = "SELECT id, full_name, email, created_at, 'user_registered' as action 
                        FROM users 
                        ORDER BY created_at DESC 
                        LIMIT ?";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([$limit]);
                $activities = $stmt->fetchAll(PDO::FETCH_ASSOC);
            }
            
            return $activities;
            
        } catch (Exception $e) {
            error_log("Recent activity error: " . $e->getMessage());
            return [];
        }
    }
}

/**
 * Get all dashboard statistics in one optimized query
 */
if (!function_exists('getAllDashboardStats')) {
    function getAllDashboardStats() {
        global $pdo;
        
        try {
            $sql = "
                SELECT 
                    (SELECT COUNT(*) FROM users WHERE deleted = 0) as total_users,
                    (SELECT COUNT(*) FROM users WHERE last_login >= DATE_SUB(NOW(), INTERVAL 30 DAY) AND deleted = 0) as active_users,
                    (SELECT COUNT(*) FROM student_projects WHERE approved = 1) as total_projects,
                    (SELECT COUNT(*) FROM student_projects WHERE approved = 0) as pending_projects,
                    (SELECT COUNT(*) FROM stories WHERE status = 'published') as total_stories,
                    (SELECT COUNT(*) FROM student_achievements WHERE verified = 1) as total_achievements,
                    (SELECT COUNT(*) FROM applications WHERE status IN ('submitted', 'pending', 'under_review')) as pending_applications,
                    (SELECT COUNT(*) FROM users WHERE role = 'student' AND (status = 'active' OR status IS NULL)) as total_students,
                    (SELECT COUNT(*) FROM partners WHERE status = 'active') as active_partners,
                    (SELECT COUNT(*) FROM notifications WHERE is_read = 0) as unread_notifications,
                    (SELECT COUNT(*) FROM users WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) AND deleted = 0) as new_users_month
            ";
            
            $stmt = $pdo->query($sql);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Calculate growth percentage
            $lastMonth = date('Y-m-d', strtotime('-1 month'));
            $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM users WHERE created_at < ? AND deleted = 0");
            $stmt->execute([$lastMonth]);
            $lastMonthUsers = $stmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 1;
            
            if ($lastMonthUsers > 0) {
                $result['growth_percentage'] = round((($result['total_users'] - $lastMonthUsers) / $lastMonthUsers) * 100, 2);
            } else {
                $result['growth_percentage'] = 100;
            }
            
            return $result;
            
        } catch (Exception $e) {
            error_log("Dashboard stats error: " . $e->getMessage());
            return [
                'total_users' => 0,
                'active_users' => 0,
                'total_projects' => 0,
                'pending_projects' => 0,
                'total_stories' => 0,
                'total_achievements' => 0,
                'pending_applications' => 0,
                'total_students' => 0,
                'active_partners' => 0,
                'unread_notifications' => 0,
                'new_users_month' => 0,
                'growth_percentage' => 0
            ];
        }
    }
}

/**
 * Get user-specific dashboard stats
 */
if (!function_exists('getUserDashboardStats')) {
    function getUserDashboardStats($userId) {
        global $pdo;
        
        try {
            $stats = [];
            
            // Get user role
            $stmt = $pdo->prepare("SELECT role FROM users WHERE id = ?");
            $stmt->execute([$userId]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            $userRole = $user['role'] ?? 'student';
            
            switch ($userRole) {
                case 'student':
                    $sql = "
                        SELECT 
                            (SELECT COUNT(*) FROM applications WHERE user_id = ?) as total_applications,
                            (SELECT COUNT(*) FROM applications WHERE user_id = ? AND status = 'approved') as approved_applications,
                            (SELECT COUNT(*) FROM applications WHERE user_id = ? AND status IN ('submitted', 'pending', 'under_review')) as pending_applications,
                            (SELECT COUNT(*) FROM student_projects WHERE user_id = ? AND approved = 1) as completed_projects,
                            (SELECT COUNT(*) FROM student_achievements WHERE user_id = ? AND verified = 1) as achievements
                    ";
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute([$userId, $userId, $userId, $userId, $userId]);
                    $stats = $stmt->fetch(PDO::FETCH_ASSOC);
                    break;
                    
                case 'admin':
                case 'staff':
                    // Use admin stats
                    $stats = getAllDashboardStats();
                    break;
                    
                default:
                    $stats = [
                        'total_applications' => 0,
                        'approved_applications' => 0,
                        'pending_applications' => 0,
                        'completed_projects' => 0,
                        'achievements' => 0
                    ];
            }
            
            return $stats;
            
        } catch (Exception $e) {
            error_log("User dashboard stats error: " . $e->getMessage());
            return [];
        }
    }
}

// Generate CSRF token for forms
if (empty($_SESSION['csrf_token'])) {
    generateCsrfToken();
}
?>