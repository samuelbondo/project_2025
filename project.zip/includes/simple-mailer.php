<?php
require_once 'email-config.php';

function sendREACEmail($to, $subject, $message, $is_html = false) {
    $headers = "From: " . ORG_NAME . " <" . SMTP_USERNAME . ">\r\n";
    $headers .= "Reply-To: " . ORG_REPLY_TO . "\r\n";
    
    if ($is_html) {
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
    } else {
        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
    }
    
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "X-Mailer: PHP/" . phpversion();
    
    // Send email using PHP's mail function
    return mail($to, $subject, $message, $headers);
}

function sendAdminNotification($contact_data) {
    $subject = EMAIL_ADMIN_SUBJECT;
    
    $message = "
    NEW CONTACT FORM SUBMISSION
    
    Contact ID: #{$contact_data['id']}
    Date: {$contact_data['date']}
    
    Contact Details:
    ----------------
    Name: {$contact_data['name']}
    Email: {$contact_data['email']}
    Phone: " . ($contact_data['phone'] ?: 'Not provided') . "
    Subject: {$contact_data['subject']}
    
    Message:
    {$contact_data['message']}
    
    Technical Details:
    -----------------
    IP Address: {$contact_data['ip_address']}
    User Agent: {$contact_data['user_agent']}
    
    ---
    This email was sent automatically from your website contact form.
    ";
    
    return sendREACEmail(ORG_EMAIL, $subject, $message);
}

function sendAutoReply($contact_data) {
    $subject = EMAIL_AUTO_REPLY_SUBJECT;
    
    $message = "
    Dear {$contact_data['name']},
    
    Thank you for contacting REACH Organization! We have received your message and appreciate you taking the time to reach out to us.
    
    Here's a summary of your submission:
    ------------------------------------
    Subject: {$contact_data['subject']}
    Date Submitted: {$contact_data['date']}
    Reference ID: #{$contact_data['id']}
    
    What happens next?
    ------------------
    ✓ Our team will review your message
    ✓ We'll respond within 24-48 hours
    ✓ You'll hear from us at this email address
    
    For urgent matters, please contact us directly:
    📞 Phone: +250 788 123 456
    📧 Email: info@reach.org
    
    We look forward to assisting you!
    
    Warm regards,
    
    The REACH Organization Team
    Transforming Lives Through Education
    Kigali, Rwanda
    
    ---
    This is an automated response. Please do not reply to this email.
    If you need to send additional information, please email info@reach.org
    ";
    
    return sendREACEmail($contact_data['email'], $subject, $message);
}
?>