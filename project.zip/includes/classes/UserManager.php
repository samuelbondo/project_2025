<?php
class UserManager {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    public function getUsers($filters = [], $limit = 20, $offset = 0) {
        $where = [];
        $params = [];

        if (!empty($filters['role']) && $filters['role'] !== 'all') {
            $where[] = 'role = ?';
            $params[] = $filters['role'];
        }

        if (!empty($filters['status']) && $filters['status'] !== 'all') {
            $where[] = 'status = ?';
            $params[] = $filters['status'];
        }

        $whereClause = $where ? 'WHERE ' . implode(' AND ', $where) : '';

        $sql = "
            SELECT * FROM users 
            $whereClause 
            ORDER BY created_at DESC 
            LIMIT $limit OFFSET $offset
        ";

        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function getUserById($id) {
        $stmt = $this->pdo->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    public function updateUser($id, $data) {
        $allowedFields = ['full_name', 'email', 'phone', 'status', 'role'];
        $updates = [];
        $params = [];

        foreach ($data as $field => $value) {
            if (in_array($field, $allowedFields)) {
                $updates[] = "$field = ?";
                $params[] = $value;
            }
        }

        if (empty($updates)) {
            return false;
        }

        $params[] = $id;
        $sql = "UPDATE users SET " . implode(', ', $updates) . " WHERE id = ?";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute($params);
    }

    public function deleteUser($id) {
        $stmt = $this->pdo->prepare("DELETE FROM users WHERE id = ?");
        return $stmt->execute([$id]);
    }

    public function getUsersByRole($role) {
        $stmt = $this->pdo->prepare("SELECT * FROM users WHERE role = ? AND status = 'active'");
        $stmt->execute([$role]);
        return $stmt->fetchAll();
    }

    // Add this method to get user application count
    public function getUserApplicationCount($userId) {
        try {
            $sql = "SELECT COUNT(*) as count FROM applications WHERE user_id = ?";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$userId]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return $result['count'] ?? 0;
        } catch (Exception $e) {
            error_log("Get user application count error: " . $e->getMessage());
            return 0;
        }
    }

    // Bulk update user status
    public function bulkUpdateStatus($userIds, $status) {
        try {
            $placeholders = str_repeat('?,', count($userIds) - 1) . '?';
            $sql = "UPDATE users SET status = ? WHERE id IN ($placeholders)";
            $stmt = $this->pdo->prepare($sql);
            $params = array_merge([$status], $userIds);
            return $stmt->execute($params);
        } catch (Exception $e) {
            error_log("Bulk update status error: " . $e->getMessage());
            return false;
        }
    }

    // Bulk soft delete users
    public function bulkDelete($userIds) {
        try {
            $placeholders = str_repeat('?,', count($userIds) - 1) . '?';
            $sql = "UPDATE users SET deleted = 1 WHERE id IN ($placeholders)";
            $stmt = $this->pdo->prepare($sql);
            return $stmt->execute($userIds);
        } catch (Exception $e) {
            error_log("Bulk delete error: " . $e->getMessage());
            return false;
        }
    }

    // Get user statistics
    public function getUserStats($userId) {
        try {
            $stats = [];
            
            // Get application count
            $stmt = $this->pdo->prepare("SELECT COUNT(*) as count FROM applications WHERE user_id = ?");
            $stmt->execute([$userId]);
            $stats['applications'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;
            
            // Get project count
            $stmt = $this->pdo->prepare("SELECT COUNT(*) as count FROM student_projects WHERE student_id = ?");
            $stmt->execute([$userId]);
            $stats['projects'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;
            
            // Get achievement count
            $stmt = $this->pdo->prepare("SELECT COUNT(*) as count FROM student_achievements WHERE student_id = ?");
            $stmt->execute([$userId]);
            $stats['achievements'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;
            
            return $stats;
        } catch (Exception $e) {
            error_log("Get user stats error: " . $e->getMessage());
            return ['applications' => 0, 'projects' => 0, 'achievements' => 0];
        }
    }

    // Search users
    public function searchUsers($query, $role = null) {
        try {
            $sql = "SELECT * FROM users WHERE (full_name LIKE ? OR email LIKE ? OR username LIKE ?)";
            $params = ["%$query%", "%$query%", "%$query%"];
            
            if ($role) {
                $sql .= " AND role = ?";
                $params[] = $role;
            }
            
            $sql .= " ORDER BY created_at DESC LIMIT 50";
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Search users error: " . $e->getMessage());
            return [];
        }
    }

    // Create new user
    public function createUser($userData) {
        try {
            $required = ['full_name', 'email', 'username', 'password', 'role'];
            foreach ($required as $field) {
                if (empty($userData[$field])) {
                    throw new Exception("Missing required field: $field");
                }
            }
            
            $sql = "INSERT INTO users (full_name, email, username, password, role, status, created_at) 
                    VALUES (?, ?, ?, ?, ?, 'active', NOW())";
            
            $stmt = $this->pdo->prepare($sql);
            $hashedPassword = password_hash($userData['password'], PASSWORD_DEFAULT);
            
            return $stmt->execute([
                $userData['full_name'],
                $userData['email'],
                $userData['username'],
                $hashedPassword,
                $userData['role']
            ]);
        } catch (Exception $e) {
            error_log("Create user error: " . $e->getMessage());
            return false;
        }
    }

    // Update user profile
    public function updateUserProfile($userId, $profileData) {
        try {
            $allowedFields = ['full_name', 'email', 'phone', 'bio', 'profile_picture'];
            $updates = [];
            $params = [];

            foreach ($profileData as $field => $value) {
                if (in_array($field, $allowedFields)) {
                    $updates[] = "$field = ?";
                    $params[] = $value;
                }
            }

            if (empty($updates)) {
                return false;
            }

            $params[] = $userId;
            $sql = "UPDATE users SET " . implode(', ', $updates) . " WHERE id = ?";
            $stmt = $this->pdo->prepare($sql);
            return $stmt->execute($params);
        } catch (Exception $e) {
            error_log("Update user profile error: " . $e->getMessage());
            return false;
        }
    }

    // Change user password
    public function changePassword($userId, $newPassword) {
        try {
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            $sql = "UPDATE users SET password = ? WHERE id = ?";
            $stmt = $this->pdo->prepare($sql);
            return $stmt->execute([$hashedPassword, $userId]);
        } catch (Exception $e) {
            error_log("Change password error: " . $e->getMessage());
            return false;
        }
    }

    // Verify user email
    public function verifyEmail($userId) {
        try {
            $sql = "UPDATE users SET email_verified = 1, verified_at = NOW() WHERE id = ?";
            $stmt = $this->pdo->prepare($sql);
            return $stmt->execute([$userId]);
        } catch (Exception $e) {
            error_log("Verify email error: " . $e->getMessage());
            return false;
        }
    }

    // Get users with pagination
    public function getUsersWithPagination($filters = [], $page = 1, $perPage = 20) {
        $offset = ($page - 1) * $perPage;
        $users = $this->getUsers($filters, $perPage, $offset);
        
        // Get total count for pagination
        $where = [];
        $params = [];

        if (!empty($filters['role']) && $filters['role'] !== 'all') {
            $where[] = 'role = ?';
            $params[] = $filters['role'];
        }

        if (!empty($filters['status']) && $filters['status'] !== 'all') {
            $where[] = 'status = ?';
            $params[] = $filters['status'];
        }

        $whereClause = $where ? 'WHERE ' . implode(' AND ', $where) : '';
        $countSql = "SELECT COUNT(*) as total FROM users $whereClause";
        
        $stmt = $this->pdo->prepare($countSql);
        $stmt->execute($params);
        $total = $stmt->fetch(PDO::FETCH_ASSOC)['total'] ?? 0;
        
        return [
            'users' => $users,
            'total' => $total,
            'page' => $page,
            'per_page' => $perPage,
            'total_pages' => ceil($total / $perPage)
        ];
    }

    // Get recent users
    public function getRecentUsers($limit = 10) {
        try {
            $sql = "SELECT * FROM users ORDER BY created_at DESC LIMIT ?";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$limit]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Get recent users error: " . $e->getMessage());
            return [];
        }
    }

    // Check if username exists
    public function usernameExists($username, $excludeUserId = null) {
        try {
            $sql = "SELECT COUNT(*) as count FROM users WHERE username = ?";
            $params = [$username];
            
            if ($excludeUserId) {
                $sql .= " AND id != ?";
                $params[] = $excludeUserId;
            }
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return $result['count'] > 0;
        } catch (Exception $e) {
            error_log("Username exists check error: " . $e->getMessage());
            return false;
        }
    }

    // Check if email exists
    public function emailExists($email, $excludeUserId = null) {
        try {
            $sql = "SELECT COUNT(*) as count FROM users WHERE email = ?";
            $params = [$email];
            
            if ($excludeUserId) {
                $sql .= " AND id != ?";
                $params[] = $excludeUserId;
            }
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return $result['count'] > 0;
        } catch (Exception $e) {
            error_log("Email exists check error: " . $e->getMessage());
            return false;
        }
    }
}
?>