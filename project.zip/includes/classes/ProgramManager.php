<?php

class ProgramManager {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    /**
     * Get all active programs
     */
    public function getActivePrograms() {
        try {
            $sql = "SELECT * FROM programs WHERE status = 'active' ORDER BY created_at DESC";
            $stmt = $this->pdo->query($sql);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error getting active programs: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Get all programs with filtering (admin use)
     */
    public function getAllPrograms($filters = []) {
        try {
            $sql = "SELECT * FROM programs WHERE 1=1";
            $params = [];

            if (!empty($filters['status']) && $filters['status'] !== 'all') {
                $sql .= " AND status = ?";
                $params[] = $filters['status'];
            }

            if (!empty($filters['type']) && $filters['type'] !== 'all') {
                $sql .= " AND type = ?";
                $params[] = $filters['type'];
            }

            $sql .= " ORDER BY created_at DESC";

            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error getting all programs: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Get program by ID
     */
    public function getProgramById($id) {
        try {
            $sql = "SELECT * FROM programs WHERE id = ?";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$id]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error getting program by ID: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Get program by slug
     */
    public function getProgramBySlug($slug) {
        try {
            $sql = "SELECT * FROM programs WHERE slug = ? AND status = 'active'";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$slug]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error getting program by slug: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Get programs by type
     */
    public function getProgramsByType($type) {
        try {
            $sql = "SELECT * FROM programs WHERE type = ? AND status = 'active' ORDER BY created_at DESC";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$type]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error getting programs by type: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Get featured programs
     */
    public function getFeaturedPrograms($limit = 3) {
        try {
            $sql = "SELECT * FROM programs WHERE status = 'active' ORDER BY created_at DESC LIMIT ?";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$limit]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error getting featured programs: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Get upcoming programs (deadline approaching)
     */
    public function getUpcomingPrograms($limit = 5) {
        try {
            $sql = "SELECT * FROM programs 
                    WHERE status = 'active' 
                    AND application_deadline IS NOT NULL 
                    AND application_deadline > CURDATE() 
                    ORDER BY application_deadline ASC 
                    LIMIT ?";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$limit]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error getting upcoming programs: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Check if program is accepting applications
     * FIXED: Uses program_type from applications table instead of program_id
     */
    public function isProgramAcceptingApplications($programType) {
        try {
            $sql = "SELECT application_deadline, max_applicants FROM programs WHERE type = ? AND status = 'active'";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$programType]);
            $program = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$program) {
                return false;
            }

            // Check application deadline
            if ($program['application_deadline'] && strtotime($program['application_deadline']) < time()) {
                return false;
            }

            // Check max applicants
            if ($program['max_applicants']) {
                $countSql = "SELECT COUNT(*) FROM applications WHERE program_type = ? AND status IN ('submitted', 'under_review', 'approved')";
                $countStmt = $this->pdo->prepare($countSql);
                $countStmt->execute([$programType]);
                $applicantCount = $countStmt->fetchColumn();
                
                if ($applicantCount >= $program['max_applicants']) {
                    return false;
                }
            }

            return true;
        } catch (Exception $e) {
            error_log("Error checking program application status: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Get program statistics
     * FIXED: Uses program_type instead of program_id
     */
    public function getProgramStats($programType) {
        try {
            $stats = [
                'total_applications' => 0,
                'submitted_applications' => 0,
                'under_review_applications' => 0,
                'approved_applications' => 0,
                'rejected_applications' => 0,
                'waitlisted_applications' => 0
            ];

            // Total applications
            $sql = "SELECT COUNT(*) as total_applications FROM applications WHERE program_type = ?";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$programType]);
            $stats['total_applications'] = $stmt->fetchColumn();

            // Applications by status
            $sql = "SELECT status, COUNT(*) as count FROM applications WHERE program_type = ? GROUP BY status";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$programType]);
            $statusCounts = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            foreach ($statusCounts as $status) {
                $stats[$status['status'] . '_applications'] = $status['count'];
            }

            return $stats;
        } catch (Exception $e) {
            error_log("Error getting program stats: " . $e->getMessage());
            return [
                'total_applications' => 0,
                'submitted_applications' => 0,
                'under_review_applications' => 0,
                'approved_applications' => 0,
                'rejected_applications' => 0,
                'waitlisted_applications' => 0
            ];
        }
    }

    /**
     * Get all program statistics
     */
    public function getAllProgramsStats() {
        try {
            $sql = "SELECT 
                    type as program_type,
                    COUNT(*) as total_applications,
                    SUM(CASE WHEN status = 'submitted' THEN 1 ELSE 0 END) as submitted_applications,
                    SUM(CASE WHEN status = 'under_review' THEN 1 ELSE 0 END) as under_review_applications,
                    SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved_applications,
                    SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected_applications,
                    SUM(CASE WHEN status = 'waitlisted' THEN 1 ELSE 0 END) as waitlisted_applications
                    FROM applications 
                    GROUP BY type";
            
            $stmt = $this->pdo->query($sql);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error getting all program stats: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Create new program (admin only)
     */
    public function createProgram($data) {
        try {
            // Generate slug if not provided
            if (empty($data['slug'])) {
                $data['slug'] = $this->generateSlug($data['name']);
            }

            // Ensure slug is unique
            $originalSlug = $data['slug'];
            $counter = 1;
            while ($this->slugExists($data['slug'])) {
                $data['slug'] = $originalSlug . '-' . $counter;
                $counter++;
            }

            $sql = "INSERT INTO programs (name, slug, type, description, eligibility_criteria, benefits, status, max_applicants, application_deadline, featured_image) 
                    VALUES (:name, :slug, :type, :description, :eligibility_criteria, :benefits, :status, :max_applicants, :application_deadline, :featured_image)";
            
            $stmt = $this->pdo->prepare($sql);
            return $stmt->execute($data);
        } catch (Exception $e) {
            error_log("Error creating program: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Update program (admin only)
     */
    public function updateProgram($id, $data) {
        try {
            // Handle slug uniqueness
            if (isset($data['slug']) && $this->slugExists($data['slug'], $id)) {
                $originalSlug = $data['slug'];
                $counter = 1;
                while ($this->slugExists($data['slug'], $id)) {
                    $data['slug'] = $originalSlug . '-' . $counter;
                    $counter++;
                }
            }

            $sql = "UPDATE programs SET 
                    name = :name, 
                    slug = :slug, 
                    type = :type, 
                    description = :description, 
                    eligibility_criteria = :eligibility_criteria, 
                    benefits = :benefits, 
                    status = :status, 
                    max_applicants = :max_applicants, 
                    application_deadline = :application_deadline, 
                    featured_image = :featured_image,
                    updated_at = NOW()
                    WHERE id = :id";
            
            $data['id'] = $id;
            $stmt = $this->pdo->prepare($sql);
            return $stmt->execute($data);
        } catch (Exception $e) {
            error_log("Error updating program: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Delete program (admin only)
     */
    public function deleteProgram($id) {
        try {
            // Soft delete by setting status to inactive
            $sql = "UPDATE programs SET status = 'inactive', updated_at = NOW() WHERE id = ?";
            $stmt = $this->pdo->prepare($sql);
            return $stmt->execute([$id]);
        } catch (Exception $e) {
            error_log("Error deleting program: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Generate slug from program name
     */
    public function generateSlug($name) {
        $slug = strtolower(trim($name));
        $slug = preg_replace('/[^a-z0-9-]/', '-', $slug);
        $slug = preg_replace('/-+/', '-', $slug);
        $slug = trim($slug, '-');
        return $slug;
    }

    /**
     * Check if slug already exists
     */
    public function slugExists($slug, $excludeId = null) {
        try {
            $sql = "SELECT COUNT(*) FROM programs WHERE slug = ?";
            $params = [$slug];
            
            if ($excludeId) {
                $sql .= " AND id != ?";
                $params[] = $excludeId;
            }
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchColumn() > 0;
        } catch (Exception $e) {
            error_log("Error checking slug existence: " . $e->getMessage());
            return true; // Assume exists to prevent conflicts
        }
    }

    /**
     * Get program types for dropdowns
     */
    public function getProgramTypes() {
        try {
            $sql = "SELECT DISTINCT type FROM programs WHERE status = 'active' ORDER BY type";
            $stmt = $this->pdo->query($sql);
            return $stmt->fetchAll(PDO::FETCH_COLUMN);
        } catch (Exception $e) {
            error_log("Error getting program types: " . $e->getMessage());
            return ['scholarship', 'housing', 'community', 'mentorship'];
        }
    }

    /**
     * Search programs
     */
    public function searchPrograms($query, $type = null) {
        try {
            $sql = "SELECT * FROM programs 
                    WHERE status = 'active' 
                    AND (name LIKE ? OR description LIKE ? OR benefits LIKE ?)";
            $params = ["%$query%", "%$query%", "%$query%"];

            if ($type) {
                $sql .= " AND type = ?";
                $params[] = $type;
            }

            $sql .= " ORDER BY created_at DESC";

            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error searching programs: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Get programs with application counts
     */
    public function getProgramsWithStats() {
        try {
            $sql = "SELECT p.*, 
                    COUNT(a.id) as total_applications,
                    SUM(CASE WHEN a.status = 'approved' THEN 1 ELSE 0 END) as approved_applications
                    FROM programs p
                    LEFT JOIN applications a ON p.type = a.program_type
                    WHERE p.status = 'active'
                    GROUP BY p.id
                    ORDER BY p.created_at DESC";
            
            $stmt = $this->pdo->query($sql);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error getting programs with stats: " . $e->getMessage());
            return [];
        }
    }
}
?>