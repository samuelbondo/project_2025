<?php
class DashboardManager {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    public function getDashboardStats() {
        return [
            'total_students' => $this->getTotalStudents(),
            'pending_applications' => $this->getPendingApplications(),
            'active_programs' => $this->getActivePrograms(),
            'total_donations' => $this->getTotalDonations(),
            'approval_rate' => $this->getApprovalRate()
        ];
    }
    
    private function getTotalStudents() {
        try {
            $stmt = $this->pdo->query("SELECT COUNT(*) as total FROM users WHERE role = 'student'");
            return $stmt->fetch()['total'] ?? 0;
        } catch (Exception $e) {
            return 0;
        }
    }
    
    private function getPendingApplications() {
        try {
            $stmt = $this->pdo->query("SELECT COUNT(*) as total FROM applications WHERE status = 'pending'");
            return $stmt->fetch()['total'] ?? 0;
        } catch (Exception $e) {
            return 0;
        }
    }
    
    private function getActivePrograms() {
        try {
            $stmt = $this->pdo->query("SELECT COUNT(*) as total FROM programs WHERE status = 'active'");
            return $stmt->fetch()['total'] ?? 0;
        } catch (Exception $e) {
            return 0;
        }
    }
    
    private function getTotalDonations() {
        try {
            $stmt = $this->pdo->query("SELECT SUM(amount) as total FROM donations WHERE status = 'completed'");
            return $stmt->fetch()['total'] ?? 0;
        } catch (Exception $e) {
            return 0;
        }
    }
    
    private function getApprovalRate() {
        try {
            $stmt = $this->pdo->query("
                SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved 
                FROM applications 
                WHERE status IN ('approved', 'rejected')
            ");
            $result = $stmt->fetch();
            if ($result['total'] > 0) {
                return round(($result['approved'] / $result['total']) * 100, 1);
            }
            return 0;
        } catch (Exception $e) {
            return 0;
        }
    }
    
    public function getRecentActivities($limit = 10) {
        try {
            $stmt = $this->pdo->prepare("
                SELECT a.*, u.username as user_name 
                FROM activity_log a 
                LEFT JOIN users u ON a.user_id = u.id 
                ORDER BY a.created_at DESC 
                LIMIT ?
            ");
            $stmt->execute([$limit]);
            return $stmt->fetchAll();
        } catch (Exception $e) {
            return [];
        }
    }
}
?>