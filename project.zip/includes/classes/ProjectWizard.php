<?php
class ProjectWizard {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    public function getProjectTemplates() {
        return [
            'academic_research' => [
                'name' => 'Academic Research',
                'description' => 'Structured research project with academic rigor',
                'type' => 'academic',
                'title' => 'Academic Research Project',
                'description' => 'A comprehensive research project following academic standards and methodologies.',
                'full_description' => '<p>This research project will follow established academic protocols and contribute to the existing body of knowledge in the field. The project will include literature review, methodology design, data collection, analysis, and presentation of findings.</p>',
                'skills' => 'research methodology, critical analysis, academic writing',
                'technologies' => 'reference managers, statistical software',
                'milestones' => [
                    ['title' => 'Literature Review', 'due_date' => date('Y-m-d', strtotime('+2 weeks'))],
                    ['title' => 'Methodology Design', 'due_date' => date('Y-m-d', strtotime('+4 weeks'))],
                    ['title' => 'Data Collection', 'due_date' => date('Y-m-d', strtotime('+8 weeks'))],
                    ['title' => 'Analysis & Writing', 'due_date' => date('Y-m-d', strtotime('+12 weeks'))]
                ]
            ],
            'community_service' => [
                'name' => 'Community Service',
                'description' => 'Project focused on community impact and engagement',
                'type' => 'community',
                'title' => 'Community Service Initiative',
                'description' => 'A project designed to address community needs and create positive social impact.',
                'full_description' => '<p>This community service project will engage local stakeholders and implement sustainable solutions to address identified needs. The initiative will focus on collaborative planning, community participation, and measurable impact assessment.</p>',
                'skills' => 'community engagement, communication, project management',
                'technologies' => 'communication tools, survey platforms',
                'milestones' => [
                    ['title' => 'Community Assessment', 'due_date' => date('Y-m-d', strtotime('+1 week'))],
                    ['title' => 'Project Planning', 'due_date' => date('Y-m-d', strtotime('+3 weeks'))],
                    ['title' => 'Implementation', 'due_date' => date('Y-m-d', strtotime('+8 weeks'))],
                    ['title' => 'Evaluation', 'due_date' => date('Y-m-d', strtotime('+10 weeks'))]
                ]
            ],
            'technical_project' => [
                'name' => 'Technical Project',
                'description' => 'Hands-on technical implementation project',
                'type' => 'technical',
                'title' => 'Technical Development Project',
                'description' => 'A practical project involving technical skills and implementation.',
                'full_description' => '<p>This technical project will involve the development and implementation of a practical solution using appropriate technologies and methodologies. The project will follow software development lifecycle principles.</p>',
                'skills' => 'programming, system design, testing',
                'technologies' => 'programming languages, development tools',
                'milestones' => [
                    ['title' => 'Requirements Analysis', 'due_date' => date('Y-m-d', strtotime('+1 week'))],
                    ['title' => 'System Design', 'due_date' => date('Y-m-d', strtotime('+3 weeks'))],
                    ['title' => 'Development', 'due_date' => date('Y-m-d', strtotime('+8 weeks'))],
                    ['title' => 'Testing & Deployment', 'due_date' => date('Y-m-d', strtotime('+10 weeks'))]
                ]
            ],
            'entrepreneurial_venture' => [
                'name' => 'Entrepreneurial Venture',
                'description' => 'Business-focused project with market potential',
                'type' => 'entrepreneurial',
                'title' => 'Entrepreneurial Project',
                'description' => 'A venture-focused project combining innovation and business strategy.',
                'full_description' => '<p>This entrepreneurial project will explore market opportunities and develop viable business solutions. The project will include market research, business model development, and implementation planning.</p>',
                'skills' => 'business planning, market analysis, financial modeling',
                'technologies' => 'business tools, analytics platforms',
                'milestones' => [
                    ['title' => 'Market Research', 'due_date' => date('Y-m-d', strtotime('+2 weeks'))],
                    ['title' => 'Business Model', 'due_date' => date('Y-m-d', strtotime('+4 weeks'))],
                    ['title' => 'Prototype Development', 'due_date' => date('Y-m-d', strtotime('+8 weeks'))],
                    ['title' => 'Validation & Planning', 'due_date' => date('Y-m-d', strtotime('+12 weeks'))]
                ]
            ]
        ];
    }
    
    public function createProject($projectData, $deliverables = [], $milestones = [], $resources = []) {
        try {
            $this->pdo->beginTransaction();
            
            // Insert main project
            $projectSql = "INSERT INTO student_projects 
                          (student_id, title, description, full_description, project_type, priority, 
                           start_date, end_date, skills_used, technologies, budget, target_audience, 
                           success_metrics, challenges, is_public, featured_image, status, created_at) 
                          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending_approval', NOW())";
            
            $projectStmt = $this->pdo->prepare($projectSql);
            $projectStmt->execute([
                $projectData['student_id'],
                $projectData['title'],
                $projectData['description'],
                $projectData['full_description'],
                $projectData['project_type'],
                $projectData['priority'],
                $projectData['start_date'],
                $projectData['end_date'],
                $projectData['skills_used'],
                $projectData['technologies'],
                $projectData['budget'],
                $projectData['target_audience'],
                $projectData['success_metrics'],
                $projectData['challenges'],
                $projectData['is_public'],
                $projectData['featured_image']
            ]);
            
            $projectId = $this->pdo->lastInsertId();
            
            // Insert deliverables
            foreach ($deliverables as $deliverable) {
                if (!empty(trim($deliverable))) {
                    $deliverableSql = "INSERT INTO project_deliverables (project_id, description, created_at) VALUES (?, ?, NOW())";
                    $deliverableStmt = $this->pdo->prepare($deliverableSql);
                    $deliverableStmt->execute([$projectId, trim($deliverable)]);
                }
            }
            
            // Insert milestones and tasks
            foreach ($milestones as $milestoneData) {
                $milestoneSql = "INSERT INTO project_milestones (project_id, title, description, due_date, created_at) 
                                VALUES (?, ?, ?, ?, NOW())";
                $milestoneStmt = $this->pdo->prepare($milestoneSql);
                $milestoneStmt->execute([
                    $projectId,
                    $milestoneData['title'],
                    $milestoneData['description'] ?? '',
                    $milestoneData['due_date']
                ]);
                
                $milestoneId = $this->pdo->lastInsertId();
                
                // Insert tasks for this milestone
                if (isset($milestoneData['tasks'])) {
                    foreach ($milestoneData['tasks'] as $taskData) {
                        if (!empty(trim($taskData['title']))) {
                            $taskSql = "INSERT INTO project_tasks (milestone_id, title, due_date, priority, created_at) 
                                       VALUES (?, ?, ?, ?, NOW())";
                            $taskStmt = $this->pdo->prepare($taskSql);
                            $taskStmt->execute([
                                $milestoneId,
                                trim($taskData['title']),
                                $taskData['due_date'] ?? null,
                                $taskData['priority'] ?? 'medium'
                            ]);
                        }
                    }
                }
            }
            
            // Insert resources
            foreach ($resources as $type => $typeResources) {
                foreach ($typeResources as $resource) {
                    if (!empty(trim($resource['title']))) {
                        $resourceSql = "INSERT INTO project_resources (project_id, resource_type, title, amount, created_at) 
                                       VALUES (?, ?, ?, ?, NOW())";
                        $resourceStmt = $this->pdo->prepare($resourceSql);
                        $resourceStmt->execute([
                            $projectId,
                            $type,
                            trim($resource['title']),
                            $resource['amount'] ?? 0
                        ]);
                    }
                }
            }
            
            $this->pdo->commit();
            return $projectId;
            
        } catch (Exception $e) {
            $this->pdo->rollBack();
            throw $e;
        }
    }
    
    public function getStudentProjects($studentId) {
        $sql = "SELECT * FROM student_projects WHERE student_id = ? ORDER BY created_at DESC";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$studentId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function validateProjectData($data) {
        $errors = [];
        
        // Required fields
        $required = ['title', 'description', 'project_type', 'start_date', 'end_date'];
        foreach ($required as $field) {
            if (empty(trim($data[$field] ?? ''))) {
                $errors[] = ucfirst(str_replace('_', ' ', $field)) . " is required";
            }
        }
        
        // Title length
        if (strlen(trim($data['title'] ?? '')) < 5) {
            $errors[] = "Title must be at least 5 characters long";
        }
        
        // Description length
        if (strlen(trim($data['description'] ?? '')) < 20) {
            $errors[] = "Description must be at least 20 characters long";
        }
        
        // Date validation
        if (!empty($data['start_date']) && !empty($data['end_date'])) {
            $start = strtotime($data['start_date']);
            $end = strtotime($data['end_date']);
            
            if ($end <= $start) {
                $errors[] = "End date must be after start date";
            }
            
            if ($start < strtotime('today')) {
                $errors[] = "Start date cannot be in the past";
            }
        }
        
        // Budget validation
        if (isset($data['budget']) && $data['budget'] < 0) {
            $errors[] = "Budget cannot be negative";
        }
        
        return $errors;
    }
}
?>