<?php
// AdminControl.php - Fixed version without session_start and proper includes

class AdminControl {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    public function getPendingApprovals() {
        try {
            $approvals = [
                'projects' => $this->getPendingProjects(),
                'stories' => $this->getPendingStories(),
                'achievements' => $this->getPendingAchievements(),
                'applications' => $this->getPendingApplications(),
                'comments' => $this->getPendingComments()
            ];
            return $approvals;
        } catch (Exception $e) {
            error_log("Pending approvals error: " . $e->getMessage());
            return [
                'projects' => [],
                'stories' => [],
                'achievements' => [],
                'applications' => [],
                'comments' => []
            ];
        }
    }
    
    private function getPendingProjects() {
        try {
            $sql = "SELECT p.*, u.full_name 
                    FROM student_projects p 
                    JOIN users u ON p.student_id = u.id 
                    WHERE p.approved = 0 
                    ORDER BY p.created_at DESC 
                    LIMIT 10";
            $stmt = $this->pdo->query($sql);
            return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        } catch (Exception $e) {
            return [];
        }
    }
    
    private function getPendingStories() {
        try {
            $sql = "SELECT s.*, u.full_name 
                    FROM stories s 
                    JOIN users u ON s.author_id = u.id 
                    WHERE s.status = 'draft' 
                    ORDER BY s.created_at DESC 
                    LIMIT 10";
            $stmt = $this->pdo->query($sql);
            return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        } catch (Exception $e) {
            return [];
        }
    }
    
    private function getPendingAchievements() {
        try {
            $sql = "SELECT a.*, u.full_name 
                    FROM student_achievements a 
                    JOIN users u ON a.student_id = u.id 
                    WHERE a.verified = 0 
                    ORDER BY a.created_at DESC 
                    LIMIT 10";
            $stmt = $this->pdo->query($sql);
            return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        } catch (Exception $e) {
            return [];
        }
    }
    
    private function getPendingApplications() {
        try {
            $sql = "SELECT a.*, u.full_name, u.email 
                    FROM applications a 
                    JOIN users u ON a.user_id = u.id 
                    WHERE a.status IN ('submitted', 'under_review') 
                    ORDER BY a.created_at DESC 
                    LIMIT 10";
            $stmt = $this->pdo->query($sql);
            return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        } catch (Exception $e) {
            return [];
        }
    }
    
    private function getPendingComments() {
        try {
            $sql = "SELECT c.*, u.full_name 
                    FROM comments c 
                    JOIN users u ON c.author_id = u.id 
                    WHERE c.status = 'pending' 
                    ORDER BY c.created_at DESC 
                    LIMIT 10";
            $stmt = $this->pdo->query($sql);
            return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        } catch (Exception $e) {
            return [];
        }
    }
    
    public function getSystemHealth() {
        return [
            'database' => $this->checkDatabaseHealth(),
            'storage' => $this->checkStorageHealth(),
            'performance' => $this->checkPerformance(),
            'security' => $this->checkSecurityStatus()
        ];
    }
    
    private function checkDatabaseHealth() {
        try {
            $stmt = $this->pdo->query("SHOW STATUS LIKE 'Threads_connected'");
            $connections = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $stmt = $this->pdo->query("SHOW TABLE STATUS");
            $tables = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            return [
                'status' => 'healthy',
                'connections' => $connections['Value'] ?? 0,
                'tables' => count($tables),
                'size' => array_sum(array_column($tables, 'Data_length'))
            ];
        } catch (Exception $e) {
            return ['status' => 'error', 'message' => $e->getMessage()];
        }
    }
    
    private function checkStorageHealth() {
        try {
            $path = __DIR__;
            
            if (!function_exists('disk_free_space') || !function_exists('disk_total_space')) {
                return [
                    'status' => 'info',
                    'message' => 'Storage monitoring not available',
                    'used_percent' => 0
                ];
            }
            
            $freeSpace = @disk_free_space($path);
            $totalSpace = @disk_total_space($path);
            
            if ($freeSpace === false || $totalSpace === false) {
                return [
                    'status' => 'info',
                    'message' => 'Storage information limited',
                    'used_percent' => 0
                ];
            }
            
            $usedSpace = $totalSpace - $freeSpace;
            $usedPercent = $totalSpace > 0 ? ($usedSpace / $totalSpace) * 100 : 0;
            
            if ($usedPercent > 90) {
                $status = 'critical';
                $message = 'Storage nearly full';
            } elseif ($usedPercent > 80) {
                $status = 'warning';
                $message = 'Storage getting full';
            } else {
                $status = 'healthy';
                $message = 'Storage OK';
            }
            
            return [
                'status' => $status,
                'message' => $message,
                'used_percent' => round($usedPercent, 2)
            ];
        } catch (Exception $e) {
            return [
                'status' => 'error',
                'message' => 'Unable to check storage: ' . $e->getMessage(),
                'used_percent' => 0
            ];
        }
    }
    
    private function checkPerformance() {
        try {
            if (!function_exists('sys_getloadavg')) {
                return [
                    'status' => 'info',
                    'message' => 'Performance metrics limited'
                ];
            }
            
            $load = sys_getloadavg();
            return [
                'status' => 'healthy',
                'message' => 'Performance OK',
                'load_average' => $load
            ];
        } catch (Exception $e) {
            return [
                'status' => 'error',
                'message' => 'Unable to check performance: ' . $e->getMessage()
            ];
        }
    }
    
    private function checkSecurityStatus() {
        try {
            $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || 
                       ($_SERVER['SERVER_PORT'] ?? null) == 443;
            
            $issues = [];
            if (!$isHttps) {
                $issues[] = 'Site not using HTTPS';
            }
            
            $status = empty($issues) ? 'secure' : 'warning';
            
            return [
                'status' => $status,
                'issues' => $issues,
                'https_enabled' => $isHttps,
                'message' => empty($issues) ? 'Security measures active' : 'Security issues detected'
            ];
        } catch (Exception $e) {
            return [
                'status' => 'error',
                'message' => 'Unable to check security: ' . $e->getMessage(),
                'issues' => [],
                'https_enabled' => false
            ];
        }
    }
}
?>