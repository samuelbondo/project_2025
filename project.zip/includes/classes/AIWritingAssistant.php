<?php
class AIWritingAssistant {
    private $pdo;
    private $openai_key;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
        $this->openai_key = 'your-openai-api-key'; // Should be in config
    }
    
    public function generateContent($prompt, $context = [], $tone = 'professional', $wordCount = 200) {
        try {
            // Prepare the enhanced prompt with context
            $enhancedPrompt = $this->buildEnhancedPrompt($prompt, $context, $tone, $wordCount);
            
            // Call OpenAI API
            $response = $this->callOpenAI($enhancedPrompt, $wordCount);
            
            // Log the AI session
            $sessionId = $this->logAISession($_SESSION['user_id'], $prompt, $response, $context, $tone, $wordCount);
            
            return [
                'success' => true,
                'content' => $response,
                'session_id' => $sessionId,
                'word_count' => str_word_count($response)
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage(),
                'content' => $this->getFallbackSuggestions($prompt, $tone)
            ];
        }
    }
    
    public function optimizeHeadline($headline, $storyContext = '') {
        $prompt = "As an expert copywriter, optimize this headline for engagement and SEO. Make it compelling while maintaining accuracy.\n\n";
        $prompt .= "Original Headline: {$headline}\n";
        $prompt .= "Story Context: {$storyContext}\n";
        $prompt .= "Provide 3 alternative headlines:\n1. ";
        
        $response = $this->callOpenAI($prompt, 100);
        return $this->parseHeadlineSuggestions($response);
    }
    
    public function improveIntroduction($introduction, $storyContext = '') {
        $prompt = "As a professional editor, improve this story introduction to make it more engaging and hook the reader immediately.\n\n";
        $prompt .= "Original Introduction: {$introduction}\n";
        $prompt .= "Story Context: {$storyContext}\n";
        $prompt .= "Provide an improved version that:\n- Grabs attention immediately\n- Sets the context clearly\n- Creates curiosity\n- Is concise and powerful\n\nImproved Introduction:";
        
        return $this->callOpenAI($prompt, 150);
    }
    
    public function generateConclusion($storyContent, $mainPoints = []) {
        $prompt = "Write a powerful conclusion for this story that:\n";
        $prompt .= "- Summarizes key points\n- Provides inspiration or call to action\n- Leaves a lasting impression\n- Connects back to the beginning\n\n";
        $prompt .= "Story Content: " . substr($storyContent, 0, 1000) . "\n\n";
        $prompt .= "Key Points: " . implode(', ', $mainPoints) . "\n\n";
        $prompt .= "Conclusion:";
        
        return $this->callOpenAI($prompt, 200);
    }
    
    public function analyzeReadability($content) {
        // Calculate readability scores
        $wordCount = str_word_count(strip_tags($content));
        $sentenceCount = preg_split('/[.!?]+/', strip_tags($content), -1, PREG_SPLIT_NO_EMPTY);
        $sentenceCount = count($sentenceCount);
        $paragraphCount = substr_count($content, '</p>') + 1;
        
        $avgSentenceLength = $sentenceCount > 0 ? $wordCount / $sentenceCount : 0;
        $avgParagraphLength = $paragraphCount > 0 ? $wordCount / $paragraphCount : 0;
        
        // Flesch Reading Ease approximation
        $fleschScore = $this->calculateFleschScore($content);
        
        return [
            'word_count' => $wordCount,
            'sentence_count' => $sentenceCount,
            'paragraph_count' => $paragraphCount,
            'avg_sentence_length' => round($avgSentenceLength, 1),
            'avg_paragraph_length' => round($avgParagraphLength, 1),
            'reading_time' => ceil($wordCount / 200), // 200 wpm reading speed
            'flesch_score' => $fleschScore,
            'readability_level' => $this->getReadabilityLevel($fleschScore)
        ];
    }
    
    public function suggestImprovements($content, $contentType = 'story') {
        $analysis = $this->analyzeReadability($content);
        $suggestions = [];
        
        // Sentence length suggestions
        if ($analysis['avg_sentence_length'] > 25) {
            $suggestions[] = [
                'type' => 'sentence_length',
                'message' => 'Some sentences are quite long. Consider breaking them up for better readability.',
                'priority' => 'medium'
            ];
        }
        
        if ($analysis['avg_sentence_length'] < 10) {
            $suggestions[] = [
                'type' => 'sentence_variety',
                'message' => 'Add some longer sentences to create better flow and variety.',
                'priority' => 'low'
            ];
        }
        
        // Paragraph length suggestions
        if ($analysis['avg_paragraph_length'] > 150) {
            $suggestions[] = [
                'type' => 'paragraph_length',
                'message' => 'Some paragraphs are quite long. Consider breaking them up for better scannability.',
                'priority' => 'medium'
            ];
        }
        
        // Readability suggestions
        if ($analysis['flesch_score'] < 60) {
            $suggestions[] = [
                'type' => 'readability',
                'message' => 'Content may be difficult for some readers. Consider simplifying complex sentences.',
                'priority' => 'high'
            ];
        }
        
        // Call AI for content-specific suggestions
        $aiSuggestions = $this->getAIContentSuggestions($content, $contentType);
        $suggestions = array_merge($suggestions, $aiSuggestions);
        
        return $suggestions;
    }
    
    private function buildEnhancedPrompt($prompt, $context, $tone, $wordCount) {
        $toneDescriptors = [
            'professional' => 'professional, authoritative, and informative',
            'casual' => 'conversational, friendly, and approachable',
            'inspirational' => 'inspiring, motivational, and uplifting',
            'academic' => 'scholarly, formal, and evidence-based',
            'storytelling' => 'narrative, engaging, and descriptive'
        ];
        
        $enhancedPrompt = "You are an expert writer creating content for REACH Organization, an educational NGO helping students in Rwanda. ";
        $enhancedPrompt .= "Write in a {$toneDescriptors[$tone]} tone. ";
        $enhancedPrompt .= "Target word count: {$wordCount} words.\n\n";
        
        if (!empty($context['story_type'])) {
            $enhancedPrompt .= "Story type: {$context['story_type']}\n";
        }
        
        if (!empty($context['target_audience'])) {
            $enhancedPrompt .= "Target audience: {$context['target_audience']}\n";
        }
        
        if (!empty($context['existing_content'])) {
            $enhancedPrompt .= "Existing content context: " . substr($context['existing_content'], 0, 500) . "\n";
        }
        
        $enhancedPrompt .= "\nWriting task: {$prompt}\n\nResponse:";
        
        return $enhancedPrompt;
    }
    
    private function callOpenAI($prompt, $maxTokens = 500) {
        // For now, return mock responses since we don't have actual API key
        // In production, this would make actual API calls to OpenAI
        
        $mockResponses = [
            "I understand you're looking for engaging content about educational journeys. Let me craft a compelling narrative that highlights the transformative power of education and the impact of REACH Organization's support on students' lives in Rwanda.",
            
            "Education is more than just learning—it's a journey of transformation. Through REACH Organization's dedicated support, students in Rwanda are discovering new possibilities and shaping brighter futures for themselves and their communities.",
            
            "The power of education to change lives cannot be overstated. At REACH Organization, we witness daily how access to quality education opens doors, builds confidence, and creates lasting positive change across Rwanda."
        ];
        
        return $mockResponses[array_rand($mockResponses)] . " " . $this->generateLoremIpsum($maxTokens - 50);
    }
    
    private function generateLoremIpsum($wordCount) {
        $lorem = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.";
        
        $words = explode(' ', $lorem);
        $result = [];
        
        for ($i = 0; $i < $wordCount; $i++) {
            $result[] = $words[$i % count($words)];
        }
        
        return implode(' ', $result);
    }
    
    private function calculateFleschScore($content) {
        // Simplified Flesch Reading Ease calculation
        $cleanContent = strip_tags($content);
        $words = str_word_count($cleanContent);
        $sentences = preg_split('/[.!?]+/', $cleanContent, -1, PREG_SPLIT_NO_EMPTY);
        $syllables = $this->countSyllables($cleanContent);
        
        if ($words > 0 && count($sentences) > 0) {
            $avgSentenceLength = $words / count($sentences);
            $avgSyllablesPerWord = $syllables / $words;
            
            return 206.835 - (1.015 * $avgSentenceLength) - (84.6 * $avgSyllablesPerWord);
        }
        
        return 0;
    }
    
    private function countSyllables($text) {
        // Simplified syllable counting
        $text = strtolower($text);
        $text = preg_replace('/[^a-z]/', ' ', $text);
        $words = explode(' ', $text);
        
        $syllableCount = 0;
        foreach ($words as $word) {
            if (strlen($word) > 0) {
                $syllableCount += max(1, ceil(strlen($word) / 3));
            }
        }
        
        return $syllableCount;
    }
    
    private function getReadabilityLevel($score) {
        if ($score >= 90) return 'Very Easy';
        if ($score >= 80) return 'Easy';
        if ($score >= 70) return 'Fairly Easy';
        if ($score >= 60) return 'Standard';
        if ($score >= 50) return 'Fairly Difficult';
        if ($score >= 30) return 'Difficult';
        return 'Very Difficult';
    }
    
    private function logAISession($userId, $prompt, $response, $context, $tone, $wordCount) {
        $stmt = $this->pdo->prepare("
            INSERT INTO ai_writing_sessions (user_id, prompt, generated_content, context_data, tone, word_count)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $userId,
            $prompt,
            $response,
            json_encode($context),
            $tone,
            $wordCount
        ]);
        
        return $this->pdo->lastInsertId();
    }
    
    private function getFallbackSuggestions($prompt, $tone) {
        // Provide fallback content when AI is unavailable
        $fallbacks = [
            "Consider starting with a personal anecdote that relates to your educational journey.",
            "Highlight the specific challenges you faced and how REACH Organization helped you overcome them.",
            "Share concrete outcomes and achievements that demonstrate the impact of your education.",
            "Connect your personal story to the broader mission of educational empowerment in Rwanda.",
            "Include specific details that make your story unique and memorable to readers."
        ];
        
        return "AI Writing Tips:\n\n" . implode("\n\n", $fallbacks);
    }
}
?>