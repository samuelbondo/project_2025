<?php
class DonationManager {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    public function getDonations($filters = [], $limit = 20, $offset = 0) {
        $where = [];
        $params = [];

        if (!empty($filters['payment_status']) && $filters['payment_status'] !== 'all') {
            $where[] = 'payment_status = ?';
            $params[] = $filters['payment_status'];
        }

        if (!empty($filters['donation_type']) && $filters['donation_type'] !== 'all') {
            $where[] = 'donation_type = ?';
            $params[] = $filters['donation_type'];
        }

        $whereClause = $where ? 'WHERE ' . implode(' AND ', $where) : '';

        $sql = "
            SELECT * FROM donations 
            $whereClause 
            ORDER BY created_at DESC 
            LIMIT $limit OFFSET $offset
        ";

        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function getDonationStatistics() {
        $sql = "
            SELECT 
                COUNT(*) as total_donations,
                SUM(amount) as total_amount,
                AVG(amount) as average_amount,
                SUM(CASE WHEN payment_status = 'completed' THEN amount ELSE 0 END) as completed_amount,
                SUM(CASE WHEN donation_type = 'one_time' THEN amount ELSE 0 END) as one_time_amount,
                SUM(CASE WHEN donation_type = 'monthly' THEN amount ELSE 0 END) as monthly_amount
            FROM donations
            WHERE payment_status = 'completed'
        ";

        $stmt = $this->pdo->query($sql);
        return $stmt->fetch();
    }

    public function createDonation($donationData) {
        $sql = "
            INSERT INTO donations (donor_name, donor_email, donor_phone, amount, currency, 
                                 payment_method, donation_type, is_anonymous)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ";

        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([
            $donationData['donor_name'],
            $donationData['donor_email'],
            $donationData['donor_phone'] ?? null,
            $donationData['amount'],
            $donationData['currency'] ?? 'USD',
            $donationData['payment_method'] ?? 'credit_card',
            $donationData['donation_type'] ?? 'one_time',
            $donationData['is_anonymous'] ?? 0
        ]);
    }

    public function updatePaymentStatus($donationId, $status, $paymentId = null) {
        $sql = "UPDATE donations SET payment_status = ?, payment_id = ? WHERE id = ?";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([$status, $paymentId, $donationId]);
    }
}
?>