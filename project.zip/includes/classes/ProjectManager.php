<?php
class ProjectManager {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    public function createProject($data, $studentId) {
        try {
            $this->pdo->beginTransaction();
            
            $slug = $this->generateSlug($data['title']);
            $featuredImage = $this->handleImageUpload($_FILES['featured_image'] ?? null, 'projects');
            
            // Handle gallery uploads
            $galleryData = [];
            if (!empty($_FILES['gallery'])) {
                $galleryData = $this->handleGalleryUpload($_FILES['gallery'], 'projects/gallery');
            }
            
            $stmt = $this->pdo->prepare("
                INSERT INTO projects (
                    title, slug, description, full_description, featured_image, gallery,
                    project_type, status, start_date, end_date, budget, student_id,
                    supervisor_id, tags, deliverables, featured, view_count
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            // Prepare data for insertion
            $tags = !empty($data['tags']) ? (is_array($data['tags']) ? json_encode($data['tags']) : $data['tags']) : null;
            $deliverables = !empty($data['deliverables']) ? (is_array($data['deliverables']) ? json_encode($data['deliverables']) : $data['deliverables']) : null;
            $gallery = !empty($galleryData) ? json_encode($galleryData) : null;
            
            $stmt->execute([
                $data['title'],
                $slug,
                $data['description'] ?? '',
                $data['full_description'] ?? '',
                $featuredImage,
                $gallery,
                $data['project_type'] ?? 'academic',
                $data['status'] ?? 'planning',
                $data['start_date'] ?? null,
                $data['end_date'] ?? null,
                $data['budget'] ?? 0,
                $studentId,
                $data['supervisor_id'] ?? null,
                $tags,
                $deliverables,
                $data['featured'] ?? 0,
                0 // Initial view count
            ]);
            
            $projectId = $this->pdo->lastInsertId();
            
            // Create initial deliverables if provided
            if (!empty($data['deliverables_list']) && is_array($data['deliverables_list'])) {
                $this->createInitialDeliverables($projectId, $data['deliverables_list']);
            }
            
            $this->pdo->commit();
            
            // Notify supervisors if assigned
            if (!empty($data['supervisor_id'])) {
                $this->notifySupervisor($projectId, $data['supervisor_id'], $studentId);
            }
            
            return $projectId;
            
        } catch (Exception $e) {
            $this->pdo->rollBack();
            throw new Exception("Project creation failed: " . $e->getMessage());
        }
    }
    
    public function getStudentProjects($studentId, $filters = [], $limit = 10, $offset = 0) {
        $sql = "SELECT p.*, 
                       u.full_name as supervisor_name,
                       (SELECT COUNT(*) FROM project_deliverables pd WHERE pd.project_id = p.id) as deliverable_count,
                       (SELECT COUNT(*) FROM project_deliverables pd WHERE pd.project_id = p.id AND pd.approved = 1) as approved_deliverables
                FROM projects p 
                LEFT JOIN users u ON p.supervisor_id = u.id
                WHERE p.student_id = ?";
        
        $params = [$studentId];
        
        // Add filters
        if (!empty($filters['status']) && $filters['status'] !== 'all') {
            $sql .= " AND p.status = ?";
            $params[] = $filters['status'];
        }
        
        if (!empty($filters['project_type']) && $filters['project_type'] !== 'all') {
            $sql .= " AND p.project_type = ?";
            $params[] = $filters['project_type'];
        }
        
        if (!empty($filters['search'])) {
            $sql .= " AND (p.title LIKE ? OR p.description LIKE ? OR p.tags LIKE ?)";
            $searchTerm = "%{$filters['search']}%";
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $params[] = $searchTerm;
        }
        
        $sql .= " ORDER BY p.created_at DESC LIMIT ? OFFSET ?";
        $params[] = $limit;
        $params[] = $offset;
        
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        $projects = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Decode JSON fields
        foreach ($projects as &$project) {
            $project['tags'] = !empty($project['tags']) ? json_decode($project['tags'], true) : [];
            $project['deliverables'] = !empty($project['deliverables']) ? json_decode($project['deliverables'], true) : [];
            $project['gallery'] = !empty($project['gallery']) ? json_decode($project['gallery'], true) : [];
        }
        
        return $projects;
    }
    
    public function getTotalProjects($filters = []) {
        $sql = "SELECT COUNT(*) FROM projects WHERE 1=1";
        $params = [];
        
        if (!empty($filters['student_id'])) {
            $sql .= " AND student_id = ?";
            $params[] = $filters['student_id'];
        }
        
        if (!empty($filters['status']) && $filters['status'] !== 'all') {
            $sql .= " AND status = ?";
            $params[] = $filters['status'];
        }
        
        if (!empty($filters['project_type']) && $filters['project_type'] !== 'all') {
            $sql .= " AND project_type = ?";
            $params[] = $filters['project_type'];
        }
        
        if (!empty($filters['search'])) {
            $sql .= " AND (title LIKE ? OR description LIKE ? OR tags LIKE ?)";
            $searchTerm = "%{$filters['search']}%";
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $params[] = $searchTerm;
        }
        
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        
        return $stmt->fetchColumn();
    }
    
    public function getStudentProjectStats($studentId) {
        $sql = "SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active,
                    SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
                    SUM(CASE WHEN status = 'planning' THEN 1 ELSE 0 END) as planning,
                    SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled,
                    SUM(CASE WHEN featured = 1 THEN 1 ELSE 0 END) as featured,
                    SUM(budget) as total_budget,
                    SUM(view_count) as total_views
                FROM projects 
                WHERE student_id = ?";
        
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$studentId]);
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    public function getProjectWithDetails($projectId) {
        $stmt = $this->pdo->prepare("
            SELECT p.*, 
                   u.full_name as student_name,
                   sup.full_name as supervisor_name,
                   (SELECT COUNT(*) FROM project_deliverables pd WHERE pd.project_id = p.id) as total_deliverables,
                   (SELECT COUNT(*) FROM project_deliverables pd WHERE pd.project_id = p.id AND pd.approved = 1) as approved_deliverables
            FROM projects p
            LEFT JOIN users u ON p.student_id = u.id
            LEFT JOIN users sup ON p.supervisor_id = sup.id
            WHERE p.id = ?
        ");
        $stmt->execute([$projectId]);
        $project = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($project) {
            // Decode JSON fields
            $project['tags'] = !empty($project['tags']) ? json_decode($project['tags'], true) : [];
            $project['deliverables'] = !empty($project['deliverables']) ? json_decode($project['deliverables'], true) : [];
            $project['gallery'] = !empty($project['gallery']) ? json_decode($project['gallery'], true) : [];
            
            // Get project deliverables
            $project['deliverables_list'] = $this->getProjectDeliverables($projectId);
        }
        
        return $project;
    }
    
    public function getProjectDeliverables($projectId) {
        $stmt = $this->pdo->prepare("
            SELECT pd.*, u.full_name as approved_by_name
            FROM project_deliverables pd
            LEFT JOIN users u ON pd.approved_by = u.id
            WHERE pd.project_id = ?
            ORDER BY pd.created_at DESC
        ");
        $stmt->execute([$projectId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function updateProject($projectId, $data) {
        $sql = "UPDATE projects SET ";
        $params = [];
        $updates = [];
        
        $allowedFields = ['title', 'description', 'full_description', 'project_type', 'status', 
                         'start_date', 'end_date', 'budget', 'supervisor_id', 'tags', 
                         'deliverables', 'featured'];
        
        foreach ($allowedFields as $field) {
            if (isset($data[$field])) {
                $updates[] = "$field = ?";
                
                if ($field === 'tags' || $field === 'deliverables') {
                    $params[] = is_array($data[$field]) ? json_encode($data[$field]) : $data[$field];
                } else {
                    $params[] = $data[$field];
                }
            }
        }
        
        // Handle featured image upload
        if (!empty($_FILES['featured_image']['name'])) {
            $featuredImage = $this->handleImageUpload($_FILES['featured_image'], 'projects');
            $updates[] = "featured_image = ?";
            $params[] = $featuredImage;
        }
        
        // Handle gallery uploads
        if (!empty($_FILES['gallery'])) {
            $galleryData = $this->handleGalleryUpload($_FILES['gallery'], 'projects/gallery');
            if (!empty($galleryData)) {
                // Get existing gallery and merge
                $existingGallery = $this->getProjectGallery($projectId);
                $mergedGallery = array_merge($existingGallery, $galleryData);
                $updates[] = "gallery = ?";
                $params[] = json_encode($mergedGallery);
            }
        }
        
        $updates[] = "updated_at = NOW()";
        $sql .= implode(', ', $updates) . " WHERE id = ?";
        $params[] = $projectId;
        
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute($params);
    }
    
    public function addProjectDeliverable($projectId, $deliverableData) {
        $stmt = $this->pdo->prepare("
            INSERT INTO project_deliverables (project_id, title, description, file_path, submitted_at)
            VALUES (?, ?, ?, ?, NOW())
        ");
        
        $filePath = null;
        if (!empty($_FILES['deliverable_file']['name'])) {
            $filePath = $this->handleFileUpload($_FILES['deliverable_file'], 'projects/deliverables');
        }
        
        return $stmt->execute([
            $projectId,
            $deliverableData['title'],
            $deliverableData['description'],
            $filePath
        ]);
    }
    
    public function approveDeliverable($deliverableId, $approvedBy) {
        $stmt = $this->pdo->prepare("
            UPDATE project_deliverables 
            SET approved = 1, approved_by = ?, approved_at = NOW() 
            WHERE id = ?
        ");
        return $stmt->execute([$approvedBy, $deliverableId]);
    }
    
    public function deleteProject($projectId, $studentId) {
        // Verify ownership
        $stmt = $this->pdo->prepare("SELECT student_id FROM projects WHERE id = ?");
        $stmt->execute([$projectId]);
        $project = $stmt->fetch();
        
        if (!$project || $project['student_id'] != $studentId) {
            throw new Exception("You don't have permission to delete this project");
        }
        
        $stmt = $this->pdo->prepare("DELETE FROM projects WHERE id = ?");
        return $stmt->execute([$projectId]);
    }
    
    public function incrementViewCount($projectId) {
        $stmt = $this->pdo->prepare("UPDATE projects SET view_count = view_count + 1 WHERE id = ?");
        return $stmt->execute([$projectId]);
    }
    
    public function getSupervisorProjects($supervisorId, $filters = []) {
        $sql = "SELECT p.*, u.full_name as student_name
                FROM projects p 
                JOIN users u ON p.student_id = u.id
                WHERE p.supervisor_id = ?";
        
        $params = [$supervisorId];
        
        if (!empty($filters['status']) && $filters['status'] !== 'all') {
            $sql .= " AND p.status = ?";
            $params[] = $filters['status'];
        }
        
        $sql .= " ORDER BY p.created_at DESC";
        
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    private function createInitialDeliverables($projectId, $deliverables) {
        foreach ($deliverables as $deliverable) {
            $stmt = $this->pdo->prepare("
                INSERT INTO project_deliverables (project_id, title, description, due_date)
                VALUES (?, ?, ?, ?)
            ");
            $stmt->execute([
                $projectId,
                $deliverable['title'],
                $deliverable['description'],
                $deliverable['due_date'] ?? null
            ]);
        }
    }
    
    private function getProjectGallery($projectId) {
        $stmt = $this->pdo->prepare("SELECT gallery FROM projects WHERE id = ?");
        $stmt->execute([$projectId]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        return !empty($result['gallery']) ? json_decode($result['gallery'], true) : [];
    }
    
    private function notifySupervisor($projectId, $supervisorId, $studentId) {
        $stmt = $this->pdo->prepare("
            INSERT INTO notifications (user_id, title, message, type, related_entity, related_id)
            VALUES (?, 'New Project Assignment', 
                   'A student has assigned you as supervisor for a new project.', 
                   'project_assignment', 'project', ?)
        ");
        $stmt->execute([$supervisorId, $projectId]);
    }
    
    private function generateSlug($title) {
        $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $title)));
        
        $counter = 1;
        $originalSlug = $slug;
        while ($this->projectSlugExists($slug)) {
            $slug = $originalSlug . '-' . $counter;
            $counter++;
        }
        
        return $slug;
    }
    
    private function projectSlugExists($slug) {
        $stmt = $this->pdo->prepare("SELECT id FROM projects WHERE slug = ?");
        $stmt->execute([$slug]);
        return $stmt->fetch() !== false;
    }
    
    private function handleImageUpload($file, $type) {
        if (empty($file) || empty($file['name'])) {
            return null;
        }
        
        $uploadDir = "../../uploads/{$type}/";
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        
        $fileName = time() . '_' . uniqid() . '_' . preg_replace('/[^a-zA-Z0-9\._-]/', '', $file['name']);
        $filePath = $uploadDir . $fileName;
        
        if (move_uploaded_file($file['tmp_name'], $filePath)) {
            return $fileName;
        }
        
        throw new Exception("Failed to upload image");
    }
    
    private function handleGalleryUpload($files, $type) {
        $uploadedFiles = [];
        
        if (!empty($files['name'][0])) {
            $uploadDir = "../../uploads/{$type}/";
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }
            
            foreach ($files['name'] as $key => $name) {
                if ($files['error'][$key] === UPLOAD_ERR_OK) {
                    $fileName = time() . '_' . uniqid() . '_' . preg_replace('/[^a-zA-Z0-9\._-]/', '', $name);
                    $filePath = $uploadDir . $fileName;
                    
                    if (move_uploaded_file($files['tmp_name'][$key], $filePath)) {
                        $uploadedFiles[] = $fileName;
                    }
                }
            }
        }
        
        return $uploadedFiles;
    }
    
    private function handleFileUpload($file, $type) {
        if (empty($file['name'])) {
            return null;
        }
        
        $uploadDir = "../../uploads/{$type}/";
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        
        $fileName = time() . '_' . uniqid() . '_' . preg_replace('/[^a-zA-Z0-9\._-]/', '', $file['name']);
        $filePath = $uploadDir . $fileName;
        
        if (move_uploaded_file($file['tmp_name'], $filePath)) {
            return $fileName;
        }
        
        throw new Exception("Failed to upload file");
    }
}
?>