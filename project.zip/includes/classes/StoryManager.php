<?php
class StoryManager {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    // Get stories with pagination and filters
    public function getStories($filters = [], $limit = 10, $offset = 0) {
        $whereClause = "WHERE 1=1";
        $params = [];
        
        if (!empty($filters['status']) && $filters['status'] !== 'all') {
            $whereClause .= " AND s.status = ?";
            $params[] = $filters['status'];
        }
        
        if (!empty($filters['story_type']) && $filters['story_type'] !== 'all') {
            $whereClause .= " AND s.story_type = ?";
            $params[] = $filters['story_type'];
        }
        
        if (!empty($filters['author_id'])) {
            $whereClause .= " AND s.author_id = ?";
            $params[] = $filters['author_id'];
        }
        
        if (!empty($filters['featured'])) {
            $whereClause .= " AND s.featured = 1";
        }
        
        if (!empty($filters['search'])) {
            $whereClause .= " AND (s.title LIKE ? OR s.content LIKE ? OR s.excerpt LIKE ? OR s.tags LIKE ?)";
            $searchTerm = "%{$filters['search']}%";
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $params[] = $searchTerm;
        }
        
        $sql = "SELECT s.*, u.full_name as author_name, u.email as author_email, u.profile_picture,
                       (SELECT COUNT(*) FROM comments c WHERE c.entity_id = s.id AND c.entity_type = 'story' AND c.status = 'approved') as comment_count,
                       (SELECT COUNT(*) FROM story_likes WHERE story_id = s.id) as like_count
                FROM stories s 
                LEFT JOIN users u ON s.author_id = u.id 
                {$whereClause} 
                ORDER BY s.created_at DESC 
                LIMIT ? OFFSET ?";
        
        $params[] = $limit;
        $params[] = $offset;
        
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }
    
    // Get total stories count for pagination
    public function getTotalStories($filters = []) {
        $whereClause = "WHERE 1=1";
        $params = [];
        
        if (!empty($filters['status']) && $filters['status'] !== 'all') {
            $whereClause .= " AND status = ?";
            $params[] = $filters['status'];
        }
        
        if (!empty($filters['story_type']) && $filters['story_type'] !== 'all') {
            $whereClause .= " AND story_type = ?";
            $params[] = $filters['story_type'];
        }
        
        if (!empty($filters['author_id'])) {
            $whereClause .= " AND author_id = ?";
            $params[] = $filters['author_id'];
        }
        
        if (!empty($filters['featured'])) {
            $whereClause .= " AND featured = 1";
        }
        
        if (!empty($filters['search'])) {
            $whereClause .= " AND (title LIKE ? OR content LIKE ? OR excerpt LIKE ? OR tags LIKE ?)";
            $searchTerm = "%{$filters['search']}%";
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $params[] = $searchTerm;
        }
        
        $sql = "SELECT COUNT(*) as total FROM stories {$whereClause}";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchColumn();
    }
    
    // Get story statistics
    public function getStoryStats() {
        $sql = "SELECT 
                COUNT(*) as total,
                SUM(status = 'published') as published,
                SUM(status = 'draft') as draft,
                SUM(status = 'pending') as pending,
                SUM(status = 'archived') as archived,
                SUM(featured = 1) as featured,
                SUM(story_type = 'student') as student_stories,
                SUM(story_type = 'project') as project_stories,
                SUM(story_type = 'achievement') as achievement_stories,
                SUM(story_type = 'community') as community_stories,
                SUM(story_type = 'news') as news_stories,
                COALESCE(SUM(view_count), 0) as total_views
                FROM stories";
        
        $stmt = $this->pdo->query($sql);
        return $stmt->fetch();
    }
    
    // Get student's stories
    public function getStudentStories($studentId, $filters = [], $limit = 10, $offset = 0) {
        $filters['author_id'] = $studentId;
        return $this->getStories($filters, $limit, $offset);
    }
    
    // Get student's story statistics
    public function getStudentStoryStats($studentId) {
        $sql = "SELECT 
                COUNT(*) as total,
                SUM(status = 'published') as published,
                SUM(status = 'draft') as draft,
                SUM(status = 'pending') as pending,
                SUM(status = 'rejected') as rejected,
                SUM(featured = 1) as featured,
                COALESCE(SUM(view_count), 0) as total_views,
                (SELECT COUNT(*) FROM comments c 
                 JOIN stories s ON c.entity_id = s.id 
                 WHERE s.author_id = ? AND c.entity_type = 'story' AND c.status = 'approved') as total_comments,
                (SELECT COUNT(*) FROM story_likes sl 
                 JOIN stories s ON sl.story_id = s.id 
                 WHERE s.author_id = ?) as total_likes
                FROM stories 
                WHERE author_id = ?";
        
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$studentId, $studentId, $studentId]);
        return $stmt->fetch();
    }
    
    // Get story by ID
    public function getStoryById($id) {
        $sql = "SELECT s.*, u.full_name as author_name, u.email as author_email, u.profile_picture, u.bio as author_bio
                FROM stories s 
                LEFT JOIN users u ON s.author_id = u.id 
                WHERE s.id = ?";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$id]);
        return $stmt->fetch();
    }
    
    // Get story by slug
    public function getStoryBySlug($slug) {
        $sql = "SELECT s.*, u.full_name as author_name, u.email as author_email, u.profile_picture, u.bio as author_bio
                FROM stories s 
                LEFT JOIN users u ON s.author_id = u.id 
                WHERE s.slug = ? AND s.status = 'published'";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$slug]);
        return $stmt->fetch();
    }
    
    // Create new story
    public function createStory($data) {
        $slug = $this->generateSlug($data['title']);
        
        $sql = "INSERT INTO stories (
            title, slug, excerpt, content, featured_image, gallery,
            author_id, story_type, featured, status, seo_title, 
            seo_description, tags, view_count, allow_comments
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([
            $data['title'],
            $slug,
            $data['excerpt'] ?? '',
            $data['content'] ?? '',
            $data['featured_image'] ?? 'default.jpg',
            $data['gallery'] ?? '',
            $data['author_id'],
            $data['story_type'],
            $data['featured'] ?? 0,
            $data['status'] ?? 'draft',
            $data['seo_title'] ?? '',
            $data['seo_description'] ?? '',
            $data['tags'] ?? '',
            $data['view_count'] ?? 0,
            $data['allow_comments'] ?? 1
        ]);
    }
    
    // Update story
    public function updateStory($id, $data) {
        $sql = "UPDATE stories SET 
                title = ?, excerpt = ?, content = ?, featured_image = ?, gallery = ?,
                story_type = ?, featured = ?, status = ?, seo_title = ?, 
                seo_description = ?, tags = ?, allow_comments = ?, updated_at = CURRENT_TIMESTAMP
                WHERE id = ?";
        
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([
            $data['title'],
            $data['excerpt'],
            $data['content'],
            $data['featured_image'],
            $data['gallery'],
            $data['story_type'],
            $data['featured'],
            $data['status'],
            $data['seo_title'],
            $data['seo_description'],
            $data['tags'],
            $data['allow_comments'] ?? 1,
            $id
        ]);
    }
    
    // Update student's story
    public function updateStudentStory($storyId, $studentId, $data) {
        $sql = "UPDATE stories SET 
                title = ?, excerpt = ?, content = ?, featured_image = ?, 
                story_type = ?, tags = ?, status = ?, updated_at = CURRENT_TIMESTAMP
                WHERE id = ? AND author_id = ?";
        
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([
            $data['title'],
            $data['excerpt'],
            $data['content'],
            $data['featured_image'],
            $data['story_type'],
            $data['tags'],
            $data['status'],
            $storyId,
            $studentId
        ]);
    }
    
    // Update story status
    public function updateStoryStatus($id, $status) {
        $sql = "UPDATE stories SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([$status, $id]);
    }
    
    // Toggle featured status
    public function toggleFeatured($id) {
        $sql = "UPDATE stories SET featured = NOT featured, updated_at = CURRENT_TIMESTAMP WHERE id = ?";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([$id]);
    }
    
    // Delete story
    public function deleteStory($id) {
        // First delete related comments
        $this->pdo->prepare("DELETE FROM comments WHERE entity_id = ? AND entity_type = 'story'")->execute([$id]);
        
        // Delete story likes
        $this->pdo->prepare("DELETE FROM story_likes WHERE story_id = ?")->execute([$id]);
        
        // Then delete the story
        $stmt = $this->pdo->prepare("DELETE FROM stories WHERE id = ?");
        return $stmt->execute([$id]);
    }
    
    // Delete student's story
    public function deleteStudentStory($storyId, $studentId) {
        // First delete related comments
        $this->pdo->prepare("DELETE FROM comments WHERE entity_id = ? AND entity_type = 'story'")->execute([$storyId]);
        
        // Delete story likes
        $this->pdo->prepare("DELETE FROM story_likes WHERE story_id = ?")->execute([$storyId]);
        
        // Then delete the story
        $stmt = $this->pdo->prepare("DELETE FROM stories WHERE id = ? AND author_id = ?");
        return $stmt->execute([$storyId, $studentId]);
    }
    
    // Increment view count
    public function incrementViewCount($id) {
        $sql = "UPDATE stories SET view_count = view_count + 1 WHERE id = ?";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([$id]);
    }
    
    // Check if story belongs to student
    public function isStoryOwner($storyId, $studentId) {
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM stories WHERE id = ? AND author_id = ?");
        $stmt->execute([$storyId, $studentId]);
        return $stmt->fetchColumn() > 0;
    }
    
    // Generate slug from title
    private function generateSlug($title) {
        $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $title)));
        
        // Check if slug exists
        $counter = 1;
        $originalSlug = $slug;
        while ($this->slugExists($slug)) {
            $slug = $originalSlug . '-' . $counter;
            $counter++;
        }
        
        return $slug;
    }
    
    private function slugExists($slug) {
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM stories WHERE slug = ?");
        $stmt->execute([$slug]);
        return $stmt->fetchColumn() > 0;
    }
    
    // Get recent stories
    public function getRecentStories($limit = 5) {
        $sql = "SELECT s.*, u.full_name as author_name, u.profile_picture
                FROM stories s 
                LEFT JOIN users u ON s.author_id = u.id 
                WHERE s.status = 'published' 
                ORDER BY s.created_at DESC 
                LIMIT ?";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$limit]);
        return $stmt->fetchAll();
    }
    
    // Get featured stories
    public function getFeaturedStories($limit = 3) {
        $sql = "SELECT s.*, u.full_name as author_name, u.profile_picture
                FROM stories s 
                LEFT JOIN users u ON s.author_id = u.id 
                WHERE s.status = 'published' AND s.featured = 1 
                ORDER BY s.created_at DESC 
                LIMIT ?";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$limit]);
        return $stmt->fetchAll();
    }
    
    // Get stories by type
    public function getStoriesByType($type, $limit = 10) {
        $sql = "SELECT s.*, u.full_name as author_name, u.profile_picture
                FROM stories s 
                LEFT JOIN users u ON s.author_id = u.id 
                WHERE s.status = 'published' AND s.story_type = ? 
                ORDER BY s.created_at DESC 
                LIMIT ?";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$type, $limit]);
        return $stmt->fetchAll();
    }
    
    // Get popular stories (most viewed)
    public function getPopularStories($limit = 5) {
        $sql = "SELECT s.*, u.full_name as author_name, u.profile_picture
                FROM stories s 
                LEFT JOIN users u ON s.author_id = u.id 
                WHERE s.status = 'published' 
                ORDER BY s.view_count DESC 
                LIMIT ?";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$limit]);
        return $stmt->fetchAll();
    }
    
    // Get related stories
    public function getRelatedStories($storyId, $limit = 3) {
        // First get the current story to find related content
        $currentStory = $this->getStoryById($storyId);
        if (!$currentStory) return [];
        
        $sql = "SELECT s.*, u.full_name as author_name, u.profile_picture
                FROM stories s 
                LEFT JOIN users u ON s.author_id = u.id 
                WHERE s.status = 'published' 
                AND s.id != ? 
                AND (s.story_type = ? OR s.tags LIKE ?)
                ORDER BY s.view_count DESC 
                LIMIT ?";
        
        $stmt = $this->pdo->prepare($sql);
        $tagTerm = "%{$currentStory['tags']}%";
        $stmt->execute([$storyId, $currentStory['story_type'], $tagTerm, $limit]);
        return $stmt->fetchAll();
    }
    
    // Search stories
    public function searchStories($query, $limit = 10) {
        $sql = "SELECT s.*, u.full_name as author_name, u.profile_picture,
                       MATCH(s.title, s.content, s.excerpt, s.tags) AGAINST(? IN NATURAL LANGUAGE MODE) as relevance
                FROM stories s 
                LEFT JOIN users u ON s.author_id = u.id 
                WHERE s.status = 'published' 
                AND (MATCH(s.title, s.content, s.excerpt, s.tags) AGAINST(? IN NATURAL LANGUAGE MODE)
                     OR s.title LIKE ? OR s.content LIKE ? OR s.tags LIKE ?)
                ORDER BY relevance DESC, s.created_at DESC 
                LIMIT ?";
        
        $searchTerm = "%{$query}%";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$query, $query, $searchTerm, $searchTerm, $searchTerm, $limit]);
        return $stmt->fetchAll();
    }
    
    // Get stories by tag
    public function getStoriesByTag($tag, $limit = 10) {
        $sql = "SELECT s.*, u.full_name as author_name, u.profile_picture
                FROM stories s 
                LEFT JOIN users u ON s.author_id = u.id 
                WHERE s.status = 'published' 
                AND s.tags LIKE ?
                ORDER BY s.created_at DESC 
                LIMIT ?";
        
        $stmt = $this->pdo->prepare($sql);
        $tagTerm = "%{$tag}%";
        $stmt->execute([$tagTerm, $limit]);
        return $stmt->fetchAll();
    }
    
    // Get all unique tags
    public function getAllTags() {
        $sql = "SELECT tags FROM stories WHERE status = 'published' AND tags IS NOT NULL AND tags != ''";
        $stmt = $this->pdo->query($sql);
        $allTags = [];
        
        while ($row = $stmt->fetch()) {
            $tags = explode(',', $row['tags']);
            foreach ($tags as $tag) {
                $tag = trim($tag);
                if (!empty($tag) && !in_array($tag, $allTags)) {
                    $allTags[] = $tag;
                }
            }
        }
        
        sort($allTags);
        return $allTags;
    }
    
    // Get monthly story count for analytics
    public function getMonthlyStoryCount($months = 12) {
        $sql = "SELECT 
                DATE_FORMAT(created_at, '%Y-%m') as month,
                COUNT(*) as count,
                SUM(status = 'published') as published,
                SUM(status = 'draft') as draft
                FROM stories 
                WHERE created_at >= DATE_SUB(NOW(), INTERVAL ? MONTH)
                GROUP BY DATE_FORMAT(created_at, '%Y-%m')
                ORDER BY month DESC 
                LIMIT ?";
        
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$months, $months]);
        return $stmt->fetchAll();
    }
    
    // Get author statistics
    public function getAuthorStats($authorId) {
        $sql = "SELECT 
                COUNT(*) as total_stories,
                SUM(status = 'published') as published_stories,
                SUM(status = 'draft') as draft_stories,
                SUM(featured = 1) as featured_stories,
                COALESCE(SUM(view_count), 0) as total_views,
                AVG(view_count) as avg_views,
                MAX(view_count) as max_views
                FROM stories 
                WHERE author_id = ?";
        
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$authorId]);
        return $stmt->fetch();
    }
    
    // Get stories needing review
    public function getStoriesNeedingReview($limit = 10) {
        $sql = "SELECT s.*, u.full_name as author_name, u.email as author_email
                FROM stories s 
                LEFT JOIN users u ON s.author_id = u.id 
                WHERE s.status = 'pending' 
                ORDER BY s.created_at ASC 
                LIMIT ?";
        
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$limit]);
        return $stmt->fetchAll();
    }
    
    // Bulk update stories status
    public function bulkUpdateStatus($storyIds, $status) {
        if (empty($storyIds)) return false;
        
        $placeholders = str_repeat('?,', count($storyIds) - 1) . '?';
        $sql = "UPDATE stories SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id IN ($placeholders)";
        
        $params = array_merge([$status], $storyIds);
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute($params);
    }
    
    // Bulk delete stories
    public function bulkDeleteStories($storyIds) {
        if (empty($storyIds)) return false;
        
        // Delete related comments
        $placeholders = str_repeat('?,', count($storyIds) - 1) . '?';
        $this->pdo->prepare("DELETE FROM comments WHERE entity_id IN ($placeholders) AND entity_type = 'story'")->execute($storyIds);
        
        // Delete story likes
        $this->pdo->prepare("DELETE FROM story_likes WHERE story_id IN ($placeholders)")->execute($storyIds);
        
        // Delete stories
        $sql = "DELETE FROM stories WHERE id IN ($placeholders)";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute($storyIds);
    }
    
    // Get story engagement metrics
    public function getStoryEngagement($storyId) {
        $sql = "SELECT 
                s.view_count,
                (SELECT COUNT(*) FROM comments c WHERE c.entity_id = s.id AND c.entity_type = 'story' AND c.status = 'approved') as comment_count,
                (SELECT COUNT(*) FROM story_likes WHERE story_id = s.id) as like_count,
                (SELECT COUNT(*) FROM story_shares WHERE story_id = s.id) as share_count
                FROM stories s 
                WHERE s.id = ?";
        
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$storyId]);
        return $stmt->fetch();
    }
    
    // Update story gallery
    public function updateStoryGallery($storyId, $galleryImages) {
        $galleryJson = !empty($galleryImages) ? json_encode($galleryImages) : '';
        $sql = "UPDATE stories SET gallery = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([$galleryJson, $storyId]);
    }
    
    // Get stories with low engagement (for content improvement suggestions)
    public function getLowEngagementStories($threshold = 10, $limit = 5) {
        $sql = "SELECT s.*, u.full_name as author_name
                FROM stories s 
                LEFT JOIN users u ON s.author_id = u.id 
                WHERE s.status = 'published' 
                AND s.view_count < ?
                ORDER BY s.view_count ASC 
                LIMIT ?";
        
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$threshold, $limit]);
        return $stmt->fetchAll();
    }
    
    // Get recent student stories for dashboard
    public function getRecentStudentStories($studentId, $limit = 5) {
        $sql = "SELECT id, title, status, created_at, view_count 
                FROM stories 
                WHERE author_id = ? 
                ORDER BY created_at DESC 
                LIMIT ?";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$studentId, $limit]);
        return $stmt->fetchAll();
    }
    
    // Check if user can edit story
    public function canEditStory($storyId, $userId, $userRole) {
        if (in_array($userRole, ['super_admin', 'admin', 'content_manager'])) {
            return true;
        }
        
        return $this->isStoryOwner($storyId, $userId);
    }
    
    // Get story count by status
    public function getStoryCountByStatus() {
        $sql = "SELECT 
                status,
                COUNT(*) as count
                FROM stories 
                GROUP BY status 
                ORDER BY count DESC";
        
        $stmt = $this->pdo->query($sql);
        return $stmt->fetchAll();
    }
    
    // Get top authors
    public function getTopAuthors($limit = 10) {
        $sql = "SELECT 
                u.id, u.full_name, u.profile_picture,
                COUNT(s.id) as story_count,
                SUM(s.view_count) as total_views,
                SUM(s.featured) as featured_count
                FROM users u 
                JOIN stories s ON u.id = s.author_id 
                WHERE s.status = 'published'
                GROUP BY u.id, u.full_name, u.profile_picture
                ORDER BY story_count DESC, total_views DESC 
                LIMIT ?";
        
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$limit]);
        return $stmt->fetchAll();
    }
}
?>