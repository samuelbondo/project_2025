<?php
class StudentPortal {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    public function getStudentDashboardData($studentId) {
        $data = [];
        
        // Basic student info
        $data['student'] = $this->getStudentInfo($studentId);
        
        // Academic progress
        $data['academic'] = $this->getAcademicProgress($studentId);
        
        // Recent projects
        $data['projects'] = $this->getRecentProjects($studentId, 3);
        
        // Recent stories
        $data['stories'] = $this->getRecentStories($studentId, 3);
        
        // Upcoming deadlines
        $data['deadlines'] = $this->getUpcomingDeadlines($studentId);
        
        // Notifications
        $data['notifications'] = $this->getRecentNotifications($studentId, 5);
        
        // Achievements
        $data['achievements'] = $this->getRecentAchievements($studentId, 5);
        
        // Progress stats
        $data['stats'] = $this->getStudentStats($studentId);
        
        return $data;
    }
    
    public function getStudentInfo($studentId) {
        $stmt = $this->pdo->prepare("
            SELECT u.*, sp.university, sp.course, sp.year_of_study, sp.expected_graduation,
                   sp.emergency_contact, sp.medical_info, sp.scholarship_type
            FROM users u 
            LEFT JOIN student_profiles sp ON u.id = sp.user_id 
            WHERE u.id = ?
        ");
        $stmt->execute([$studentId]);
        return $stmt->fetch();
    }
    
    public function getAcademicProgress($studentId) {
        $stmt = $this->pdo->prepare("
            SELECT * FROM student_academic_records 
            WHERE student_id = ? 
            ORDER BY academic_year DESC, semester DESC 
            LIMIT 4
        ");
        $stmt->execute([$studentId]);
        return $stmt->fetchAll();
    }
    
    public function getRecentProjects($studentId, $limit = 5) {
        $stmt = $this->pdo->prepare("
            SELECT * FROM student_projects 
            WHERE student_id = ? 
            ORDER BY created_at DESC 
            LIMIT ?
        ");
        $stmt->execute([$studentId, $limit]);
        return $stmt->fetchAll();
    }
    
    public function getRecentStories($studentId, $limit = 5) {
        $stmt = $this->pdo->prepare("
            SELECT * FROM stories 
            WHERE author_id = ? AND status = 'published'
            ORDER BY published_at DESC 
            LIMIT ?
        ");
        $stmt->execute([$studentId, $limit]);
        return $stmt->fetchAll();
    }
    
    public function getStudentStats($studentId) {
        $stats = [];
        
        // Project stats
        $stmt = $this->pdo->prepare("
            SELECT 
                COUNT(*) as total_projects,
                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_projects,
                SUM(CASE WHEN status = 'in_progress' THEN 1 ELSE 0 END) as active_projects
            FROM student_projects 
            WHERE student_id = ?
        ");
        $stmt->execute([$studentId]);
        $stats['projects'] = $stmt->fetch();
        
        // Story stats
        $stmt = $this->pdo->prepare("
            SELECT 
                COUNT(*) as total_stories,
                SUM(view_count) as total_views,
                SUM(like_count) as total_likes
            FROM stories 
            WHERE author_id = ? AND status = 'published'
        ");
        $stmt->execute([$studentId]);
        $stats['stories'] = $stmt->fetch();
        
        // Achievement stats
        $stmt = $this->pdo->prepare("
            SELECT 
                COUNT(*) as total_achievements,
                SUM(points_awarded) as total_points
            FROM student_achievements 
            WHERE student_id = ? AND verified = 1
        ");
        $stmt->execute([$studentId]);
        $stats['achievements'] = $stmt->fetch();
        
        return $stats;
    }
    
    public function createStudentStory($data, $studentId) {
        try {
            $this->pdo->beginTransaction();
            
            // Generate slug
            $slug = $this->generateSlug($data['title']);
            
            // Handle featured image
            $featuredImage = $this->handleImageUpload($_FILES['featured_image'], 'stories');
            
            $stmt = $this->pdo->prepare("
                INSERT INTO stories (title, slug, excerpt, content, featured_image, author_id, 
                                   story_type, status, tags, is_public)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            $stmt->execute([
                $data['title'],
                $slug,
                $data['excerpt'],
                $data['content'],
                $featuredImage,
                $studentId,
                $data['story_type'],
                'draft', // Students submit as draft for approval
                json_encode(explode(',', $data['tags'])),
                $data['is_public'] ?? false
            ]);
            
            $storyId = $this->pdo->lastInsertId();
            
            // Handle gallery images
            if (!empty($_FILES['gallery'])) {
                $this->handleGalleryUpload($_FILES['gallery'], $storyId, 'story');
            }
            
            $this->pdo->commit();
            
            // Notify admin for approval
            $this->notifyAdmins("New story submitted for approval: {$data['title']}", $studentId);
            
            return $storyId;
            
        } catch (Exception $e) {
            $this->pdo->rollBack();
            throw new Exception("Story creation failed: " . $e->getMessage());
        }
    }
    
    public function createStudentProject($data, $studentId) {
        try {
            $this->pdo->beginTransaction();
            
            $slug = $this->generateSlug($data['title']);
            $featuredImage = $this->handleImageUpload($_FILES['featured_image'], 'projects');
            
            $stmt = $this->pdo->prepare("
                INSERT INTO student_projects (title, slug, description, full_description, student_id,
                                           project_type, status, priority, start_date, end_date,
                                           budget, skills_used, technologies, featured_image,
                                           deliverables, is_public)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            $stmt->execute([
                $data['title'],
                $slug,
                $data['description'],
                $data['full_description'],
                $studentId,
                $data['project_type'],
                'planning',
                $data['priority'],
                $data['start_date'],
                $data['end_date'],
                $data['budget'] ?? 0,
                json_encode(explode(',', $data['skills_used'])),
                json_encode(explode(',', $data['technologies'])),
                $featuredImage,
                json_encode($data['deliverables'] ?? []),
                $data['is_public'] ?? false
            ]);
            
            $projectId = $this->pdo->lastInsertId();
            
            if (!empty($_FILES['gallery'])) {
                $this->handleGalleryUpload($_FILES['gallery'], $projectId, 'project');
            }
            
            $this->pdo->commit();
            
            return $projectId;
            
        } catch (Exception $e) {
            $this->pdo->rollBack();
            throw new Exception("Project creation failed: " . $e->getMessage());
        }
    }
    
    private function generateSlug($title) {
        $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $title)));
        
        $counter = 1;
        $originalSlug = $slug;
        while ($this->slugExists($slug)) {
            $slug = $originalSlug . '-' . $counter;
            $counter++;
        }
        
        return $slug;
    }
    
    private function slugExists($slug) {
        $stmt = $this->pdo->prepare("SELECT id FROM stories WHERE slug = ?");
        $stmt->execute([$slug]);
        return $stmt->fetch() !== false;
    }
    
    private function handleImageUpload($file, $type) {
        if (empty($file['name'])) {
            return 'default.jpg';
        }
        
        $uploadDir = "../assets/uploads/{$type}/";
        $fileName = time() . '_' . uniqid() . '_' . preg_replace('/[^a-zA-Z0-9\._-]/', '', $file['name']);
        $filePath = $uploadDir . $fileName;
        
        if (move_uploaded_file($file['tmp_name'], $filePath)) {
            $this->createImageThumbnails($filePath);
            return $fileName;
        }
        
        throw new Exception("Failed to upload image");
    }
    
    private function notifyAdmins($message, $studentId) {
        $stmt = $this->pdo->prepare("
            INSERT INTO notifications (user_id, title, message, type, related_entity, related_id)
            SELECT id, 'Story Submission', ?, 'story_submission', 'story', ?
            FROM users WHERE role IN ('super_admin', 'admin')
        ");
        $stmt->execute([$message, $studentId]);
    }
}
?>