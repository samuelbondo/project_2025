<?php

class ApplicationManager {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    /**
     * Get applications with filtering and pagination
     */
    public function getApplications($filters = [], $limit = 20, $offset = 0) {
        try {
            $sql = "
                SELECT 
                    a.*, 
                    u.full_name, 
                    u.email,
                    u.profile_picture,
                    r.full_name as reviewer_name,
                    p.name as program_name
                FROM applications a 
                LEFT JOIN users u ON a.user_id = u.id 
                LEFT JOIN users r ON a.reviewer_id = r.id
                LEFT JOIN programs p ON a.program_type = p.type
                WHERE 1=1
            ";
            
            $params = [];
            
            // Add filters
            if (!empty($filters['status']) && $filters['status'] !== 'all') {
                $sql .= " AND a.status = ?";
                $params[] = $filters['status'];
            }
            
            if (!empty($filters['program_type']) && $filters['program_type'] !== 'all') {
                $sql .= " AND a.program_type = ?";
                $params[] = $filters['program_type'];
            }
            
            if (!empty($filters['date_from'])) {
                $sql .= " AND DATE(a.submitted_at) >= ?";
                $params[] = $filters['date_from'];
            }
            
            if (!empty($filters['date_to'])) {
                $sql .= " AND DATE(a.submitted_at) <= ?";
                $params[] = $filters['date_to'];
            }
            
            if (!empty($filters['user_id'])) {
                $sql .= " AND a.user_id = ?";
                $params[] = $filters['user_id'];
            }
            
            if (!empty($filters['reviewer_id'])) {
                $sql .= " AND a.reviewer_id = ?";
                $params[] = $filters['reviewer_id'];
            }
            
            // Only show submitted applications by default (not drafts)
            if (empty($filters['status']) || $filters['status'] === 'all') {
                $sql .= " AND a.status != 'draft'";
            }
            
            // Add sorting
            $sql .= " ORDER BY COALESCE(a.submitted_at, a.created_at) DESC";
            
            // Add pagination
            if ($limit > 0) {
                $sql .= " LIMIT ? OFFSET ?";
                $params[] = $limit;
                $params[] = $offset;
            }
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
            
        } catch (Exception $e) {
            error_log("Error getting applications: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Search applications with text search
     */
    public function searchApplications($searchTerm, $filters = [], $limit = 20, $offset = 0) {
        try {
            $sql = "
                SELECT 
                    a.*, 
                    u.full_name, 
                    u.email,
                    p.name as program_name
                FROM applications a 
                LEFT JOIN users u ON a.user_id = u.id 
                LEFT JOIN programs p ON a.program_type = p.type
                WHERE 1=1
            ";
            
            $params = [];
            
            // Add search conditions
            if (!empty($searchTerm)) {
                $sql .= " AND (
                    u.full_name LIKE ? OR 
                    u.email LIKE ? OR 
                    a.application_code LIKE ? OR
                    a.institution_applying LIKE ? OR
                    a.intended_major LIKE ? OR
                    p.name LIKE ?
                )";
                $searchParam = "%" . $searchTerm . "%";
                $params = array_merge($params, 
                    array_fill(0, 6, $searchParam)
                );
            }
            
            // Add existing filters
            if (!empty($filters['status']) && $filters['status'] !== 'all') {
                $sql .= " AND a.status = ?";
                $params[] = $filters['status'];
            }
            
            if (!empty($filters['program_type']) && $filters['program_type'] !== 'all') {
                $sql .= " AND a.program_type = ?";
                $params[] = $filters['program_type'];
            }
            
            // Add sorting and pagination
            $sql .= " ORDER BY COALESCE(a.submitted_at, a.created_at) DESC";
            $sql .= " LIMIT ? OFFSET ?";
            $params[] = $limit;
            $params[] = $offset;
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
            
        } catch (Exception $e) {
            error_log("Error searching applications: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Get total number of applications with filters
     */
    public function getTotalApplications($filters = []) {
        try {
            $sql = "SELECT COUNT(*) as total FROM applications a WHERE 1=1";
            $params = [];
            
            // Add filters
            if (!empty($filters['status']) && $filters['status'] !== 'all') {
                $sql .= " AND a.status = ?";
                $params[] = $filters['status'];
            }
            
            if (!empty($filters['program_type']) && $filters['program_type'] !== 'all') {
                $sql .= " AND a.program_type = ?";
                $params[] = $filters['program_type'];
            }
            
            if (!empty($filters['date_from'])) {
                $sql .= " AND DATE(a.submitted_at) >= ?";
                $params[] = $filters['date_from'];
            }
            
            if (!empty($filters['date_to'])) {
                $sql .= " AND DATE(a.submitted_at) <= ?";
                $params[] = $filters['date_to'];
            }
            
            if (!empty($filters['user_id'])) {
                $sql .= " AND a.user_id = ?";
                $params[] = $filters['user_id'];
            }
            
            // Only count non-draft applications by default
            if (empty($filters['status']) || $filters['status'] === 'all') {
                $sql .= " AND a.status != 'draft'";
            }
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return $result['total'] ?? 0;
            
        } catch (Exception $e) {
            error_log("Error getting total applications: " . $e->getMessage());
            return 0;
        }
    }
    
    /**
     * Get application statistics
     */
    public function getApplicationStats() {
        try {
            $stmt = $this->pdo->prepare("
                SELECT 
                    status,
                    COUNT(*) as count
                FROM applications 
                WHERE status != 'draft'
                GROUP BY status
            ");
            $stmt->execute();
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Initialize stats with your actual database status values
            $stats = [
                'total' => 0,
                'draft' => 0,
                'submitted' => 0,
                'under_review' => 0,
                'approved' => 0,
                'rejected' => 0,
                'waitlisted' => 0
            ];
            
            foreach ($results as $row) {
                $status = $row['status'];
                $count = $row['count'];
                
                if (isset($stats[$status])) {
                    $stats[$status] = $count;
                }
                $stats['total'] += $count;
            }
            
            return $stats;
            
        } catch (Exception $e) {
            error_log("Error getting application stats: " . $e->getMessage());
            return [
                'total' => 0,
                'draft' => 0,
                'submitted' => 0,
                'under_review' => 0,
                'approved' => 0,
                'rejected' => 0,
                'waitlisted' => 0
            ];
        }
    }
    
    /**
     * Get application statistics by program type
     */
    public function getProgramStats() {
        try {
            $stmt = $this->pdo->prepare("
                SELECT 
                    p.type,
                    p.name,
                    COUNT(a.id) as total_applications,
                    SUM(CASE WHEN a.status = 'approved' THEN 1 ELSE 0 END) as approved,
                    SUM(CASE WHEN a.status = 'rejected' THEN 1 ELSE 0 END) as rejected,
                    SUM(CASE WHEN a.status = 'under_review' THEN 1 ELSE 0 END) as under_review
                FROM programs p
                LEFT JOIN applications a ON p.type = a.program_type AND a.status != 'draft'
                WHERE p.status = 'active'
                GROUP BY p.type, p.name
                ORDER BY total_applications DESC
            ");
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error getting program stats: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Get monthly application trends
     */
    public function getMonthlyTrends($year = null) {
        try {
            $year = $year ?: date('Y');
            $stmt = $this->pdo->prepare("
                SELECT 
                    MONTH(submitted_at) as month,
                    COUNT(*) as applications,
                    SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved
                FROM applications 
                WHERE YEAR(submitted_at) = ? AND status != 'draft'
                GROUP BY MONTH(submitted_at)
                ORDER BY month
            ");
            $stmt->execute([$year]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error getting monthly trends: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Get application by ID with proper error handling
     */
    public function getApplicationById($id) {
        try {
            $stmt = $this->pdo->prepare("
                SELECT 
                    a.*, 
                    u.full_name, 
                    u.email, 
                    u.phone, 
                    u.address,
                    u.date_of_birth,
                    u.gender,
                    u.profile_picture,
                    r.full_name as reviewer_name,
                    r.email as reviewer_email,
                    p.name as program_name,
                    p.description as program_description
                FROM applications a 
                LEFT JOIN users u ON a.user_id = u.id 
                LEFT JOIN users r ON a.reviewer_id = r.id
                LEFT JOIN programs p ON a.program_type = p.type
                WHERE a.id = ?
            ");
            $stmt->execute([$id]);
            $application = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$application) {
                throw new Exception("Application not found with ID: " . $id);
            }
            
            return $application;
        } catch (Exception $e) {
            error_log("Error getting application by ID: " . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * Create new application
     */
    public function createApplication($data) {
        try {
            // Validate application data
            $errors = $this->validateApplication($data);
            if (!empty($errors)) {
                throw new Exception("Validation failed: " . implode(', ', $errors));
            }
            
            // Generate application code
            $application_code = $this->generateApplicationCode($data['program_type']);
            
            $stmt = $this->pdo->prepare("
                INSERT INTO applications 
                (application_code, user_id, program_type, academic_level, institution_applying, 
                 intended_major, academic_history, family_income, financial_needs, 
                 personal_statement, reference_letters, documents, status) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            $result = $stmt->execute([
                $application_code,
                $data['user_id'],
                $data['program_type'],
                $data['academic_level'] ?? null,
                $data['institution_applying'] ?? null,
                $data['intended_major'] ?? null,
                $data['academic_history'] ?? null,
                $data['family_income'] ?? null,
                $data['financial_needs'] ?? null,
                $data['personal_statement'] ?? null,
                $data['reference_letters'] ?? null,
                $data['documents'] ?? null,
                $data['status'] ?? 'draft'
            ]);
            
            if ($result) {
                return $this->pdo->lastInsertId();
            }
            
            return false;
            
        } catch (Exception $e) {
            error_log("Error creating application: " . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * Submit application (update from draft to submitted)
     */
    public function submitApplication($application_id, $user_id) {
        try {
            // Check if user can edit this application
            if (!$this->canEditApplication($application_id, $user_id)) {
                throw new Exception("Application cannot be submitted or user doesn't have permission");
            }
            
            $stmt = $this->pdo->prepare("
                UPDATE applications 
                SET status = 'submitted', submitted_at = NOW() 
                WHERE id = ? AND user_id = ? AND status = 'draft'
            ");
            return $stmt->execute([$application_id, $user_id]);
        } catch (Exception $e) {
            error_log("Error submitting application: " . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * Update application status
     */
    public function updateApplicationStatus($id, $status, $reviewer_id = null, $notes = null) {
        try {
            $validStatuses = ['draft', 'submitted', 'under_review', 'approved', 'rejected', 'waitlisted'];
            if (!in_array($status, $validStatuses)) {
                throw new Exception("Invalid status: " . $status);
            }
            
            $sql = "UPDATE applications SET status = ?";
            $params = [$status];
            
            if ($notes !== null) {
                $sql .= ", review_notes = ?";
                $params[] = $notes;
            }
            
            if ($reviewer_id !== null) {
                $sql .= ", reviewer_id = ?";
                $params[] = $reviewer_id;
            }
            
            // Set reviewed_at if status is being changed to under_review, approved, rejected, or waitlisted
            if (in_array($status, ['under_review', 'approved', 'rejected', 'waitlisted'])) {
                $sql .= ", reviewed_at = NOW()";
            }
            
            $sql .= " WHERE id = ?";
            $params[] = $id;
            
            $stmt = $this->pdo->prepare($sql);
            return $stmt->execute($params);
        } catch (Exception $e) {
            error_log("Error updating application status: " . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * Bulk update application statuses
     */
    public function bulkUpdateStatus($applicationIds, $status, $reviewerId = null, $notes = null) {
        try {
            $this->pdo->beginTransaction();
            
            $validStatuses = ['draft', 'submitted', 'under_review', 'approved', 'rejected', 'waitlisted'];
            if (!in_array($status, $validStatuses)) {
                throw new Exception("Invalid status: " . $status);
            }
            
            $placeholders = str_repeat('?,', count($applicationIds) - 1) . '?';
            $sql = "UPDATE applications SET status = ?";
            $params = [$status];
            
            if ($reviewerId !== null) {
                $sql .= ", reviewer_id = ?";
                $params[] = $reviewerId;
            }
            
            if ($notes !== null) {
                $sql .= ", review_notes = ?";
                $params[] = $notes;
            }
            
            if (in_array($status, ['under_review', 'approved', 'rejected', 'waitlisted'])) {
                $sql .= ", reviewed_at = NOW()";
            }
            
            $sql .= " WHERE id IN ($placeholders)";
            $params = array_merge($params, $applicationIds);
            
            $stmt = $this->pdo->prepare($sql);
            $success = $stmt->execute($params);
            
            if ($success) {
                $this->pdo->commit();
                return true;
            } else {
                $this->pdo->rollBack();
                return false;
            }
            
        } catch (Exception $e) {
            $this->pdo->rollBack();
            error_log("Error in bulk update: " . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * Get application details from application_details table
     */
    public function getApplicationDetails($application_id) {
        try {
            $stmt = $this->pdo->prepare("
                SELECT * FROM application_details 
                WHERE application_id = ? 
                ORDER BY section, field_name
            ");
            $stmt->execute([$application_id]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error getting application details: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Save application details to application_details table
     */
    public function saveApplicationDetails($application_id, $section, $field_name, $field_value) {
        try {
            // Check if detail already exists
            $checkStmt = $this->pdo->prepare("
                SELECT id FROM application_details 
                WHERE application_id = ? AND section = ? AND field_name = ?
            ");
            $checkStmt->execute([$application_id, $section, $field_name]);
            
            if ($checkStmt->fetch()) {
                // Update existing
                $stmt = $this->pdo->prepare("
                    UPDATE application_details 
                    SET field_value = ? 
                    WHERE application_id = ? AND section = ? AND field_name = ?
                ");
                return $stmt->execute([$field_value, $application_id, $section, $field_name]);
            } else {
                // Insert new
                $stmt = $this->pdo->prepare("
                    INSERT INTO application_details (application_id, section, field_name, field_value) 
                    VALUES (?, ?, ?, ?)
                ");
                return $stmt->execute([$application_id, $section, $field_name, $field_value]);
            }
        } catch (Exception $e) {
            error_log("Error saving application details: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Add document to application
     */
    public function addApplicationDocument($applicationId, $documentType, $fileName, $filePath) {
        try {
            // Get current documents
            $app = $this->getApplicationById($applicationId);
            $documents = json_decode($app['documents'] ?? '[]', true) ?: [];
            
            // Add new document
            $documents[] = [
                'type' => $documentType,
                'name' => $fileName,
                'path' => $filePath,
                'uploaded_at' => date('Y-m-d H:i:s')
            ];
            
            // Update database
            $stmt = $this->pdo->prepare("
                UPDATE applications SET documents = ? WHERE id = ?
            ");
            return $stmt->execute([json_encode($documents), $applicationId]);
            
        } catch (Exception $e) {
            error_log("Error adding application document: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Remove document from application
     */
    public function removeApplicationDocument($applicationId, $documentIndex) {
        try {
            $app = $this->getApplicationById($applicationId);
            $documents = json_decode($app['documents'] ?? '[]', true) ?: [];
            
            if (isset($documents[$documentIndex])) {
                // Remove file from filesystem
                $document = $documents[$documentIndex];
                if (file_exists($document['path'])) {
                    unlink($document['path']);
                }
                
                // Remove from array
                array_splice($documents, $documentIndex, 1);
                
                // Update database
                $stmt = $this->pdo->prepare("
                    UPDATE applications SET documents = ? WHERE id = ?
                ");
                return $stmt->execute([json_encode($documents), $applicationId]);
            }
            
            return false;
            
        } catch (Exception $e) {
            error_log("Error removing application document: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Get active programs for dropdowns
     */
    public function getActivePrograms() {
        try {
            $stmt = $this->pdo->prepare("
                SELECT type, name FROM programs 
                WHERE status = 'active' 
                ORDER BY name
            ");
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error getting active programs: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Check if user can apply to program (no existing active application)
     */
    public function canUserApply($user_id, $program_type) {
        try {
            $stmt = $this->pdo->prepare("
                SELECT COUNT(*) 
                FROM applications 
                WHERE user_id = ? AND program_type = ? 
                AND status IN ('draft', 'submitted', 'under_review')
            ");
            $stmt->execute([$user_id, $program_type]);
            
            return $stmt->fetchColumn() == 0;
        } catch (Exception $e) {
            error_log("Error checking user application eligibility: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Get user's applications
     */
    public function getUserApplications($user_id, $include_drafts = false) {
        try {
            $sql = "
                SELECT a.*, p.name as program_name 
                FROM applications a 
                LEFT JOIN programs p ON a.program_type = p.type 
                WHERE a.user_id = ?
            ";
            
            if (!$include_drafts) {
                $sql .= " AND a.status != 'draft'";
            }
            
            $sql .= " ORDER BY a.created_at DESC";
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$user_id]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error getting user applications: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Validate application data before submission
     */
    public function validateApplication($data) {
        $errors = [];
        
        // Required fields
        $required = ['program_type', 'academic_level', 'institution_applying', 'intended_major'];
        foreach ($required as $field) {
            if (empty($data[$field])) {
                $errors[] = "Field '{$field}' is required";
            }
        }
        
        // Validate program type
        $validPrograms = array_column($this->getActivePrograms(), 'type');
        if (!empty($data['program_type']) && !in_array($data['program_type'], $validPrograms)) {
            $errors[] = "Invalid program type";
        }
        
        // Validate academic level
        $validLevels = ['high_school', 'undergraduate', 'masters', 'phd'];
        if (!empty($data['academic_level']) && !in_array($data['academic_level'], $validLevels)) {
            $errors[] = "Invalid academic level";
        }
        
        // Validate family income
        if (isset($data['family_income']) && $data['family_income'] < 0) {
            $errors[] = "Family income cannot be negative";
        }
        
        return $errors;
    }
    
    /**
     * Check if application can be edited
     */
    public function canEditApplication($applicationId, $userId) {
        try {
            $stmt = $this->pdo->prepare("
                SELECT status FROM applications 
                WHERE id = ? AND user_id = ?
            ");
            $stmt->execute([$applicationId, $userId]);
            $application = $stmt->fetch(PDO::FETCH_ASSOC);
            
            return $application && $application['status'] === 'draft';
        } catch (Exception $e) {
            error_log("Error checking edit permission: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Generate unique application code
     */
    private function generateApplicationCode($programType) {
        $prefix = strtoupper(substr($programType, 0, 3));
        $timestamp = time();
        $random = mt_rand(1000, 9999);
        
        return $prefix . '-' . $timestamp . '-' . $random;
    }
    
    /**
     * Create sample applications data
     */
    public function createSampleApplications() {
        try {
            // Check if applications already exist
            $checkStmt = $this->pdo->prepare("SELECT COUNT(*) FROM applications");
            $checkStmt->execute();
            if ($checkStmt->fetchColumn() > 0) {
                return true;
            }
            
            // Get a sample user
            $userStmt = $this->pdo->prepare("SELECT id FROM users WHERE role = 'student' LIMIT 1");
            $userStmt->execute();
            $user = $userStmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$user) {
                error_log("No student user found for sample data");
                return false;
            }
            
            $sampleApplications = [
                [
                    'application_code' => $this->generateApplicationCode('scholarship'),
                    'user_id' => $user['id'],
                    'program_type' => 'scholarship',
                    'academic_level' => 'undergraduate',
                    'institution_applying' => 'University of Example',
                    'intended_major' => 'Computer Science',
                    'family_income' => 45000.00,
                    'personal_statement' => 'I am passionate about computer science...',
                    'status' => 'submitted',
                    'submitted_at' => date('Y-m-d H:i:s', strtotime('-5 days'))
                ],
                [
                    'application_code' => $this->generateApplicationCode('housing'),
                    'user_id' => $user['id'],
                    'program_type' => 'housing',
                    'academic_level' => 'undergraduate',
                    'institution_applying' => 'City College',
                    'intended_major' => 'Business Administration',
                    'family_income' => 38000.00,
                    'personal_statement' => 'I need housing assistance...',
                    'status' => 'under_review',
                    'submitted_at' => date('Y-m-d H:i:s', strtotime('-3 days'))
                ]
            ];
            
            $insertStmt = $this->pdo->prepare("
                INSERT INTO applications 
                (application_code, user_id, program_type, academic_level, institution_applying, 
                 intended_major, family_income, personal_statement, status, submitted_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            foreach ($sampleApplications as $app) {
                $insertStmt->execute([
                    $app['application_code'],
                    $app['user_id'],
                    $app['program_type'],
                    $app['academic_level'],
                    $app['institution_applying'],
                    $app['intended_major'],
                    $app['family_income'],
                    $app['personal_statement'],
                    $app['status'],
                    $app['submitted_at']
                ]);
            }
            
            return true;
            
        } catch (Exception $e) {
            error_log("Error creating sample applications: " . $e->getMessage());
            return false;
        }
    }
}
?>