<?php
// REACH Organization Configuration
// Check if config is already loaded to prevent multiple inclusions

if (!defined('REACH_CONFIG_LOADED')) {
    define('REACH_CONFIG_LOADED', true);

    // Database Configuration for InfinityFree
    define('ORG_NAME', 'REACH Organization');
    define('ORG_ACRONYM', 'REACH');
    define('ORG_FULL_NAME', 'Recognizing Each Action Can Help');
    define('SITE_NAME', 'REACH - Recognizing Each Action Can Help');
    define('SITE_URL', 'https://reach.gt.tc');
    define('SITE_PATH', realpath(__DIR__ . '/..'));

    // Database Configuration for InfinityFree
    define('DB_HOST', 'sql105.infinityfree.com');
    define('DB_NAME', 'if0_39669901_reach');
    define('DB_USER', 'if0_39669901');
    define('DB_PASS', 'Quewon2025');
    define('DB_PORT', '3306');
    define('DB_CHARSET', 'utf8mb4');

    // Security Configuration
    define('PEPPER', 'reach-org-2024-secret-pepper-change-in-production');
    define('SESSION_TIMEOUT', 3600); // 1 hour
    define('CSRF_TOKEN_LIFE', 3600); // 1 hour

    // Application Settings - FIXED: Only define MAX_FILE_SIZE once
    define('MAX_FILE_SIZE', 10 * 1024 * 1024); // 10MB
    define('ALLOWED_IMAGE_TYPES', ['jpg', 'jpeg', 'png', 'gif', 'webp']);
    define('ALLOWED_DOC_TYPES', ['pdf', 'doc', 'docx', 'txt']);
    define('UPLOAD_PATH', SITE_PATH . '/assets/uploads/');
    define('ALLOWED_FILE_TYPES', ['pdf', 'jpg', 'jpeg', 'png']); // Consolidated file types
    define('UPLOAD_BASE_DIR', dirname(__DIR__) . '/uploads/');

    // Email Configuration - Using your cPanel email
    define('SMTP_HOST', 'mail.youngdevsofficial.com');
    define('SMTP_PORT', 587);
    define('SMTP_USER', 'no-reply@youngdevsofficial.com');
    define('SMTP_PASS', 'Youngdevs@123');
    define('FROM_EMAIL', 'no-reply@youngdevsofficial.com');
    define('FROM_NAME', 'REACH Organization');
    define('EMAIL_ENABLED', true);

    // Application Settings
    define('ITEMS_PER_PAGE', 12);
    define('MAX_LOGIN_ATTEMPTS', 5);
    define('LOCKOUT_TIME', 900); // 15 minutes

    // Environment
    define('ENVIRONMENT', 'production'); // development, testing, production

    // Error Reporting - FIXED: Always show errors for now to debug
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);

    // Timezone
    date_default_timezone_set('Africa/Kigali');

    // Start session with secure settings
    if (session_status() === PHP_SESSION_NONE) {
        session_set_cookie_params([
            'lifetime' => SESSION_TIMEOUT,
            'path' => '/',
            'domain' => 'reach.gt.tc',
            'secure' => true,
            'httponly' => true,
            'samesite' => 'Strict'
        ]);
        session_start();
    }

    // Auto-load classes
    spl_autoload_register(function ($class) {
        $file = __DIR__ . '/classes/' . $class . '.php';
        if (file_exists($file)) {
            require_once $file;
        }
    });

    // Create database connection with error handling
    try {
        $dsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
        ]);
    } catch (PDOException $e) {
        error_log("Database connection failed: " . $e->getMessage());
        // TEMPORARILY SHOW ERRORS EVEN IN PRODUCTION FOR DEBUGGING
        die("Database connection error: " . $e->getMessage());
    }

    // Security headers - Only if headers not already sent
    if (!headers_sent()) {
        header('X-Frame-Options: DENY');
        header('X-Content-Type-Options: nosniff');
        header('X-XSS-Protection: 1; mode=block');
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    }

    // CSRF Token Generation
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        $_SESSION['csrf_token_time'] = time();
    }

    // Check for CSRF token expiration
    if (isset($_SESSION['csrf_token_time']) && 
        (time() - $_SESSION['csrf_token_time']) > CSRF_TOKEN_LIFE) {
        unset($_SESSION['csrf_token']);
        unset($_SESSION['csrf_token_time']);
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        $_SESSION['csrf_token_time'] = time();
    }

    // Create necessary directories if they don't exist
    $uploadDirs = [
        UPLOAD_PATH . 'profiles/',
        UPLOAD_PATH . 'stories/',
        UPLOAD_PATH . 'projects/',
        UPLOAD_PATH . 'documents/',
        UPLOAD_PATH . 'applications/',
        SITE_PATH . '/system/logs/',
        UPLOAD_BASE_DIR . 'applications/',
        UPLOAD_BASE_DIR . 'profiles/',
        UPLOAD_BASE_DIR . 'documents/'
    ];

    foreach ($uploadDirs as $dir) {
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
    }

    // Utility function to get organization info
    if (!function_exists('getOrganizationInfo')) {
        function getOrganizationInfo() {
            return [
                'name' => ORG_NAME,
                'acronym' => ORG_ACRONYM,
                'full_name' => ORG_FULL_NAME,
                'email' => 'info@reach.org',
                'phone' => '+250 788 123 456',
                'address' => 'Kigali, Rwanda',
                'founders' => 'Mr. Philip B. Suah Jr. & Mrs. Hawa Suah',
                'mission' => 'To empower underprivileged students and communities through comprehensive educational support and sustainable development programs.',
                'vision' => 'A world where every individual has access to quality education and opportunities for growth',
                'contact_email' => 'no-reply@youngdevsofficial.com'
            ];
        }
    }

    // Utility function to get dashboard URL based on role
    if (!function_exists('getDashboardUrl')) {
        function getDashboardUrl($role) {
            $dashboards = [
                'super_admin' => '/admin/dashboard.php',
                'admin' => '/admin/dashboard.php',
                'staff' => '/portal/staff/dashboard.php',
                'student' => '/portal/student/dashboard.php',
                'sponsor' => '/portal/sponsor/dashboard.php',
                'partner' => '/portal/partner/dashboard.php',
                'volunteer' => '/portal/volunteer/dashboard.php',
                'reviewer' => '/portal/reviewer/dashboard.php'
            ];
            
            return $dashboards[$role] ?? '/public/login.php';
        }
    }

    // Utility function to get story type color
    if (!function_exists('getStoryTypeColor')) {
        function getStoryTypeColor($type) {
            $colors = [
                'student' => 'primary',
                'project' => 'success', 
                'achievement' => 'warning',
                'community' => 'info',
                'news' => 'secondary'
            ];
            return $colors[$type] ?? 'secondary';
        }
    }

    // Utility function to get project status color
    if (!function_exists('getProjectStatusColor')) {
        function getProjectStatusColor($status) {
            $colors = [
                'planning' => 'secondary',
                'in_progress' => 'primary',
                'completed' => 'success',
                'on_hold' => 'warning',
                'cancelled' => 'danger'
            ];
            return $colors[$status] ?? 'secondary';
        }
    }

    // Utility function to validate CSRF token
    if (!function_exists('validateCsrfToken')) {
        function validateCsrfToken($token) {
            if (!isset($_SESSION['csrf_token']) || $token !== $_SESSION['csrf_token']) {
                return false;
            }
            
            if ((time() - $_SESSION['csrf_token_time']) > CSRF_TOKEN_LIFE) {
                unset($_SESSION['csrf_token']);
                unset($_SESSION['csrf_token_time']);
                return false;
            }
            
            return true;
        }
    }

    // Utility function to generate random string
    if (!function_exists('generateRandomString')) {
        function generateRandomString($length = 10) {
            $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
            $charactersLength = strlen($characters);
            $randomString = '';
            for ($i = 0; $i < $length; $i++) {
                $randomString .= $characters[rand(0, $charactersLength - 1)];
            }
            return $randomString;
        }
    }

    // Utility function to sanitize input
    if (!function_exists('sanitizeInput')) {
        function sanitizeInput($data) {
            if (is_array($data)) {
                return array_map('sanitizeInput', $data);
            }
            
            return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
        }
    }

    // Utility function to format date
    if (!function_exists('formatDate')) {
        function formatDate($date, $format = 'F j, Y') {
            if (empty($date)) return '';
            $datetime = new DateTime($date);
            return $datetime->format($format);
        }
    }

    // Utility function to get file extension
    if (!function_exists('getFileExtension')) {
        function getFileExtension($filename) {
            return strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        }
    }

    // Utility function to check if file type is allowed
    if (!function_exists('isAllowedFileType')) {
        function isAllowedFileType($filename, $allowedTypes) {
            $extension = getFileExtension($filename);
            return in_array($extension, $allowedTypes);
        }
    }

    // Function to check if user is logged in
    if (!function_exists('isLoggedIn')) {
        function isLoggedIn() {
            return isset($_SESSION['user_id']) && isset($_SESSION['user_role']);
        }
    }

    // Function to require authentication
    if (!function_exists('requireAuth')) {
        function requireAuth() {
            if (!isLoggedIn()) {
                header('Location: /public/login.php');
                exit;
            }
        }
    }

    // Function to require specific role
    if (!function_exists('requireRole')) {
        function requireRole($requiredRole) {
            requireAuth();
            
            $roleHierarchy = [
                'super_admin' => 100,
                'admin' => 90,
                'staff' => 80,
                'reviewer' => 70,
                'partner' => 60,
                'sponsor' => 50,
                'volunteer' => 40,
                'student' => 30
            ];
            
            $userRoleLevel = $roleHierarchy[$_SESSION['user_role']] ?? 0;
            $requiredRoleLevel = $roleHierarchy[$requiredRole] ?? 0;
            
            if ($userRoleLevel < $requiredRoleLevel) {
                if (!headers_sent()) {
                    header('HTTP/1.1 403 Forbidden');
                }
                die("<div style='text-align: center; padding: 50px; font-family: Arial, sans-serif;'>
                        <h1>Access Denied</h1>
                        <p>You don't have permission to access this page.</p>
                        <a href='" . getDashboardUrl($_SESSION['user_role']) . "' style='color: #3498db;'>Return to Dashboard</a>
                    </div>");
            }
        }
    }

    // Function to generate application code
    if (!function_exists('generateApplicationCode')) {
        function generateApplicationCode() {
            return 'APP-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -6));
        }
    }

    // Function to send email
    if (!function_exists('sendEmail')) {
        function sendEmail($to, $subject, $body, $isHTML = true) {
            // If email is disabled, log it instead
            if (!EMAIL_ENABLED) {
                logEmail($to, $subject, $body, 'DISABLED - Would send');
                return true;
            }
            
            $headers = [];
            $headers[] = "From: " . FROM_NAME . " <" . FROM_EMAIL . ">";
            $headers[] = "Reply-To: " . FROM_EMAIL;
            $headers[] = "X-Mailer: PHP/" . phpversion();
            
            if ($isHTML) {
                $headers[] = "MIME-Version: 1.0";
                $headers[] = "Content-Type: text/html; charset=UTF-8";
            }
            
            $headerString = implode("\r\n", $headers);
            
            try {
                $result = mail($to, $subject, $body, $headerString);
                
                if (!$result) {
                    error_log("Email sending failed to: $to, Subject: $subject");
                    logEmail($to, $subject, $body, 'FAILED');
                    return false;
                }
                
                logEmail($to, $subject, $body, 'SENT');
                return true;
                
            } catch (Exception $e) {
                error_log("Email exception: " . $e->getMessage());
                logEmail($to, $subject, $body, 'ERROR: ' . $e->getMessage());
                return false;
            }
        }
    }

    // Function to log email activity
    if (!function_exists('logEmail')) {
        function logEmail($to, $subject, $body, $status = 'SENT') {
            $logMessage = "[" . date('Y-m-d H:i:s') . "] EMAIL $status:\n";
            $logMessage .= "To: $to\n";
            $logMessage .= "Subject: $subject\n";
            $logMessage .= "Body Length: " . strlen($body) . " characters\n";
            $logMessage .= "From: " . FROM_EMAIL . "\n";
            $logMessage .= "Status: $status\n";
            $logMessage .= "------------------------\n";
            
            $logDir = __DIR__ . '/../system/logs/';
            if (!is_dir($logDir)) {
                mkdir($logDir, 0755, true);
            }
            
            file_put_contents($logDir . 'email.log', $logMessage, FILE_APPEND);
        }
    }

    // Function to log activity
    if (!function_exists('logActivity')) {
        function logActivity($action, $description = '', $tableName = null, $recordId = null) {
            global $pdo;
            
            try {
                $stmt = $pdo->prepare("
                    INSERT INTO audit_logs (user_id, action, table_name, record_id, description, ip_address, user_agent) 
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([
                    $_SESSION['user_id'] ?? null,
                    $action,
                    $tableName,
                    $recordId,
                    $description,
                    $_SERVER['REMOTE_ADDR'],
                    $_SERVER['HTTP_USER_AGENT'] ?? ''
                ]);
                return true;
            } catch (Exception $e) {
                error_log("Activity log failed: " . $e->getMessage());
                return false;
            }
        }
    }

    // Function to get user by ID
    if (!function_exists('getUserById')) {
        function getUserById($userId) {
            global $pdo;
            
            try {
                $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
                $stmt->execute([$userId]);
                return $stmt->fetch();
            } catch (Exception $e) {
                error_log("Get user failed: " . $e->getMessage());
                return null;
            }
        }
    }

    // Function to validate file upload
    if (!function_exists('validateFileUpload')) {
        function validateFileUpload($file, $allowedTypes = [], $maxSize = MAX_FILE_SIZE) {
            $errors = [];
            
            if ($file['error'] !== UPLOAD_ERR_OK) {
                $errors[] = 'File upload error: ' . $file['error'];
                return $errors;
            }
            
            if ($file['size'] > $maxSize) {
                $errors[] = 'File size exceeds maximum allowed size of ' . formatFileSize($maxSize);
            }
            
            $extension = getFileExtension($file['name']);
            if (!empty($allowedTypes) && !in_array($extension, $allowedTypes)) {
                $errors[] = 'File type not allowed. Allowed types: ' . implode(', ', $allowedTypes);
            }
            
            return $errors;
        }
    }

    // Function to format file size
    if (!function_exists('formatFileSize')) {
        function formatFileSize($bytes) {
            if ($bytes >= 1073741824) {
                return number_format($bytes / 1073741824, 2) . ' GB';
            } elseif ($bytes >= 1048576) {
                return number_format($bytes / 1048576, 2) . ' MB';
            } elseif ($bytes >= 1024) {
                return number_format($bytes / 1024, 2) . ' KB';
            } else {
                return $bytes . ' bytes';
            }
        }
    }

    // Initialize default settings if not exists
    if (!function_exists('initializeDefaultSettings')) {
        function initializeDefaultSettings() {
            global $pdo;
            
            $defaultSettings = [
                ['organization_name', 'REACH - Recognizing Each Action Can Help', 'string'],
                ['founder_name', 'Mr. Philip B. Suah Jr. & Mrs. Hawa Suah', 'string'],
                ['contact_email', 'no-reply@youngdevsofficial.com', 'string'],
                ['contact_phone', '+250 788 123 456', 'string'],
                ['address', 'Kigali, Rwanda', 'string'],
                ['mission_statement', 'To empower underprivileged students and communities through comprehensive educational support and sustainable development programs.', 'string'],
                ['donation_goal', '1000000', 'integer'],
                ['scholarship_application_open', 'true', 'boolean'],
                ['volunteer_registration_open', 'true', 'boolean'],
                ['maintenance_mode', 'false', 'boolean']
            ];
            
            try {
                foreach ($defaultSettings as $setting) {
                    $stmt = $pdo->prepare("INSERT IGNORE INTO settings (setting_key, setting_value, setting_type) VALUES (?, ?, ?)");
                    $stmt->execute($setting);
                }
            } catch (Exception $e) {
                // Settings table might not exist yet, that's okay
            }
        }
    }

    // Initialize settings on first run
    initializeDefaultSettings();

    // Additional utility functions for better functionality

    // Function to get current user
    if (!function_exists('getCurrentUser')) {
        function getCurrentUser() {
            if (!isset($_SESSION['user_id'])) {
                return null;
            }
            
            return getUserById($_SESSION['user_id']);
        }
    }

    // Function to check if user has role
    if (!function_exists('hasRole')) {
        function hasRole($role) {
            return isset($_SESSION['user_role']) && $_SESSION['user_role'] === $role;
        }
    }

    // Function to check if user has any of specified roles
    if (!function_exists('hasAnyRole')) {
        function hasAnyRole($roles) {
            if (!isset($_SESSION['user_role'])) {
                return false;
            }
            return in_array($_SESSION['user_role'], (array)$roles);
        }
    }

    // Function to get user display name
    if (!function_exists('getDisplayName')) {
        function getDisplayName($user) {
            if (is_array($user)) {
                return $user['first_name'] . ' ' . $user['last_name'];
            }
            return 'User';
        }
    }

    // Function to get relative time
    if (!function_exists('getRelativeTime')) {
        function getRelativeTime($date) {
            if (empty($date)) return '';
            
            $time = strtotime($date);
            $timeDiff = time() - $time;
            
            if ($timeDiff < 60) {
                return 'just now';
            } elseif ($timeDiff < 3600) {
                $minutes = round($timeDiff / 60);
                return $minutes . ' minute' . ($minutes > 1 ? 's' : '') . ' ago';
            } elseif ($timeDiff < 86400) {
                $hours = round($timeDiff / 3600);
                return $hours . ' hour' . ($hours > 1 ? 's' : '') . ' ago';
            } elseif ($timeDiff < 2592000) {
                $days = round($timeDiff / 86400);
                return $days . ' day' . ($days > 1 ? 's' : '') . ' ago';
            } else {
                return formatDate($date);
            }
        }
    }

    // Function to redirect with messages
    if (!function_exists('redirectWithMessage')) {
        function redirectWithMessage($url, $type, $message) {
            if ($type === 'success') {
                addSuccessMessage($message);
            } else {
                addErrorMessage($message);
            }
            if (!headers_sent()) {
                header("Location: $url");
            }
            exit;
        }
    }

    // Function to add success message
    if (!function_exists('addSuccessMessage')) {
        function addSuccessMessage($message) {
            if (!isset($_SESSION['success_messages'])) {
                $_SESSION['success_messages'] = [];
            }
            $_SESSION['success_messages'][] = $message;
        }
    }

    // Function to add error message
    if (!function_exists('addErrorMessage')) {
        function addErrorMessage($message) {
            if (!isset($_SESSION['error_messages'])) {
                $_SESSION['error_messages'] = [];
            }
            $_SESSION['error_messages'][] = $message;
        }
    }

    // Function to get and clear success messages
    if (!function_exists('getSuccessMessages')) {
        function getSuccessMessages() {
            $messages = $_SESSION['success_messages'] ?? [];
            unset($_SESSION['success_messages']);
            return $messages;
        }
    }

    // Function to get and clear error messages
    if (!function_exists('getErrorMessages')) {
        function getErrorMessages() {
            $messages = $_SESSION['error_messages'] ?? [];
            unset($_SESSION['error_messages']);
            return $messages;
        }
    }

    // Function to check if string starts with specific text
    if (!function_exists('startsWith')) {
        function startsWith($string, $startString) {
            $len = strlen($startString);
            return substr($string, 0, $len) === $startString;
        }
    }

    // Function to check if string ends with specific text
    if (!function_exists('endsWith')) {
        function endsWith($string, $endString) {
            $len = strlen($endString);
            if ($len == 0) {
                return true;
            }
            return substr($string, -$len) === $endString;
        }
    }

    // Function to truncate text
    if (!function_exists('truncateText')) {
        function truncateText($text, $maxLength = 100) {
            if (strlen($text) <= $maxLength) {
                return $text;
            }
            return substr($text, 0, $maxLength) . '...';
        }
    }

    // Function to get current URL
    if (!function_exists('getCurrentUrl')) {
        function getCurrentUrl() {
            $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
            return $protocol . "://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
        }
    }

    // Function to get base URL
    if (!function_exists('getBaseUrl')) {
        function getBaseUrl() {
            $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
            $path = dirname($_SERVER['SCRIPT_NAME']);
            $baseUrl = $protocol . "://" . $_SERVER['HTTP_HOST'] . $path;
            return rtrim($baseUrl, '/');
        }
    }

    // Function to get client IP
    if (!function_exists('getClientIp')) {
        function getClientIp() {
            if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
                return $_SERVER['HTTP_CLIENT_IP'];
            } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                return $_SERVER['HTTP_X_FORWARDED_FOR'];
            } else {
                return $_SERVER['REMOTE_ADDR'];
            }
        }
    }

    // Function to check if file is an image
    if (!function_exists('isImageFile')) {
        function isImageFile($filename) {
            $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'svg'];
            return in_array(getFileExtension($filename), $allowedExtensions);
        }
    }

    // Function to check if file is a document
    if (!function_exists('isDocumentFile')) {
        function isDocumentFile($filename) {
            $allowedExtensions = ['pdf', 'doc', 'docx', 'txt', 'rtf', 'odt'];
            return in_array(getFileExtension($filename), $allowedExtensions);
        }
    }

    // Function to sanitize output for XSS protection
    if (!function_exists('sanitizeOutput')) {
        function sanitizeOutput($data) {
            return htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
        }
    }

    // Function to redirect
    if (!function_exists('redirect')) {
        function redirect($url) {
            if (!headers_sent()) {
                header("Location: " . $url);
            }
            exit();
        }
    }

    // Function to check if request is AJAX
    if (!function_exists('isAjaxRequest')) {
        function isAjaxRequest() {
            return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
                   strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
        }
    }

    // Function to get current page name
    if (!function_exists('getCurrentPage')) {
        function getCurrentPage() {
            return basename($_SERVER['PHP_SELF']);
        }
    }

    // Function to validate email
    if (!function_exists('isValidEmail')) {
        function isValidEmail($email) {
            return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
        }
    }

    // Function to generate CSRF token
    if (!function_exists('generateCsrfToken')) {
        function generateCsrfToken() {
            if (empty($_SESSION['csrf_token'])) {
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            }
            return $_SESSION['csrf_token'];
        }
    }

    // Function to verify CSRF token
    if (!function_exists('verifyCsrfToken')) {
        function verifyCsrfToken($token) {
            return isset($_SESSION['csrf_token']) && 
                   hash_equals($_SESSION['csrf_token'], $token);
        }
    }

    // Function to get notification count for current user
    if (!function_exists('getNotificationCount')) {
        function getNotificationCount() {
            global $pdo;
            
            if (!isset($_SESSION['user_id'])) {
                return 0;
            }
            
            try {
                $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0");
                $stmt->execute([$_SESSION['user_id']]);
                $result = $stmt->fetch(PDO::FETCH_ASSOC);
                return $result['count'] ?? 0;
            } catch (Exception $e) {
                error_log("Error getting notification count: " . $e->getMessage());
                return 0;
            }
        }
    }

    // ADD THE MISSING DASHBOARD STATS FUNCTION
    if (!function_exists('getDashboardStats')) {
        function getDashboardStats() {
            global $pdo;
            
            try {
                $stats = [];
                
                // Total users
                $stmt = $pdo->query("SELECT COUNT(*) as total_users FROM users WHERE deleted = 0");
                $stats['total_users'] = $stmt->fetch(PDO::FETCH_ASSOC)['total_users'] ?? 0;
                
                // Active users (last 30 days) - fallback if user_sessions table doesn't exist
                try {
                    $stmt = $pdo->query("SELECT COUNT(DISTINCT user_id) as active_users FROM user_sessions WHERE last_activity >= DATE_SUB(NOW(), INTERVAL 30 DAY)");
                    $stats['active_users'] = $stmt->fetch(PDO::FETCH_ASSOC)['active_users'] ?? 0;
                } catch (Exception $e) {
                    // Fallback: count users who logged in last 30 days
                    $stmt = $pdo->query("SELECT COUNT(*) as active_users FROM users WHERE last_login >= DATE_SUB(NOW(), INTERVAL 30 DAY) AND deleted = 0");
                    $stats['active_users'] = $stmt->fetch(PDO::FETCH_ASSOC)['active_users'] ?? 0;
                }
                
                // Total projects
                $stmt = $pdo->query("SELECT COUNT(*) as total_projects FROM student_projects WHERE approved = 1");
                $stats['total_projects'] = $stmt->fetch(PDO::FETCH_ASSOC)['total_projects'] ?? 0;
                
                // Pending projects
                $stmt = $pdo->query("SELECT COUNT(*) as pending_projects FROM student_projects WHERE approved = 0");
                $stats['pending_projects'] = $stmt->fetch(PDO::FETCH_ASSOC)['pending_projects'] ?? 0;
                
                // Total stories
                $stmt = $pdo->query("SELECT COUNT(*) as total_stories FROM stories WHERE status = 'published'");
                $stats['total_stories'] = $stmt->fetch(PDO::FETCH_ASSOC)['total_stories'] ?? 0;
                
                // Total achievements
                $stmt = $pdo->query("SELECT COUNT(*) as total_achievements FROM student_achievements WHERE verified = 1");
                $stats['total_achievements'] = $stmt->fetch(PDO::FETCH_ASSOC)['total_achievements'] ?? 0;
                
                // Pending approvals
                $stmt = $pdo->query("SELECT COUNT(*) as pending_approvals FROM student_projects WHERE approved = 0");
                $stats['pending_approvals'] = $stmt->fetch(PDO::FETCH_ASSOC)['pending_approvals'] ?? 0;
                
                // New users this month
                $stmt = $pdo->query("SELECT COUNT(*) as new_users_month FROM users WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) AND deleted = 0");
                $stats['new_users_month'] = $stmt->fetch(PDO::FETCH_ASSOC)['new_users_month'] ?? 0;
                
                // User growth percentage
                $lastMonth = date('Y-m-d', strtotime('-1 month'));
                $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM users WHERE created_at < ? AND deleted = 0");
                $stmt->execute([$lastMonth]);
                $lastMonthUsers = $stmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 1;
                
                if ($lastMonthUsers > 0) {
                    $stats['growth_percentage'] = round((($stats['total_users'] - $lastMonthUsers) / $lastMonthUsers) * 100, 2);
                } else {
                    $stats['growth_percentage'] = 100;
                }
                
                return $stats;
                
            } catch (Exception $e) {
                error_log("Dashboard stats error: " . $e->getMessage());
                return [
                    'total_users' => 0,
                    'active_users' => 0,
                    'total_projects' => 0,
                    'pending_projects' => 0,
                    'total_stories' => 0,
                    'total_achievements' => 0,
                    'pending_approvals' => 0,
                    'new_users_month' => 0,
                    'growth_percentage' => 0
                ];
            }
        }
    }

} // End REACH_CONFIG_LOADED check
?>