<?php
// Manual PHPMailer setup with SSL fix
require_once 'email-config.php';

// Check if PHPMailer files exist in src/ directory
$phpmailer_path = __DIR__ . '/PHPMailer/src/';
if (!file_exists($phpmailer_path . 'PHPMailer.php')) {
    throw new Exception('PHPMailer not found. Please check PHPMailer files in includes/PHPMailer/src/ directory.');
}

// Manually include PHPMailer files from src/ directory
require_once $phpmailer_path . 'PHPMailer.php';
require_once $phpmailer_path . 'SMTP.php';
require_once $phpmailer_path . 'Exception.php';

// Import PHPMailer classes
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

class REACHMailer {
    private $mailer;
    
    public function __construct() {
        $this->mailer = new PHPMailer(true);
        $this->setup();
    }
    
    private function setup() {
        try {
            // Server settings - NO debug output to prevent HTML in JSON
            $this->mailer->SMTPDebug = SMTP::DEBUG_OFF;
            $this->mailer->isSMTP();
            $this->mailer->Host       = SMTP_HOST;
            $this->mailer->SMTPAuth   = true;
            $this->mailer->Username   = SMTP_USERNAME;
            $this->mailer->Password   = SMTP_PASSWORD;
            $this->mailer->SMTPSecure = SMTP_SECURE;
            $this->mailer->Port       = SMTP_PORT;
            
            // FIX: Bypass SSL certificate verification for shared hosting
            $this->mailer->SMTPOptions = array(
                'ssl' => array(
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true
                )
            );
            
            // Sender info
            $this->mailer->setFrom(SMTP_USERNAME, ORG_NAME);
            $this->mailer->addReplyTo(ORG_REPLY_TO, ORG_NAME);
            
            // Content
            $this->mailer->isHTML(true);
            $this->mailer->CharSet = 'UTF-8';
            
        } catch (Exception $e) {
            error_log("PHPMailer setup error: " . $e->getMessage());
            throw $e;
        }
    }
    
    public function sendEmail($to, $subject, $body, $isHTML = true) {
        try {
            // Reset recipients for new email
            $this->mailer->clearAddresses();
            $this->mailer->clearCCs();
            $this->mailer->clearBCCs();
            $this->mailer->clearAttachments();
            
            // Add recipient
            $this->mailer->addAddress($to);
            
            // Content
            $this->mailer->Subject = $subject;
            $this->mailer->Body    = $body;
            $this->mailer->AltBody = strip_tags($body); // Plain text version
            $this->mailer->isHTML($isHTML);
            
            $result = $this->mailer->send();
            error_log("Email sent to $to: " . ($result ? 'SUCCESS' : 'FAILED'));
            return $result;
            
        } catch (Exception $e) {
            error_log("Email sending error to $to: " . $e->getMessage());
            return false;
        }
    }
}

// Helper functions
function sendAdminNotification($contact_data) {
    try {
        $mailer = new REACHMailer();
        
        $subject = EMAIL_ADMIN_SUBJECT;
        
        $html_body = "
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: #2c5aa0; color: white; padding: 20px; text-align: center; }
                .content { padding: 20px; background: #f9f9f9; border: 1px solid #ddd; }
                .field { margin-bottom: 10px; }
                .field-label { font-weight: bold; color: #2c5aa0; }
                .message-box { background: white; padding: 15px; border-left: 4px solid #2c5aa0; margin: 15px 0; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h1>REACH Organization</h1>
                    <h2>New Contact Form Submission</h2>
                </div>
                <div class='content'>
                    <div class='field'><span class='field-label'>Contact ID:</span> #{$contact_data['id']}</div>
                    <div class='field'><span class='field-label'>Date:</span> {$contact_data['date']}</div>
                    <div class='field'><span class='field-label'>Name:</span> {$contact_data['name']}</div>
                    <div class='field'><span class='field-label'>Email:</span> {$contact_data['email']}</div>
                    <div class='field'><span class='field-label'>Phone:</span> " . ($contact_data['phone'] ?: 'Not provided') . "</div>
                    <div class='field'><span class='field-label'>Subject:</span> {$contact_data['subject']}</div>
                    
                    <div class='message-box'>
                        <strong>Message:</strong><br>
                        " . nl2br(htmlspecialchars($contact_data['message'])) . "
                    </div>
                </div>
            </div>
        </body>
        </html>
        ";
        
        return $mailer->sendEmail(ORG_EMAIL, $subject, $html_body);
        
    } catch (Exception $e) {
        error_log("Admin notification error: " . $e->getMessage());
        return false;
    }
}

function sendAutoReply($contact_data) {
    try {
        $mailer = new REACHMailer();
        
        $subject = EMAIL_AUTO_REPLY_SUBJECT;
        
        $html_body = "
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: #2c5aa0; color: white; padding: 30px; text-align: center; }
                .content { padding: 30px; background: white; }
                .thank-you { font-size: 24px; color: #2c5aa0; margin-bottom: 20px; }
                .summary { background: #f8f9fa; padding: 20px; border-radius: 5px; margin: 20px 0; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h1>REACH Organization</h1>
                    <p>Transforming Lives Through Education</p>
                </div>
                <div class='content'>
                    <div class='thank-you'>Thank You for Contacting Us!</div>
                    
                    <p>Dear <strong>{$contact_data['name']}</strong>,</p>
                    
                    <p>Thank you for reaching out to REACH Organization! We have received your message and appreciate you taking the time to contact us.</p>
                    
                    <div class='summary'>
                        <h3 style='color: #2c5aa0; margin-top: 0;'>Submission Summary</h3>
                        <p><strong>Reference ID:</strong> #{$contact_data['id']}</p>
                        <p><strong>Subject:</strong> {$contact_data['subject']}</p>
                        <p><strong>Date Submitted:</strong> {$contact_data['date']}</p>
                    </div>
                    
                    <p><strong>What happens next?</strong><br>
                    ✓ Our team will review your message within 24 hours<br>
                    ✓ We'll respond to you at this email address<br>
                    ✓ You'll hear from us within 24-48 hours</p>
                    
                    <p><strong>For urgent matters:</strong><br>
                    📞 Phone: +250 788 123 456<br>
                    📧 Email: info@reach.org</p>
                    
                    <p>We look forward to assisting you!</p>
                    
                    <p>Warm regards,<br>
                    <strong>The REACH Organization Team</strong></p>
                </div>
            </div>
        </body>
        </html>
        ";
        
        return $mailer->sendEmail($contact_data['email'], $subject, $html_body);
        
    } catch (Exception $e) {
        error_log("Auto-reply error: " . $e->getMessage());
        return false;
    }
}
?>