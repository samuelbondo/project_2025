<?php
// includes/helpers.php

/**
 * Get CSS class for application status
 */
function getApplicationStatusColor($status) {
    $colors = [
        'pending' => 'warning',
        'approved' => 'success',
        'rejected' => 'danger',
        'reviewed' => 'info',
        'draft' => 'secondary'
    ];
    return $colors[$status] ?? 'secondary';
}

/**
 * Get icon for activity type
 */
function getActivityIcon($action) {
    $icons = [
        'login' => 'sign-in-alt',
        'logout' => 'sign-out-alt',
        'create' => 'plus',
        'update' => 'edit',
        'delete' => 'trash',
        'approve' => 'check',
        'reject' => 'times',
        'register' => 'user-plus',
        'application' => 'clipboard-list'
    ];
    return $icons[$action] ?? 'circle';
}

/**
 * Format time as human-readable string
 */
function time_elapsed_string($datetime, $full = false) {
    $now = new DateTime;
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    $diff->w = floor($diff->d / 7);
    $diff->d -= $diff->w * 7;

    $string = array(
        'y' => 'year',
        'm' => 'month',
        'w' => 'week',
        'd' => 'day',
        'h' => 'hour',
        'i' => 'minute',
        's' => 'second',
    );
    
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
        } else {
            unset($string[$k]);
        }
    }

    if (!$full) $string = array_slice($string, 0, 1);
    return $string ? implode(', ', $string) . ' ago' : 'just now';
}

/**
 * Get role badge color
 */
function getRoleBadgeColor($role) {
    $colors = [
        'super_admin' => 'super_admin',
        'admin' => 'admin',
        'manager' => 'manager',
        'user' => 'user',
        'volunteer' => 'volunteer',
        'student' => 'student'
    ];
    return $colors[$role] ?? 'user';
}

/**
 * Check if current page matches section
 */
function isActiveSection($section) {
    $current_page = basename($_SERVER['PHP_SELF']);
    $section_pages = [
        'dashboard' => ['dashboard.php'],
        'applications' => ['index.php', 'view.php', 'edit.php', 'review.php'],
        'students' => ['index.php', 'view.php', 'edit.php', 'profile.php'],
        'finances' => ['index.php', 'transactions.php', 'reports.php'],
        'partners' => ['index.php', 'view.php', 'edit.php'],
        'reports' => ['index.php', 'generate.php', 'analytics.php'],
        'users' => ['index.php', 'view.php', 'edit.php', 'create.php'],
        'settings' => ['settings.php', 'profile.php']
    ];
    
    return in_array($current_page, $section_pages[$section] ?? []);
}

/**
 * Format currency
 */
function formatCurrency($amount, $currency = 'USD') {
    return '$' . number_format($amount, 2);
}

/**
 * Get user display name
 */
function getUserDisplayName($user) {
    if (!empty($user['full_name'])) {
        return $user['full_name'];
    }
    return $user['username'] ?? 'Unknown User';
}

/**
 * Check if string is JSON
 */
function isJson($string) {
    json_decode($string);
    return json_last_error() === JSON_ERROR_NONE;
}

/**
 * Generate pagination array
 */
function generatePagination($currentPage, $totalPages, $maxPages = 5) {
    $pagination = [];
    
    // Always show first page
    $pagination[] = 1;
    
    // Calculate start and end pages
    $startPage = max(2, $currentPage - floor($maxPages / 2));
    $endPage = min($totalPages - 1, $startPage + $maxPages - 1);
    
    // Adjust if we're near the end
    if ($endPage - $startPage < $maxPages - 1) {
        $startPage = max(2, $endPage - $maxPages + 1);
    }
    
    // Add middle pages
    if ($startPage > 2) {
        $pagination[] = '...';
    }
    
    for ($i = $startPage; $i <= $endPage; $i++) {
        $pagination[] = $i;
    }
    
    if ($endPage < $totalPages - 1) {
        $pagination[] = '...';
    }
    
    // Always show last page if there is more than one page
    if ($totalPages > 1) {
        $pagination[] = $totalPages;
    }
    
    return $pagination;
}

/**
 * Get month name from number
 */
function getMonthName($monthNumber) {
    $months = [
        1 => 'January', 2 => 'February', 3 => 'March', 4 => 'April',
        5 => 'May', 6 => 'June', 7 => 'July', 8 => 'August',
        9 => 'September', 10 => 'October', 11 => 'November', 12 => 'December'
    ];
    return $months[$monthNumber] ?? 'Unknown';
}

/**
 * Truncate text with ellipsis
 */
function truncateText($text, $length = 100) {
    if (strlen($text) <= $length) {
        return $text;
    }
    return substr($text, 0, $length) . '...';
}

/**
 * Generate random color
 */
function generateRandomColor() {
    return '#' . str_pad(dechex(mt_rand(0, 0xFFFFFF)), 6, '0', STR_PAD_LEFT);
}

/**
 * Get file icon based on extension
 */
function getFileIcon($filename) {
    $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    
    $icons = [
        'pdf' => 'file-pdf',
        'doc' => 'file-word',
        'docx' => 'file-word',
        'xls' => 'file-excel',
        'xlsx' => 'file-excel',
        'ppt' => 'file-powerpoint',
        'pptx' => 'file-powerpoint',
        'jpg' => 'file-image',
        'jpeg' => 'file-image',
        'png' => 'file-image',
        'gif' => 'file-image',
        'zip' => 'file-archive',
        'rar' => 'file-archive',
        'txt' => 'file-alt'
    ];
    
    return $icons[$extension] ?? 'file';
}
?>