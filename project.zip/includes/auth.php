<?php
/**
 * REACH Organization - Authentication System
 * Streamlined version to prevent memory issues
 */

// Check if class already exists to prevent redeclaration
if (!class_exists('Auth')) {

class Auth {
    private $pdo;
    private $maxLoginAttempts;
    private $lockoutTime;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
        $this->maxLoginAttempts = 5;
        $this->lockoutTime = 900;
    }
    
    /**
     * User Login - Simplified version
     */
    public function login($username, $password) {
        try {
            // Simple query with minimal joins
            $stmt = $this->pdo->prepare("
                SELECT id, username, email, password_hash, full_name, role, status 
                FROM users 
                WHERE (username = ? OR email = ?) 
                AND status = 'active'
                LIMIT 1
            ");
            $stmt->execute([$username, $username]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($user && $this->verifyPassword($password, $user['password_hash'])) {
                // Set session variables
                $this->setUserSession($user);
                
                // Update last login
                $this->updateLastLogin($user['id']);
                
                return $user;
            }
            
            throw new Exception("Invalid username or password.");
            
        } catch (Exception $e) {
            throw new Exception("Login failed: " . $e->getMessage());
        }
    }
    
    /**
     * User Logout
     */
    public function logout() {
        session_destroy();
        
        // Start new session for CSRF token
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    
    /**
     * Check User Role for Authorization
     */
    public function checkRole($allowedRoles) {
        if (!isset($_SESSION['user_id'])) {
            if (!headers_sent()) {
                header('Location: /public/login.php?redirect=' . urlencode($_SERVER['REQUEST_URI']));
            }
            exit();
        }
        
        $userRole = $_SESSION['role'] ?? 'user';
        
        if (!in_array($userRole, (array)$allowedRoles)) {
            http_response_code(403);
            die("
                <div style='text-align: center; padding: 50px; font-family: Arial, sans-serif;'>
                    <h1>Access Denied</h1>
                    <p>You don't have permission to access this page.</p>
                    <a href='" . $this->getDashboardUrl() . "' style='color: #3498db;'>Return to Dashboard</a>
                </div>
            ");
        }
    }
    
    /**
     * Check if User is Logged In
     */
    public function isLoggedIn() {
        return isset($_SESSION['user_id']) && isset($_SESSION['username']);
    }
    
    /**
     * Get Current User Data - Simplified
     */
    public function getCurrentUser() {
        if (!$this->isLoggedIn()) {
            return null;
        }
        
        try {
            $stmt = $this->pdo->prepare("
                SELECT id, username, email, role, full_name, profile_picture, status 
                FROM users 
                WHERE id = ? 
                LIMIT 1
            ");
            $stmt->execute([$_SESSION['user_id']]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error getting current user: " . $e->getMessage());
            return null;
        }
    }
    
    /**
     * Check if User has Specific Role
     */
    public function hasRole($role) {
        if (!$this->isLoggedIn()) {
            return false;
        }
        return ($_SESSION['role'] ?? '') === $role;
    }
    
    /**
     * Check if User has Any of Specified Roles
     */
    public function hasAnyRole($roles) {
        if (!$this->isLoggedIn()) {
            return false;
        }
        return in_array($_SESSION['role'] ?? '', (array)$roles);
    }
    
    /**
     * Get Dashboard URL based on User Role
     */
    public function getDashboardUrl() {
        $dashboards = [
            'super_admin' => '/admin/dashboard.php',
            'admin' => '/admin/dashboard.php',
            'staff' => '/portal/staff/dashboard.php',
            'student' => '/portal/student/dashboard.php',
            'sponsor' => '/portal/sponsor/dashboard.php',
            'partner' => '/portal/partner/dashboard.php',
            'volunteer' => '/portal/volunteer/dashboard.php',
            'reviewer' => '/portal/reviewer/dashboard.php'
        ];
        
        return $dashboards[$_SESSION['role'] ?? ''] ?? '/public/login.php';
    }
    
    /**
     * Hash password with pepper
     */
    private function hashPassword($password) {
        $pepper = defined('PEPPER') ? PEPPER : "REACH_PEPPER_SECRET_2024";
        return password_hash($password . $pepper, PASSWORD_DEFAULT);
    }
    
    /**
     * Verify password
     */
    private function verifyPassword($password, $hash) {
        if (empty($hash)) {
            return false;
        }
        
        $pepper = defined('PEPPER') ? PEPPER : "REACH_PEPPER_SECRET_2024";
        return password_verify($password . $pepper, $hash);
    }
    
    /**
     * Set user session after login
     */
    private function setUserSession($user) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['full_name'] = $user['full_name'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['login_time'] = time();
        
        // Set CSRF token for form protection
        if (!isset($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
    }
    
    /**
     * Update last login timestamp
     */
    private function updateLastLogin($userId) {
        try {
            $stmt = $this->pdo->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
            $stmt->execute([$userId]);
        } catch (Exception $e) {
            // If column doesn't exist, ignore
        }
    }
    
    /**
     * Validate CSRF token
     */
    public function validateCSRFToken($token) {
        if (!isset($_SESSION['csrf_token'])) {
            return false;
        }
        
        return hash_equals($_SESSION['csrf_token'], $token);
    }
    
    /**
     * Generate CSRF token for forms
     */
    public function generateCSRFToken() {
        if (!isset($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }
}

} // End class_exists check

// Initialize Auth system only if not already initialized and PDO exists
if (!isset($auth) && isset($pdo)) {
    $auth = new Auth($pdo);
}
?>