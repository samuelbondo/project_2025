    </main>

    <!-- Footer -->
    <footer class="footer bg-dark text-white">
        <div class="container">
            <div class="row">
                <!-- Organization Info -->
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="footer-brand mb-3">
                        <i class="fas fa-hands-helping me-2"></i>
                        <strong>REACH</strong>
                        <small>Recognizing Each Action Can Help</small>
                    </div>
                    <p class="footer-description">
                        Transforming lives through education, empowerment, and community development 
                        in Rwanda and beyond.
                    </p>
                    <div class="social-links">
                        <a href="#" class="social-link"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-linkedin-in"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-youtube"></i></a>
                    </div>
                </div>

                <!-- Quick Links -->
                <div class="col-lg-2 col-md-6 mb-4">
                    <h5 class="footer-title">Quick Links</h5>
                    <ul class="footer-links">
                        <li><a href="/about.php">About Us</a></li>
                        <li><a href="/programs.php">Our Programs</a></li>
                        <li><a href="/stories.php">Success Stories</a></li>
                        <li><a href="/partners.php">Partners</a></li>
                        <li><a href="/impact.php">Our Impact</a></li>
                    </ul>
                </div>

                <!-- Programs -->
                <div class="col-lg-2 col-md-6 mb-4">
                    <h5 class="footer-title">Programs</h5>
                    <ul class="footer-links">
                        <li><a href="/programs.php#scholarships">Scholarships</a></li>
                        <li><a href="/programs.php#housing">Student Housing</a></li>
                        <li><a href="/programs.php#community">Community Development</a></li>
                        <li><a href="/programs.php#mentorship">Mentorship</a></li>
                        <li><a href="/apply.php">Apply Now</a></li>
                    </ul>
                </div>

                <!-- Contact Info -->
                <div class="col-lg-4 col-md-6 mb-4">
                    <h5 class="footer-title">Contact Us</h5>
                    <div class="contact-info">
                        <div class="contact-item">
                            <i class="fas fa-map-marker-alt me-2"></i>
                            <span>Kigali, Rwanda</span>
                        </div>
                        <div class="contact-item">
                            <i class="fas fa-phone me-2"></i>
                            <span>+250 788 123 456</span>
                        </div>
                        <div class="contact-item">
                            <i class="fas fa-envelope me-2"></i>
                            <span>info@reach.org</span>
                        </div>
                        <div class="contact-item">
                            <i class="fas fa-clock me-2"></i>
                            <span>Mon - Fri: 9:00 AM - 5:00 PM</span>
                        </div>
                    </div>

                    <!-- Newsletter Signup -->
                    <div class="newsletter mt-4">
                        <h6 class="newsletter-title">Stay Updated</h6>
                        <form class="newsletter-form">
                            <div class="input-group">
                                <input type="email" class="form-control" placeholder="Your email address" required>
                                <button class="btn btn-primary" type="submit">
                                    <i class="fas fa-paper-plane"></i>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <hr class="footer-divider">

            <!-- Bottom Footer -->
            <div class="footer-bottom">
                <div class="row align-items-center">
                    <div class="col-md-6">
                        <p class="copyright mb-0">
                            &copy; <?php echo date('Y'); ?> REACH Organization. All rights reserved.
                        </p>
                    </div>
                    <div class="col-md-6">
                        <div class="footer-bottom-links">
                            <a href="/privacy.php">Privacy Policy</a>
                            <a href="/terms.php">Terms of Service</a>
                            <a href="/contact.php">Contact</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    
    <?php if (isset($additionalJS)): ?>
        <?php foreach ($additionalJS as $js): ?>
            <script src="<?php echo $js; ?>"></script>
        <?php endforeach; ?>
    <?php endif; ?>

    <!-- Initialize AOS -->
    <script>
        AOS.init({
            duration: 1000,
            once: true,
            offset: 100
        });
    </script>

    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', 'GA_MEASUREMENT_ID');
    </script>
</body>
</html>