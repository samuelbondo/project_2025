<?php
/**
 * Database Backup Manager for REACH Organization
 */
class BackupManager {
    private $pdo;
    private $backupPath;
    
    public function __construct($pdo, $backupPath = null) {
        $this->pdo = $pdo;
        $this->backupPath = $backupPath ?: __DIR__ . '/backups/';
        
        if (!is_dir($this->backupPath)) {
            mkdir($this->backupPath, 0755, true);
        }
    }
    
    public function createBackup($includeData = true, $compress = true) {
        $timestamp = date('Y-m-d_H-i-s');
        $filename = "reach_backup_{$timestamp}.sql";
        $filepath = $this->backupPath . $filename;
        
        try {
            $backupContent = $this->generateBackupSQL($includeData);
            
            if ($compress) {
                $filepath .= '.gz';
                file_put_contents($filepath, gzencode($backupContent, 9));
            } else {
                file_put_contents($filepath, $backupContent);
            }
            
            // Log backup creation
            $this->logBackupAction('create', $filename, filesize($filepath));
            
            return [
                'success' => true,
                'filename' => basename($filepath),
                'filepath' => $filepath,
                'size' => filesize($filepath),
                'created_at' => $timestamp
            ];
            
        } catch (Exception $e) {
            error_log("Backup failed: " . $e->getMessage());
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
    
    private function generateBackupSQL($includeData = true) {
        $sql = "-- REACH Organization Database Backup\n";
        $sql .= "-- Generated: " . date('Y-m-d H:i:s') . "\n";
        $sql .= "-- Version: 1.0\n\n";
        
        // Get all tables
        $tables = $this->pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
        
        foreach ($tables as $table) {
            $sql .= "--\n-- Table structure for table `$table`\n--\n\n";
            
            // Get create table statement
            $createTable = $this->pdo->query("SHOW CREATE TABLE `$table`")->fetch(PDO::FETCH_ASSOC);
            $sql .= $createTable['Create Table'] . ";\n\n";
            
            if ($includeData) {
                $sql .= "--\n-- Dumping data for table `$table`\n--\n\n";
                
                $data = $this->pdo->query("SELECT * FROM `$table`")->fetchAll(PDO::FETCH_ASSOC);
                
                if (!empty($data)) {
                    $columns = array_keys($data[0]);
                    $sql .= "INSERT INTO `$table` (`" . implode('`, `', $columns) . "`) VALUES \n";
                    
                    $rows = [];
                    foreach ($data as $row) {
                        $values = array_map(function($value) {
                            if ($value === null) return 'NULL';
                            // Escape special characters
                            return $this->pdo->quote($value);
                        }, $row);
                        $rows[] = "(" . implode(', ', $values) . ")";
                    }
                    
                    $sql .= implode(",\n", $rows) . ";\n\n";
                }
            }
        }
        
        return $sql;
    }
    
    public function listBackups() {
        $backups = [];
        $files = glob($this->backupPath . "reach_backup_*.sql*");
        
        foreach ($files as $file) {
            $backups[] = [
                'filename' => basename($file),
                'filepath' => $file,
                'size' => filesize($file),
                'modified' => date('Y-m-d H:i:s', filemtime($file)),
                'compressed' => pathinfo($file, PATHINFO_EXTENSION) === 'gz'
            ];
        }
        
        // Sort by modification time (newest first)
        usort($backups, function($a, $b) {
            return filemtime($b['filepath']) - filemtime($a['filepath']);
        });
        
        return $backups;
    }
    
    public function restoreBackup($filename) {
        $filepath = $this->backupPath . $filename;
        
        if (!file_exists($filepath)) {
            throw new Exception("Backup file not found: $filename");
        }
        
        try {
            // Read backup file
            if (pathinfo($filepath, PATHINFO_EXTENSION) === 'gz') {
                $content = gzdecode(file_get_contents($filepath));
            } else {
                $content = file_get_contents($filepath);
            }
            
            // Split into individual queries
            $queries = array_filter(array_map('trim', explode(';', $content)));
            
            // Begin transaction
            $this->pdo->beginTransaction();
            
            foreach ($queries as $query) {
                if (!empty($query) && !str_starts_with($query, '--')) {
                    $this->pdo->exec($query);
                }
            }
            
            $this->pdo->commit();
            $this->logBackupAction('restore', $filename, filesize($filepath));
            
            return true;
            
        } catch (Exception $e) {
            $this->pdo->rollBack();
            throw new Exception("Restore failed: " . $e->getMessage());
        }
    }
    
    public function deleteBackup($filename) {
        $filepath = $this->backupPath . $filename;
        
        if (file_exists($filepath)) {
            $size = filesize($filepath);
            if (unlink($filepath)) {
                $this->logBackupAction('delete', $filename, $size);
                return true;
            }
        }
        
        return false;
    }
    
    private function logBackupAction($action, $filename, $size) {
        $logFile = $this->backupPath . 'backup_log.txt';
        $logEntry = sprintf(
            "[%s] %s: %s (Size: %s) - User: %s\n",
            date('Y-m-d H:i:s'),
            strtoupper($action),
            $filename,
            $this->formatBytes($size),
            $_SESSION['user_name'] ?? 'System'
        );
        
        file_put_contents($logFile, $logEntry, FILE_APPEND | LOCK_EX);
    }
    
    private function formatBytes($size, $precision = 2) {
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        $bytes = max($size, 0);
        $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
        $pow = min($pow, count($units) - 1);
        $bytes /= pow(1024, $pow);
        
        return round($bytes, $precision) . ' ' . $units[$pow];
    }
    
    public function getBackupStats() {
        $backups = $this->listBackups();
        $totalSize = 0;
        $oldestBackup = null;
        $newestBackup = null;
        
        foreach ($backups as $backup) {
            $totalSize += $backup['size'];
            if (!$oldestBackup || $backup['modified'] < $oldestBackup) {
                $oldestBackup = $backup['modified'];
            }
            if (!$newestBackup || $backup['modified'] > $newestBackup) {
                $newestBackup = $backup['modified'];
            }
        }
        
        return [
            'total_backups' => count($backups),
            'total_size' => $this->formatBytes($totalSize),
            'oldest_backup' => $oldestBackup,
            'newest_backup' => $newestBackup,
            'backup_path' => $this->backupPath
        ];
    }
}

// Usage example:
// $backupManager = new BackupManager($pdo);
// $result = $backupManager->createBackup();
?>