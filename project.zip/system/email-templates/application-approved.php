<?php
/**
 * Application Approved Email Template
 */
function getApplicationApprovedEmail($applicantName, $applicationCode, $programType) {
    return "
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: #3498db; color: white; padding: 20px; text-align: center; }
            .content { background: #f9f9f9; padding: 20px; }
            .footer { background: #34495e; color: white; padding: 10px; text-align: center; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h1>REACH Organization</h1>
                <h2>Application Approved!</h2>
            </div>
            <div class='content'>
                <p>Dear $applicantName,</p>
                <p>We are pleased to inform you that your application <strong>$applicationCode</strong> for the <strong>" . ucfirst($programType) . " Program</strong> has been approved!</p>
                <p>Congratulations on this achievement. Our team will contact you shortly with the next steps.</p>
                <p>If you have any questions, please don't hesitate to contact us.</p>
                <p>Best regards,<br>REACH Organization Team</p>
            </div>
            <div class='footer'>
                <p>&copy; " . date('Y') . " REACH Organization. All rights reserved.</p>
            </div>
        </div>
    </body>
    </html>
    ";
}
?>