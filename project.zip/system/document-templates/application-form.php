<?php
/**
 * Application Form Document Template
 */
function generateApplicationForm($applicationData, $applicantInfo) {
    $html = "
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; margin: 40px; }
            .header { text-align: center; border-bottom: 2px solid #333; padding-bottom: 20px; margin-bottom: 30px; }
            .section { margin-bottom: 30px; }
            .section-title { background: #f8f9fa; padding: 10px; border-left: 4px solid #3498db; margin-bottom: 15px; }
            .field { margin-bottom: 10px; }
            .field-label { font-weight: bold; width: 200px; display: inline-block; }
            .footer { margin-top: 50px; text-align: center; font-size: 12px; color: #666; }
        </style>
    </head>
    <body>
        <div class='header'>
            <h1>REACH Organization</h1>
            <h2>Application Form</h2>
            <p>Application ID: {$applicationData['application_code']}</p>
        </div>

        <div class='section'>
            <div class='section-title'>
                <h3>Personal Information</h3>
            </div>
    ";

    foreach ($applicationData['personal'] as $field => $value) {
        $html .= "
            <div class='field'>
                <span class='field-label'>" . ucwords(str_replace('_', ' ', $field)) . ":</span>
                <span>" . htmlspecialchars($value) . "</span>
            </div>
        ";
    }

    $html .= "
        </div>

        <div class='section'>
            <div class='section-title'>
                <h3>Academic Information</h3>
            </div>
    ";

    foreach ($applicationData['academic'] as $field => $value) {
        $html .= "
            <div class='field'>
                <span class='field-label'>" . ucwords(str_replace('_', ' ', $field)) . ":</span>
                <span>" . htmlspecialchars($value) . "</span>
            </div>
        ";
    }

    $html .= "
        </div>

        <div class='footer'>
            <p>Generated on " . date('F j, Y') . " | REACH Organization</p>
        </div>
    </body>
    </html>
    ";

    return $html;
}
?>