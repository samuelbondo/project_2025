<?php
header('Content-Type: application/json');
include '../../includes/config.php';
include '../../includes/auth.php';
include '../../includes/functions.php';

// Start debug logging
error_log("=== STUDENT CREATION STARTED ===");
error_log("POST data: " . print_r($_POST, true));

// Initialize auth and check permissions
$auth = new Auth();
if (!$auth->isLoggedIn()) {
    error_log("Auth failed: User not logged in");
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit;
}

if (!$auth->hasRole(['super_admin', 'admin'])) {
    error_log("Auth failed: Insufficient role");
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Insufficient permissions']);
    exit;
}

// Validate CSRF token
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== ($_SESSION['csrf_token'] ?? '')) {
    error_log("CSRF token validation failed");
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Invalid CSRF token']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    error_log("Invalid method: " . $_SERVER['REQUEST_METHOD']);
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// Validate required fields
$required = ['username', 'email', 'password', 'full_name', 'confirm_password'];
foreach ($required as $field) {
    if (empty($_POST[$field])) {
        error_log("Missing required field: $field");
        echo json_encode(['success' => false, 'message' => "Field '$field' is required"]);
        exit;
    }
}

// Validate password match
if ($_POST['password'] !== $_POST['confirm_password']) {
    error_log("Password confirmation failed");
    echo json_encode(['success' => false, 'message' => 'Passwords do not match']);
    exit;
}

// Validate email format
if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
    error_log("Invalid email format: " . $_POST['email']);
    echo json_encode(['success' => false, 'message' => 'Invalid email format']);
    exit;
}

// Validate password length
if (strlen($_POST['password']) < 8) {
    error_log("Password too short");
    echo json_encode(['success' => false, 'message' => 'Password must be at least 8 characters long']);
    exit;
}

// Check if username already exists
try {
    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->execute([$_POST['username']]);
    if ($stmt->fetch()) {
        error_log("Username already exists: " . $_POST['username']);
        echo json_encode(['success' => false, 'message' => 'Username already exists']);
        exit;
    }
} catch (Exception $e) {
    error_log("Username check error: " . $e->getMessage());
}

// Check if email already exists
try {
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->execute([$_POST['email']]);
    if ($stmt->fetch()) {
        error_log("Email already exists: " . $_POST['email']);
        echo json_encode(['success' => false, 'message' => 'Email already exists']);
        exit;
    }
} catch (Exception $e) {
    error_log("Email check error: " . $e->getMessage());
}

$userData = [
    'username' => trim($_POST['username']),
    'email' => trim($_POST['email']),
    'password' => $_POST['password'],
    'full_name' => trim($_POST['full_name']),
    'phone' => !empty($_POST['phone']) ? trim($_POST['phone']) : null,
    'role' => 'student',
    'status' => $_POST['status'] ?? 'active'
];

error_log("Attempting to create user with data: " . print_r($userData, true));

try {
    // Start transaction for data consistency
    $pdo->beginTransaction();
    error_log("Database transaction started");

    // Method 1: Try using Auth class first
    $userId = null;
    if (method_exists($auth, 'register')) {
        error_log("Using Auth::register method");
        $userId = $auth->register($userData);
    } 
    
    // Method 2: If Auth class doesn't work, do direct insertion
    if (!$userId) {
        error_log("Auth::register failed or doesn't exist, using direct insertion");
        
        $hashedPassword = password_hash($userData['password'], PASSWORD_DEFAULT);
        
        $userSql = "INSERT INTO users (username, email, password, role, full_name, phone, status, created_at, updated_at) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW())";
        
        $userStmt = $pdo->prepare($userSql);
        $result = $userStmt->execute([
            $userData['username'],
            $userData['email'],
            $hashedPassword,
            $userData['role'],
            $userData['full_name'],
            $userData['phone'],
            $userData['status']
        ]);
        
        if ($result) {
            $userId = $pdo->lastInsertId();
            error_log("Direct insertion successful, user ID: " . $userId);
        } else {
            throw new Exception("Failed to insert user record");
        }
    }

    if ($userId) {
        // Generate unique student ID
        $studentId = 'STU' . date('Y') . str_pad(mt_rand(1, 999), 3, '0', STR_PAD_LEFT);
        
        // Ensure student ID is unique
        $retryCount = 0;
        $maxRetries = 5;
        while ($retryCount < $maxRetries) {
            $checkStmt = $pdo->prepare("SELECT id FROM student_profiles WHERE student_id = ?");
            $checkStmt->execute([$studentId]);
            if (!$checkStmt->fetch()) {
                break; // ID is unique
            }
            $studentId = 'STU' . date('Y') . str_pad(mt_rand(1, 999), 3, '0', STR_PAD_LEFT);
            $retryCount++;
        }

        error_log("Generated student ID: " . $studentId);

        // Create student profile
        $profileSql = "INSERT INTO student_profiles 
                      (user_id, student_id, full_name, email, phone, program_type, enrollment_date, created_at, updated_at) 
                      VALUES (?, ?, ?, ?, ?, 'scholarship', CURDATE(), NOW(), NOW())";
        
        $profileStmt = $pdo->prepare($profileSql);
        $profileResult = $profileStmt->execute([
            $userId, 
            $studentId, 
            $userData['full_name'], 
            $userData['email'],
            $userData['phone']
        ]);

        if (!$profileResult) {
            throw new Exception("Failed to create student profile");
        }

        // Commit transaction
        $pdo->commit();
        error_log("Transaction committed successfully");

        // Log activity
        logActivity('student_created', "Created student: {$userData['full_name']} ({$userData['username']}) with ID: $studentId");

        error_log("=== STUDENT CREATION SUCCESS ===");
        echo json_encode([
            'success' => true, 
            'message' => 'Student created successfully',
            'student_id' => $studentId,
            'user_id' => $userId
        ]);
    } else {
        // Rollback if user creation failed
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        error_log("User creation failed - no user ID returned");
        echo json_encode(['success' => false, 'message' => 'Failed to create student user account']);
    }
    
} catch (PDOException $e) {
    // Rollback transaction on database error
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
        error_log("Transaction rolled back due to PDOException");
    }
    
    error_log("Student creation PDO error: " . $e->getMessage());
    error_log("PDO error code: " . $e->getCode());
    error_log("PDO error info: " . print_r($pdo->errorInfo(), true));
    
    // Check for specific database errors
    if (strpos($e->getMessage(), 'Duplicate entry') !== false) {
        echo json_encode(['success' => false, 'message' => 'Username or email already exists']);
    } else if (strpos($e->getMessage(), 'foreign key constraint') !== false) {
        echo json_encode(['success' => false, 'message' => 'Database constraint error']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
    
} catch (Exception $e) {
    // Rollback transaction on any other error
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
        error_log("Transaction rolled back due to Exception");
    }
    
    error_log("Student creation general error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}

error_log("=== STUDENT CREATION ENDED ===");
?>