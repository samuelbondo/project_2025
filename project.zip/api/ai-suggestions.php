<?php
session_start();
require_once '../includes/config.php';

// Check if AIAssistant class exists, if not create a simple fallback
if (file_exists('../includes/classes/AIAssistant.php')) {
    require_once '../includes/classes/AIAssistant.php';
    
    header('Content-Type: application/json');
    
    try {
        // Check if user is logged in
        if (!isset($_SESSION['user_id'])) {
            throw new Exception('Authentication required');
        }
        
        // Get input data
        $input = json_decode(file_get_contents('php://input'), true);
        $title = $input['title'] ?? '';
        $description = $input['description'] ?? '';
        $projectType = $input['project_type'] ?? '';
        
        // Initialize AI assistant
        $aiAssistant = new AIAssistant($pdo);
        
        // Generate suggestions
        $suggestions = $aiAssistant->generateProjectSuggestions($title, $description, $projectType);
        
        echo json_encode([
            'success' => true,
            'suggestions' => $suggestions
        ]);
        
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
} else {
    // Fallback suggestions without the class
    header('Content-Type: application/json');
    
    $input = json_decode(file_get_contents('php://input'), true);
    $title = $input['title'] ?? '';
    $description = $input['description'] ?? '';
    $projectType = $input['project_type'] ?? '';
    
    $fallbackSuggestions = [
        'title' => $title ? "Enhanced: $title" : "Consider a clear, action-oriented title",
        'description' => $description ? "Build on your idea by focusing on specific goals and outcomes" : "Describe your project's purpose, methods, and expected impact",
        'skills' => ['Planning', 'Research', 'Communication', 'Documentation'],
        'milestones' => [
            ['title' => 'Project Planning', 'description' => 'Define objectives and setup'],
            ['title' => 'Execution', 'description' => 'Implement main activities'],
            ['title' => 'Review', 'description' => 'Evaluate progress and outcomes']
        ],
        'tips' => [
            'Set clear, measurable goals',
            'Break the project into manageable phases',
            'Document your process',
            'Seek feedback regularly'
        ]
    ];
    
    echo json_encode([
        'success' => true,
        'suggestions' => $fallbackSuggestions
    ]);
}
?>