<?php
session_start();
header('Content-Type: application/json');

// Include required files
require_once '../../includes/config.php';
require_once '../../includes/auth.php';
require_once '../../includes/ApplicationManager.php';
require_once '../../includes/functions.php';

// Check if user is logged in and has appropriate role
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Authentication required']);
    exit;
}

// Check user role
$auth = new Auth($pdo);
if (!$auth->checkRole(['super_admin', 'admin', 'reviewer'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Insufficient permissions']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// Get and validate input
$input = json_decode(file_get_contents('php://input'), true);
$applicationId = $input['application_id'] ?? null;
$status = $input['status'] ?? null;
$reviewNotes = $input['notes'] ?? null;
$reviewerId = $_SESSION['user_id'];

// Validate required fields
if (!$applicationId || !$status) {
    http_response_code(400);
    echo json_encode([
        'success' => false, 
        'message' => 'Missing required fields: application_id and status are required',
        'received' => ['application_id' => $applicationId, 'status' => $status]
    ]);
    exit;
}

// Validate status
$validStatuses = ['draft', 'submitted', 'under_review', 'approved', 'rejected', 'waitlisted'];
if (!in_array($status, $validStatuses)) {
    http_response_code(400);
    echo json_encode([
        'success' => false, 
        'message' => 'Invalid status. Must be one of: ' . implode(', ', $validStatuses),
        'received_status' => $status
    ]);
    exit;
}

try {
    // Verify application exists and get current status
    $applicationManager = new ApplicationManager($pdo);
    $application = $applicationManager->getApplicationById($applicationId);
    
    if (!$application) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Application not found']);
        exit;
    }
    
    // Store old values for audit log
    $oldValues = [
        'status' => $application['status'],
        'reviewer_id' => $application['reviewer_id'],
        'review_notes' => $application['review_notes']
    ];
    
    // Update application status
    $success = $applicationManager->updateApplicationStatus($applicationId, $status, $reviewerId, $reviewNotes);
    
    if ($success) {
        // Log the action
        $newValues = [
            'status' => $status,
            'reviewer_id' => $reviewerId,
            'review_notes' => $reviewNotes,
            'reviewed_at' => date('Y-m-d H:i:s')
        ];
        
        logAction($pdo, $reviewerId, 'update_application_status', 'applications', $applicationId, $oldValues, $newValues);
        
        // If application is approved, you might want to trigger additional actions
        if ($status === 'approved') {
            // Example: Send approval email, create user account, etc.
            // triggerApprovalActions($applicationId, $application);
        }
        
        // If application is rejected, you might want to send rejection email
        if ($status === 'rejected') {
            // triggerRejectionActions($applicationId, $application);
        }
        
        echo json_encode([
            'success' => true, 
            'message' => 'Application status updated successfully',
            'data' => [
                'application_id' => $applicationId,
                'new_status' => $status,
                'reviewer_id' => $reviewerId,
                'reviewed_at' => date('Y-m-d H:i:s')
            ]
        ]);
    } else {
        throw new Exception('Database update failed');
    }
    
} catch (Exception $e) {
    error_log("Application status update error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false, 
        'message' => 'Server error: ' . $e->getMessage(),
        'debug_info' => [
            'application_id' => $applicationId,
            'status' => $status,
            'reviewer_id' => $reviewerId
        ]
    ]);
}
?>