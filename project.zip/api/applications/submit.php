<?php
session_start();
include '../../includes/config.php';

header('Content-Type: application/json');

// Enable error logging for debugging
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Please log in to submit an application']);
    exit;
}

// Log submission attempt
error_log("=== APPLICATION SUBMISSION STARTED ===");
error_log("User ID: " . $_SESSION['user_id']);

try {
    // Validate required fields
    $required_fields = [
        'program_type', 
        'academic_level', 
        'institution_applying', 
        'intended_major',
        'academic_history' // Added this as required based on your form
    ];
    
    $missing_fields = [];
    foreach ($required_fields as $field) {
        if (empty(trim($_POST[$field] ?? ''))) {
            $missing_fields[] = $field;
        }
    }
    
    if (!empty($missing_fields)) {
        throw new Exception("Please fill in all required fields: " . implode(', ', $missing_fields));
    }
    
    error_log("Basic validation passed");

    // Validate program type
    $valid_program_types = ['scholarship', 'housing', 'community', 'mentorship'];
    if (!in_array($_POST['program_type'], $valid_program_types)) {
        throw new Exception('Invalid program type selected');
    }

    // Validate academic level
    $valid_academic_levels = ['high_school', 'undergraduate', 'masters', 'phd'];
    if (!in_array($_POST['academic_level'], $valid_academic_levels)) {
        throw new Exception('Invalid academic level selected');
    }

    // Validate family income
    if (!empty($_POST['family_income'])) {
        $income = floatval($_POST['family_income']);
        if ($income < 0 || $income > 1000000) {
            throw new Exception('Please enter a valid family income amount (0 - 1,000,000)');
        }
    }

    // Check if program exists and is active
    $program_check = $pdo->prepare("
        SELECT id, name, application_deadline, max_applicants, status
        FROM programs 
        WHERE type = ? AND status = 'active'
    ");
    $program_check->execute([$_POST['program_type']]);
    $program = $program_check->fetch(PDO::FETCH_ASSOC);
    
    if (!$program) {
        throw new Exception('Selected program is not currently available for applications');
    }
    
    // Check application deadline
    if ($program['application_deadline'] && strtotime($program['application_deadline']) < time()) {
        throw new Exception('Application deadline has passed for this program');
    }
    
    // Check max applicants
    if ($program['max_applicants']) {
        $count_stmt = $pdo->prepare("
            SELECT COUNT(*) FROM applications 
            WHERE program_type = ? AND status IN ('submitted', 'under_review', 'approved')
        ");
        $count_stmt->execute([$_POST['program_type']]);
        $applicant_count = $count_stmt->fetchColumn();
        
        if ($applicant_count >= $program['max_applicants']) {
            throw new Exception('This program has reached the maximum number of applicants');
        }
    }

    // Generate unique application code
    $application_code = 'APP' . date('Ymd') . strtoupper(substr($_POST['program_type'], 0, 3)) . str_pad(mt_rand(1, 9999), 4, '0', STR_PAD_LEFT);
    error_log("Generated application code: " . $application_code);

    // Start transaction
    $pdo->beginTransaction();
    
    try {
        // Insert application data - CORRECTED VERSION
        $stmt = $pdo->prepare("
            INSERT INTO applications (
                application_code, 
                user_id, 
                program_type, 
                academic_level, 
                institution_applying, 
                intended_major, 
                academic_history, 
                family_income, 
                financial_needs, 
                personal_statement,
                reference_letters,
                documents,
                application_type,
                status, 
                submitted_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'submitted', NOW())
        ");
        
        // Prepare data for insertion
        $family_income = !empty($_POST['family_income']) ? floatval($_POST['family_income']) : null;
        $financial_needs = $_POST['financial_needs'] ?? '';
        $personal_statement = $_POST['personal_statement'] ?? '';
        $academic_history = $_POST['academic_history'] ?? '';
        
        // For file fields, we'll update after upload
        $reference_letters_json = null;
        $documents_json = null;
        
        error_log("Inserting application data...");
        
        $result = $stmt->execute([
            $application_code,
            $_SESSION['user_id'],
            $_POST['program_type'],
            $_POST['academic_level'],
            $_POST['institution_applying'],
            $_POST['intended_major'],
            $academic_history, // Fixed: using actual text content, not boolean
            $family_income,
            $financial_needs,
            $personal_statement,
            $reference_letters_json,
            $documents_json,
            $_POST['program_type'] // application_type
        ]);

        if (!$result) {
            $errorInfo = $stmt->errorInfo();
            error_log("Database insertion error: " . print_r($errorInfo, true));
            throw new Exception('Failed to save application: ' . ($errorInfo[2] ?? 'Unknown database error'));
        }

        $application_id = $pdo->lastInsertId();
        error_log("Application inserted successfully with ID: " . $application_id);

        // Handle file uploads (make them optional)
        $uploaded_documents = [];
        $uploaded_references = [];
        
        // Create upload directory
        $upload_dir = "../../uploads/applications/{$application_id}/";
        if (!is_dir($upload_dir)) {
            if (!mkdir($upload_dir, 0755, true)) {
                error_log("Failed to create upload directory: " . $upload_dir);
            } else {
                error_log("Created upload directory: " . $upload_dir);
            }
        }

        // File upload function
        function uploadApplicationFiles($files, $upload_dir) {
            $uploaded = [];
            if (is_array($files['name'])) {
                for ($i = 0; $i < count($files['name']); $i++) {
                    if ($files['error'][$i] === UPLOAD_ERR_OK && !empty($files['name'][$i])) {
                        // Validate file type
                        $allowed_types = ['application/pdf', 'image/jpeg', 'image/png', 'image/jpg', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
                        $file_type = mime_content_type($files['tmp_name'][$i]);
                        
                        if (!in_array($file_type, $allowed_types)) {
                            error_log("Invalid file type: " . $file_type . " for file: " . $files['name'][$i]);
                            continue; // Skip invalid files
                        }
                        
                        // Validate file size (5MB max)
                        if ($files['size'][$i] > 5 * 1024 * 1024) {
                            error_log("File too large: " . $files['name'][$i] . " (" . $files['size'][$i] . " bytes)");
                            continue; // Skip oversized files
                        }
                        
                        $filename = uniqid() . '_' . preg_replace('/[^a-zA-Z0-9._-]/', '_', $files['name'][$i]);
                        $file_path = $upload_dir . $filename;
                        
                        if (move_uploaded_file($files['tmp_name'][$i], $file_path)) {
                            $uploaded[] = [
                                'name' => $files['name'][$i],
                                'path' => $filename,
                                'size' => $files['size'][$i],
                                'type' => $file_type
                            ];
                            error_log("Successfully uploaded: " . $filename);
                        } else {
                            error_log("Failed to move uploaded file: " . $files['name'][$i]);
                        }
                    }
                }
            }
            return $uploaded;
        }
        
        // Upload documents
        if (isset($_FILES['documents']) && !empty($_FILES['documents']['name'][0])) {
            error_log("Processing documents upload...");
            $uploaded_documents = uploadApplicationFiles($_FILES['documents'], $upload_dir);
            $documents_json = !empty($uploaded_documents) ? json_encode($uploaded_documents, JSON_UNESCAPED_UNICODE) : null;
            error_log("Documents uploaded: " . count($uploaded_documents));
        } else {
            error_log("No documents uploaded or documents field not set");
        }
        
        // Upload reference letters
        if (isset($_FILES['reference_letters']) && !empty($_FILES['reference_letters']['name'][0])) {
            error_log("Processing reference letters upload...");
            $uploaded_references = uploadApplicationFiles($_FILES['reference_letters'], $upload_dir);
            $reference_letters_json = !empty($uploaded_references) ? json_encode($uploaded_references, JSON_UNESCAPED_UNICODE) : null;
            error_log("Reference letters uploaded: " . count($uploaded_references));
        } else {
            error_log("No reference letters uploaded or reference_letters field not set");
        }
        
        // Update application with file info if any files were uploaded
        if (!empty($uploaded_documents) || !empty($uploaded_references)) {
            $update_stmt = $pdo->prepare("
                UPDATE applications 
                SET documents = ?, reference_letters = ? 
                WHERE id = ?
            ");
            
            $update_result = $update_stmt->execute([$documents_json, $reference_letters_json, $application_id]);
            if ($update_result) {
                error_log("Files updated successfully for application ID: " . $application_id);
            } else {
                $errorInfo = $update_stmt->errorInfo();
                error_log("File update failed for application ID: " . $application_id . " - Error: " . print_r($errorInfo, true));
            }
        } else {
            error_log("No files to update for application ID: " . $application_id);
        }

        // Store additional details if provided in application_details table
        if (!empty($_POST['additional_details'])) {
            $details_data = json_decode($_POST['additional_details'], true);
            if ($details_data && is_array($details_data)) {
                $details_stmt = $pdo->prepare("
                    INSERT INTO application_details (application_id, section, field_name, field_value) 
                    VALUES (?, ?, ?, ?)
                ");
                
                foreach ($details_data as $section => $fields) {
                    if (is_array($fields)) {
                        foreach ($fields as $field_name => $field_value) {
                            if (!empty(trim($field_value))) {
                                $details_stmt->execute([
                                    $application_id,
                                    $section,
                                    $field_name,
                                    $field_value
                                ]);
                            }
                        }
                    }
                }
                error_log("Additional details stored for application ID: " . $application_id);
            }
        }

        // Commit transaction
        $pdo->commit();
        
        error_log("=== APPLICATION SUBMISSION COMPLETED SUCCESSFULLY ===");
        error_log("Application ID: {$application_id}, Code: {$application_code}");
        
        // Return success response
        echo json_encode([
            'success' => true,
            'message' => 'Application submitted successfully!',
            'application_code' => $application_code,
            'application_id' => $application_id,
            'redirect' => '../../portal/student/dashboard.php' // Fixed redirect path
        ]);

    } catch (Exception $e) {
        $pdo->rollBack();
        error_log("Transaction rolled back due to error: " . $e->getMessage());
        throw $e;
    }
    
} catch (Exception $e) {
    error_log("=== APPLICATION SUBMISSION FAILED ===");
    error_log("Error: " . $e->getMessage());
    error_log("POST data: " . print_r($_POST, true));
    error_log("FILES data: " . print_r($_FILES, true));
    
    http_response_code(400);
    echo json_encode([
        'success' => false, 
        'message' => $e->getMessage()
    ]);
}
?>