<?php
// Set headers FIRST to prevent any output before JSON
header('Content-Type: application/json');
ob_start(); // Start output buffering

// Turn off display errors
ini_set('display_errors', 0);
error_reporting(E_ALL);

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Function to clean output buffer and send JSON
function sendJsonResponse($data) {
    ob_end_clean();
    echo json_encode($data);
    exit;
}

try {
    // Check if it's a POST request
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Invalid request method.');
    }

    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || !isset($_SESSION['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        throw new Exception('Security error. Please refresh the page and try again.');
    }

    // Get and sanitize form data
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');
    $newsletter = isset($_POST['newsletter']) ? 1 : 0;
    
    // Server-side validation
    $errors = [];
    
    if (empty($name) || strlen($name) < 2) {
        $errors[] = 'Please enter a valid name (minimum 2 characters)';
    }
    
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Please enter a valid email address';
    }
    
    if (empty($subject)) {
        $errors[] = 'Please select a subject';
    }
    
    if (empty($message) || strlen($message) < 10) {
        $errors[] = 'Please enter a message (minimum 10 characters)';
    }
    
    if (!empty($errors)) {
        http_response_code(400);
        sendJsonResponse(['success' => false, 'message' => implode('<br>', $errors)]);
    }
    
    // Include configuration files
    $configPath = __DIR__ . '/../../includes/config.php';
    $mailerPath = __DIR__ . '/../../includes/phpmailer-setup.php';
    
    $configIncluded = file_exists($configPath);
    $mailerAvailable = file_exists($mailerPath);
    
    if ($configIncluded) {
        require_once $configPath;
    }
    
    $contact_id = null;
    $db_success = false;
    
    // Save to database
    if ($configIncluded && isset($pdo)) {
        try {
            $stmt = $pdo->prepare("
                INSERT INTO contacts (name, email, phone, subject, message, ip_address, status, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, 'new', NOW())
            ");
            
            $ip_address = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
            $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';
            
            $stmt->execute([$name, $email, $phone, $subject, $message, $ip_address]);
            $contact_id = $pdo->lastInsertId();
            $db_success = true;
            
            // Handle newsletter subscription
            if ($newsletter) {
                try {
                    $check_stmt = $pdo->prepare("SELECT id FROM subscribers WHERE email = ?");
                    $check_stmt->execute([$email]);
                    $existing_subscriber = $check_stmt->fetch();
                    
                    if ($existing_subscriber) {
                        $update_stmt = $pdo->prepare("
                            UPDATE subscribers 
                            SET name = ?, subscription_type = 'both', is_active = 1
                            WHERE email = ?
                        ");
                        $update_stmt->execute([$name, $email]);
                    } else {
                        $token = bin2hex(random_bytes(32));
                        $subscriber_stmt = $pdo->prepare("
                            INSERT INTO subscribers (email, name, subscription_type, is_active, token, subscribed_at) 
                            VALUES (?, ?, 'both', 1, ?, NOW())
                        ");
                        $subscriber_stmt->execute([$email, $name, $token]);
                    }
                } catch (PDOException $e) {
                    error_log("Newsletter subscription error: " . $e->getMessage());
                }
            }
            
        } catch (PDOException $e) {
            error_log("Database error: " . $e->getMessage());
        }
    }
    
    // Prepare contact data
    $contact_data = [
        'id' => $contact_id ?: 'CONTACT-' . time(),
        'name' => $name,
        'email' => $email,
        'phone' => $phone,
        'subject' => $subject,
        'message' => $message,
        'date' => date('F j, Y \a\t g:i A'),
        'ip_address' => $ip_address ?? 'unknown',
        'user_agent' => $user_agent ?? 'unknown'
    ];
    
    // Send professional emails using FIXED PHPMailer
    $emails_sent = false;
    
    if ($mailerAvailable) {
        try {
            require_once $mailerPath;
            
            $admin_sent = sendAdminNotification($contact_data);
            $auto_reply_sent = sendAutoReply($contact_data);
            $emails_sent = $admin_sent && $auto_reply_sent;
            
            error_log("PHPMailer results - Admin: " . ($admin_sent ? 'sent' : 'failed') . 
                     ", Auto-reply: " . ($auto_reply_sent ? 'sent' : 'failed'));
                     
        } catch (Exception $e) {
            error_log("PHPMailer error: " . $e->getMessage());
            $emails_sent = sendBasicEmailsFallback($contact_data);
        }
    } else {
        // Fallback to basic email
        error_log("PHPMailer not available, using fallback");
        $emails_sent = sendBasicEmailsFallback($contact_data);
    }
    
    // Prepare success message
    if ($emails_sent) {
        $success_message = 'Thank you for your message! We have sent a confirmation email to your inbox.';
    } else {
        $success_message = 'Thank you for your message! We will get back to you within 24 hours.';
    }
    
    sendJsonResponse([
        'success' => true, 
        'message' => $success_message,
        'contact_id' => $contact_id,
        'db_success' => $db_success,
        'emails_sent' => $emails_sent
    ]);
    
} catch (Exception $e) {
    error_log("Contact form error: " . $e->getMessage());
    
    http_response_code(500);
    sendJsonResponse([
        'success' => false, 
        'message' => 'An error occurred. Please try again later.'
    ]);
}

// Fallback function if PHPMailer fails
function sendBasicEmailsFallback($contact_data) {
    try {
        // Admin email (HTML)
        $admin_subject = "New Contact Form: " . $contact_data['subject'];
        $admin_html = "
        <!DOCTYPE html>
        <html>
        <head>
            <style>body { font-family: Arial, sans-serif; line-height: 1.6; }</style>
        </head>
        <body>
            <h2>New Contact Form Submission</h2>
            <p><strong>Contact ID:</strong> #{$contact_data['id']}</p>
            <p><strong>Name:</strong> {$contact_data['name']}</p>
            <p><strong>Email:</strong> {$contact_data['email']}</p>
            <p><strong>Subject:</strong> {$contact_data['subject']}</p>
            <p><strong>Message:</strong><br>" . nl2br(htmlspecialchars($contact_data['message'])) . "</p>
        </body>
        </html>
        ";
        
        $admin_headers = "From: REACH Organization <no-reply@youngdevsofficial.com>\r\n";
        $admin_headers .= "Reply-To: {$contact_data['email']}\r\n";
        $admin_headers .= "Content-Type: text/html; charset=UTF-8\r\n";
        
        $admin_sent = mail('info@reach.org', $admin_subject, $admin_html, $admin_headers);
        
        // Auto-reply to user
        $user_subject = "Thank You for Contacting REACH Organization";
        $user_message = "
        Dear {$contact_data['name']},
        
        Thank you for contacting REACH Organization!
        
        We have received your message about \"{$contact_data['subject']}\" and will respond within 24-48 hours.
        
        Reference: #{$contact_data['id']}
        
        Best regards,
        REACH Organization Team
        ";
        
        $user_headers = "From: REACH Organization <no-reply@youngdevsofficial.com>\r\n";
        $user_headers .= "Reply-To: info@reach.org\r\n";
        $user_headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
        
        $user_sent = mail($contact_data['email'], $user_subject, $user_message, $user_headers);
        
        return $admin_sent && $user_sent;
        
    } catch (Exception $e) {
        error_log("Fallback email error: " . $e->getMessage());
        return false;
    }
}
?>