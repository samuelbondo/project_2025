<?php
header('Content-Type: application/json');
include '../../includes/config.php';
include '../../includes/auth.php';

$auth->checkRole(['super_admin', 'admin', 'partnership_manager']);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$partnerData = [
    'name' => $_POST['name'],
    'website' => $_POST['website'] ?? null,
    'contact_person' => $_POST['contact_person'] ?? null,
    'contact_email' => $_POST['contact_email'] ?? null,
    'partnership_type' => $_POST['partnership_type'] ?? 'corporate',
    'status' => $_POST['status'] ?? 'active',
    'agreement_date' => $_POST['agreement_date'] ?? null
];

try {
    $stmt = $pdo->prepare("
        INSERT INTO partners (name, website, contact_person, contact_email, partnership_type, status, agreement_date)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    
    $success = $stmt->execute([
        $partnerData['name'],
        $partnerData['website'],
        $partnerData['contact_person'],
        $partnerData['contact_email'],
        $partnerData['partnership_type'],
        $partnerData['status'],
        $partnerData['agreement_date']
    ]);
    
    if ($success) {
        logAction($pdo, $_SESSION['user_id'], 'create_partner', 'partners', $pdo->lastInsertId(), null, $partnerData);
        echo json_encode(['success' => true, 'message' => 'Partner created successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to create partner']);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}
?>