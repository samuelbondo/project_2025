<?php
header('Content-Type: application/json');
include '../../includes/config.php';
include '../../includes/auth.php';

$auth->checkRole(['super_admin', 'admin', 'finance_manager']);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$donationId = $input['donation_id'] ?? null;
$status = $input['status'] ?? null;

if (!$donationId || !$status) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Missing required fields']);
    exit;
}

try {
    $donationManager = new DonationManager($pdo);
    $success = $donationManager->updatePaymentStatus($donationId, $status);
    
    if ($success) {
        logAction($pdo, $_SESSION['user_id'], 'update_donation_status', 'donations', $donationId, null, ['status' => $status]);
        echo json_encode(['success' => true, 'message' => 'Donation status updated']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update donation status']);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}
?>