<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/database.php';
require_once '../includes/auth.php';

header('Content-Type: application/json');

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 0);

// Check if user is logged in and is a student
if (!$auth->isLoggedIn() || !$auth->hasRole('student')) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit;
}

// Validate CSRF token
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Security token invalid']);
    exit;
}

$currentUser = $auth->getCurrentUser();
$studentId = $currentUser['id'];

class ProjectCreationAPI {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    public function createProject($data, $files = []) {
        try {
            $this->pdo->beginTransaction();
            
            // Validate required fields
            $validationErrors = $this->validateProjectData($data);
            if (!empty($validationErrors)) {
                return ['success' => false, 'errors' => $validationErrors];
            }
            
            // Handle file upload
            $featuredImagePath = null;
            if (!empty($files['featured_image'])) {
                $featuredImagePath = $this->handleFileUpload($files['featured_image']);
                if (!$featuredImagePath) {
                    return ['success' => false, 'message' => 'Invalid file upload'];
                }
            }
            
            // Generate slug
            $slug = $this->generateSlug($data['title']);
            
            // Insert main project
            $projectId = $this->insertProject($data, $slug, $featuredImagePath, $studentId);
            if (!$projectId) {
                throw new Exception('Failed to create project');
            }
            
            // Insert deliverables
            if (!empty($data['deliverables'])) {
                $this->insertDeliverables($projectId, $data['deliverables']);
            }
            
            // Insert milestones and tasks
            if (!empty($data['milestones'])) {
                $this->insertMilestones($projectId, $data['milestones']);
            }
            
            // Insert resources
            if (!empty($data['resources'])) {
                $this->insertResources($projectId, $data['resources'], $studentId);
            }
            
            // Log activity
            $this->logProjectCreation($projectId, $studentId);
            
            $this->pdo->commit();
            
            return [
                'success' => true, 
                'project_id' => $projectId,
                'message' => 'Project created successfully and submitted for approval'
            ];
            
        } catch (Exception $e) {
            $this->pdo->rollBack();
            error_log("Project creation error: " . $e->getMessage());
            return ['success' => false, 'message' => 'Database error: ' . $e->getMessage()];
        }
    }
    
    private function validateProjectData($data) {
        $errors = [];
        
        $required = [
            'title' => 'Project title',
            'description' => 'Project description', 
            'project_type' => 'Project type',
            'start_date' => 'Start date',
            'end_date' => 'End date'
        ];
        
        foreach ($required as $field => $label) {
            if (empty(trim($data[$field] ?? ''))) {
                $errors[$field] = "$label is required";
            }
        }
        
        // Validate dates
        if (!empty($data['start_date']) && !empty($data['end_date'])) {
            $start = strtotime($data['start_date']);
            $end = strtotime($data['end_date']);
            
            if ($end <= $start) {
                $errors['end_date'] = 'End date must be after start date';
            }
        }
        
        return $errors;
    }
    
    private function generateSlug($title) {
        $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $title)));
        $slug = substr($slug, 0, 100);
        
        // Check if slug exists and make unique
        $baseSlug = $slug;
        $counter = 1;
        
        while ($this->slugExists($slug)) {
            $slug = $baseSlug . '-' . $counter;
            $counter++;
        }
        
        return $slug;
    }
    
    private function slugExists($slug) {
        $stmt = $this->pdo->prepare("SELECT id FROM student_projects WHERE slug = ?");
        $stmt->execute([$slug]);
        return $stmt->fetch() !== false;
    }
    
    private function handleFileUpload($file) {
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        $maxSize = 5 * 1024 * 1024;
        
        if ($file['error'] !== UPLOAD_ERR_OK) {
            return null;
        }
        
        if (!in_array($file['type'], $allowedTypes)) {
            return null;
        }
        
        if ($file['size'] > $maxSize) {
            return null;
        }
        
        $uploadDir = '../uploads/projects/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        
        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = uniqid() . '_' . time() . '.' . $extension;
        $filepath = $uploadDir . $filename;
        
        if (move_uploaded_file($file['tmp_name'], $filepath)) {
            return $filepath;
        }
        
        return null;
    }
    
    private function insertProject($data, $slug, $featuredImagePath, $studentId) {
        $sql = "INSERT INTO student_projects (
            title, slug, description, full_description, student_id, project_type, 
            status, priority, start_date, end_date, budget, skills_used, technologies,
            challenges, is_public, featured_image, approved
        ) VALUES (?, ?, ?, ?, ?, ?, 'planning', ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)";
        
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([
            trim($data['title']),
            $slug,
            trim($data['description']),
            $data['full_description'] ?? '',
            $studentId,
            $data['project_type'],
            $data['priority'] ?? 'medium',
            $data['start_date'],
            $data['end_date'],
            $data['budget'] ?? 0,
            $data['skills_used'] ?? '',
            $data['technologies'] ?? '',
            $data['challenges'] ?? '',
            $data['is_public'] ?? 0,
            $featuredImagePath
        ]);
        
        return $this->pdo->lastInsertId();
    }
    
    private function insertDeliverables($projectId, $deliverables) {
        $sql = "INSERT INTO project_deliverables (project_id, title, description, submitted_at) VALUES (?, ?, '', NOW())";
        $stmt = $this->pdo->prepare($sql);
        
        foreach ($deliverables as $deliverable) {
            if (!empty(trim($deliverable))) {
                $stmt->execute([$projectId, trim($deliverable)]);
            }
        }
    }
    
    private function insertMilestones($projectId, $milestones) {
        $milestoneSql = "INSERT INTO project_milestones (project_id, title, description, due_date, status, order_index) VALUES (?, ?, ?, ?, 'pending', ?)";
        $taskSql = "INSERT INTO project_tasks (milestone_id, title, description, due_date, priority, status) VALUES (?, ?, ?, ?, ?, 'todo')";
        
        $milestoneStmt = $this->pdo->prepare($milestoneSql);
        $taskStmt = $this->pdo->prepare($taskSql);
        
        foreach ($milestones as $index => $milestoneData) {
            if (empty(trim($milestoneData['title']))) continue;
            
            $milestoneStmt->execute([
                $projectId,
                trim($milestoneData['title']),
                $milestoneData['description'] ?? '',
                $milestoneData['due_date'],
                $index
            ]);
            
            $milestoneId = $this->pdo->lastInsertId();
            
            if (!empty($milestoneData['tasks'])) {
                foreach ($milestoneData['tasks'] as $taskData) {
                    if (!empty(trim($taskData['title']))) {
                        $taskStmt->execute([
                            $milestoneId,
                            trim($taskData['title']),
                            $taskData['description'] ?? '',
                            $taskData['due_date'] ?? null,
                            $taskData['priority'] ?? 'medium'
                        ]);
                    }
                }
            }
        }
    }
    
    private function insertResources($projectId, $resources, $studentId) {
        $typeMapping = [
            'financial' => 'funding',
            'material' => 'tool',
            'human' => 'contact'
        ];
        
        $sql = "INSERT INTO project_resources (project_id, resource_type, title, description, uploaded_by, is_public) VALUES (?, ?, ?, ?, ?, 1)";
        $stmt = $this->pdo->prepare($sql);
        
        foreach ($resources as $type => $resourceList) {
            $mappedType = $typeMapping[$type] ?? 'document';
            
            foreach ($resourceList as $resource) {
                if (!empty(trim($resource['title']))) {
                    $description = '';
                    if ($type === 'financial') {
                        $description = 'Budget: $' . ($resource['amount'] ?? 0);
                    }
                    
                    $stmt->execute([
                        $projectId,
                        $mappedType,
                        trim($resource['title']),
                        $description,
                        $studentId
                    ]);
                }
            }
        }
    }
    
    private function logProjectCreation($projectId, $studentId) {
        // Log to activity_log
        try {
            $sql = "INSERT INTO activity_log (user_id, action, description, ip_address) 
                    VALUES (?, 'project_created', ?, ?)";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([
                $studentId,
                "Created new project with ID: $projectId",
                $_SERVER['REMOTE_ADDR']
            ]);
        } catch (Exception $e) {
            error_log("Activity log error: " . $e->getMessage());
        }
        
        // Notify admins
        $this->notifyAdmins($projectId);
    }
    
    private function notifyAdmins($projectId) {
        try {
            $sql = "INSERT INTO notifications (user_id, title, message, type) 
                    SELECT id, 'New Project Submission', 'A student has submitted a new project for review', 'info'
                    FROM users WHERE role IN ('admin', 'super_admin') AND is_active = 1";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute();
        } catch (Exception $e) {
            error_log("Notification error: " . $e->getMessage());
        }
    }
}

// Process the request
try {
    $api = new ProjectCreationAPI($pdo);
    $result = $api->createProject($_POST, $_FILES);
    
    if ($result['success']) {
        unset($_SESSION['csrf_token']);
    }
    
    echo json_encode($result);
    
} catch (Exception $e) {
    error_log("API Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false, 
        'message' => 'Internal server error'
    ]);
}
?>