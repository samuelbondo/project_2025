<?php
header('Content-Type: application/json');
include '../../includes/config.php';
include '../../includes/auth.php';

$auth->checkRole(['super_admin', 'admin', 'staff']);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$reportType = $input['report_type'] ?? null;
$dateFrom = $input['date_from'] ?? null;
$dateTo = $input['date_to'] ?? null;
$format = $input['format'] ?? 'pdf';

if (!$reportType) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Report type is required']);
    exit;
}

try {
    // Generate report based on type
    switch ($reportType) {
        case 'applications':
            $reportData = generateApplicationsReport($pdo, $dateFrom, $dateTo);
            break;
        case 'donations':
            $reportData = generateDonationsReport($pdo, $dateFrom, $dateTo);
            break;
        case 'financial':
            $reportData = generateFinancialReport($pdo, $dateFrom, $dateTo);
            break;
        case 'performance':
            $reportData = generatePerformanceReport($pdo, $dateFrom, $dateTo);
            break;
        default:
            throw new Exception('Invalid report type');
    }

    // Log report generation
    logAction($pdo, $_SESSION['user_id'], 'generate_report', 'reports', null, null, [
        'report_type' => $reportType,
        'date_range' => [$dateFrom, $dateTo],
        'format' => $format
    ]);

    echo json_encode([
        'success' => true,
        'message' => 'Report generated successfully',
        'data' => $reportData,
        'download_url' => generateDownloadUrl($reportData, $format)
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Report generation failed: ' . $e->getMessage()]);
}

function generateApplicationsReport($pdo, $dateFrom, $dateTo) {
    $where = [];
    $params = [];

    if ($dateFrom) {
        $where[] = "created_at >= ?";
        $params[] = $dateFrom;
    }
    if ($dateTo) {
        $where[] = "created_at <= ?";
        $params[] = $dateTo . ' 23:59:59';
    }

    $whereClause = $where ? 'WHERE ' . implode(' AND ', $where) : '';

    $sql = "
        SELECT 
            program_type,
            status,
            COUNT(*) as count,
            DATE(created_at) as date
        FROM applications 
        $whereClause
        GROUP BY program_type, status, DATE(created_at)
        ORDER BY date DESC, program_type
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $data = $stmt->fetchAll();

    // Generate summary statistics
    $summary = $pdo->prepare("
        SELECT 
            COUNT(*) as total_applications,
            SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved,
            SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected,
            SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
            AVG(TIMESTAMPDIFF(DAY, created_at, reviewed_at)) as avg_processing_days
        FROM applications 
        $whereClause
    ");
    $summary->execute($params);
    $summaryData = $summary->fetch();

    return [
        'type' => 'applications',
        'period' => ['from' => $dateFrom, 'to' => $dateTo],
        'summary' => $summaryData,
        'data' => $data,
        'generated_at' => date('Y-m-d H:i:s')
    ];
}

function generateDonationsReport($pdo, $dateFrom, $dateTo) {
    $where = ["payment_status = 'completed'"];
    $params = [];

    if ($dateFrom) {
        $where[] = "created_at >= ?";
        $params[] = $dateFrom;
    }
    if ($dateTo) {
        $where[] = "created_at <= ?";
        $params[] = $dateTo . ' 23:59:59';
    }

    $whereClause = 'WHERE ' . implode(' AND ', $where);

    $sql = "
        SELECT 
            donation_type,
            payment_method,
            COUNT(*) as count,
            SUM(amount) as total_amount,
            DATE(created_at) as date
        FROM donations 
        $whereClause
        GROUP BY donation_type, payment_method, DATE(created_at)
        ORDER BY date DESC, total_amount DESC
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $data = $stmt->fetchAll();

    $summary = $pdo->prepare("
        SELECT 
            COUNT(*) as total_donations,
            SUM(amount) as total_amount,
            AVG(amount) as average_donation,
            MAX(amount) as largest_donation,
            COUNT(DISTINCT donor_email) as unique_donors
        FROM donations 
        $whereClause
    ");
    $summary->execute($params);
    $summaryData = $summary->fetch();

    return [
        'type' => 'donations',
        'period' => ['from' => $dateFrom, 'to' => $dateTo],
        'summary' => $summaryData,
        'data' => $data,
        'generated_at' => date('Y-m-d H:i:s')
    ];
}

function generateFinancialReport($pdo, $dateFrom, $dateTo) {
    // This would combine donations, expenses, and other financial data
    // Implementation would depend on your specific financial tracking system
    return [
        'type' => 'financial',
        'period' => ['from' => $dateFrom, 'to' => $dateTo],
        'message' => 'Financial report generation would be implemented based on your accounting system',
        'generated_at' => date('Y-m-d H:i:s')
    ];
}

function generatePerformanceReport($pdo, $dateFrom, $dateTo) {
    // Student performance and project success metrics
    $studentPerformance = $pdo->query("
        SELECT 
            u.full_name,
            COUNT(DISTINCT sp.id) as total_projects,
            COUNT(DISTINCT sa.id) as total_achievements,
            AVG(sar.gpa) as avg_gpa,
            COUNT(DISTINCT CASE WHEN sp.status = 'completed' THEN sp.id END) as completed_projects
        FROM users u
        LEFT JOIN student_projects sp ON u.id = sp.student_id
        LEFT JOIN student_achievements sa ON u.id = sa.student_id AND sa.verified = 1
        LEFT JOIN student_academic_records sar ON u.id = sar.student_id
        WHERE u.role = 'student' AND u.status = 'active'
        GROUP BY u.id, u.full_name
        ORDER BY completed_projects DESC, avg_gpa DESC
    ")->fetchAll();

    $projectSuccess = $pdo->query("
        SELECT 
            project_type,
            COUNT(*) as total,
            SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
            AVG(budget) as avg_budget,
            AVG(TIMESTAMPDIFF(DAY, start_date, end_date)) as avg_duration
        FROM student_projects
        GROUP BY project_type
        ORDER BY completed DESC
    ")->fetchAll();

    return [
        'type' => 'performance',
        'period' => ['from' => $dateFrom, 'to' => $dateTo],
        'student_performance' => $studentPerformance,
        'project_success' => $projectSuccess,
        'generated_at' => date('Y-m-d H:i:s')
    ];
}

function generateDownloadUrl($reportData, $format) {
    // This would generate actual file and return download URL
    // For now, return a placeholder
    return '/api/reports/download/' . uniqid() . '.' . $format;
}
?>