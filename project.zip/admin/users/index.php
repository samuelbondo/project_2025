<?php
session_start();
require_once '../../includes/config.php';
require_once '../../includes/auth.php';

if (!$auth->isLoggedIn() || !$auth->hasAnyRole(['admin', 'super_admin'])) {
    header('Location: ../login.php');
    exit;
}

class UserManager {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    public function getUsersWithFilters($filters = []) {
        $where = ['1=1'];
        $params = [];
        
        // Role filter
        if (!empty($filters['role'])) {
            $where[] = "u.role = ?";
            $params[] = $filters['role'];
        }
        
        // Status filter
        if (!empty($filters['status'])) {
            $where[] = "u.status = ?";
            $params[] = $filters['status'];
        }
        
        // Search filter
        if (!empty($filters['search'])) {
            $where[] = "(u.full_name LIKE ? OR u.email LIKE ? OR u.username LIKE ?)";
            $searchTerm = "%{$filters['search']}%";
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $params[] = $searchTerm;
        }
        
        $whereClause = implode(' AND ', $where);
        
        $sql = "SELECT 
                u.*,
                sp.university,
                sp.program,
                sp.year_of_study,
                (SELECT COUNT(*) FROM student_projects WHERE student_id = u.id) as project_count,
                (SELECT COUNT(*) FROM stories WHERE author_id = u.id) as story_count,
                (SELECT COUNT(*) FROM applications WHERE user_id = u.id) as application_count,
                (SELECT COUNT(*) FROM student_achievements WHERE student_id = u.id AND verified = 1) as achievement_count
            FROM users u
            LEFT JOIN student_profiles sp ON u.id = sp.user_id
            WHERE $whereClause
            ORDER BY u.created_at DESC
            LIMIT 100";
            
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function updateUserRole($userId, $newRole, $adminId) {
        $allowedRoles = ['student', 'staff', 'admin', 'sponsor', 'volunteer'];
        if (!in_array($newRole, $allowedRoles)) return false;
        
        try {
            $sql = "UPDATE users SET role = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?";
            $stmt = $this->pdo->prepare($sql);
            $result = $stmt->execute([$newRole, $userId]);
            
            if ($result) {
                $this->logUserAction($adminId, $userId, 'role_change', "Changed role to $newRole");
            }
            
            return $result;
        } catch (Exception $e) {
            error_log("Role update error: " . $e->getMessage());
            return false;
        }
    }
    
    public function bulkUserActions($userIds, $action, $adminId) {
        $results = [];
        
        foreach ($userIds as $userId) {
            switch ($action) {
                case 'activate':
                    $results[$userId] = $this->updateUserStatus($userId, 'active', $adminId);
                    break;
                case 'deactivate':
                    $results[$userId] = $this->updateUserStatus($userId, 'inactive', $adminId);
                    break;
                case 'delete':
                    $results[$userId] = $this->softDeleteUser($userId, $adminId);
                    break;
                case 'export':
                    $results[$userId] = $this->exportUserData($userId);
                    break;
            }
        }
        
        return $results;
    }
    
    public function getUserStats() {
        $stats = [];
        
        // Total users by role
        $sql = "SELECT role, COUNT(*) as count FROM users GROUP BY role";
        $stmt = $this->pdo->query($sql);
        $stats['by_role'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Users by status
        $sql = "SELECT status, COUNT(*) as count FROM users GROUP BY status";
        $stmt = $this->pdo->query($sql);
        $stats['by_status'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // New users this month
        $sql = "SELECT COUNT(*) as count FROM users 
                WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
        $stmt = $this->pdo->query($sql);
        $stats['new_this_month'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        return $stats;
    }
    
    private function updateUserStatus($userId, $status, $adminId) {
        try {
            $sql = "UPDATE users SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?";
            $stmt = $this->pdo->prepare($sql);
            $result = $stmt->execute([$status, $userId]);
            
            if ($result) {
                $this->logUserAction($adminId, $userId, 'status_change', "Changed status to $status");
            }
            
            return $result;
        } catch (Exception $e) {
            error_log("Status update error: " . $e->getMessage());
            return false;
        }
    }
    
    private function softDeleteUser($userId, $adminId) {
        try {
            // Soft delete by deactivating and anonymizing
            $sql = "UPDATE users SET 
                    status = 'inactive', 
                    email = CONCAT('deleted_', id, '@example.com'),
                    username = CONCAT('deleted_', id),
                    full_name = 'Deleted User',
                    updated_at = CURRENT_TIMESTAMP 
                    WHERE id = ?";
            $stmt = $this->pdo->prepare($sql);
            $result = $stmt->execute([$userId]);
            
            if ($result) {
                $this->logUserAction($adminId, $userId, 'soft_delete', "User soft deleted");
            }
            
            return $result;
        } catch (Exception $e) {
            error_log("Soft delete error: " . $e->getMessage());
            return false;
        }
    }
    
    private function logUserAction($adminId, $userId, $action, $details) {
        $sql = "INSERT INTO audit_logs (user_id, action, table_name, record_id, new_values, ip_address) 
                VALUES (?, ?, 'users', ?, ?, ?)";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([
            $adminId, 
            $action, 
            $userId, 
            json_encode(['details' => $details]),
            $_SERVER['REMOTE_ADDR']
        ]);
    }
}

// Initialize User Manager
$userManager = new UserManager($pdo);
$currentUser = $auth->getCurrentUser();

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        case 'bulk_action':
            $userIds = $_POST['user_ids'] ?? [];
            $bulkAction = $_POST['bulk_action'] ?? '';
            if (!empty($userIds) && $bulkAction) {
                $results = $userManager->bulkUserActions($userIds, $bulkAction, $currentUser['id']);
                $_SESSION['flash_message'] = "Bulk action completed on " . count($userIds) . " users";
                $_SESSION['flash_type'] = 'success';
            }
            break;
            
        case 'update_role':
            $userId = $_POST['user_id'];
            $newRole = $_POST['new_role'];
            if ($userManager->updateUserRole($userId, $newRole, $currentUser['id'])) {
                $_SESSION['flash_message'] = "User role updated successfully";
                $_SESSION['flash_type'] = 'success';
            }
            break;
    }
    
    header('Location: index.php?' . http_build_query($_GET));
    exit;
}

// Get filters from URL
$filters = [
    'role' => $_GET['role'] ?? '',
    'status' => $_GET['status'] ?? '',
    'search' => $_GET['search'] ?? ''
];

// Get users and stats
$users = $userManager->getUsersWithFilters($filters);
$userStats = $userManager->getUserStats();

// Log access
logActivity('user_management_view', 'Accessed user management');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management - REACH Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .user-management {
            background-color: #f8f9fa;
            min-height: 100vh;
        }
        .user-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-left: 4px solid #007bff;
        }
        .user-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .stat-number {
            font-size: 2rem;
            font-weight: bold;
            color: #007bff;
        }
        .user-avatar {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            object-fit: cover;
        }
        .bulk-actions {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body class="user-management">
    <?php include '../partials/admin-sidebar.php'; ?>
    
    <main class="admin-main">
        <div class="container-fluid py-4">
            <!-- Header -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1><i class="fas fa-users me-2"></i>User Management</h1>
                <div>
                    <a href="export.php" class="btn btn-outline-primary">
                        <i class="fas fa-download me-2"></i>Export Users
                    </a>
                </div>
            </div>

            <!-- Flash Messages -->
            <?php if (isset($_SESSION['flash_message'])): ?>
                <div class="alert alert-<?php echo $_SESSION['flash_type'] ?> alert-dismissible fade show">
                    <?php echo $_SESSION['flash_message']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <?php unset($_SESSION['flash_message'], $_SESSION['flash_type']); ?>
            <?php endif; ?>

            <!-- User Stats -->
            <div class="user-stats">
                <?php foreach ($userStats['by_role'] as $stat): ?>
                    <div class="stat-card">
                        <div class="stat-number"><?php echo $stat['count']; ?></div>
                        <div class="stat-label"><?php echo ucfirst($stat['role']); ?>s</div>
                    </div>
                <?php endforeach; ?>
                <div class="stat-card">
                    <div class="stat-number"><?php echo $userStats['new_this_month']; ?></div>
                    <div class="stat-label">New This Month</div>
                </div>
            </div>

            <!-- Filters -->
            <div class="card mb-4">
                <div class="card-body">
                    <form method="GET" class="row g-3">
                        <div class="col-md-3">
                            <label class="form-label">Role</label>
                            <select name="role" class="form-select">
                                <option value="">All Roles</option>
                                <option value="student" <?php echo $filters['role'] === 'student' ? 'selected' : ''; ?>>Students</option>
                                <option value="staff" <?php echo $filters['role'] === 'staff' ? 'selected' : ''; ?>>Staff</option>
                                <option value="admin" <?php echo $filters['role'] === 'admin' ? 'selected' : ''; ?>>Admins</option>
                                <option value="sponsor" <?php echo $filters['role'] === 'sponsor' ? 'selected' : ''; ?>>Sponsors</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Status</label>
                            <select name="status" class="form-select">
                                <option value="">All Status</option>
                                <option value="active" <?php echo $filters['status'] === 'active' ? 'selected' : ''; ?>>Active</option>
                                <option value="inactive" <?php echo $filters['status'] === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                                <option value="suspended" <?php echo $filters['status'] === 'suspended' ? 'selected' : ''; ?>>Suspended</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Search</label>
                            <input type="text" name="search" class="form-control" 
                                   placeholder="Search by name, email, username..." 
                                   value="<?php echo htmlspecialchars($filters['search']); ?>">
                        </div>
                        <div class="col-md-2 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-search me-2"></i>Filter
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Bulk Actions -->
            <form method="POST" id="bulkForm">
                <input type="hidden" name="action" value="bulk_action">
                <div class="bulk-actions mb-4">
                    <div class="row align-items-center">
                        <div class="col-md-6">
                            <select name="bulk_action" class="form-select" required>
                                <option value="">Bulk Actions</option>
                                <option value="activate">Activate Selected</option>
                                <option value="deactivate">Deactivate Selected</option>
                                <option value="export">Export Selected</option>
                                <option value="delete">Delete Selected</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <button type="submit" class="btn btn-warning" id="bulkActionBtn">
                                <i class="fas fa-play me-2"></i>Apply
                            </button>
                            <span class="ms-2 text-muted" id="selectedCount">0 users selected</span>
                        </div>
                    </div>
                </div>

                <!-- Users List -->
                <div class="row">
                    <?php foreach ($users as $user): ?>
                        <div class="col-md-6 col-lg-4">
                            <div class="user-card">
                                <div class="d-flex justify-content-between align-items-start mb-3">
                                    <div class="d-flex align-items-center">
                                        <img src="../../assets/images/profiles/<?php echo $user['profile_picture'] ?? 'default.jpg'; ?>" 
                                             class="user-avatar me-3" alt="Avatar">
                                        <div>
                                            <h6 class="mb-1"><?php echo htmlspecialchars($user['full_name']); ?></h6>
                                            <small class="text-muted">@<?php echo htmlspecialchars($user['username']); ?></small>
                                        </div>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input user-checkbox" type="checkbox" 
                                               name="user_ids[]" value="<?php echo $user['id']; ?>">
                                    </div>
                                </div>
                                
                                <div class="user-info mb-3">
                                    <div class="mb-2">
                                        <i class="fas fa-envelope me-2 text-muted"></i>
                                        <small><?php echo htmlspecialchars($user['email']); ?></small>
                                    </div>
                                    <?php if ($user['university']): ?>
                                        <div class="mb-2">
                                            <i class="fas fa-university me-2 text-muted"></i>
                                            <small><?php echo htmlspecialchars($user['university']); ?></small>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="user-stats-small d-flex justify-content-between mb-3">
                                    <span class="badge bg-primary">
                                        <i class="fas fa-project-diagram me-1"></i>
                                        <?php echo $user['project_count']; ?> Projects
                                    </span>
                                    <span class="badge bg-success">
                                        <i class="fas fa-book me-1"></i>
                                        <?php echo $user['story_count']; ?> Stories
                                    </span>
                                    <span class="badge bg-info">
                                        <i class="fas fa-trophy me-1"></i>
                                        <?php echo $user['achievement_count']; ?> Achievements
                                    </span>
                                </div>
                                
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <span class="badge bg-<?php echo $user['status'] === 'active' ? 'success' : 'secondary'; ?>">
                                            <?php echo ucfirst($user['status']); ?>
                                        </span>
                                        <span class="badge bg-dark ms-1">
                                            <?php echo ucfirst($user['role']); ?>
                                        </span>
                                    </div>
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-outline-secondary dropdown-toggle" 
                                                type="button" data-bs-toggle="dropdown">
                                            <i class="fas fa-cog"></i>
                                        </button>
                                        <ul class="dropdown-menu">
                                            <li>
                                                <a class="dropdown-item" href="view.php?id=<?php echo $user['id']; ?>">
                                                    <i class="fas fa-eye me-2"></i>View Profile
                                                </a>
                                            </li>
                                            <li>
                                                <a class="dropdown-item" href="edit.php?id=<?php echo $user['id']; ?>">
                                                    <i class="fas fa-edit me-2"></i>Edit User
                                                </a>
                                            </li>
                                            <li><hr class="dropdown-divider"></li>
                                            <li>
                                                <form method="POST" class="d-inline">
                                                    <input type="hidden" name="action" value="update_role">
                                                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                                    <select name="new_role" class="form-select form-select-sm" onchange="this.form.submit()">
                                                        <option value="student" <?php echo $user['role'] === 'student' ? 'selected' : ''; ?>>Student</option>
                                                        <option value="staff" <?php echo $user['role'] === 'staff' ? 'selected' : ''; ?>>Staff</option>
                                                        <option value="admin" <?php echo $user['role'] === 'admin' ? 'selected' : ''; ?>>Admin</option>
                                                        <option value="sponsor" <?php echo $user['role'] === 'sponsor' ? 'selected' : ''; ?>>Sponsor</option>
                                                    </select>
                                                </form>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </form>

            <?php if (empty($users)): ?>
                <div class="text-center py-5">
                    <i class="fas fa-users fa-3x text-muted mb-3"></i>
                    <h4>No users found</h4>
                    <p class="text-muted">Try adjusting your filters or search terms</p>
                </div>
            <?php endif; ?>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Bulk actions functionality
        document.addEventListener('DOMContentLoaded', function() {
            const checkboxes = document.querySelectorAll('.user-checkbox');
            const selectedCount = document.getElementById('selectedCount');
            const bulkActionBtn = document.getElementById('bulkActionBtn');
            
            function updateSelectedCount() {
                const selected = document.querySelectorAll('.user-checkbox:checked').length;
                selectedCount.textContent = selected + ' users selected';
                bulkActionBtn.disabled = selected === 0;
            }
            
            checkboxes.forEach(checkbox => {
                checkbox.addEventListener('change', updateSelectedCount);
            });
            
            // Select all functionality
            const selectAll = document.createElement('button');
            selectAll.type = 'button';
            selectAll.className = 'btn btn-sm btn-outline-secondary me-2';
            selectAll.innerHTML = '<i class="fas fa-check-square me-1"></i>Select All';
            selectAll.addEventListener('click', function() {
                checkboxes.forEach(checkbox => checkbox.checked = true);
                updateSelectedCount();
            });
            
            document.querySelector('.bulk-actions .col-md-6').prepend(selectAll);
            
            updateSelectedCount();
        });
    </script>
</body>
</html>