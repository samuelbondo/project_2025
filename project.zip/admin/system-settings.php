<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/auth.php';

if (!$auth->isLoggedIn() || !$auth->hasRole('super_admin')) {
    header('Location: dashboard.php');
    exit;
}

class SystemSettings {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
        $this->ensureSettingsTable();
    }
    
    private function ensureSettingsTable() {
        $this->pdo->query("
            CREATE TABLE IF NOT EXISTS system_settings (
                id INT PRIMARY KEY AUTO_INCREMENT,
                setting_key VARCHAR(100) UNIQUE NOT NULL,
                setting_value TEXT,
                setting_type ENUM('string', 'integer', 'boolean', 'json') DEFAULT 'string',
                category VARCHAR(50) DEFAULT 'general',
                description TEXT,
                is_public BOOLEAN DEFAULT FALSE,
                updated_by INT,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (updated_by) REFERENCES users(id)
            )
        ");
    }
    
    public function getSettingsByCategory() {
        $sql = "SELECT * FROM system_settings ORDER BY category, setting_key";
        $stmt = $this->pdo->query($sql);
        $settings = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Group by category
        $grouped = [];
        foreach ($settings as $setting) {
            $grouped[$setting['category']][] = $setting;
        }
        
        return $grouped;
    }
    
    public function updateSetting($key, $value, $userId) {
        // Get current setting to determine type
        $current = $this->getSetting($key);
        $type = $current['setting_type'] ?? 'string';
        
        // Validate based on type
        $validatedValue = $this->validateValue($value, $type);
        
        if ($validatedValue === false) {
            throw new Exception("Invalid value for setting type: $type");
        }
        
        $sql = "INSERT INTO system_settings (setting_key, setting_value, setting_type, updated_by) 
                VALUES (?, ?, ?, ?) 
                ON DUPLICATE KEY UPDATE setting_value = ?, updated_by = ?";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([$key, $validatedValue, $type, $userId, $validatedValue, $userId]);
    }
    
    public function updateMultipleSettings($settings, $userId) {
        $results = [];
        
        foreach ($settings as $key => $value) {
            try {
                $results[$key] = $this->updateSetting($key, $value, $userId);
            } catch (Exception $e) {
                $results[$key] = false;
                error_log("Setting update failed for $key: " . $e->getMessage());
            }
        }
        
        return $results;
    }
    
    public function getDefaultSettings() {
        return [
            'general' => [
                [
                    'setting_key' => 'site_name',
                    'setting_value' => 'REACH Organization',
                    'setting_type' => 'string',
                    'description' => 'The name of your organization'
                ],
                [
                    'setting_key' => 'site_description', 
                    'setting_value' => 'Empowering students through education',
                    'setting_type' => 'string',
                    'description' => 'Brief description of your organization'
                ]
            ],
            'email' => [
                [
                    'setting_key' => 'smtp_host',
                    'setting_value' => '',
                    'setting_type' => 'string',
                    'description' => 'SMTP server hostname'
                ],
                [
                    'setting_key' => 'smtp_port',
                    'setting_value' => '587',
                    'setting_type' => 'integer',
                    'description' => 'SMTP server port'
                ]
            ],
            'features' => [
                [
                    'setting_key' => 'enable_registration',
                    'setting_value' => '1',
                    'setting_type' => 'boolean',
                    'description' => 'Allow new user registrations'
                ],
                [
                    'setting_key' => 'require_approval',
                    'setting_value' => '1', 
                    'setting_type' => 'boolean',
                    'description' => 'Require admin approval for new users'
                ]
            ]
        ];
    }
    
    private function getSetting($key) {
        $sql = "SELECT * FROM system_settings WHERE setting_key = ?";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$key]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    private function validateValue($value, $type) {
        switch ($type) {
            case 'integer':
                return filter_var($value, FILTER_VALIDATE_INT) !== false ? (int)$value : false;
            case 'boolean':
                return in_array(strtolower($value), ['1', 'true', 'yes', 'on']) ? '1' : '0';
            case 'json':
                json_decode($value);
                return json_last_error() === JSON_ERROR_NONE ? $value : false;
            case 'string':
            default:
                return htmlspecialchars($value);
        }
    }
    
    // Helper methods for the view
    public function getCategoryIcon($category) {
        $icons = [
            'general' => 'cog',
            'email' => 'envelope',
            'features' => 'toggle-on',
            'security' => 'shield-alt',
            'appearance' => 'palette',
            'integration' => 'puzzle-piece'
        ];
        return $icons[$category] ?? 'cog';
    }
    
    public function formatSettingKey($key) {
        return ucwords(str_replace('_', ' ', $key));
    }
    
    public function renderSettingInput($setting) {
        $value = htmlspecialchars($setting['setting_value'] ?? '');
        $name = "settings[{$setting['setting_key']}]";
        
        switch ($setting['setting_type']) {
            case 'boolean':
                $checked = $value === '1' ? 'checked' : '';
                return '
                    <div class="form-check form-switch">
                        <input class="form-check-input boolean-toggle" type="checkbox" 
                               name="' . $name . '" value="1" ' . $checked . '>
                        <label class="form-check-label toggle-label">
                            ' . ($value === '1' ? 'Enabled' : 'Disabled') . '
                        </label>
                    </div>
                ';
                
            case 'integer':
                return '<input type="number" name="' . $name . '" value="' . $value . '" class="form-control">';
                
            case 'json':
                return '<textarea name="' . $name . '" class="form-control" rows="4">' . $value . '</textarea>';
                
            case 'string':
            default:
                if (strlen($value) > 100) {
                    return '<textarea name="' . $name . '" class="form-control" rows="3">' . $value . '</textarea>';
                } else {
                    return '<input type="text" name="' . $name . '" value="' . $value . '" class="form-control">';
                }
        }
    }
}

// Initialize Settings Manager
$settingsManager = new SystemSettings($pdo);
$currentUser = $auth->getCurrentUser();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        case 'update_settings':
            $settings = $_POST['settings'] ?? [];
            $results = $settingsManager->updateMultipleSettings($settings, $currentUser['id']);
            
            $successCount = count(array_filter($results));
            $totalCount = count($results);
            
            if ($successCount === $totalCount) {
                $_SESSION['flash_message'] = "All settings updated successfully";
                $_SESSION['flash_type'] = 'success';
            } else {
                $_SESSION['flash_message'] = "Updated $successCount of $totalCount settings";
                $_SESSION['flash_type'] = 'warning';
            }
            break;
            
        case 'reset_defaults':
            // Implementation to reset to defaults
            $_SESSION['flash_message'] = "Settings reset to defaults";
            $_SESSION['flash_type'] = 'info';
            break;
    }
    
    header('Location: system-settings.php');
    exit;
}

// Get current settings
$settings = $settingsManager->getSettingsByCategory();
$defaultSettings = $settingsManager->getDefaultSettings();

// Ensure all default settings exist
foreach ($defaultSettings as $category => $categorySettings) {
    foreach ($categorySettings as $default) {
        $exists = false;
        if (isset($settings[$category])) {
            foreach ($settings[$category] as $existing) {
                if ($existing['setting_key'] === $default['setting_key']) {
                    $exists = true;
                    break;
                }
            }
        }
        
        if (!$exists) {
            $settingsManager->updateSetting(
                $default['setting_key'], 
                $default['setting_value'], 
                $currentUser['id']
            );
        }
    }
}

// Refresh settings after ensuring defaults
$settings = $settingsManager->getSettingsByCategory();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System Settings - REACH Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .settings-category {
            background: white;
            border-radius: 10px;
            padding: 0;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .settings-header {
            background: #f8f9fa;
            padding: 20px;
            border-bottom: 1px solid #dee2e6;
            border-radius: 10px 10px 0 0;
        }
        .setting-item {
            padding: 20px;
            border-bottom: 1px solid #f8f9fa;
        }
        .setting-item:last-child {
            border-bottom: none;
        }
        .setting-description {
            font-size: 0.875rem;
            color: #6c757d;
            margin-top: 5px;
        }
        .boolean-toggle {
            width: 60px;
            height: 30px;
        }
        .user-management {
            background-color: #f8f9fa;
            min-height: 100vh;
        }
        .admin-main {
            margin-left: 250px;
            padding: 20px;
        }
        @media (max-width: 768px) {
            .admin-main {
                margin-left: 0;
            }
        }
    </style>
</head>
<body class="user-management">
    <?php if (file_exists('partials/admin-sidebar.php')): ?>
        <?php include 'partials/admin-sidebar.php'; ?>
    <?php endif; ?>
    
    <main class="admin-main">
        <div class="container-fluid py-4">
            <!-- Header -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1><i class="fas fa-cogs me-2"></i>System Settings</h1>
                <div>
                    <button type="button" class="btn btn-outline-warning me-2" data-bs-toggle="modal" data-bs-target="#resetModal">
                        <i class="fas fa-undo me-2"></i>Reset Defaults
                    </button>
                    <button type="submit" form="settingsForm" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i>Save All Changes
                    </button>
                </div>
            </div>

            <!-- Flash Messages -->
            <?php if (isset($_SESSION['flash_message'])): ?>
                <div class="alert alert-<?php echo $_SESSION['flash_type'] ?? 'info'; ?> alert-dismissible fade show">
                    <?php echo $_SESSION['flash_message']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <?php unset($_SESSION['flash_message'], $_SESSION['flash_type']); ?>
            <?php endif; ?>

            <form method="POST" id="settingsForm">
                <input type="hidden" name="action" value="update_settings">
                
                <?php foreach ($settings as $category => $categorySettings): ?>
                    <div class="settings-category">
                        <div class="settings-header">
                            <h5 class="mb-0 text-capitalize">
                                <i class="fas fa-<?php echo $settingsManager->getCategoryIcon($category); ?> me-2"></i>
                                <?php echo ucfirst($category); ?> Settings
                            </h5>
                        </div>
                        
                        <div class="settings-body">
                            <?php foreach ($categorySettings as $setting): ?>
                                <div class="setting-item">
                                    <div class="row align-items-center">
                                        <div class="col-md-4">
                                            <label class="form-label fw-bold">
                                                <?php echo $settingsManager->formatSettingKey($setting['setting_key']); ?>
                                            </label>
                                            <?php if (!empty($setting['description'])): ?>
                                                <div class="setting-description">
                                                    <?php echo htmlspecialchars($setting['description']); ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-md-6">
                                            <?php echo $settingsManager->renderSettingInput($setting); ?>
                                        </div>
                                        <div class="col-md-2">
                                            <span class="badge bg-secondary">
                                                <?php echo $setting['setting_type']; ?>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </form>
        </div>
    </main>

    <!-- Reset Confirmation Modal -->
    <div class="modal fade" id="resetModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Reset Settings to Defaults</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to reset all settings to their default values? This action cannot be undone.</p>
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        This will overwrite all current settings with default values.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <form method="POST">
                        <input type="hidden" name="action" value="reset_defaults">
                        <button type="submit" class="btn btn-warning">Reset to Defaults</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Enhanced toggle switches for boolean settings
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('.boolean-toggle').forEach(toggle => {
                toggle.addEventListener('change', function() {
                    const label = this.parentElement.querySelector('.toggle-label');
                    if (label) {
                        label.textContent = this.checked ? 'Enabled' : 'Disabled';
                    }
                });
            });
            
            // Settings form validation
            const settingsForm = document.getElementById('settingsForm');
            if (settingsForm) {
                settingsForm.addEventListener('submit', function(e) {
                    let hasErrors = false;
                    
                    // Validate integer fields
                    document.querySelectorAll('input[type="number"]').forEach(input => {
                        if (input.hasAttribute('min') || input.hasAttribute('max')) {
                            const value = parseInt(input.value);
                            const min = parseInt(input.getAttribute('min')) || -Infinity;
                            const max = parseInt(input.getAttribute('max')) || Infinity;
                            
                            if (value < min || value > max) {
                                input.classList.add('is-invalid');
                                hasErrors = true;
                            } else {
                                input.classList.remove('is-invalid');
                            }
                        }
                    });
                    
                    // Validate JSON fields
                    document.querySelectorAll('textarea').forEach(textarea => {
                        const name = textarea.getAttribute('name');
                        if (name && name.includes('settings[')) {
                            // Check if this might be a JSON field by looking at surrounding context
                            const parentRow = textarea.closest('.row');
                            if (parentRow) {
                                const badge = parentRow.querySelector('.badge');
                                if (badge && badge.textContent === 'json') {
                                    try {
                                        JSON.parse(textarea.value);
                                        textarea.classList.remove('is-invalid');
                                    } catch (e) {
                                        textarea.classList.add('is-invalid');
                                        hasErrors = true;
                                    }
                                }
                            }
                        }
                    });
                    
                    if (hasErrors) {
                        e.preventDefault();
                        alert('Please fix validation errors before saving.');
                    }
                });
            }
            
            // Auto-save indicator
            let saveTimeout;
            document.querySelectorAll('#settingsForm input, #settingsForm textarea, #settingsForm select').forEach(element => {
                element.addEventListener('change', function() {
                    const saveButton = document.querySelector('button[form="settingsForm"]');
                    if (saveButton) {
                        saveButton.innerHTML = '<i class="fas fa-save me-2"></i>Save Changes*';
                        saveButton.classList.add('btn-warning');
                        saveButton.classList.remove('btn-primary');
                        
                        clearTimeout(saveTimeout);
                        saveTimeout = setTimeout(() => {
                            saveButton.innerHTML = '<i class="fas fa-save me-2"></i>Save Changes';
                            saveButton.classList.remove('btn-warning');
                            saveButton.classList.add('btn-primary');
                        }, 3000);
                    }
                });
            });
        });
    </script>
</body>
</html>