<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include '../../includes/config.php';
include '../../includes/auth.php';

// Try multiple possible paths for ApplicationManager
$possiblePaths = [
    '../../includes/ApplicationManager.php',
    '../../includes/classes/ApplicationManager.php', 
    '../includes/ApplicationManager.php',
    './ApplicationManager.php'
];

$applicationManagerLoaded = false;
foreach ($possiblePaths as $path) {
    if (file_exists($path)) {
        include $path;
        $applicationManagerLoaded = true;
        error_log("ApplicationManager loaded from: " . $path);
        break;
    }
}

if (!$applicationManagerLoaded) {
    // If ApplicationManager is not found, create a minimal version
    error_log("ApplicationManager not found, creating minimal version");
    class ApplicationManager {
        private $pdo;
        
        public function __construct($pdo) {
            $this->pdo = $pdo;
        }
        
        public function getApplicationById($id) {
            try {
                $stmt = $this->pdo->prepare("
                    SELECT a.*, u.full_name, u.email, u.phone, u.profile_picture,
                           r.full_name as reviewer_name, p.name as program_name
                    FROM applications a 
                    LEFT JOIN users u ON a.user_id = u.id 
                    LEFT JOIN users r ON a.reviewer_id = r.id
                    LEFT JOIN programs p ON a.program_type = p.type
                    WHERE a.id = ?
                ");
                $stmt->execute([$id]);
                return $stmt->fetch(PDO::FETCH_ASSOC);
            } catch (Exception $e) {
                error_log("Error getting application: " . $e->getMessage());
                return false;
            }
        }
        
        public function getApplicationDetails($applicationId) {
            try {
                $stmt = $this->pdo->prepare("
                    SELECT * FROM application_details 
                    WHERE application_id = ? 
                    ORDER BY section, field_name
                ");
                $stmt->execute([$applicationId]);
                return $stmt->fetchAll(PDO::FETCH_ASSOC);
            } catch (Exception $e) {
                error_log("Error getting application details: " . $e->getMessage());
                return [];
            }
        }
        
        public function updateApplicationStatus($id, $status, $reviewerId = null, $notes = null) {
            try {
                $sql = "UPDATE applications SET status = ?";
                $params = [$status];
                
                if ($notes !== null) {
                    $sql .= ", review_notes = ?";
                    $params[] = $notes;
                }
                
                if ($reviewerId !== null) {
                    $sql .= ", reviewer_id = ?";
                    $params[] = $reviewerId;
                }
                
                if (in_array($status, ['under_review', 'approved', 'rejected', 'waitlisted'])) {
                    $sql .= ", reviewed_at = NOW()";
                }
                
                $sql .= " WHERE id = ?";
                $params[] = $id;
                
                $stmt = $this->pdo->prepare($sql);
                return $stmt->execute($params);
            } catch (Exception $e) {
                error_log("Error updating application status: " . $e->getMessage());
                return false;
            }
        }
    }
}

$auth->checkRole(['super_admin', 'admin', 'reviewer']);

$applicationManager = new ApplicationManager($pdo);

$applicationId = $_GET['id'] ?? null;
if (!$applicationId) {
    header('Location: index.php');
    exit;
}

try {
    $application = $applicationManager->getApplicationById($applicationId);
    if (!$application) {
        $_SESSION['error'] = 'Application not found';
        header('Location: index.php');
        exit;
    }
} catch (Exception $e) {
    $_SESSION['error'] = 'Error loading application: ' . $e->getMessage();
    header('Location: index.php');
    exit;
}

$applicationDetails = $applicationManager->getApplicationDetails($applicationId);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $status = $_POST['status'] ?? '';
    $reviewNotes = $_POST['review_notes'] ?? '';
    
    try {
        $success = $applicationManager->updateApplicationStatus($applicationId, $status, $_SESSION['user_id'], $reviewNotes);
        
        if ($success) {
            $_SESSION['success'] = 'Application reviewed successfully';
            header('Location: index.php');
            exit;
        } else {
            $error = 'Failed to update application status';
        }
    } catch (Exception $e) {
        $error = 'Error updating application: ' . $e->getMessage();
    }
}

// Helper functions
function getApplicationStatusColor($status) {
    $colors = [
        'draft' => 'secondary',
        'submitted' => 'info',
        'under_review' => 'warning',
        'approved' => 'success',
        'rejected' => 'danger',
        'waitlisted' => 'primary'
    ];
    return $colors[$status] ?? 'secondary';
}

function formatDate($date) {
    if (!$date) return 'Not submitted';
    return date('M j, Y g:i A', strtotime($date));
}

function formatCurrency($amount) {
    if (!$amount) return 'Not provided';
    return '$' . number_format($amount, 2);
}

// Parse application details into sections
$sections = [];
foreach ($applicationDetails as $detail) {
    $section = $detail['section'];
    $fieldName = $detail['field_name'];
    $fieldValue = $detail['field_value'];
    
    if (!isset($sections[$section])) {
        $sections[$section] = [];
    }
    $sections[$section][$fieldName] = $fieldValue;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Review Application - REACH Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #2c5aa0;
            --primary-dark: #1e3d72;
            --secondary: #6c757d;
            --success: #28a745;
            --info: #17a2b8;
            --warning: #ffc107;
            --danger: #dc3545;
            --light: #f8f9fa;
            --dark: #343a40;
            --border-radius: 12px;
            --box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --transition: all 0.3s ease;
        }

        * {
            font-family: 'Inter', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .dashboard-container {
            max-width: 1400px;
            margin: 0 auto;
        }

        .glass-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: var(--border-radius);
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: var(--box-shadow);
            transition: var(--transition);
        }

        .glass-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px -8px rgba(0, 0, 0, 0.15);
        }

        .header-section {
            padding: 2rem;
            margin-bottom: 2rem;
            text-align: center;
        }

        .header-section h1 {
            color: white;
            font-weight: 700;
            margin-bottom: 0.5rem;
            text-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .header-section .lead {
            color: rgba(255, 255, 255, 0.9);
            font-weight: 400;
        }

        .card-header {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white;
            padding: 1.5rem;
            border-radius: var(--border-radius) var(--border-radius) 0 0 !important;
        }

        .card-header h5 {
            margin: 0;
            font-weight: 600;
        }

        .card-body {
            padding: 1.5rem;
        }

        .application-section {
            border: 1px solid #e9ecef;
            border-radius: 8px;
            margin-bottom: 20px;
            overflow: hidden;
            background: white;
        }

        .section-header {
            background: linear-gradient(135deg, #f8f9fa, #e9ecef);
            padding: 1rem 1.5rem;
            border-bottom: 1px solid #e9ecef;
            font-weight: 600;
            color: var(--primary-dark);
        }

        .section-body {
            padding: 1.5rem;
        }

        .info-item {
            margin-bottom: 1rem;
        }

        .info-label {
            font-weight: 600;
            color: var(--primary-dark);
            margin-bottom: 0.5rem;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .info-value {
            color: #495057;
            background: #f8f9fa;
            padding: 0.75rem 1rem;
            border-radius: 8px;
            border: 1px solid #e9ecef;
            font-weight: 500;
        }

        .text-preline {
            white-space: pre-line;
            line-height: 1.6;
        }

        .btn {
            border-radius: 8px;
            font-weight: 500;
            transition: var(--transition);
            padding: 0.75rem 1.5rem;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border: none;
        }

        .btn-primary:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(44, 90, 160, 0.3);
        }

        .form-control, .form-select {
            border-radius: 8px;
            border: 1px solid #e1e5e9;
            padding: 0.75rem 1rem;
            transition: var(--transition);
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.2rem rgba(44, 90, 160, 0.25);
        }

        .alert {
            border-radius: var(--border-radius);
            border: none;
            box-shadow: var(--box-shadow);
        }

        .badge {
            font-weight: 600;
            padding: 0.5em 1em;
            border-radius: 20px;
        }

        .applicant-avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid white;
            box-shadow: var(--box-shadow);
        }

        .applicant-info {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border-radius: var(--border-radius);
            padding: 1.5rem;
            margin-bottom: 1.5rem;
        }

        .status-badge-large {
            font-size: 1rem;
            padding: 0.75rem 1.5rem;
            border-radius: 25px;
        }

        .nav-tabs .nav-link {
            border: none;
            color: var(--secondary);
            font-weight: 500;
            padding: 1rem 1.5rem;
        }

        .nav-tabs .nav-link.active {
            background: transparent;
            color: var(--primary);
            border-bottom: 3px solid var(--primary);
        }

        .timeline {
            position: relative;
            padding-left: 2rem;
        }

        .timeline::before {
            content: '';
            position: absolute;
            left: 15px;
            top: 0;
            bottom: 0;
            width: 2px;
            background: #e9ecef;
        }

        .timeline-item {
            position: relative;
            margin-bottom: 1.5rem;
        }

        .timeline-item::before {
            content: '';
            position: absolute;
            left: -2rem;
            top: 5px;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: var(--primary);
            border: 2px solid white;
        }

        @media (max-width: 768px) {
            body {
                padding: 10px;
            }
            
            .header-section {
                padding: 1rem;
            }
            
            .card-body {
                padding: 1rem;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Header Section -->
        <div class="header-section">
            <h1><i class="fas fa-search me-3"></i>Application Review</h1>
            <p class="lead">Detailed review and evaluation of scholarship application</p>
        </div>

        <!-- Success/Error Messages -->
        <?php if (isset($error)): ?>
            <div class="alert alert-danger alert-dismissible fade show glass-card mb-4" role="alert">
                <i class="fas fa-exclamation-triangle me-2"></i>
                <?php echo $error; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success alert-dismissible fade show glass-card mb-4">
                <i class="fas fa-check-circle me-2"></i><?php echo $_SESSION['success']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>

        <div class="row g-4">
            <!-- Left Column - Application Details -->
            <div class="col-lg-8">
                <!-- Applicant Header Card -->
                <div class="glass-card mb-4">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col-auto">
                                <?php 
                                $profilePic = $application['profile_picture'] ?? 'default.jpg';
                                $fullName = $application['full_name'] ?? 'Unknown';
                                $initial = substr($fullName, 0, 1);
                                ?>
                                <img src="../../assets/uploads/profiles/<?php echo htmlspecialchars($profilePic); ?>" 
                                     alt="<?php echo htmlspecialchars($fullName); ?>" 
                                     class="applicant-avatar"
                                     onerror="this.src='https://placehold.co/80x80/2c5aa0/ffffff?text=<?php echo urlencode($initial); ?>'">
                            </div>
                            <div class="col">
                                <h3 class="mb-1"><?php echo htmlspecialchars($fullName); ?></h3>
                                <p class="text-muted mb-2"><?php echo htmlspecialchars($application['email'] ?? 'No email'); ?></p>
                                <div class="d-flex flex-wrap gap-2 align-items-center">
                                    <span class="badge status-badge-large bg-<?php echo getApplicationStatusColor($application['status'] ?? 'submitted'); ?>">
                                        <?php echo ucfirst(str_replace('_', ' ', $application['status'] ?? 'submitted')); ?>
                                    </span>
                                    <span class="text-muted">Application #<?php echo htmlspecialchars($application['application_code'] ?? 'N/A'); ?></span>
                                </div>
                            </div>
                            <div class="col-auto">
                                <a href="index.php" class="btn btn-outline-primary">
                                    <i class="fas fa-arrow-left me-2"></i>Back to Applications
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Application Details -->
                <div class="glass-card">
                    <div class="card-header">
                        <h5><i class="fas fa-file-alt me-2"></i>Application Details</h5>
                    </div>
                    <div class="card-body">
                        <!-- Program Information -->
                        <div class="application-section">
                            <div class="section-header">
                                <i class="fas fa-project-diagram me-2"></i>Program Information
                            </div>
                            <div class="section-body">
                                <div class="row">
                                    <div class="col-md-6 info-item">
                                        <div class="info-label">Program Type</div>
                                        <div class="info-value"><?php echo htmlspecialchars($application['program_name'] ?? $application['program_type'] ?? 'Not specified'); ?></div>
                                    </div>
                                    <div class="col-md-6 info-item">
                                        <div class="info-label">Academic Level</div>
                                        <div class="info-value"><?php echo ucfirst(str_replace('_', ' ', $application['academic_level'] ?? 'Not specified')); ?></div>
                                    </div>
                                    <div class="col-md-6 info-item">
                                        <div class="info-label">Institution</div>
                                        <div class="info-value"><?php echo htmlspecialchars($application['institution_applying'] ?? 'Not specified'); ?></div>
                                    </div>
                                    <div class="col-md-6 info-item">
                                        <div class="info-label">Intended Major</div>
                                        <div class="info-value"><?php echo htmlspecialchars($application['intended_major'] ?? 'Not specified'); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Academic Information -->
                        <?php if (!empty($application['academic_history'])): ?>
                        <div class="application-section">
                            <div class="section-header">
                                <i class="fas fa-graduation-cap me-2"></i>Academic History
                            </div>
                            <div class="section-body">
                                <div class="info-item">
                                    <div class="info-value text-preline"><?php echo htmlspecialchars($application['academic_history']); ?></div>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>

                        <!-- Financial Information -->
                        <div class="application-section">
                            <div class="section-header">
                                <i class="fas fa-money-bill-wave me-2"></i>Financial Information
                            </div>
                            <div class="section-body">
                                <div class="row">
                                    <div class="col-md-6 info-item">
                                        <div class="info-label">Annual Family Income</div>
                                        <div class="info-value"><?php echo formatCurrency($application['family_income'] ?? 0); ?></div>
                                    </div>
                                    <?php if (!empty($application['financial_needs'])): ?>
                                    <div class="col-12 info-item">
                                        <div class="info-label">Financial Needs Description</div>
                                        <div class="info-value text-preline"><?php echo htmlspecialchars($application['financial_needs']); ?></div>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <!-- Personal Statement -->
                        <?php if (!empty($application['personal_statement'])): ?>
                        <div class="application-section">
                            <div class="section-header">
                                <i class="fas fa-edit me-2"></i>Personal Statement
                            </div>
                            <div class="section-body">
                                <div class="info-item">
                                    <div class="info-value text-preline"><?php echo htmlspecialchars($application['personal_statement']); ?></div>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>

                        <!-- Additional Details from application_details table -->
                        <?php if (!empty($sections)): ?>
                            <?php foreach ($sections as $sectionName => $fields): ?>
                            <div class="application-section">
                                <div class="section-header">
                                    <i class="fas fa-info-circle me-2"></i><?php echo ucfirst(str_replace('_', ' ', $sectionName)); ?>
                                </div>
                                <div class="section-body">
                                    <div class="row">
                                        <?php foreach ($fields as $fieldName => $fieldValue): ?>
                                        <div class="col-md-6 info-item">
                                            <div class="info-label"><?php echo ucwords(str_replace('_', ' ', $fieldName)); ?></div>
                                            <div class="info-value"><?php echo htmlspecialchars($fieldValue); ?></div>
                                        </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        <?php endif; ?>

                        <!-- Documents Information -->
                        <?php if (!empty($application['documents']) || !empty($application['reference_letters'])): ?>
                        <div class="application-section">
                            <div class="section-header">
                                <i class="fas fa-file-upload me-2"></i>Uploaded Documents
                            </div>
                            <div class="section-body">
                                <div class="row">
                                    <?php if (!empty($application['documents'])): ?>
                                    <div class="col-md-6 info-item">
                                        <div class="info-label">Supporting Documents</div>
                                        <div class="info-value">
                                            <?php
                                            $documents = json_decode($application['documents'], true);
                                            if (is_array($documents)) {
                                                echo '<ul class="mb-0 ps-3">';
                                                foreach ($documents as $doc) {
                                                    echo '<li>' . htmlspecialchars($doc['name'] ?? $doc) . '</li>';
                                                }
                                                echo '</ul>';
                                            } else {
                                                echo 'Documents uploaded';
                                            }
                                            ?>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    
                                    <?php if (!empty($application['reference_letters'])): ?>
                                    <div class="col-md-6 info-item">
                                        <div class="info-label">Reference Letters</div>
                                        <div class="info-value">
                                            <?php
                                            $references = json_decode($application['reference_letters'], true);
                                            if (is_array($references)) {
                                                echo '<ul class="mb-0 ps-3">';
                                                foreach ($references as $ref) {
                                                    echo '<li>' . htmlspecialchars($ref['name'] ?? $ref) . '</li>';
                                                }
                                                echo '</ul>';
                                            } else {
                                                echo 'Reference letters uploaded';
                                            }
                                            ?>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Right Column - Review Form & Applicant Info -->
            <div class="col-lg-4">
                <!-- Review Form -->
                <div class="glass-card mb-4">
                    <div class="card-header">
                        <h5><i class="fas fa-clipboard-check me-2"></i>Review Decision</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Status Decision</label>
                                <select class="form-select" name="status" required>
                                    <option value="under_review" <?php echo ($application['status'] ?? '') === 'under_review' ? 'selected' : ''; ?>>Under Review</option>
                                    <option value="approved" <?php echo ($application['status'] ?? '') === 'approved' ? 'selected' : ''; ?>>Approved</option>
                                    <option value="rejected" <?php echo ($application['status'] ?? '') === 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                                    <option value="waitlisted" <?php echo ($application['status'] ?? '') === 'waitlisted' ? 'selected' : ''; ?>>Waitlisted</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Review Notes & Comments</label>
                                <textarea class="form-control" name="review_notes" rows="6" 
                                          placeholder="Provide detailed feedback, evaluation comments, or reasons for your decision..."><?php echo htmlspecialchars($application['review_notes'] ?? ''); ?></textarea>
                                <div class="form-text">These notes will be visible to other reviewers and administrators.</div>
                            </div>
                            <button type="submit" class="btn btn-primary w-100 py-2">
                                <i class="fas fa-paper-plane me-2"></i>Submit Review Decision
                            </button>
                        </form>
                    </div>
                </div>

                <!-- Application Timeline -->
                <div class="glass-card mb-4">
                    <div class="card-header">
                        <h5><i class="fas fa-history me-2"></i>Application Timeline</h5>
                    </div>
                    <div class="card-body">
                        <div class="timeline">
                            <div class="timeline-item">
                                <div class="info-label">Application Created</div>
                                <div class="info-value"><?php echo formatDate($application['created_at'] ?? ''); ?></div>
                            </div>
                            <?php if (!empty($application['submitted_at'])): ?>
                            <div class="timeline-item">
                                <div class="info-label">Application Submitted</div>
                                <div class="info-value"><?php echo formatDate($application['submitted_at']); ?></div>
                            </div>
                            <?php endif; ?>
                            <?php if (!empty($application['reviewed_at'])): ?>
                            <div class="timeline-item">
                                <div class="info-label">Last Reviewed</div>
                                <div class="info-value"><?php echo formatDate($application['reviewed_at']); ?></div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="glass-card">
                    <div class="card-header">
                        <h5><i class="fas fa-bolt me-2"></i>Quick Actions</h5>
                    </div>
                    <div class="card-body">
                        <div class="d-grid gap-2">
                            <?php if (!empty($application['email'])): ?>
                            <a href="mailto:<?php echo $application['email']; ?>" class="btn btn-outline-primary">
                                <i class="fas fa-envelope me-2"></i>Email Applicant
                            </a>
                            <?php endif; ?>
                            <button type="button" class="btn btn-outline-info" onclick="window.print()">
                                <i class="fas fa-print me-2"></i>Print Application
                            </button>
                            <a href="#" class="btn btn-outline-secondary">
                                <i class="fas fa-download me-2"></i>Export as PDF
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Add confirmation for status changes
        document.querySelector('form').addEventListener('submit', function(e) {
            const status = document.querySelector('select[name="status"]').value;
            const currentStatus = '<?php echo $application['status'] ?? 'submitted'; ?>';
            
            if (status !== currentStatus) {
                const message = `You are changing the application status from "${currentStatus.replace('_', ' ')}" to "${status.replace('_', ' ')}". Continue?`;
                if (!confirm(message)) {
                    e.preventDefault();
                }
            }
        });

        // Add real-time character count for review notes
        const textarea = document.querySelector('textarea[name="review_notes"]');
        const charCount = document.createElement('div');
        charCount.className = 'form-text text-end';
        textarea.parentNode.appendChild(charCount);

        function updateCharCount() {
            const length = textarea.value.length;
            charCount.textContent = `${length} characters`;
            
            if (length > 500) {
                charCount.className = 'form-text text-end text-success';
            } else if (length > 100) {
                charCount.className = 'form-text text-end text-info';
            } else {
                charCount.className = 'form-text text-end text-muted';
            }
        }

        textarea.addEventListener('input', updateCharCount);
        updateCharCount();
    </script>
</body>
</html>