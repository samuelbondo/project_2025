<?php
// Enable full error reporting at the start
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Increase memory limit
ini_set('memory_limit', '256M');

include '../../includes/config.php';
include '../../includes/auth.php';
include '../../includes/classes/ApplicationManager.php';

// Check if user is logged in and has proper role
if (!isset($auth)) {
    die("Authentication not loaded");
}
$auth->checkRole(['super_admin', 'admin', 'reviewer']);

// Check if database connection is working
if (!isset($pdo)) {
    die("Database connection not established");
}

$applicationManager = new ApplicationManager($pdo);

// Handle actions
if (isset($_GET['action'])) {
    switch ($_GET['action']) {
        case 'create_sample':
            try {
                $success = $applicationManager->createSampleApplications();
                if ($success) {
                    $_SESSION['success'] = 'Sample applications created successfully';
                } else {
                    $_SESSION['error'] = 'Failed to create sample applications';
                }
            } catch (Exception $e) {
                $_SESSION['error'] = 'Error creating sample data: ' . $e->getMessage();
            }
            header('Location: index.php');
            exit;
    }
}

// Handle bulk actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['bulk_action'])) {
    $applicationIds = $_POST['application_ids'] ?? [];
    $bulkAction = $_POST['bulk_action'];
    
    if (!empty($applicationIds)) {
        try {
            switch ($bulkAction) {
                case 'approve':
                    $success = $applicationManager->bulkUpdateStatus($applicationIds, 'approved', $_SESSION['user_id']);
                    if ($success) {
                        $_SESSION['success'] = count($applicationIds) . ' applications approved';
                    }
                    break;
                case 'reject':
                    $success = $applicationManager->bulkUpdateStatus($applicationIds, 'rejected', $_SESSION['user_id']);
                    if ($success) {
                        $_SESSION['success'] = count($applicationIds) . ' applications rejected';
                    }
                    break;
                case 'under_review':
                    $success = $applicationManager->bulkUpdateStatus($applicationIds, 'under_review', $_SESSION['user_id']);
                    if ($success) {
                        $_SESSION['success'] = count($applicationIds) . ' applications marked for review';
                    }
                    break;
                default:
                    $_SESSION['error'] = 'Invalid bulk action';
            }
        } catch (Exception $e) {
            $_SESSION['error'] = 'Bulk action failed: ' . $e->getMessage();
        }
    } else {
        $_SESSION['error'] = 'No applications selected';
    }
    
    header('Location: index.php');
    exit;
}

// Get filter parameters with validation
$status = $_GET['status'] ?? 'all';
$program = $_GET['program'] ?? 'all';
$date_from = $_GET['date_from'] ?? '';
$date_to = $_GET['date_to'] ?? '';
$search = $_GET['search'] ?? '';
$page = max(1, intval($_GET['page'] ?? 1));
$limit = 20;
$offset = ($page - 1) * $limit;

// Build filters efficiently
$filters = [];
if ($status !== 'all') {
    $filters['status'] = $status;
}
if ($program !== 'all') {
    $filters['program_type'] = $program;
}
if (!empty($date_from)) {
    $filters['date_from'] = $date_from;
}
if (!empty($date_to)) {
    $filters['date_to'] = $date_to;
}

// Get applications with error handling
try {
    if (!empty($search)) {
        $applications = $applicationManager->searchApplications($search, $filters, $limit, $offset);
        $totalApplications = $applicationManager->getTotalApplications(array_merge($filters, ['search' => $search]));
    } else {
        $applications = $applicationManager->getApplications($filters, $limit, $offset);
        $totalApplications = $applicationManager->getTotalApplications($filters);
    }
    
    $totalPages = ceil($totalApplications / $limit);
    
    // Get statistics
    $stats = $applicationManager->getApplicationStats();
    
} catch (Exception $e) {
    error_log("Application management error: " . $e->getMessage());
    $applications = [];
    $totalApplications = 0;
    $totalPages = 1;
    $stats = [
        'total' => 0,
        'submitted' => 0,
        'under_review' => 0,
        'approved' => 0,
        'rejected' => 0,
        'waitlisted' => 0
    ];
}

// Get active programs for filter dropdown
$activePrograms = $applicationManager->getActivePrograms();

// Helper function for status colors
function getApplicationStatusColor($status) {
    switch ($status) {
        case 'submitted': return 'warning';
        case 'under_review': return 'info';
        case 'approved': return 'success';
        case 'rejected': return 'danger';
        case 'waitlisted': return 'secondary';
        case 'draft': return 'light';
        default: return 'secondary';
    }
}

// Helper function to format dates
function formatDate($date) {
    if (!$date) return 'Not submitted';
    return date('M j, Y', strtotime($date));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Application Management - REACH Portal</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --primary: #2c5aa0;
            --primary-dark: #1e3d72;
            --secondary: #6c757d;
            --success: #28a745;
            --info: #17a2b8;
            --warning: #ffc107;
            --danger: #dc3545;
            --light: #f8f9fa;
            --dark: #343a40;
            --border-radius: 12px;
            --box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --transition: all 0.3s ease;
        }

        * {
            font-family: 'Inter', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .dashboard-container {
            max-width: 1400px;
            margin: 0 auto;
        }

        .glass-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: var(--border-radius);
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: var(--box-shadow);
            transition: var(--transition);
        }

        .glass-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px -8px rgba(0, 0, 0, 0.15);
        }

        .header-section {
            padding: 2rem;
            margin-bottom: 2rem;
        }

        .header-section h1 {
            color: white;
            font-weight: 700;
            margin-bottom: 0.5rem;
            text-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .header-section .lead {
            color: rgba(255, 255, 255, 0.9);
            font-weight: 400;
        }

        .stats-grid {
            margin-bottom: 2rem;
        }

        .stat-card {
            padding: 1.5rem;
            border-radius: var(--border-radius);
            color: white;
            position: relative;
            overflow: hidden;
            transition: var(--transition);
        }

        .stat-card:hover {
            transform: translateY(-3px);
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(135deg, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0) 100%);
        }

        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            margin-bottom: 1rem;
            background: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(10px);
        }

        .stat-content h3 {
            font-size: 2rem;
            margin: 0;
            font-weight: 700;
        }

        .stat-content p {
            margin: 0;
            opacity: 0.9;
            font-size: 0.9rem;
            font-weight: 500;
        }

        .filter-section {
            padding: 1.5rem;
            margin-bottom: 1.5rem;
        }

        .table-section {
            padding: 0;
        }

        .table-header {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white;
            padding: 1.5rem;
            border-radius: var(--border-radius) var(--border-radius) 0 0;
        }

        .table-header h5 {
            margin: 0;
            font-weight: 600;
        }

        .table-container {
            padding: 1.5rem;
        }

        .table th {
            font-weight: 600;
            border-top: none;
            background: #f8f9fa;
        }

        .table-hover tbody tr:hover {
            background-color: rgba(44, 90, 160, 0.05);
            transform: scale(1.01);
            transition: var(--transition);
        }

        .avatar-sm {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #e9ecef;
        }

        .badge {
            font-weight: 500;
            padding: 0.5em 0.75em;
        }

        .btn {
            border-radius: 8px;
            font-weight: 500;
            transition: var(--transition);
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border: none;
        }

        .btn-primary:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(44, 90, 160, 0.3);
        }

        .pagination .page-item.active .page-link {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-color: var(--primary);
        }

        .bulk-actions {
            background: rgba(44, 90, 160, 0.05);
            padding: 1rem 1.5rem;
            border-radius: var(--border-radius);
            margin-bottom: 1.5rem;
            border: 1px solid rgba(44, 90, 160, 0.1);
        }

        .empty-state {
            text-align: center;
            padding: 3rem 1rem;
            color: var(--secondary);
        }

        .empty-state i {
            font-size: 4rem;
            margin-bottom: 1rem;
            opacity: 0.5;
        }

        .form-control, .form-select {
            border-radius: 8px;
            border: 1px solid #e1e5e9;
            transition: var(--transition);
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.2rem rgba(44, 90, 160, 0.25);
        }

        .alert {
            border-radius: var(--border-radius);
            border: none;
            box-shadow: var(--box-shadow);
        }

        .modal-content {
            border-radius: var(--border-radius);
            border: none;
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        }

        @media (max-width: 768px) {
            body {
                padding: 10px;
            }
            
            .header-section {
                padding: 1rem;
            }
            
            .stat-content h3 {
                font-size: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Header Section -->
        <div class="header-section text-center">
            <h1><i class="fas fa-clipboard-list me-3"></i>Application Management</h1>
            <p class="lead">Comprehensive overview and management of all scholarship applications</p>
        </div>

        <!-- Success/Error Messages -->
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success alert-dismissible fade show glass-card mb-4">
                <i class="fas fa-check-circle me-2"></i><?php echo $_SESSION['success']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger alert-dismissible fade show glass-card mb-4">
                <i class="fas fa-exclamation-triangle me-2"></i><?php echo $_SESSION['error']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>

        <!-- Statistics Cards -->
        <div class="stats-grid">
            <div class="row g-3">
                <div class="col-xl-2 col-lg-4 col-md-6">
                    <div class="stat-card" style="background: linear-gradient(135deg, #667eea, #764ba2);">
                        <div class="stat-icon">
                            <i class="fas fa-inbox"></i>
                        </div>
                        <div class="stat-content">
                            <h3><?php echo number_format($stats['total']); ?></h3>
                            <p>Total Applications</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-2 col-lg-4 col-md-6">
                    <div class="stat-card" style="background: linear-gradient(135deg, #f093fb, #f5576c);">
                        <div class="stat-icon">
                            <i class="fas fa-clock"></i>
                        </div>
                        <div class="stat-content">
                            <h3><?php echo number_format($stats['submitted']); ?></h3>
                            <p>Submitted</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-2 col-lg-4 col-md-6">
                    <div class="stat-card" style="background: linear-gradient(135deg, #4facfe, #00f2fe);">
                        <div class="stat-icon">
                            <i class="fas fa-search"></i>
                        </div>
                        <div class="stat-content">
                            <h3><?php echo number_format($stats['under_review']); ?></h3>
                            <p>Under Review</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-2 col-lg-4 col-md-6">
                    <div class="stat-card" style="background: linear-gradient(135deg, #43e97b, #38f9d7);">
                        <div class="stat-icon">
                            <i class="fas fa-check-circle"></i>
                        </div>
                        <div class="stat-content">
                            <h3><?php echo number_format($stats['approved']); ?></h3>
                            <p>Approved</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-2 col-lg-4 col-md-6">
                    <div class="stat-card" style="background: linear-gradient(135deg, #fa709a, #fee140);">
                        <div class="stat-icon">
                            <i class="fas fa-times-circle"></i>
                        </div>
                        <div class="stat-content">
                            <h3><?php echo number_format($stats['rejected']); ?></h3>
                            <p>Rejected</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-2 col-lg-4 col-md-6">
                    <div class="stat-card" style="background: linear-gradient(135deg, #a8c0ff, #3f2b96);">
                        <div class="stat-icon">
                            <i class="fas fa-pause-circle"></i>
                        </div>
                        <div class="stat-content">
                            <h3><?php echo number_format($stats['waitlisted']); ?></h3>
                            <p>Waitlisted</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Filters Section -->
        <div class="glass-card filter-section">
            <form method="GET" class="row g-3">
                <div class="col-md-2">
                    <label class="form-label fw-semibold">Status</label>
                    <select class="form-select" name="status">
                        <option value="all">All Statuses</option>
                        <option value="submitted" <?php echo $status === 'submitted' ? 'selected' : ''; ?>>Submitted</option>
                        <option value="under_review" <?php echo $status === 'under_review' ? 'selected' : ''; ?>>Under Review</option>
                        <option value="approved" <?php echo $status === 'approved' ? 'selected' : ''; ?>>Approved</option>
                        <option value="rejected" <?php echo $status === 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                        <option value="waitlisted" <?php echo $status === 'waitlisted' ? 'selected' : ''; ?>>Waitlisted</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label fw-semibold">Program Type</label>
                    <select class="form-select" name="program">
                        <option value="all">All Programs</option>
                        <?php foreach ($activePrograms as $programItem): ?>
                            <option value="<?php echo $programItem['type']; ?>" <?php echo $program === $programItem['type'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($programItem['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label fw-semibold">Date From</label>
                    <input type="date" class="form-control" name="date_from" value="<?php echo htmlspecialchars($date_from); ?>">
                </div>
                <div class="col-md-2">
                    <label class="form-label fw-semibold">Date To</label>
                    <input type="date" class="form-control" name="date_to" value="<?php echo htmlspecialchars($date_to); ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-semibold">Search Applications</label>
                    <input type="text" class="form-control" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search by name, email, or application ID...">
                </div>
                <div class="col-md-1 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-filter me-1"></i> Apply
                    </button>
                </div>
                <div class="col-12">
                    <a href="?" class="btn btn-outline-secondary">
                        <i class="fas fa-refresh me-1"></i> Clear Filters
                    </a>
                    <div class="float-end">
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exportModal">
                            <i class="fas fa-download me-2"></i>Export Data
                        </button>
                        <?php if ($_SESSION['role'] === 'super_admin'): ?>
                            <a href="?action=create_sample" class="btn btn-outline-info ms-2">
                                <i class="fas fa-plus me-2"></i>Create Sample Data
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </form>
        </div>

        <!-- Bulk Actions -->
        <?php if (!empty($applications)): ?>
        <div class="bulk-actions glass-card">
            <form method="POST" id="bulkActionForm" class="row g-3 align-items-center">
                <div class="col-auto">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="selectAll">
                        <label class="form-check-label fw-semibold" for="selectAll">
                            Select All
                        </label>
                    </div>
                </div>
                <div class="col-auto">
                    <select class="form-select" name="bulk_action" id="bulkAction">
                        <option value="">Bulk Actions</option>
                        <option value="approve">Approve Selected</option>
                        <option value="reject">Reject Selected</option>
                        <option value="under_review">Mark for Review</option>
                    </select>
                </div>
                <div class="col-auto">
                    <button type="submit" class="btn btn-outline-primary" id="applyBulkAction">
                        <i class="fas fa-play me-1"></i>Apply
                    </button>
                </div>
            </form>
        </div>
        <?php endif; ?>

        <!-- Applications Table -->
        <div class="glass-card table-section">
            <div class="table-header d-flex justify-content-between align-items-center">
                <h5><i class="fas fa-table me-2"></i>Applications (<?php echo number_format($totalApplications); ?>)</h5>
                <div class="text-white-50 small">
                    Page <?php echo $page; ?> of <?php echo $totalPages; ?>
                </div>
            </div>
            <div class="table-container">
                <?php if (empty($applications)): ?>
                    <div class="empty-state">
                        <i class="fas fa-clipboard-list"></i>
                        <h5>No Applications Found</h5>
                        <p class="text-muted">There are no applications matching your current filters.</p>
                        <a href="?" class="btn btn-primary">
                            <i class="fas fa-refresh me-1"></i>Clear Filters
                        </a>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th width="30">
                                        <input type="checkbox" class="form-check-input" id="selectAllHeader">
                                    </th>
                                    <th>Application ID</th>
                                    <th>Applicant</th>
                                    <th>Program</th>
                                    <th>Status</th>
                                    <th>Submitted</th>
                                    <th>Reviewer</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($applications as $application): ?>
                                <tr>
                                    <td>
                                        <input type="checkbox" class="form-check-input application-checkbox" name="application_ids[]" value="<?php echo $application['id']; ?>">
                                    </td>
                                    <td>
                                        <strong class="text-primary"><?php echo htmlspecialchars($application['application_code'] ?? 'N/A'); ?></strong>
                                    </td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="me-3">
                                                <?php 
                                                $profilePic = $application['profile_picture'] ?? 'default.jpg';
                                                $fullName = $application['full_name'] ?? 'Unknown';
                                                $initial = substr($fullName, 0, 1);
                                                ?>
                                                <img src="../../assets/uploads/profiles/<?php echo htmlspecialchars($profilePic); ?>" 
                                                     alt="<?php echo htmlspecialchars($fullName); ?>" 
                                                     class="avatar-sm"
                                                     onerror="this.src='https://placehold.co/40x40/2c5aa0/ffffff?text=<?php echo urlencode($initial); ?>'">
                                            </div>
                                            <div>
                                                <div class="fw-semibold"><?php echo htmlspecialchars($fullName); ?></div>
                                                <small class="text-muted"><?php echo htmlspecialchars($application['email'] ?? 'No email'); ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="badge bg-light text-dark border">
                                            <?php echo htmlspecialchars($application['program_name'] ?? ucfirst($application['program_type'] ?? 'Unknown')); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?php echo getApplicationStatusColor($application['status'] ?? 'submitted'); ?>">
                                            <?php echo ucfirst(str_replace('_', ' ', $application['status'] ?? 'submitted')); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php echo formatDate($application['submitted_at'] ?? $application['created_at'] ?? ''); ?>
                                    </td>
                                    <td>
                                        <?php if (!empty($application['reviewer_name'])): ?>
                                            <span class="fw-semibold"><?php echo htmlspecialchars($application['reviewer_name']); ?></span>
                                        <?php else: ?>
                                            <span class="text-muted">Not assigned</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <a href="review.php?id=<?php echo $application['id']; ?>" 
                                               class="btn btn-outline-primary" title="Review Application">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <?php if (($application['status'] ?? '') === 'submitted'): ?>
                                                <button class="btn btn-outline-warning assign-reviewer" 
                                                        data-application-id="<?php echo $application['id']; ?>"
                                                        data-applicant-name="<?php echo htmlspecialchars($application['full_name'] ?? 'Applicant'); ?>"
                                                        title="Assign Reviewer">
                                                    <i class="fas fa-user-check"></i>
                                                </button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination -->
                    <?php if ($totalPages > 1): ?>
                    <nav class="mt-4">
                        <ul class="pagination justify-content-center">
                            <?php if ($page > 1): ?>
                            <li class="page-item">
                                <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page - 1])); ?>">
                                    <i class="fas fa-chevron-left me-1"></i> Previous
                                </a>
                            </li>
                            <?php endif; ?>
                            
                            <?php 
                            $startPage = max(1, $page - 2);
                            $endPage = min($totalPages, $page + 2);
                            
                            for ($i = $startPage; $i <= $endPage; $i++): ?>
                                <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                    <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $i])); ?>">
                                        <?php echo $i; ?>
                                    </a>
                                </li>
                            <?php endfor; ?>
                            
                            <?php if ($page < $totalPages): ?>
                            <li class="page-item">
                                <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page + 1])); ?>">
                                    Next <i class="fas fa-chevron-right ms-1"></i>
                                </a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                    <?php endif; ?>

                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Export Modal -->
    <div class="modal fade" id="exportModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-download me-2"></i>Export Applications</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="exportForm">
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Export Format</label>
                            <select class="form-select" name="format">
                                <option value="csv">CSV Format</option>
                                <option value="excel">Excel Format</option>
                                <option value="pdf">PDF Report</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Date Range</label>
                            <div class="row g-2">
                                <div class="col-md-6">
                                    <input type="date" class="form-control" name="export_date_from" placeholder="From date">
                                </div>
                                <div class="col-md-6">
                                    <input type="date" class="form-control" name="export_date_to" placeholder="To date">
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Include Fields</label>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="fields[]" value="personal" checked>
                                <label class="form-check-label">Personal Information</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="fields[]" value="academic" checked>
                                <label class="form-check-label">Academic Information</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="fields[]" value="financial">
                                <label class="form-check-label">Financial Information</label>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="exportBtn">
                        <i class="fas fa-download me-2"></i>Export Data
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Bulk selection functionality
        const selectAllHeader = document.getElementById('selectAllHeader');
        const selectAll = document.getElementById('selectAll');
        const applicationCheckboxes = document.querySelectorAll('.application-checkbox');
        const bulkActionForm = document.getElementById('bulkActionForm');
        const applyBulkAction = document.getElementById('applyBulkAction');

        function updateSelectAllState() {
            const checkedBoxes = document.querySelectorAll('.application-checkbox:checked');
            const allChecked = checkedBoxes.length === applicationCheckboxes.length;
            const someChecked = checkedBoxes.length > 0;
            
            if (selectAllHeader) {
                selectAllHeader.checked = allChecked;
                selectAllHeader.indeterminate = someChecked && !allChecked;
            }
            if (selectAll) {
                selectAll.checked = allChecked;
                selectAll.indeterminate = someChecked && !allChecked;
            }
            
            applyBulkAction.disabled = !someChecked;
        }

        if (selectAllHeader) {
            selectAllHeader.addEventListener('change', function() {
                applicationCheckboxes.forEach(checkbox => {
                    checkbox.checked = this.checked;
                });
                updateSelectAllState();
            });
        }

        if (selectAll) {
            selectAll.addEventListener('change', function() {
                applicationCheckboxes.forEach(checkbox => {
                    checkbox.checked = this.checked;
                });
                updateSelectAllState();
            });
        }

        applicationCheckboxes.forEach(checkbox => {
            checkbox.addEventListener('change', updateSelectAllState);
        });

        // Bulk action form submission
        if (bulkActionForm) {
            bulkActionForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                const selectedAction = document.getElementById('bulkAction').value;
                const selectedApplications = document.querySelectorAll('.application-checkbox:checked');
                
                if (!selectedAction) {
                    alert('Please select a bulk action');
                    return;
                }
                
                if (selectedApplications.length === 0) {
                    alert('Please select at least one application');
                    return;
                }
                
                if (!confirm(`Are you sure you want to ${selectedAction.replace('_', ' ')} ${selectedApplications.length} application(s)?`)) {
                    return;
                }
                
                this.submit();
            });
        }

        // Export functionality
        const exportBtn = document.getElementById('exportBtn');
        if (exportBtn) {
            exportBtn.addEventListener('click', function() {
                const form = document.getElementById('exportForm');
                const formData = new FormData(form);
                
                // Show loading state
                const originalText = exportBtn.innerHTML;
                exportBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Exporting...';
                exportBtn.disabled = true;
                
                // Simulate export process
                setTimeout(() => {
                    alert('Export functionality would be implemented here');
                    exportBtn.innerHTML = originalText;
                    exportBtn.disabled = false;
                    bootstrap.Modal.getInstance(document.getElementById('exportModal')).hide();
                }, 1500);
            });
        }

        // Table row click functionality
        const tableRows = document.querySelectorAll('tbody tr');
        tableRows.forEach(row => {
            row.addEventListener('click', function(e) {
                // Don't trigger if clicking on checkboxes or action buttons
                if (!e.target.closest('input[type="checkbox"]') && 
                    !e.target.closest('.btn-group') && 
                    !e.target.closest('.assign-reviewer')) {
                    const viewLink = this.querySelector('a[href*="review.php"]');
                    if (viewLink) {
                        window.location.href = viewLink.href;
                    }
                }
            });
        });

        // Auto-submit filters on change
        const statusFilter = document.querySelector('select[name="status"]');
        const programFilter = document.querySelector('select[name="program"]');
        
        if (statusFilter) {
            statusFilter.addEventListener('change', function() {
                this.form.submit();
            });
        }

        if (programFilter) {
            programFilter.addEventListener('change', function() {
                this.form.submit();
            });
        }

        // Image error handling
        const images = document.querySelectorAll('.avatar-sm');
        images.forEach(img => {
            img.addEventListener('error', function() {
                const name = this.alt || 'U';
                const initial = name.charAt(0).toUpperCase();
                this.src = `https://placehold.co/40x40/2c5aa0/ffffff?text=${initial}`;
            });
        });

        // Initialize select all state
        updateSelectAllState();
    });
    </script>
</body>
</html>