<?php
// admin-sidebar.php - Complete fixed version
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/database.php';

// Utility functions
if (!function_exists('getTotalUsersCount')) {
    function getTotalUsersCount() {
        try {
            $db = new Database();
            $db->query("SELECT COUNT(*) as total FROM users WHERE deleted = 0");
            $result = $db->single();
            return $result['total'] ?? 0;
        } catch (Exception $e) {
            error_log("Error in getTotalUsersCount: " . $e->getMessage());
            return 0;
        }
    }
}

if (!function_exists('getTotalStudentsCount')) {
    function getTotalStudentsCount() {
        try {
            $db = new Database();
            $db->query("SELECT COUNT(*) as total FROM users WHERE role = 'student' AND deleted = 0");
            $result = $db->single();
            return $result['total'] ?? 0;
        } catch (Exception $e) {
            error_log("Error in getTotalStudentsCount: " . $e->getMessage());
            return 0;
        }
    }
}

if (!function_exists('getPendingApplicationsCount')) {
    function getPendingApplicationsCount() {
        try {
            $db = new Database();
            $db->query("SELECT COUNT(*) as total FROM applications WHERE status = 'pending'");
            $result = $db->single();
            return $result['total'] ?? 0;
        } catch (Exception $e) {
            error_log("Error in getPendingApplicationsCount: " . $e->getMessage());
            return 0;
        }
    }
}

if (!function_exists('getActivePartnersCount')) {
    function getActivePartnersCount() {
        try {
            $db = new Database();
            $db->query("SELECT COUNT(*) as total FROM users WHERE role = 'partner' AND status = 'active' AND deleted = 0");
            $result = $db->single();
            return $result['total'] ?? 0;
        } catch (Exception $e) {
            error_log("Error in getActivePartnersCount: " . $e->getMessage());
            return 0;
        }
    }
}

if (!function_exists('getUnreadNotificationsCount')) {
    function getUnreadNotificationsCount() {
        try {
            $db = new Database();
            $db->query("SELECT COUNT(*) as total FROM notifications WHERE is_read = 0 AND admin_notification = 1");
            $result = $db->single();
            return $result['total'] ?? 0;
        } catch (Exception $e) {
            error_log("Error in getUnreadNotificationsCount: " . $e->getMessage());
            return 0;
        }
    }
}

if (!function_exists('getCurrentUser')) {
    function getCurrentUser() {
        if (!isset($_SESSION['user_id'])) {
            return [
                'id' => 0,
                'first_name' => 'Guest',
                'last_name' => 'User',
                'email' => '',
                'role' => 'guest',
                'avatar' => null
            ];
        }
        
        try {
            $db = new Database();
            $db->query("SELECT * FROM users WHERE id = :id AND deleted = 0");
            $db->bind(':id', $_SESSION['user_id']);
            $user = $db->single();
            
            if ($user) {
                return $user;
            }
        } catch (Exception $e) {
            error_log("Error in getCurrentUser: " . $e->getMessage());
        }
        
        return [
            'id' => $_SESSION['user_id'] ?? 0,
            'first_name' => $_SESSION['first_name'] ?? 'Admin',
            'last_name' => $_SESSION['last_name'] ?? 'User',
            'email' => $_SESSION['email'] ?? '',
            'role' => $_SESSION['user_role'] ?? 'admin',
            'avatar' => null
        ];
    }
}

if (!function_exists('getUserInitials')) {
    function getUserInitials($user) {
        $firstName = $user['first_name'] ?? 'A';
        $lastName = $user['last_name'] ?? 'dmin';
        
        $initials = strtoupper(substr($firstName, 0, 1));
        if (!empty($lastName)) {
            $initials .= strtoupper(substr($lastName, 0, 1));
        }
        
        return $initials ?: 'AU';
    }
}

if (!function_exists('getDisplayName')) {
    function getDisplayName($user) {
        if (is_array($user)) {
            $firstName = $user['first_name'] ?? '';
            $lastName = $user['last_name'] ?? '';
            
            if (!empty($firstName) && !empty($lastName)) {
                return $firstName . ' ' . $lastName;
            } elseif (!empty($firstName)) {
                return $firstName;
            } elseif (!empty($lastName)) {
                return $lastName;
            }
        }
        return 'Administrator';
    }
}

if (!function_exists('sanitizeOutput')) {
    function sanitizeOutput($string) {
        return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('getRoleDisplayName')) {
    function getRoleDisplayName($role) {
        $roles = [
            'super_admin' => 'Super Administrator',
            'admin' => 'Administrator',
            'staff' => 'Staff Member',
            'student' => 'Student',
            'sponsor' => 'Sponsor',
            'partner' => 'Partner',
            'volunteer' => 'Volunteer',
            'reviewer' => 'Reviewer'
        ];
        return $roles[$role] ?? ucfirst($role);
    }
}

if (!function_exists('isActiveSection')) {
    function isActiveSection($section) {
        $currentPage = $_SERVER['PHP_SELF'] ?? '';
        return strpos($currentPage, $section) !== false;
    }
}

if (!function_exists('getCurrentPage')) {
    function getCurrentPage() {
        return basename($_SERVER['PHP_SELF'] ?? '');
    }
}

if (!function_exists('getPendingApprovals')) {
    function getPendingApprovals() {
        try {
            $db = new Database();
            
            // Projects pending approval
            $db->query("SELECT COUNT(*) as count FROM student_projects WHERE approved = 0 OR approved IS NULL");
            $projects = $db->single();
            
            // Stories pending approval
            $db->query("SELECT COUNT(*) as count FROM stories WHERE status = 'pending' OR status IS NULL");
            $stories = $db->single();
            
            // Comments pending approval
            $db->query("SELECT COUNT(*) as count FROM comments WHERE status = 'pending' OR status IS NULL");
            $comments = $db->single();
            
            // Achievements pending verification
            $db->query("SELECT COUNT(*) as count FROM student_achievements WHERE verified = 0 OR verified IS NULL");
            $achievements = $db->single();
            
            return [
                'projects' => $projects['count'] ?? 0,
                'stories' => $stories['count'] ?? 0,
                'comments' => $comments['count'] ?? 0,
                'achievements' => $achievements['count'] ?? 0
            ];
            
        } catch (Exception $e) {
            error_log("Error in getPendingApprovals: " . $e->getMessage());
            return [
                'projects' => 0,
                'stories' => 0,
                'comments' => 0,
                'achievements' => 0
            ];
        }
    }
}

// Get counts for sidebar badges using the utility functions
$total_users_count = getTotalUsersCount();
$total_students_count = getTotalStudentsCount();
$pending_applications_count = getPendingApplicationsCount();
$active_partners_count = getActivePartnersCount();
$unread_notifications_count = getUnreadNotificationsCount();

// Get pending approvals
$pendingApprovals = getPendingApprovals();

// Get current user info
$currentUser = getCurrentUser();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Sidebar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .admin-sidebar {
            width: 280px;
            min-height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            z-index: 1000;
            overflow-y: auto;
            background: linear-gradient(180deg, #212529 0%, #1a1e21 100%);
        }

        .sidebar-nav .nav-link {
            color: #adb5bd;
            text-decoration: none;
            transition: all 0.3s ease;
            border: none;
            font-weight: 400;
        }

        .sidebar-nav .nav-link:hover {
            color: #fff;
            background-color: rgba(255, 255, 255, 0.1);
            transform: translateX(5px);
            box-shadow: 0 2px 8px rgba(0,0,0,0.2);
        }

        .sidebar-nav .nav-link.active {
            color: #fff;
            background: linear-gradient(135deg, #0d6efd 0%, #0a58ca 100%);
            box-shadow: 0 4px 12px rgba(13, 110, 253, 0.3);
            font-weight: 500;
        }

        .sidebar-nav .nav-link i {
            width: 20px;
            text-align: center;
            transition: transform 0.3s ease;
        }

        .sidebar-nav .nav-link:hover i {
            transform: scale(1.1);
        }

        .nav-section {
            padding: 0.5rem 1rem;
        }

        .sidebar-footer {
            background-color: rgba(0, 0, 0, 0.3);
            backdrop-filter: blur(10px);
        }

        .user-avatar {
            color: #6c757d;
        }

        /* Quick Stats Styles */
        .quick-stats {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 8px;
            padding: 10px;
        }

        .stat-item {
            transition: all 0.3s ease;
        }

        .stat-item:hover {
            background: rgba(255, 255, 255, 0.1) !important;
            transform: translateY(-2px);
        }

        /* Badge styles */
        .badge {
            font-size: 0.7em;
            min-width: 20px;
            font-weight: 600;
        }

        /* Scrollbar styling */
        .admin-sidebar::-webkit-scrollbar {
            width: 6px;
        }

        .admin-sidebar::-webkit-scrollbar-track {
            background: rgba(255, 255, 255, 0.1);
        }

        .admin-sidebar::-webkit-scrollbar-thumb {
            background: rgba(255, 255, 255, 0.3);
            border-radius: 3px;
        }

        .admin-sidebar::-webkit-scrollbar-thumb:hover {
            background: rgba(255, 255, 255, 0.5);
        }

        /* Responsive design */
        @media (max-width: 768px) {
            .admin-sidebar {
                width: 100%;
                position: relative;
                min-height: auto;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }
            
            .sidebar-nav {
                max-height: 60vh;
                overflow-y: auto;
            }
        }

        /* Animation for sidebar items */
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateX(-20px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        .sidebar-nav .nav-item {
            animation: slideIn 0.3s ease forwards;
        }

        .sidebar-nav .nav-item:nth-child(1) { animation-delay: 0.1s; }
        .sidebar-nav .nav-item:nth-child(2) { animation-delay: 0.15s; }
        .sidebar-nav .nav-item:nth-child(3) { animation-delay: 0.2s; }
        .sidebar-nav .nav-item:nth-child(4) { animation-delay: 0.25s; }
        .sidebar-nav .nav-item:nth-child(5) { animation-delay: 0.3s; }
    </style>
</head>
<body>
    <!-- Enhanced Admin Sidebar -->
    <nav class="admin-sidebar bg-dark text-white">
        <div class="sidebar-header p-3 border-bottom border-secondary">
            <div class="d-flex align-items-center">
                <div class="sidebar-logo me-2">
                    <i class="fas fa-hands-helping fa-2x text-primary"></i>
                </div>
                <div>
                    <h5 class="mb-0 fw-bold">REACH Admin</h5>
                    <small class="text-muted">Control Panel</small>
                </div>
            </div>
        </div>
        
        <ul class="sidebar-nav list-unstyled p-3">
            <!-- DASHBOARD -->
            <li class="nav-item mb-2">
                <a href="dashboard.php" class="nav-link d-flex align-items-center py-2 px-3 rounded <?php echo isActiveSection('dashboard') ? 'active bg-primary' : 'text-white'; ?>">
                    <i class="fas fa-tachometer-alt me-3"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            
            <!-- QUICK STATS -->
            <li class="nav-section mt-4 mb-2">
                <small class="text-uppercase text-muted fw-bold">Quick Stats</small>
            </li>
            <div class="quick-stats mb-3">
                <div class="stat-item bg-dark border border-secondary rounded p-2 mb-2">
                    <small class="text-muted d-block">Total Users</small>
                    <strong class="text-white"><?php echo $total_users_count; ?></strong>
                </div>
                <div class="stat-item bg-dark border border-secondary rounded p-2 mb-2">
                    <small class="text-muted d-block">Pending Applications</small>
                    <strong class="text-warning"><?php echo $pending_applications_count; ?></strong>
                </div>
                <div class="stat-item bg-dark border border-secondary rounded p-2">
                    <small class="text-muted d-block">Active Partners</small>
                    <strong class="text-success"><?php echo $active_partners_count; ?></strong>
                </div>
            </div>
            
            <!-- SYSTEM CONTROL -->
            <li class="nav-section mt-4 mb-2">
                <small class="text-uppercase text-muted fw-bold">System Control</small>
            </li>
            <li class="nav-item mb-2">
                <a href="control-panel.php" class="nav-link d-flex align-items-center py-2 px-3 rounded <?php echo getCurrentPage() == 'control-panel.php' ? 'active bg-primary' : 'text-white'; ?>">
                    <i class="fas fa-cogs me-3"></i>
                    <span>Control Panel</span>
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="system-settings.php" class="nav-link d-flex align-items-center py-2 px-3 rounded <?php echo getCurrentPage() == 'system-settings.php' ? 'active bg-primary' : 'text-white'; ?>">
                    <i class="fas fa-sliders-h me-3"></i>
                    <span>System Settings</span>
                </a>
            </li>
            
            <!-- USER MANAGEMENT -->
            <li class="nav-section mt-4 mb-2">
                <small class="text-uppercase text-muted fw-bold">User Management</small>
            </li>
            <li class="nav-item mb-2">
                <a href="users.php" class="nav-link d-flex align-items-center justify-content-between py-2 px-3 rounded <?php echo isActiveSection('users') ? 'active bg-primary' : 'text-white'; ?>">
                    <div class="d-flex align-items-center">
                        <i class="fas fa-users me-3"></i>
                        <span>All Users</span>
                    </div>
                    <span class="badge bg-primary rounded-pill"><?php echo $total_users_count; ?></span>
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="students.php" class="nav-link d-flex align-items-center justify-content-between py-2 px-3 rounded <?php echo isActiveSection('students') ? 'active bg-primary' : 'text-white'; ?>">
                    <div class="d-flex align-items-center">
                        <i class="fas fa-user-graduate me-3"></i>
                        <span>Students</span>
                    </div>
                    <span class="badge bg-info rounded-pill"><?php echo $total_students_count; ?></span>
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="partners.php" class="nav-link d-flex align-items-center justify-content-between py-2 px-3 rounded <?php echo getCurrentPage() == 'partners.php' ? 'active bg-primary' : 'text-white'; ?>">
                    <div class="d-flex align-items-center">
                        <i class="fas fa-handshake me-3"></i>
                        <span>Partners</span>
                    </div>
                    <span class="badge bg-success rounded-pill"><?php echo $active_partners_count; ?></span>
                </a>
            </li>
            
            <!-- CONTENT MODERATION -->
            <li class="nav-section mt-4 mb-2">
                <small class="text-uppercase text-muted fw-bold">Content Moderation</small>
            </li>
            <li class="nav-item mb-2">
                <a href="projects.php" class="nav-link d-flex align-items-center justify-content-between py-2 px-3 rounded <?php echo getCurrentPage() == 'projects.php' ? 'active bg-primary' : 'text-white'; ?>">
                    <div class="d-flex align-items-center">
                        <i class="fas fa-project-diagram me-3"></i>
                        <span>Projects</span>
                    </div>
                    <?php if ($pendingApprovals['projects'] > 0): ?>
                        <span class="badge bg-warning rounded-pill"><?php echo $pendingApprovals['projects']; ?></span>
                    <?php else: ?>
                        <span class="badge bg-secondary rounded-pill">0</span>
                    <?php endif; ?>
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="stories.php" class="nav-link d-flex align-items-center justify-content-between py-2 px-3 rounded <?php echo getCurrentPage() == 'stories.php' ? 'active bg-primary' : 'text-white'; ?>">
                    <div class="d-flex align-items-center">
                        <i class="fas fa-book-open me-3"></i>
                        <span>Stories</span>
                    </div>
                    <?php if ($pendingApprovals['stories'] > 0): ?>
                        <span class="badge bg-warning rounded-pill"><?php echo $pendingApprovals['stories']; ?></span>
                    <?php else: ?>
                        <span class="badge bg-secondary rounded-pill">0</span>
                    <?php endif; ?>
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="comments.php" class="nav-link d-flex align-items-center justify-content-between py-2 px-3 rounded <?php echo getCurrentPage() == 'comments.php' ? 'active bg-primary' : 'text-white'; ?>">
                    <div class="d-flex align-items-center">
                        <i class="fas fa-comments me-3"></i>
                        <span>Comments</span>
                    </div>
                    <?php if ($pendingApprovals['comments'] > 0): ?>
                        <span class="badge bg-warning rounded-pill"><?php echo $pendingApprovals['comments']; ?></span>
                    <?php else: ?>
                        <span class="badge bg-secondary rounded-pill">0</span>
                    <?php endif; ?>
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="achievements.php" class="nav-link d-flex align-items-center justify-content-between py-2 px-3 rounded <?php echo getCurrentPage() == 'achievements.php' ? 'active bg-primary' : 'text-white'; ?>">
                    <div class="d-flex align-items-center">
                        <i class="fas fa-trophy me-3"></i>
                        <span>Achievements</span>
                    </div>
                    <?php if ($pendingApprovals['achievements'] > 0): ?>
                        <span class="badge bg-warning rounded-pill"><?php echo $pendingApprovals['achievements']; ?></span>
                    <?php else: ?>
                        <span class="badge bg-secondary rounded-pill">0</span>
                    <?php endif; ?>
                </a>
            </li>
            
            <!-- APPLICATIONS -->
            <li class="nav-section mt-4 mb-2">
                <small class="text-uppercase text-muted fw-bold">Applications</small>
            </li>
            <li class="nav-item mb-2">
                <a href="applications.php" class="nav-link d-flex align-items-center justify-content-between py-2 px-3 rounded <?php echo isActiveSection('applications') ? 'active bg-primary' : 'text-white'; ?>">
                    <div class="d-flex align-items-center">
                        <i class="fas fa-clipboard-list me-3"></i>
                        <span>All Applications</span>
                    </div>
                    <span class="badge bg-warning rounded-pill"><?php echo $pending_applications_count; ?></span>
                </a>
            </li>
            
            <!-- SYSTEM TOOLS -->
            <li class="nav-section mt-4 mb-2">
                <small class="text-uppercase text-muted fw-bold">System Tools</small>
            </li>
            <li class="nav-item mb-2">
                <a href="logs.php" class="nav-link d-flex align-items-center justify-content-between py-2 px-3 rounded <?php echo getCurrentPage() == 'logs.php' ? 'active bg-primary' : 'text-white'; ?>">
                    <div class="d-flex align-items-center">
                        <i class="fas fa-history me-3"></i>
                        <span>System Logs</span>
                    </div>
                    <span class="badge bg-info rounded-pill"><?php echo $unread_notifications_count; ?></span>
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="maintenance.php" class="nav-link d-flex align-items-center py-2 px-3 rounded <?php echo getCurrentPage() == 'maintenance.php' ? 'active bg-primary' : 'text-white'; ?>">
                    <i class="fas fa-tools me-3"></i>
                    <span>Maintenance</span>
                </a>
            </li>
        </ul>
        
        <div class="sidebar-footer p-3 border-top border-secondary">
            <div class="user-info mb-3">
                <div class="d-flex align-items-center">
                    <div class="user-avatar me-2">
                        <div class="bg-primary rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                            <span class="text-white fw-bold"><?php echo getUserInitials($currentUser); ?></span>
                        </div>
                    </div>
                    <div>
                        <strong class="d-block"><?php echo sanitizeOutput(getDisplayName($currentUser)); ?></strong>
                        <small class="text-muted"><?php echo getRoleDisplayName($currentUser['role'] ?? 'admin'); ?></small>
                    </div>
                </div>
            </div>
            <div class="d-grid gap-2">
                <a href="../profile.php" class="btn btn-sm btn-outline-light">
                    <i class="fas fa-user-cog me-2"></i> Profile
                </a>
                <a href="../logout.php" class="btn btn-sm btn-outline-danger">
                    <i class="fas fa-sign-out-alt me-2"></i> Logout
                </a>
            </div>
        </div>
    </nav>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Enhanced sidebar functionality
        document.addEventListener('DOMContentLoaded', function() {
            const sidebar = document.querySelector('.admin-sidebar');
            const navLinks = document.querySelectorAll('.nav-link');
            
            // Add active state based on current page
            function setActiveNav() {
                const currentPath = window.location.pathname;
                navLinks.forEach(link => {
                    link.classList.remove('active');
                    const href = link.getAttribute('href');
                    if (href && currentPath.includes(href)) {
                        link.classList.add('active');
                    }
                });
            }
            
            // Add hover effects
            navLinks.forEach(link => {
                link.addEventListener('mouseenter', function() {
                    this.style.transform = 'translateX(8px)';
                });
                
                link.addEventListener('mouseleave', function() {
                    if (!this.classList.contains('active')) {
                        this.style.transform = 'translateX(0)';
                    }
                });
            });
            
            // Initialize
            setActiveNav();
            
            // Update active nav on navigation
            window.addEventListener('popstate', setActiveNav);
        });

        // Add keyboard navigation
        document.addEventListener('keydown', function(e) {
            if (e.altKey && e.key >= '1' && e.key <= '9') {
                const index = parseInt(e.key) - 1;
                const navLinks = document.querySelectorAll('.nav-link');
                if (navLinks[index]) {
                    navLinks[index].click();
                }
            }
        });
    </script>
</body>
</html>