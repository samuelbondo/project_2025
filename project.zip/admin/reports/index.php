<?php
include '../../includes/config.php';
include '../../includes/auth.php';
$auth->checkRole(['super_admin', 'admin']);

include '../../includes/classes/ApplicationManager.php';
include '../../includes/classes/DonationManager.php';

$applicationManager = new ApplicationManager($pdo);
$donationManager = new DonationManager($pdo);

$appStats = $applicationManager->getApplicationStatistics();
$donationStats = $donationManager->getDonationStatistics();

// Get monthly data for charts
$monthlyApps = $pdo->query("
    SELECT DATE_FORMAT(submitted_at, '%Y-%m') as month, COUNT(*) as count 
    FROM applications 
    WHERE status != 'draft' 
    GROUP BY DATE_FORMAT(submitted_at, '%Y-%m') 
    ORDER BY month DESC 
    LIMIT 12
")->fetchAll();

$monthlyDonations = $pdo->query("
    SELECT DATE_FORMAT(created_at, '%Y-%m') as month, SUM(amount) as total 
    FROM donations 
    WHERE payment_status = 'completed' 
    GROUP BY DATE_FORMAT(created_at, '%Y-%m') 
    ORDER BY month DESC 
    LIMIT 12
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports & Analytics - REACH Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../../assets/css/admin.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="admin-dashboard">
    <?php include '../partials/admin-header.php'; ?>
    <?php include '../partials/admin-sidebar.php'; ?>

    <main class="admin-main">
        <div class="admin-header">
            <h1><i class="fas fa-chart-bar me-2"></i>Reports & Analytics</h1>
            <div class="admin-actions">
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#generateReportModal">
                    <i class="fas fa-download me-2"></i>Generate Report
                </button>
            </div>
        </div>

        <!-- Key Metrics -->
        <div class="row g-4 mb-4">
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-icon primary">
                        <i class="fas fa-inbox"></i>
                    </div>
                    <div class="stat-content">
                        <h3><?php echo number_format($appStats['total']); ?></h3>
                        <p>Total Applications</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-icon success">
                        <i class="fas fa-dollar-sign"></i>
                    </div>
                    <div class="stat-content">
                        <h3>$<?php echo number_format($donationStats['total_amount'] ?? 0); ?></h3>
                        <p>Total Donations</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-icon warning">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="stat-content">
                        <h3><?php echo number_format($appStats['pending']); ?></h3>
                        <p>Pending Review</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-icon info">
                        <i class="fas fa-percentage"></i>
                    </div>
                    <div class="stat-content">
                        <h3><?php echo number_format(($appStats['approved'] / max($appStats['total'], 1)) * 100, 1); ?>%</h3>
                        <p>Approval Rate</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Charts -->
        <div class="row g-4">
            <div class="col-lg-6">
                <div class="admin-card">
                    <div class="card-header">
                        <h5 class="mb-0">Applications Trend</h5>
                    </div>
                    <div class="card-body">
                        <canvas id="applicationsChart" height="250"></canvas>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="admin-card">
                    <div class="card-header">
                        <h5 class="mb-0">Donations Trend</h5>
                    </div>
                    <div class="card-body">
                        <canvas id="donationsChart" height="250"></canvas>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="admin-card">
                    <div class="card-header">
                        <h5 class="mb-0">Application Status Distribution</h5>
                    </div>
                    <div class="card-body">
                        <canvas id="statusChart" height="250"></canvas>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="admin-card">
                    <div class="card-header">
                        <h5 class="mb-0">Program Type Distribution</h5>
                    </div>
                    <div class="card-body">
                        <canvas id="programChart" height="250"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Generate Report Modal -->
    <div class="modal fade" id="generateReportModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Generate Custom Report</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="generateReportForm">
                        <div class="mb-3">
                            <label class="form-label">Report Type</label>
                            <select class="form-select" name="report_type">
                                <option value="applications">Applications Report</option>
                                <option value="donations">Donations Report</option>
                                <option value="financial">Financial Summary</option>
                                <option value="performance">Performance Analytics</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Date Range</label>
                            <div class="row">
                                <div class="col-md-6">
                                    <input type="date" class="form-control" name="date_from" required>
                                </div>
                                <div class="col-md-6">
                                    <input type="date" class="form-control" name="date_to" required>
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Format</label>
                            <select class="form-select" name="format">
                                <option value="pdf">PDF</option>
                                <option value="excel">Excel</option>
                                <option value="csv">CSV</option>
                            </select>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="generateReportBtn">Generate Report</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Applications Trend Chart
        const appsCtx = document.getElementById('applicationsChart').getContext('2d');
        new Chart(appsCtx, {
            type: 'line',
            data: {
                labels: <?php echo json_encode(array_column($monthlyApps, 'month')); ?>.reverse(),
                datasets: [{
                    label: 'Applications',
                    data: <?php echo json_encode(array_column($monthlyApps, 'count')); ?>.reverse(),
                    borderColor: '#3498db',
                    backgroundColor: 'rgba(52, 152, 219, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });

        // Donations Trend Chart
        const donationsCtx = document.getElementById('donationsChart').getContext('2d');
        new Chart(donationsCtx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode(array_column($monthlyDonations, 'month')); ?>.reverse(),
                datasets: [{
                    label: 'Donations ($)',
                    data: <?php echo json_encode(array_column($monthlyDonations, 'total')); ?>.reverse(),
                    backgroundColor: '#27ae60'
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });

        // Application Status Chart
        const statusCtx = document.getElementById('statusChart').getContext('2d');
        new Chart(statusCtx, {
            type: 'doughnut',
            data: {
                labels: ['Submitted', 'Under Review', 'Approved', 'Rejected', 'Waitlisted'],
                datasets: [{
                    data: [
                        <?php echo $appStats['pending']; ?>,
                        <?php echo $appStats['under_review']; ?>,
                        <?php echo $appStats['approved']; ?>,
                        <?php echo $appStats['rejected']; ?>,
                        <?php echo $appStats['waitlisted']; ?>
                    ],
                    backgroundColor: [
                        '#6c757d', '#ffc107', '#28a745', '#dc3545', '#17a2b8'
                    ]
                }]
            }
        });

        // Generate Report
        document.getElementById('generateReportBtn').addEventListener('click', function() {
            const form = document.getElementById('generateReportForm');
            const formData = new FormData(form);
            
            // Simulate report generation
            alert('Report generation functionality would be implemented here');
            bootstrap.Modal.getInstance(document.getElementById('generateReportModal')).hide();
        });
    });
    </script>
</body>
</html>