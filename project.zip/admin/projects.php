<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/database.php';

if (!$auth->isLoggedIn() || !$auth->hasAnyRole(['admin', 'staff'])) {
    header('Location: ../login.php');
    exit;
}

class ContentModerator {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    public function getModerationStats() {
        $stats = [
            'pending_projects' => 0,
            'pending_stories' => 0,
            'pending_comments' => 0,
            'pending_deliverables' => 0
        ];
        
        try {
            // Pending projects (not approved)
            $stmt = $this->pdo->query("SELECT COUNT(*) FROM student_projects WHERE approved = 0");
            $stats['pending_projects'] = $stmt->fetchColumn();
            
            // Pending stories (draft status)
            $stmt = $this->pdo->query("SELECT COUNT(*) FROM stories WHERE status = 'draft'");
            $stats['pending_stories'] = $stmt->fetchColumn();
            
            // Pending comments
            $stmt = $this->pdo->query("SELECT COUNT(*) FROM comments WHERE status = 'pending'");
            $stats['pending_comments'] = $stmt->fetchColumn();
            
            // Pending deliverables
            $stmt = $this->pdo->query("SELECT COUNT(*) FROM project_deliverables WHERE approved = 0");
            $stats['pending_deliverables'] = $stmt->fetchColumn();
            
        } catch (Exception $e) {
            error_log("Moderation stats error: " . $e->getMessage());
        }
        
        return $stats;
    }
    
    public function getPendingProjects() {
        try {
            $sql = "SELECT 
                    p.*, 
                    u.full_name as student_name,
                    u.email as student_email,
                    sp.university,
                    sp.program,
                    sp.faculty,
                    sp.department
                FROM student_projects p
                JOIN users u ON p.student_id = u.id
                LEFT JOIN student_profiles sp ON u.id = sp.user_id
                WHERE p.approved = 0
                ORDER BY p.created_at DESC";
                
            $stmt = $this->pdo->query($sql);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Pending projects error: " . $e->getMessage());
            return [];
        }
    }
    
    public function getPendingStories() {
        try {
            $sql = "SELECT 
                    s.*, 
                    u.full_name as author_name,
                    u.email as author_email
                FROM stories s
                JOIN users u ON s.author_id = u.id
                WHERE s.status = 'draft'
                ORDER BY s.created_at DESC";
                
            $stmt = $this->pdo->query($sql);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Pending stories error: " . $e->getMessage());
            return [];
        }
    }
    
    public function getPendingComments() {
        try {
            $sql = "SELECT 
                    c.*, 
                    u.full_name as author_name,
                    u.email as author_email,
                    CASE 
                        WHEN c.entity_type = 'story' THEN (SELECT title FROM stories WHERE id = c.entity_id)
                        WHEN c.entity_type = 'project' THEN (SELECT title FROM student_projects WHERE id = c.entity_id)
                        ELSE 'Unknown'
                    END as entity_title
                FROM comments c
                JOIN users u ON c.author_id = u.id
                WHERE c.status = 'pending'
                ORDER BY c.created_at DESC";
                
            $stmt = $this->pdo->query($sql);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Pending comments error: " . $e->getMessage());
            return [];
        }
    }
    
    public function getPendingDeliverables() {
        try {
            $sql = "SELECT 
                    d.*,
                    p.title as project_title,
                    u.full_name as student_name,
                    u.email as student_email
                FROM project_deliverables d
                JOIN student_projects p ON d.project_id = p.id
                JOIN users u ON p.student_id = u.id
                WHERE d.approved = 0
                ORDER BY d.created_at DESC";
                
            $stmt = $this->pdo->query($sql);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Pending deliverables error: " . $e->getMessage());
            return [];
        }
    }
    
    public function moderateProject($projectId, $action, $adminId, $notes = '') {
        try {
            $updates = [];
            $currentTime = date('Y-m-d H:i:s');
            
            switch ($action) {
                case 'approve':
                    $updates = [
                        'approved' => 1, 
                        'approved_by' => $adminId, 
                        'approved_at' => $currentTime,
                        'status' => 'in_progress'
                    ];
                    break;
                case 'reject':
                    $updates = [
                        'approved' => 0, 
                        'approved_by' => $adminId, 
                        'approved_at' => $currentTime,
                        'status' => 'on_hold'
                    ];
                    break;
                case 'request_revision':
                    $updates = [
                        'approved' => 0,
                        'status' => 'planning',
                        'challenges' => $notes
                    ];
                    break;
                default:
                    return false;
            }
            
            $setClause = implode(', ', array_map(fn($k) => "$k = ?", array_keys($updates)));
            $params = array_values($updates);
            $params[] = $projectId;
            
            $sql = "UPDATE student_projects SET $setClause WHERE id = ?";
            $stmt = $this->pdo->prepare($sql);
            $result = $stmt->execute($params);
            
            if ($result) {
                $this->logModeration($adminId, $projectId, $action, $notes);
                $this->notifyStudentAboutProject($projectId, $action, $notes);
                return true;
            }
            
            return false;
            
        } catch (Exception $e) {
            error_log("Moderate project error: " . $e->getMessage());
            return false;
        }
    }
    
    public function moderateStory($storyId, $action, $adminId, $notes = '') {
        try {
            $updates = [];
            $currentTime = date('Y-m-d H:i:s');
            
            switch ($action) {
                case 'publish':
                    $updates = [
                        'status' => 'published', 
                        'published_at' => $currentTime
                    ];
                    break;
                case 'reject':
                    $updates = ['status' => 'archived'];
                    break;
                case 'request_revision':
                    $updates = ['status' => 'draft'];
                    break;
                default:
                    return false;
            }
            
            $setClause = implode(', ', array_map(fn($k) => "$k = ?", array_keys($updates)));
            $params = array_values($updates);
            $params[] = $storyId;
            
            $sql = "UPDATE stories SET $setClause WHERE id = ?";
            $stmt = $this->pdo->prepare($sql);
            $result = $stmt->execute($params);
            
            if ($result) {
                $this->logModeration($adminId, $storyId, $action, $notes, 'story');
                $this->notifyAuthorAboutStory($storyId, $action, $notes);
                return true;
            }
            
            return false;
            
        } catch (Exception $e) {
            error_log("Moderate story error: " . $e->getMessage());
            return false;
        }
    }
    
    public function moderateComment($commentId, $action, $adminId, $notes = '') {
        try {
            $statusMap = [
                'approve' => 'approved',
                'reject' => 'rejected',
                'spam' => 'rejected'
            ];
            
            if (!isset($statusMap[$action])) return false;
            
            $sql = "UPDATE comments SET status = ? WHERE id = ?";
            $stmt = $this->pdo->prepare($sql);
            $result = $stmt->execute([$statusMap[$action], $commentId]);
            
            if ($result) {
                $this->logModeration($adminId, $commentId, $action, $notes, 'comment');
                return true;
            }
            
            return false;
            
        } catch (Exception $e) {
            error_log("Moderate comment error: " . $e->getMessage());
            return false;
        }
    }
    
    public function moderateDeliverable($deliverableId, $action, $adminId, $notes = '') {
        try {
            $updates = [];
            $currentTime = date('Y-m-d H:i:s');
            
            switch ($action) {
                case 'approve':
                    $updates = [
                        'approved' => 1, 
                        'approved_by' => $adminId, 
                        'approved_at' => $currentTime
                    ];
                    break;
                case 'reject':
                    $updates = [
                        'approved' => 0, 
                        'approved_by' => $adminId, 
                        'approved_at' => $currentTime
                    ];
                    break;
                case 'request_revision':
                    $updates = [
                        'approved' => 0,
                        'description' => $notes
                    ];
                    break;
                default:
                    return false;
            }
            
            $setClause = implode(', ', array_map(fn($k) => "$k = ?", array_keys($updates)));
            $params = array_values($updates);
            $params[] = $deliverableId;
            
            $sql = "UPDATE project_deliverables SET $setClause WHERE id = ?";
            $stmt = $this->pdo->prepare($sql);
            $result = $stmt->execute($params);
            
            if ($result) {
                $this->logModeration($adminId, $deliverableId, $action, $notes, 'deliverable');
                return true;
            }
            
            return false;
            
        } catch (Exception $e) {
            error_log("Moderate deliverable error: " . $e->getMessage());
            return false;
        }
    }
    
    public function bulkModerateProjects($projectIds, $action, $adminId, $notes = '') {
        try {
            if (empty($projectIds)) return false;
            
            $placeholders = str_repeat('?,', count($projectIds) - 1) . '?';
            $currentTime = date('Y-m-d H:i:s');
            
            switch ($action) {
                case 'approve':
                    $sql = "UPDATE student_projects SET approved = 1, approved_by = ?, approved_at = ?, status = 'in_progress' WHERE id IN ($placeholders)";
                    break;
                case 'reject':
                    $sql = "UPDATE student_projects SET approved = 0, approved_by = ?, approved_at = ?, status = 'on_hold' WHERE id IN ($placeholders)";
                    break;
                default:
                    return false;
            }
            
            $params = array_merge([$adminId, $currentTime], $projectIds);
            $stmt = $this->pdo->prepare($sql);
            $result = $stmt->execute($params);
            
            if ($result) {
                foreach ($projectIds as $projectId) {
                    $this->logModeration($adminId, $projectId, $action, $notes);
                }
                return true;
            }
            
            return false;
            
        } catch (Exception $e) {
            error_log("Bulk moderation error: " . $e->getMessage());
            return false;
        }
    }
    
    private function logModeration($adminId, $entityId, $action, $notes, $entityType = 'project') {
        try {
            $sql = "INSERT INTO activity_log (user_id, action, description, ip_address) 
                    VALUES (?, ?, ?, ?)";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([
                $adminId,
                "moderate_{$entityType}_{$action}",
                "{$entityType} ID {$entityId}: {$action}" . ($notes ? " - {$notes}" : ""),
                $_SERVER['REMOTE_ADDR']
            ]);
        } catch (Exception $e) {
            error_log("Activity log error: " . $e->getMessage());
        }
    }
    
    private function notifyStudentAboutProject($projectId, $action, $notes) {
        try {
            $sql = "SELECT p.title, u.id as student_id, u.email, u.full_name 
                    FROM student_projects p 
                    JOIN users u ON p.student_id = u.id 
                    WHERE p.id = ?";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$projectId]);
            $project = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($project) {
                $message = "Your project '{$project['title']}' has been {$action}ed";
                if (!empty($notes)) {
                    $message .= ". Admin feedback: {$notes}";
                }
                
                // Create notification
                $notifSql = "INSERT INTO notifications (user_id, title, message, type) VALUES (?, 'Project Update', ?, ?)";
                $notifStmt = $this->pdo->prepare($notifSql);
                $notifStmt->execute([
                    $project['student_id'],
                    $message,
                    $action === 'approve' ? 'success' : 'warning'
                ]);
                
                error_log("Project notification: {$projectId} {$action} - Student: {$project['email']}");
            }
        } catch (Exception $e) {
            error_log("Project notification error: " . $e->getMessage());
        }
    }
    
    private function notifyAuthorAboutStory($storyId, $action, $notes) {
        try {
            $sql = "SELECT s.title, u.id as author_id, u.email, u.full_name 
                    FROM stories s 
                    JOIN users u ON s.author_id = u.id 
                    WHERE s.id = ?";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$storyId]);
            $story = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($story) {
                $message = "Your story '{$story['title']}' has been {$action}ed";
                if (!empty($notes)) {
                    $message .= ". Admin feedback: {$notes}";
                }
                
                // Create notification
                $notifSql = "INSERT INTO notifications (user_id, title, message, type) VALUES (?, 'Story Update', ?, ?)";
                $notifStmt = $this->pdo->prepare($notifSql);
                $notifStmt->execute([
                    $story['author_id'],
                    $message,
                    $action === 'publish' ? 'success' : 'warning'
                ]);
                
                error_log("Story notification: {$storyId} {$action} - Author: {$story['email']}");
            }
        } catch (Exception $e) {
            error_log("Story notification error: " . $e->getMessage());
        }
    }
}

// Initialize Moderator
$moderator = new ContentModerator($pdo);
$currentUser = $auth->getCurrentUser();

// Handle moderation actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF protection
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $_SESSION['flash_message'] = "Security token invalid. Please try again.";
        $_SESSION['flash_type'] = 'danger';
        header('Location: projects.php');
        exit;
    }
    
    $entityType = $_POST['entity_type'] ?? '';
    $entityId = $_POST['entity_id'] ?? '';
    $action = $_POST['action'] ?? '';
    $notes = $_POST['notes'] ?? '';
    
    // Validate inputs
    if (empty($entityType) || empty($entityId) || empty($action)) {
        $_SESSION['flash_message'] = "Invalid moderation request";
        $_SESSION['flash_type'] = 'danger';
        header('Location: projects.php');
        exit;
    }
    
    $result = false;
    
    switch ($entityType) {
        case 'project':
            $result = $moderator->moderateProject($entityId, $action, $currentUser['id'], $notes);
            break;
        case 'story':
            $result = $moderator->moderateStory($entityId, $action, $currentUser['id'], $notes);
            break;
        case 'comment':
            $result = $moderator->moderateComment($entityId, $action, $currentUser['id'], $notes);
            break;
        case 'deliverable':
            $result = $moderator->moderateDeliverable($entityId, $action, $currentUser['id'], $notes);
            break;
        case 'bulk_projects':
            $projectIds = $_POST['project_ids'] ?? [];
            if (!empty($projectIds) && is_array($projectIds)) {
                $result = $moderator->bulkModerateProjects($projectIds, $action, $currentUser['id'], $notes);
            }
            break;
    }
    
    if ($result) {
        $_SESSION['flash_message'] = "Content moderated successfully";
        $_SESSION['flash_type'] = 'success';
    } else {
        $_SESSION['flash_message'] = "Error moderating content";
        $_SESSION['flash_type'] = 'danger';
    }
    
    header('Location: projects.php');
    exit;
}

// Generate CSRF token
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Get pending content
$moderationStats = $moderator->getModerationStats();
$pendingProjects = $moderator->getPendingProjects();
$pendingStories = $moderator->getPendingStories();
$pendingComments = $moderator->getPendingComments();
$pendingDeliverables = $moderator->getPendingDeliverables();

// Log access
try {
    $logSql = "INSERT INTO activity_log (user_id, action, description, ip_address) VALUES (?, 'page_view', 'Accessed project moderation', ?)";
    $logStmt = $pdo->prepare($logSql);
    $logStmt->execute([$currentUser['id'], $_SERVER['REMOTE_ADDR']]);
} catch (Exception $e) {
    error_log("Activity log error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project Moderation - REACH Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .moderation-item {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-left: 4px solid #ffc107;
            transition: all 0.3s ease;
        }
        .moderation-item:hover {
            box-shadow: 0 5px 20px rgba(0,0,0,0.15);
            transform: translateY(-2px);
        }
        .content-preview {
            max-height: 200px;
            overflow: hidden;
            position: relative;
            cursor: pointer;
        }
        .content-preview::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            height: 40px;
            background: linear-gradient(transparent, rgba(255,255,255,0.9));
        }
        .content-preview.expanded::after {
            display: none;
        }
        .moderation-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
        }
        .stat-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 20px rgba(0,0,0,0.15);
        }
        .stat-number {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
        }
        .stat-label {
            font-size: 0.9rem;
            color: #6c757d;
            font-weight: 600;
        }
        .bulk-actions {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 20px;
        }
        .entity-meta {
            font-size: 0.85rem;
            color: #6c757d;
        }
        .action-buttons {
            display: flex;
            gap: 5px;
            flex-wrap: wrap;
        }
        .empty-state {
            text-align: center;
            padding: 3rem 1rem;
            color: #6c757d;
        }
        .empty-state i {
            font-size: 4rem;
            margin-bottom: 1rem;
            opacity: 0.5;
        }
        .admin-main {
            margin-left: 250px;
            padding: 20px;
        }
        @media (max-width: 768px) {
            .admin-main {
                margin-left: 0;
            }
        }
        .nav-tabs .nav-link.active {
            font-weight: 600;
            border-bottom: 3px solid #0d6efd;
        }
    </style>
</head>
<body>
    <!-- Include your admin sidebar -->
    <?php if (file_exists('../partials/admin-sidebar.php')): ?>
        <?php include '../partials/admin-sidebar.php'; ?>
    <?php else: ?>
        <!-- Fallback navigation -->
        <nav class="navbar navbar-dark bg-dark">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">
                    <i class="fas fa-hands-helping me-2"></i>REACH Admin
                </a>
                <div class="d-flex">
                    <a href="../dashboard.php" class="btn btn-outline-light btn-sm me-2">
                        <i class="fas fa-tachometer-alt"></i> Dashboard
                    </a>
                    <a href="../../logout.php" class="btn btn-outline-light btn-sm">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </div>
            </div>
        </nav>
    <?php endif; ?>
    
    <main class="admin-main">
        <div class="container-fluid py-4">
            <!-- Header -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1><i class="fas fa-gavel me-2"></i>Project Moderation</h1>
                <div class="moderation-stats">
                    <div class="stat-card">
                        <div class="stat-number text-warning"><?php echo $moderationStats['pending_projects'] ?? 0; ?></div>
                        <div class="stat-label">Pending Projects</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number text-warning"><?php echo $moderationStats['pending_stories'] ?? 0; ?></div>
                        <div class="stat-label">Pending Stories</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number text-warning"><?php echo $moderationStats['pending_comments'] ?? 0; ?></div>
                        <div class="stat-label">Pending Comments</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number text-warning"><?php echo $moderationStats['pending_deliverables'] ?? 0; ?></div>
                        <div class="stat-label">Pending Deliverables</div>
                    </div>
                </div>
            </div>

            <!-- Flash Messages -->
            <?php if (isset($_SESSION['flash_message'])): ?>
                <div class="alert alert-<?php echo $_SESSION['flash_type'] ?> alert-dismissible fade show">
                    <?php echo $_SESSION['flash_message']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <?php unset($_SESSION['flash_message'], $_SESSION['flash_type']); ?>
            <?php endif; ?>

            <!-- Navigation Tabs -->
            <ul class="nav nav-tabs mb-4" id="moderationTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="projects-tab" data-bs-toggle="tab" data-bs-target="#projects" type="button" role="tab">
                        <i class="fas fa-project-diagram me-2"></i>Projects
                        <span class="badge bg-warning ms-2"><?php echo count($pendingProjects); ?></span>
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="stories-tab" data-bs-toggle="tab" data-bs-target="#stories" type="button" role="tab">
                        <i class="fas fa-newspaper me-2"></i>Stories
                        <span class="badge bg-warning ms-2"><?php echo count($pendingStories); ?></span>
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="comments-tab" data-bs-toggle="tab" data-bs-target="#comments" type="button" role="tab">
                        <i class="fas fa-comments me-2"></i>Comments
                        <span class="badge bg-warning ms-2"><?php echo count($pendingComments); ?></span>
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="deliverables-tab" data-bs-toggle="tab" data-bs-target="#deliverables" type="button" role="tab">
                        <i class="fas fa-tasks me-2"></i>Deliverables
                        <span class="badge bg-warning ms-2"><?php echo count($pendingDeliverables); ?></span>
                    </button>
                </li>
            </ul>

            <div class="tab-content" id="moderationTabsContent">
                <!-- Projects Tab -->
                <div class="tab-pane fade show active" id="projects" role="tabpanel">
                    <!-- Bulk Actions for Projects -->
                    <?php if (!empty($pendingProjects)): ?>
                    <div class="bulk-actions">
                        <form method="POST" id="bulkModerationForm">
                            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                            <input type="hidden" name="entity_type" value="bulk_projects">
                            
                            <div class="row align-items-center">
                                <div class="col-md-4">
                                    <h6 class="mb-0"><i class="fas fa-layer-group me-2"></i>Bulk Actions</h6>
                                </div>
                                <div class="col-md-4">
                                    <select name="action" class="form-select" required>
                                        <option value="">Choose bulk action...</option>
                                        <option value="approve">Approve Selected</option>
                                        <option value="reject">Reject Selected</option>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <button type="submit" class="btn btn-primary w-100">
                                        <i class="fas fa-play me-2"></i>Apply to Selected
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                    <?php endif; ?>

                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="mb-0">
                                Pending Project Approvals
                                <span class="badge bg-warning ms-2"><?php echo count($pendingProjects); ?></span>
                            </h5>
                            <?php if (!empty($pendingProjects)): ?>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="selectAllProjects">
                                <label class="form-check-label small" for="selectAllProjects">
                                    Select All
                                </label>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="card-body">
                            <?php foreach ($pendingProjects as $project): ?>
                                <div class="moderation-item">
                                    <div class="row">
                                        <div class="col-md-8">
                                            <div class="form-check mb-2">
                                                <input class="form-check-input project-checkbox" type="checkbox" 
                                                       name="project_ids[]" value="<?php echo $project['id']; ?>" 
                                                       form="bulkModerationForm">
                                                <label class="form-check-label fw-bold">
                                                    <?php echo htmlspecialchars($project['title']); ?>
                                                </label>
                                            </div>
                                            
                                            <p class="text-muted mb-2">
                                                <i class="fas fa-user me-1"></i>
                                                By <?php echo htmlspecialchars($project['student_name']); ?> 
                                                (<?php echo htmlspecialchars($project['university']); ?> - <?php echo htmlspecialchars($project['program']); ?>)
                                            </p>
                                            
                                            <div class="content-preview mb-3">
                                                <p class="mb-2"><?php echo strip_tags($project['description'] ?? 'No description provided'); ?></p>
                                            </div>
                                            
                                            <div class="entity-meta">
                                                <small>
                                                    <i class="fas fa-calendar me-1"></i>
                                                    Submitted: <?php echo date('M j, Y g:i A', strtotime($project['created_at'])); ?>
                                                </small>
                                                <span class="badge bg-secondary ms-2"><?php echo ucfirst($project['project_type']); ?></span>
                                                <span class="badge bg-info ms-1"><?php echo ucfirst($project['status']); ?></span>
                                                <?php if ($project['budget']): ?>
                                                <span class="badge bg-success ms-1">$<?php echo number_format($project['budget'], 2); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <form method="POST" class="moderation-form">
                                                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                                <input type="hidden" name="entity_type" value="project">
                                                <input type="hidden" name="entity_id" value="<?php echo $project['id']; ?>">
                                                
                                                <div class="mb-3">
                                                    <label class="form-label fw-bold">Action</label>
                                                    <select name="action" class="form-select" required>
                                                        <option value="">Choose action...</option>
                                                        <option value="approve">Approve Project</option>
                                                        <option value="request_revision">Request Revision</option>
                                                        <option value="reject">Reject Project</option>
                                                    </select>
                                                </div>
                                                
                                                <div class="mb-3">
                                                    <label class="form-label fw-bold">Notes (Optional)</label>
                                                    <textarea name="notes" class="form-control" rows="3" 
                                                              placeholder="Add notes for the student..."></textarea>
                                                </div>
                                                
                                                <div class="d-grid gap-2">
                                                    <button type="submit" class="btn btn-success">
                                                        <i class="fas fa-check me-2"></i>Submit Decision
                                                    </button>
                                                    <a href="../projects/view.php?id=<?php echo $project['id']; ?>" 
                                                       class="btn btn-outline-primary" target="_blank">
                                                        <i class="fas fa-external-link-alt me-2"></i>View Details
                                                    </a>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                            
                            <?php if (empty($pendingProjects)): ?>
                                <div class="empty-state">
                                    <i class="fas fa-check-circle"></i>
                                    <h5>No pending projects</h5>
                                    <p class="text-muted">All projects have been moderated</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Stories Tab -->
                <div class="tab-pane fade" id="stories" role="tabpanel">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">
                                Pending Story Approvals
                                <span class="badge bg-warning ms-2"><?php echo count($pendingStories); ?></span>
                            </h5>
                        </div>
                        <div class="card-body">
                            <?php foreach ($pendingStories as $story): ?>
                                <div class="moderation-item">
                                    <div class="row">
                                        <div class="col-md-8">
                                            <h6 class="fw-bold"><?php echo htmlspecialchars($story['title']); ?></h6>
                                            <p class="text-muted mb-2">
                                                <i class="fas fa-user me-1"></i>
                                                By <?php echo htmlspecialchars($story['author_name']); ?>
                                            </p>
                                            
                                            <div class="content-preview mb-3">
                                                <p class="mb-2"><?php echo strip_tags($story['content'] ?? 'No content provided'); ?></p>
                                            </div>
                                            
                                            <div class="entity-meta">
                                                <small>
                                                    <i class="fas fa-calendar me-1"></i>
                                                    Submitted: <?php echo date('M j, Y g:i A', strtotime($story['created_at'])); ?>
                                                </small>
                                                <span class="badge bg-secondary ms-2">Story</span>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <form method="POST" class="moderation-form">
                                                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                                <input type="hidden" name="entity_type" value="story">
                                                <input type="hidden" name="entity_id" value="<?php echo $story['id']; ?>">
                                                
                                                <div class="mb-3">
                                                    <label class="form-label fw-bold">Action</label>
                                                    <select name="action" class="form-select" required>
                                                        <option value="">Choose action...</option>
                                                        <option value="publish">Publish Story</option>
                                                        <option value="request_revision">Request Revision</option>
                                                        <option value="reject">Reject Story</option>
                                                    </select>
                                                </div>
                                                
                                                <div class="mb-3">
                                                    <label class="form-label fw-bold">Notes (Optional)</label>
                                                    <textarea name="notes" class="form-control" rows="3" 
                                                              placeholder="Add notes for the author..."></textarea>
                                                </div>
                                                
                                                <div class="d-grid gap-2">
                                                    <button type="submit" class="btn btn-success">
                                                        <i class="fas fa-check me-2"></i>Submit Decision
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                            
                            <?php if (empty($pendingStories)): ?>
                                <div class="empty-state">
                                    <i class="fas fa-check-circle"></i>
                                    <h5>No pending stories</h5>
                                    <p class="text-muted">All stories have been moderated</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Comments Tab -->
                <div class="tab-pane fade" id="comments" role="tabpanel">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">
                                Pending Comment Approvals
                                <span class="badge bg-warning ms-2"><?php echo count($pendingComments); ?></span>
                            </h5>
                        </div>
                        <div class="card-body">
                            <?php foreach ($pendingComments as $comment): ?>
                                <div class="moderation-item">
                                    <div class="row">
                                        <div class="col-md-8">
                                            <p class="fw-bold mb-2"><?php echo htmlspecialchars($comment['entity_title'] ?? 'Unknown'); ?></p>
                                            <p class="text-muted mb-2">
                                                <i class="fas fa-user me-1"></i>
                                                By <?php echo htmlspecialchars($comment['author_name']); ?>
                                            </p>
                                            
                                            <div class="content-preview mb-3">
                                                <p class="mb-2"><?php echo htmlspecialchars($comment['content']); ?></p>
                                            </div>
                                            
                                            <div class="entity-meta">
                                                <small>
                                                    <i class="fas fa-calendar me-1"></i>
                                                    Submitted: <?php echo date('M j, Y g:i A', strtotime($comment['created_at'])); ?>
                                                </small>
                                                <span class="badge bg-secondary ms-2"><?php echo ucfirst($comment['entity_type']); ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <form method="POST" class="moderation-form">
                                                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                                <input type="hidden" name="entity_type" value="comment">
                                                <input type="hidden" name="entity_id" value="<?php echo $comment['id']; ?>">
                                                
                                                <div class="mb-3">
                                                    <label class="form-label fw-bold">Action</label>
                                                    <select name="action" class="form-select" required>
                                                        <option value="">Choose action...</option>
                                                        <option value="approve">Approve Comment</option>
                                                        <option value="reject">Reject Comment</option>
                                                        <option value="spam">Mark as Spam</option>
                                                    </select>
                                                </div>
                                                
                                                <div class="mb-3">
                                                    <label class="form-label fw-bold">Notes (Optional)</label>
                                                    <textarea name="notes" class="form-control" rows="3" 
                                                              placeholder="Add moderation notes..."></textarea>
                                                </div>
                                                
                                                <div class="d-grid gap-2">
                                                    <button type="submit" class="btn btn-success">
                                                        <i class="fas fa-check me-2"></i>Submit Decision
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                            
                            <?php if (empty($pendingComments)): ?>
                                <div class="empty-state">
                                    <i class="fas fa-check-circle"></i>
                                    <h5>No pending comments</h5>
                                    <p class="text-muted">All comments have been moderated</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Deliverables Tab -->
                <div class="tab-pane fade" id="deliverables" role="tabpanel">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">
                                Pending Deliverable Approvals
                                <span class="badge bg-warning ms-2"><?php echo count($pendingDeliverables); ?></span>
                            </h5>
                        </div>
                        <div class="card-body">
                            <?php foreach ($pendingDeliverables as $deliverable): ?>
                                <div class="moderation-item">
                                    <div class="row">
                                        <div class="col-md-8">
                                            <h6 class="fw-bold"><?php echo htmlspecialchars($deliverable['title']); ?></h6>
                                            <p class="text-muted mb-2">
                                                <i class="fas fa-user me-1"></i>
                                                By <?php echo htmlspecialchars($deliverable['student_name']); ?>
                                                for project: <?php echo htmlspecialchars($deliverable['project_title']); ?>
                                            </p>
                                            
                                            <div class="content-preview mb-3">
                                                <p class="mb-2"><?php echo strip_tags($deliverable['description'] ?? 'No description provided'); ?></p>
                                            </div>
                                            
                                            <div class="entity-meta">
                                                <small>
                                                    <i class="fas fa-calendar me-1"></i>
                                                    Submitted: <?php echo date('M j, Y g:i A', strtotime($deliverable['created_at'])); ?>
                                                </small>
                                                <?php if ($deliverable['file_path']): ?>
                                                <span class="badge bg-info ms-2">Has Attachment</span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <form method="POST" class="moderation-form">
                                                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                                <input type="hidden" name="entity_type" value="deliverable">
                                                <input type="hidden" name="entity_id" value="<?php echo $deliverable['id']; ?>">
                                                
                                                <div class="mb-3">
                                                    <label class="form-label fw-bold">Action</label>
                                                    <select name="action" class="form-select" required>
                                                        <option value="">Choose action...</option>
                                                        <option value="approve">Approve Deliverable</option>
                                                        <option value="request_revision">Request Revision</option>
                                                        <option value="reject">Reject Deliverable</option>
                                                    </select>
                                                </div>
                                                
                                                <div class="mb-3">
                                                    <label class="form-label fw-bold">Notes (Optional)</label>
                                                    <textarea name="notes" class="form-control" rows="3" 
                                                              placeholder="Add feedback for the student..."></textarea>
                                                </div>
                                                
                                                <div class="d-grid gap-2">
                                                    <button type="submit" class="btn btn-success">
                                                        <i class="fas fa-check me-2"></i>Submit Decision
                                                    </button>
                                                    <?php if ($deliverable['file_path']): ?>
                                                    <a href="<?php echo htmlspecialchars($deliverable['file_path']); ?>" 
                                                       class="btn btn-outline-primary" target="_blank">
                                                        <i class="fas fa-download me-2"></i>Download File
                                                    </a>
                                                    <?php endif; ?>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                            
                            <?php if (empty($pendingDeliverables)): ?>
                                <div class="empty-state">
                                    <i class="fas fa-check-circle"></i>
                                    <h5>No pending deliverables</h5>
                                    <p class="text-muted">All deliverables have been moderated</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Auto-expand content preview on click
            document.querySelectorAll('.content-preview').forEach(preview => {
                preview.addEventListener('click', function() {
                    this.style.maxHeight = 'none';
                    this.style.overflow = 'visible';
                    this.classList.add('expanded');
                });
            });

            // Select all projects functionality
            const selectAllCheckbox = document.getElementById('selectAllProjects');
            const projectCheckboxes = document.querySelectorAll('.project-checkbox');
            
            if (selectAllCheckbox) {
                selectAllCheckbox.addEventListener('change', function() {
                    projectCheckboxes.forEach(checkbox => {
                        checkbox.checked = this.checked;
                    });
                });
            }

            // Form validation
            document.querySelectorAll('.moderation-form').forEach(form => {
                form.addEventListener('submit', function(e) {
                    const action = this.querySelector('select[name="action"]')?.value;
                    const notes = this.querySelector('textarea[name="notes"]')?.value;
                    
                    if ((action === 'reject' || action === 'request_revision') && (!notes || notes.trim() === '')) {
                        e.preventDefault();
                        alert('Please provide a reason for ' + (action === 'reject' ? 'rejection' : 'revision request') + '.');
                        return false;
                    }
                    
                    if (action === 'reject' && !confirm('Are you sure you want to reject this content?')) {
                        e.preventDefault();
                        return false;
                    }
                });
            });

            // Bulk form validation
            const bulkForm = document.getElementById('bulkModerationForm');
            if (bulkForm) {
                bulkForm.addEventListener('submit', function(e) {
                    const selectedProjects = document.querySelectorAll('.project-checkbox:checked');
                    const action = this.querySelector('select[name="action"]').value;
                    
                    if (selectedProjects.length === 0) {
                        e.preventDefault();
                        alert('Please select at least one project for bulk action.');
                        return false;
                    }
                    
                    if (!action) {
                        e.preventDefault();
                        alert('Please select a bulk action.');
                        return false;
                    }
                    
                    if (action === 'reject' && !confirm(`Are you sure you want to reject ${selectedProjects.length} project(s)?`)) {
                        e.preventDefault();
                        return false;
                    }
                });
            }

            // Tab persistence
            const moderationTabs = document.getElementById('moderationTabs');
            if (moderationTabs) {
                moderationTabs.addEventListener('shown.bs.tab', function (event) {
                    const activeTab = event.target.getAttribute('data-bs-target');
                    sessionStorage.setItem('activeModerationTab', activeTab);
                });

                // Restore active tab
                const activeTab = sessionStorage.getItem('activeModerationTab');
                if (activeTab) {
                    const tabTrigger = document.querySelector(`[data-bs-target="${activeTab}"]`);
                    if (tabTrigger) {
                        new bootstrap.Tab(tabTrigger).show();
                    }
                }
            }
        });
    </script>
</body>
</html>