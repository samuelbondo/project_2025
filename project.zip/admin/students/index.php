<?php
include '../../includes/config.php';
include '../../includes/auth.php';
include '../../includes/functions.php';
$auth->checkRole(['super_admin', 'admin']);

include '../../includes/classes/UserManager.php';

// Initialize $adminControl variable safely for sidebar compatibility
$adminControl = null;
if (file_exists('../../includes/classes/AdminControl.php')) {
    include '../../includes/classes/AdminControl.php';
    if (class_exists('AdminControl')) {
        $adminControl = new AdminControl($pdo);
    }
}

$userManager = new UserManager($pdo);
$students = $userManager->getUsers(['role' => 'student']);

// Handle bulk actions
if ($_POST['action'] ?? '' === 'bulk_action') {
    $selectedStudents = $_POST['selected_students'] ?? [];
    $bulkAction = $_POST['bulk_action_type'] ?? '';
    
    if (!empty($selectedStudents) && !empty($bulkAction)) {
        switch ($bulkAction) {
            case 'activate':
                if (method_exists($userManager, 'bulkUpdateStatus')) {
                    $userManager->bulkUpdateStatus($selectedStudents, 'active');
                    addSuccessMessage('Selected students activated successfully');
                }
                break;
            case 'deactivate':
                if (method_exists($userManager, 'bulkUpdateStatus')) {
                    $userManager->bulkUpdateStatus($selectedStudents, 'inactive');
                    addSuccessMessage('Selected students deactivated successfully');
                }
                break;
            case 'delete':
                if (method_exists($userManager, 'bulkDelete')) {
                    $userManager->bulkDelete($selectedStudents);
                    addSuccessMessage('Selected students deleted successfully');
                }
                break;
        }
        header('Location: students.php');
        exit;
    }
}

// Log activity
logActivity('view_students', 'Accessed student management page');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Students - REACH Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="../../assets/css/admin.css" rel="stylesheet">
    <style>
        .student-avatar {
            width: 40px;
            height: 40px;
            object-fit: cover;
        }
        .bulk-actions {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 20px;
        }
        .table-checkbox {
            width: 40px;
        }
        .action-buttons .btn {
            margin-right: 5px;
        }
        .status-badge {
            font-size: 0.8em;
        }
        .search-box {
            max-width: 300px;
        }
        .admin-main {
            margin-left: 280px;
            padding: 20px;
            min-height: 100vh;
            background-color: #f8f9fa;
        }
        @media (max-width: 768px) {
            .admin-main {
                margin-left: 0;
            }
        }
        .table-responsive {
            border-radius: 8px;
        }
        .admin-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border: none;
        }
        .card-header {
            background: #f8f9fa;
            border-bottom: 1px solid #dee2e6;
            padding: 1rem 1.5rem;
        }
    </style>
</head>
<body class="admin-dashboard">
    

    <main class="admin-main">
        <div class="container-fluid">
            <!-- Page Header -->
            <div class="admin-header mb-4">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h1><i class="fas fa-user-graduate me-2"></i>Student Management</h1>
                        <p class="text-muted mb-0">Manage student accounts and information</p>
                    </div>
                    <div class="admin-actions">
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addStudentModal">
                            <i class="fas fa-plus me-2"></i>Add Student
                        </button>
                        <button class="btn btn-outline-success" id="exportStudents">
                            <i class="fas fa-download me-2"></i>Export
                        </button>
                    </div>
                </div>
            </div>

            <!-- Flash Messages -->
            <?php echo displayFlashMessages(); ?>

            <!-- Bulk Actions -->
            <div class="bulk-actions">
                <form method="POST" id="bulkActionForm">
                    <div class="row align-items-center">
                        <div class="col-md-6">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="selectAll">
                                <label class="form-check-label" for="selectAll">
                                    Select All
                                </label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="d-flex gap-2">
                                <select class="form-select form-select-sm" name="bulk_action_type" style="max-width: 200px;">
                                    <option value="">Bulk Actions</option>
                                    <option value="activate">Activate</option>
                                    <option value="deactivate">Deactivate</option>
                                    <option value="delete">Delete</option>
                                </select>
                                <button type="submit" name="action" value="bulk_action" class="btn btn-sm btn-outline-primary">
                                    Apply
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>

            <!-- Search and Filters -->
            <div class="row mb-4">
                <div class="col-md-6">
                    <div class="input-group search-box">
                        <input type="text" class="form-control" placeholder="Search students..." id="searchInput">
                        <button class="btn btn-outline-secondary" type="button" id="searchButton">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="d-flex gap-2 justify-content-end">
                        <select class="form-select form-select-sm" style="max-width: 200px;" id="statusFilter">
                            <option value="">All Status</option>
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                            <option value="pending">Pending</option>
                        </select>
                        <select class="form-select form-select-sm" style="max-width: 200px;" id="sortBy">
                            <option value="newest">Newest First</option>
                            <option value="oldest">Oldest First</option>
                            <option value="name_asc">Name A-Z</option>
                            <option value="name_desc">Name Z-A</option>
                        </select>
                    </div>
                </div>
            </div>

            <!-- Students Table -->
            <div class="admin-card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">
                        Students 
                        <span class="badge bg-primary"><?php echo count($students); ?></span>
                    </h5>
                    <div class="text-muted small">
                        Showing <?php echo count($students); ?> students
                    </div>
                </div>
                <div class="card-body">
                    <?php if ($students): ?>
                        <div class="table-responsive">
                            <table class="table table-hover table-striped">
                                <thead class="table-light">
                                    <tr>
                                        <th class="table-checkbox">
                                            <input type="checkbox" class="form-check-input" id="selectAllHeader">
                                        </th>
                                        <th>Student</th>
                                        <th>Contact</th>
                                        <th>Status</th>
                                        <th>Applications</th>
                                        <th>Last Login</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($students as $student): 
                                        // Safe application count retrieval
                                        $applicationCount = 0;
                                        if (method_exists($userManager, 'getUserApplicationCount')) {
                                            $applicationCount = $userManager->getUserApplicationCount($student['id']);
                                        } else {
                                            // Fallback: Try direct query
                                            try {
                                                $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM applications WHERE user_id = ?");
                                                $stmt->execute([$student['id']]);
                                                $result = $stmt->fetch(PDO::FETCH_ASSOC);
                                                $applicationCount = $result['count'] ?? 0;
                                            } catch (Exception $e) {
                                                $applicationCount = 0;
                                            }
                                        }
                                        
                                        $lastLogin = $student['last_login'] ? getRelativeTime($student['last_login']) : 'Never';
                                    ?>
                                    <tr>
                                        <td>
                                            <input type="checkbox" class="form-check-input student-checkbox" 
                                                   name="selected_students[]" value="<?php echo $student['id']; ?>">
                                        </td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="avatar-sm me-3">
                                                    <img src="../../assets/uploads/profiles/<?php echo $student['profile_picture'] ?? 'default.jpg'; ?>" 
                                                         alt="<?php echo htmlspecialchars($student['full_name']); ?>" 
                                                         class="rounded-circle student-avatar"
                                                         onerror="this.src='../../assets/images/default-avatar.jpg'">
                                                </div>
                                                <div>
                                                    <div class="fw-semibold"><?php echo htmlspecialchars($student['full_name']); ?></div>
                                                    <small class="text-muted">@<?php echo $student['username']; ?></small>
                                                    <div class="small text-muted">
                                                        ID: <?php echo $student['id']; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div>
                                                <div><i class="fas fa-envelope me-2 text-muted"></i><?php echo $student['email']; ?></div>
                                                <?php if ($student['phone']): ?>
                                                    <div class="small text-muted">
                                                        <i class="fas fa-phone me-2"></i><?php echo $student['phone']; ?>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td>
                                            <?php
                                            $statusColor = 'secondary';
                                            $statusText = ucfirst($student['status']);
                                            switch($student['status']) {
                                                case 'active': $statusColor = 'success'; break;
                                                case 'inactive': $statusColor = 'secondary'; break;
                                                case 'pending': $statusColor = 'warning'; break;
                                                case 'suspended': $statusColor = 'danger'; break;
                                            }
                                            ?>
                                            <span class="badge status-badge bg-<?php echo $statusColor; ?>">
                                                <?php echo $statusText; ?>
                                            </span>
                                            <?php if (isset($student['email_verified']) && $student['email_verified']): ?>
                                                <br><small class="text-success"><i class="fas fa-check-circle"></i> Verified</small>
                                            <?php else: ?>
                                                <br><small class="text-warning"><i class="fas fa-clock"></i> Unverified</small>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="badge bg-info"><?php echo $applicationCount; ?> apps</span>
                                        </td>
                                        <td>
                                            <small class="text-muted"><?php echo $lastLogin; ?></small>
                                            <br>
                                            <small>Joined <?php echo getRelativeTime($student['created_at']); ?></small>
                                        </td>
                                        <td>
                                            <div class="action-buttons">
                                                <a href="student-profile.php?id=<?php echo $student['id']; ?>" 
                                                   class="btn btn-sm btn-outline-primary" 
                                                   title="View Profile">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <button class="btn btn-sm btn-outline-warning edit-student" 
                                                        data-student-id="<?php echo $student['id']; ?>"
                                                        title="Edit Student">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                <?php if ($student['status'] === 'active'): ?>
                                                    <button class="btn btn-sm btn-outline-secondary toggle-status" 
                                                            data-id="<?php echo $student['id']; ?>" 
                                                            data-action="deactivate"
                                                            title="Deactivate">
                                                        <i class="fas fa-pause"></i>
                                                    </button>
                                                <?php else: ?>
                                                    <button class="btn btn-sm btn-outline-success toggle-status" 
                                                            data-id="<?php echo $student['id']; ?>" 
                                                            data-action="activate"
                                                            title="Activate">
                                                        <i class="fas fa-play"></i>
                                                    </button>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>

                        <!-- Pagination -->
                        <nav aria-label="Student pagination">
                            <ul class="pagination justify-content-center">
                                <li class="page-item disabled">
                                    <a class="page-link" href="#">Previous</a>
                                </li>
                                <li class="page-item active"><a class="page-link" href="#">1</a></li>
                                <li class="page-item"><a class="page-link" href="#">2</a></li>
                                <li class="page-item"><a class="page-link" href="#">3</a></li>
                                <li class="page-item">
                                    <a class="page-link" href="#">Next</a>
                                </li>
                            </ul>
                        </nav>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="fas fa-user-graduate fa-4x text-muted mb-3"></i>
                            <h4>No Students Found</h4>
                            <p class="text-muted mb-4">There are no students registered in the system yet.</p>
                            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addStudentModal">
                                <i class="fas fa-plus me-2"></i>Add First Student
                            </button>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>

    <!-- Add Student Modal -->
    <div class="modal fade" id="addStudentModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-user-plus me-2"></i>Add New Student</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="addStudentForm">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Full Name *</label>
                                    <input type="text" class="form-control" name="full_name" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Username *</label>
                                    <input type="text" class="form-control" name="username" required>
                                    <div class="form-text">Must be unique</div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Email *</label>
                                    <input type="email" class="form-control" name="email" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Phone</label>
                                    <input type="tel" class="form-control" name="phone">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Password *</label>
                                    <input type="password" class="form-control" name="password" required>
                                    <div class="form-text">Minimum 8 characters</div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Confirm Password *</label>
                                    <input type="password" class="form-control" name="confirm_password" required>
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Initial Status</label>
                            <select class="form-select" name="status">
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                                <option value="pending">Pending</option>
                            </select>
                        </div>
                        <!-- CSRF Token for Security -->
                        <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="addStudentBtn">
                        <i class="fas fa-plus me-2"></i>Add Student
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Bulk selection
        const selectAllCheckbox = document.getElementById('selectAll');
        const selectAllHeader = document.getElementById('selectAllHeader');
        const studentCheckboxes = document.querySelectorAll('.student-checkbox');
        
        function updateSelectAllState() {
            const allChecked = Array.from(studentCheckboxes).every(checkbox => checkbox.checked);
            const someChecked = Array.from(studentCheckboxes).some(checkbox => checkbox.checked);
            
            if (selectAllCheckbox) {
                selectAllCheckbox.checked = allChecked;
                selectAllCheckbox.indeterminate = someChecked && !allChecked;
            }
            if (selectAllHeader) {
                selectAllHeader.checked = allChecked;
                selectAllHeader.indeterminate = someChecked && !allChecked;
            }
        }
        
        selectAllCheckbox?.addEventListener('change', function() {
            studentCheckboxes.forEach(checkbox => {
                checkbox.checked = this.checked;
            });
            updateSelectAllState();
        });

        selectAllHeader?.addEventListener('change', function() {
            studentCheckboxes.forEach(checkbox => {
                checkbox.checked = this.checked;
            });
            updateSelectAllState();
        });

        studentCheckboxes.forEach(checkbox => {
            checkbox.addEventListener('change', updateSelectAllState);
        });

        // Add student form
        document.getElementById('addStudentBtn')?.addEventListener('click', function() {
            const form = document.getElementById('addStudentForm');
            const formData = new FormData(form);
            
            // Validate passwords match
            const password = form.querySelector('[name="password"]').value;
            const confirmPassword = form.querySelector('[name="confirm_password"]').value;
            
            if (password !== confirmPassword) {
                alert('Passwords do not match!');
                return;
            }
            
            if (password.length < 8) {
                alert('Password must be at least 8 characters long!');
                return;
            }
            
            // Add role to form data
            formData.append('role', 'student');
            
            // Show loading state
            const btn = this;
            const originalText = btn.innerHTML;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Adding...';
            btn.disabled = true;
            
            fetch('../../api/users/create.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                } else {
                    alert('Error: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while adding the student.');
            })
            .finally(() => {
                btn.innerHTML = originalText;
                btn.disabled = false;
            });
        });

        // Status toggle
        document.querySelectorAll('.toggle-status').forEach(button => {
            button.addEventListener('click', function() {
                const studentId = this.dataset.id;
                const action = this.dataset.action;
                
                if (confirm(`Are you sure you want to ${action} this student?`)) {
                    fetch(`../../api/users/update-status.php`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            user_id: studentId,
                            status: action === 'activate' ? 'active' : 'inactive',
                            csrf_token: '<?php echo $_SESSION['csrf_token'] ?? ''; ?>'
                        })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            location.reload();
                        } else {
                            alert('Error: ' + data.message);
                        }
                    });
                }
            });
        });

        // Search functionality
        const searchInput = document.getElementById('searchInput');
        const searchButton = document.getElementById('searchButton');
        
        function performSearch() {
            const searchTerm = searchInput.value.toLowerCase();
            const rows = document.querySelectorAll('tbody tr');
            let visibleCount = 0;
            
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                const isVisible = text.includes(searchTerm);
                row.style.display = isVisible ? '' : 'none';
                if (isVisible) visibleCount++;
            });
            
            // Update showing count
            const showingElement = document.querySelector('.text-muted.small');
            if (showingElement) {
                showingElement.textContent = `Showing ${visibleCount} students`;
            }
        }
        
        searchInput?.addEventListener('input', performSearch);
        searchButton?.addEventListener('click', performSearch);

        // Filter functionality
        const statusFilter = document.getElementById('statusFilter');
        statusFilter?.addEventListener('change', function() {
            const filterValue = this.value;
            const rows = document.querySelectorAll('tbody tr');
            
            rows.forEach(row => {
                if (!filterValue) {
                    row.style.display = '';
                    return;
                }
                
                const statusBadge = row.querySelector('.status-badge');
                if (statusBadge) {
                    const status = statusBadge.textContent.trim().toLowerCase();
                    row.style.display = status.includes(filterValue) ? '' : 'none';
                }
            });
        });
    });
    </script>
</body>
</html>