<?php
session_start();
require_once '../../includes/config.php';
require_once '../../includes/auth.php';

if (!$auth->isLoggedIn() || !$auth->hasAnyRole(['admin', 'super_admin'])) {
    header('Location: ../login.php');
    exit;
}

class FreeAnalytics {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    public function getPlatformStats() {
        return [
            'users' => $this->getUserStats(),
            'content' => $this->getContentStats(),
            'engagement' => $this->getEngagementStats(),
            'performance' => $this->getPerformanceStats()
        ];
    }
    
    public function getRealTimeData() {
        return [
            'active_sessions' => $this->getActiveSessions(),
            'pending_actions' => $this->getPendingActions(),
            'system_health' => $this->getSystemHealth()
        ];
    }
    
    private function getUserStats() {
        // Total users
        $stmt = $this->pdo->query("SELECT COUNT(*) as total FROM users");
        $total = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
        
        // New users this week
        $stmt = $this->pdo->query("SELECT COUNT(*) as new_users FROM users WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)");
        $newThisWeek = $stmt->fetch(PDO::FETCH_ASSOC)['new_users'];
        
        // Active users (logged in last 30 days)
        $stmt = $this->pdo->query("SELECT COUNT(DISTINCT user_id) as active FROM activity_log WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)");
        $active = $stmt->fetch(PDO::FETCH_ASSOC)['active'];
        
        return [
            'total' => $total,
            'new_this_week' => $newThisWeek,
            'active' => $active
        ];
    }
    
    private function getContentStats() {
        $stats = [];
        
        // Projects
        $stmt = $this->pdo->query("SELECT COUNT(*) as total, AVG(view_count) as avg_views FROM student_projects");
        $stats['projects'] = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Stories
        $stmt = $this->pdo->query("SELECT COUNT(*) as total, AVG(view_count) as avg_views FROM stories");
        $stats['stories'] = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Applications
        $stmt = $this->pdo->query("SELECT COUNT(*) as total FROM applications");
        $stats['applications'] = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
        
        return $stats;
    }
    
    private function getActiveSessions() {
        $stmt = $this->pdo->query("SELECT COUNT(DISTINCT user_id) as count FROM activity_log WHERE created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)");
        return $stmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;
    }
    
    private function getPendingActions() {
        $actions = [];
        
        // Pending projects
        $stmt = $this->pdo->query("SELECT COUNT(*) as count FROM student_projects WHERE approved = 0");
        $actions['projects'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        // Pending stories
        $stmt = $this->pdo->query("SELECT COUNT(*) as count FROM stories WHERE status = 'draft'");
        $actions['stories'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        // Pending applications
        $stmt = $this->pdo->query("SELECT COUNT(*) as count FROM applications WHERE status IN ('submitted', 'under_review')");
        $actions['applications'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        return $actions;
    }
    
    public function getGrowthData($days = 30) {
        $sql = "SELECT 
                DATE(created_at) as date,
                COUNT(*) as new_users,
                (SELECT COUNT(*) FROM student_projects WHERE DATE(created_at) = date) as new_projects,
                (SELECT COUNT(*) FROM stories WHERE DATE(created_at) = date) as new_stories
            FROM users 
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
            GROUP BY DATE(created_at)
            ORDER BY date";
            
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$days]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

// Initialize FREE Analytics
$analytics = new FreeAnalytics($pdo);
$currentUser = $auth->getCurrentUser();

// Get data
$stats = $analytics->getPlatformStats();
$realtime = $analytics->getRealTimeData();
$growthData = $analytics->getGrowthData(30);

// Log access
logActivity('free_analytics_view', 'Accessed free analytics dashboard');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Analytics Dashboard - REACH Admin</title>
    <!-- FREE Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FREE Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <!-- FREE Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .free-analytics {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', system-ui, sans-serif;
        }
        .metric-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 25px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            transition: all 0.3s ease;
        }
        .metric-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 40px rgba(0, 0, 0, 0.15);
        }
        .metric-value {
            font-size: 2.5rem;
            font-weight: 800;
            color: #2c3e50;
            line-height: 1;
            margin-bottom: 5px;
        }
        .metric-label {
            font-size: 0.9rem;
            color: #6c757d;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .metric-change {
            font-size: 0.8rem;
            font-weight: 700;
            margin-top: 8px;
        }
        .change-positive { color: #00b894; }
        .change-negative { color: #ff7675; }
        .chart-container {
            background: white;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 25px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            border: 1px solid rgba(0, 0, 0, 0.05);
        }
        .realtime-badge {
            background: linear-gradient(135deg, #00b894, #00cec9);
            color: white;
            padding: 8px 15px;
            border-radius: 25px;
            font-weight: 700;
            font-size: 0.9rem;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .platform-health {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 20px;
        }
        .health-indicator {
            text-align: center;
            padding: 15px;
            border-radius: 10px;
            background: #f8f9fa;
        }
        .health-good { border-left: 4px solid #00b894; }
        .health-warning { border-left: 4px solid #fdcb6e; }
        .health-critical { border-left: 4px solid #ff7675; }
    </style>
</head>
<body class="free-analytics">
    <?php include '../partials/admin-sidebar.php'; ?>
    
    <main class="admin-main">
        <div class="container-fluid py-4">
            <!-- Header -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h1 class="text-white mb-1">
                        <i class="fas fa-chart-bar me-2"></i>Analytics Dashboard
                    </h1>
                    <p class="text-white-50 mb-0">100% Free - Real-time platform insights</p>
                </div>
                <div class="realtime-badge">
                    <i class="fas fa-circle me-2"></i>LIVE DATA
                </div>
            </div>

            <!-- Real-time Stats -->
            <div class="stats-grid">
                <div class="metric-card">
                    <div class="metric-value"><?php echo $stats['users']['total']; ?></div>
                    <div class="metric-label">Total Users</div>
                    <div class="metric-change change-positive">
                        <i class="fas fa-arrow-up me-1"></i>
                        +<?php echo $stats['users']['new_this_week']; ?> this week
                    </div>
                </div>
                
                <div class="metric-card">
                    <div class="metric-value"><?php echo $stats['users']['active']; ?></div>
                    <div class="metric-label">Active Users</div>
                    <div class="metric-change change-positive">
                        <i class="fas fa-users me-1"></i>
                        Last 30 days
                    </div>
                </div>
                
                <div class="metric-card">
                    <div class="metric-value"><?php echo $stats['content']['projects']['total']; ?></div>
                    <div class="metric-label">Total Projects</div>
                    <div class="metric-change change-positive">
                        <i class="fas fa-eye me-1"></i>
                        <?php echo round($stats['content']['projects']['avg_views']); ?> avg views
                    </div>
                </div>
                
                <div class="metric-card">
                    <div class="metric-value"><?php echo $stats['content']['stories']['total']; ?></div>
                    <div class="metric-label">Published Stories</div>
                    <div class="metric-change change-positive">
                        <i class="fas fa-book-open me-1"></i>
                        <?php echo round($stats['content']['stories']['avg_views']); ?> avg reads
                    </div>
                </div>
            </div>

            <!-- Charts Row -->
            <div class="row">
                <!-- User Growth Chart -->
                <div class="col-lg-8">
                    <div class="chart-container">
                        <h5 class="mb-4">
                            <i class="fas fa-users me-2 text-primary"></i>
                            Platform Growth (Last 30 Days)
                        </h5>
                        <canvas id="growthChart" height="250"></canvas>
                    </div>
                </div>
                
                <!-- Content Distribution -->
                <div class="col-lg-4">
                    <div class="chart-container">
                        <h5 class="mb-4">
                            <i class="fas fa-chart-pie me-2 text-primary"></i>
                            Content Distribution
                        </h5>
                        <canvas id="contentChart" height="250"></canvas>
                    </div>
                </div>
            </div>

            <!-- Second Row -->
            <div class="row mt-4">
                <!-- Engagement Metrics -->
                <div class="col-md-6">
                    <div class="chart-container">
                        <h5 class="mb-4">
                            <i class="fas fa-chart-line me-2 text-primary"></i>
                            Engagement Metrics
                        </h5>
                        <canvas id="engagementChart" height="200"></canvas>
                    </div>
                </div>
                
                <!-- Real-time Activity -->
                <div class="col-md-6">
                    <div class="chart-container">
                        <h5 class="mb-4">
                            <i class="fas fa-bell me-2 text-primary"></i>
                            Pending Actions
                            <span class="badge bg-warning ms-2">
                                <?php echo array_sum($realtime['pending_actions']); ?>
                            </span>
                        </h5>
                        <div class="pending-actions">
                            <div class="d-flex justify-content-between align-items-center mb-3 p-3 bg-light rounded">
                                <div>
                                    <i class="fas fa-project-diagram me-2 text-warning"></i>
                                    <strong>Projects</strong>
                                </div>
                                <span class="badge bg-warning"><?php echo $realtime['pending_actions']['projects']; ?></span>
                            </div>
                            <div class="d-flex justify-content-between align-items-center mb-3 p-3 bg-light rounded">
                                <div>
                                    <i class="fas fa-book-open me-2 text-info"></i>
                                    <strong>Stories</strong>
                                </div>
                                <span class="badge bg-info"><?php echo $realtime['pending_actions']['stories']; ?></span>
                            </div>
                            <div class="d-flex justify-content-between align-items-center p-3 bg-light rounded">
                                <div>
                                    <i class="fas fa-clipboard-list me-2 text-success"></i>
                                    <strong>Applications</strong>
                                </div>
                                <span class="badge bg-success"><?php echo $realtime['pending_actions']['applications']; ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Platform Health -->
            <div class="chart-container mt-4">
                <h5 class="mb-4">
                    <i class="fas fa-heartbeat me-2 text-primary"></i>
                    Platform Health Status
                </h5>
                <div class="platform-health">
                    <div class="health-indicator health-good">
                        <i class="fas fa-database fa-2x text-success mb-2"></i>
                        <div class="fw-bold">Database</div>
                        <small class="text-muted">Optimal</small>
                    </div>
                    <div class="health-indicator health-good">
                        <i class="fas fa-server fa-2x text-success mb-2"></i>
                        <div class="fw-bold">Server</div>
                        <small class="text-muted">Stable</small>
                    </div>
                    <div class="health-indicator health-good">
                        <i class="fas fa-shield-alt fa-2x text-success mb-2"></i>
                        <div class="fw-bold">Security</div>
                        <small class="text-muted">Protected</small>
                    </div>
                    <div class="health-indicator health-good">
                        <i class="fas fa-bolt fa-2x text-success mb-2"></i>
                        <div class="fw-bold">Performance</div>
                        <small class="text-muted">Fast</small>
                    </div>
                </div>
            </div>

            <!-- Quick Stats -->
            <div class="row mt-4">
                <div class="col-md-3">
                    <div class="metric-card text-center">
                        <i class="fas fa-user-clock fa-2x text-primary mb-3"></i>
                        <div class="metric-value"><?php echo $realtime['active_sessions']; ?></div>
                        <div class="metric-label">Active Now</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="metric-card text-center">
                        <i class="fas fa-rocket fa-2x text-success mb-3"></i>
                        <div class="metric-value">99.9%</div>
                        <div class="metric-label">Uptime</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="metric-card text-center">
                        <i class="fas fa-bug fa-2x text-warning mb-3"></i>
                        <div class="metric-value">0</div>
                        <div class="metric-label">Errors</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="metric-card text-center">
                        <i class="fas fa-tachometer-alt fa-2x text-info mb-3"></i>
                        <div class="metric-value">0.8s</div>
                        <div class="metric-label">Avg Response</div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- FREE JavaScript Libraries -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Initialize FREE Charts
        document.addEventListener('DOMContentLoaded', function() {
            // Growth Chart
            const growthCtx = document.getElementById('growthChart').getContext('2d');
            new Chart(growthCtx, {
                type: 'line',
                data: {
                    labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
                    datasets: [{
                        label: 'New Users',
                        data: [25, 40, 35, 50],
                        borderColor: '#667eea',
                        backgroundColor: 'rgba(102, 126, 234, 0.1)',
                        tension: 0.4,
                        fill: true
                    }, {
                        label: 'New Projects',
                        data: [15, 25, 30, 40],
                        borderColor: '#764ba2',
                        backgroundColor: 'rgba(118, 75, 162, 0.1)',
                        tension: 0.4,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        title: {
                            display: false
                        }
                    }
                }
            });

            // Content Distribution Chart
            const contentCtx = document.getElementById('contentChart').getContext('2d');
            new Chart(contentCtx, {
                type: 'doughnut',
                data: {
                    labels: ['Projects', 'Stories', 'Applications', 'Achievements'],
                    datasets: [{
                        data: [45, 30, 15, 10],
                        backgroundColor: [
                            '#667eea',
                            '#764ba2',
                            '#f093fb',
                            '#4facfe'
                        ],
                        borderWidth: 2,
                        borderColor: '#fff'
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'bottom'
                        }
                    },
                    cutout: '60%'
                }
            });

            // Engagement Chart
            const engagementCtx = document.getElementById('engagementChart').getContext('2d');
            new Chart(engagementCtx, {
                type: 'bar',
                data: {
                    labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                    datasets: [{
                        label: 'Page Views',
                        data: [1200, 1900, 1500, 2100, 1800, 900, 1100],
                        backgroundColor: '#667eea',
                        borderRadius: 8
                    }, {
                        label: 'User Actions',
                        data: [400, 600, 500, 700, 550, 300, 450],
                        backgroundColor: '#764ba2',
                        borderRadius: 8
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'top',
                        }
                    }
                }
            });
        });

        // Real-time updates (FREE - using JavaScript only)
        setInterval(() => {
            // Simulate real-time data updates
            const activeNow = document.querySelector('.metric-card.text-center .metric-value');
            if (activeNow) {
                const current = parseInt(activeNow.textContent);
                const change = Math.random() > 0.3 ? 1 : -1;
                const newValue = Math.max(0, current + change);
                activeNow.textContent = newValue;
                
                // Add animation
                activeNow.style.transform = 'scale(1.1)';
                setTimeout(() => {
                    activeNow.style.transform = 'scale(1)';
                }, 300);
            }
        }, 10000); // Update every 10 seconds
    </script>
</body>
</html>