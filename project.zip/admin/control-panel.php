<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

// Enhanced authentication check
if (!$auth->isLoggedIn() || !$auth->hasRole('super_admin')) {
    header('Location: dashboard.php');
    exit;
}

// Get current user before using it
$currentUser = $auth->getCurrentUser();

class SystemControl {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    // SYSTEM SETTINGS CONTROL
    public function getSystemSettings() {
        $settings = [];
        try {
            // Check if settings table exists, if not create it
            $stmt = $this->pdo->query("
                CREATE TABLE IF NOT EXISTS system_settings (
                    id INT PRIMARY KEY AUTO_INCREMENT,
                    setting_key VARCHAR(100) UNIQUE NOT NULL,
                    setting_value TEXT,
                    setting_type ENUM('string', 'integer', 'boolean', 'json') DEFAULT 'string',
                    description TEXT,
                    updated_by INT,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                )
            ");
            
            $stmt = $this->pdo->query("SELECT * FROM system_settings");
            $settings = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Settings error: " . $e->getMessage());
        }
        return $settings;
    }
    
    public function updateSystemSetting($key, $value, $userId) {
        try {
            $sql = "INSERT INTO system_settings (setting_key, setting_value, updated_by) 
                    VALUES (?, ?, ?) 
                    ON DUPLICATE KEY UPDATE setting_value = ?, updated_by = ?";
            $stmt = $this->pdo->prepare($sql);
            return $stmt->execute([$key, $value, $userId, $value, $userId]);
        } catch (Exception $e) {
            error_log("Update setting error: " . $e->getMessage());
            return false;
        }
    }
    
    // USER MANAGEMENT
    public function getAllUsers($filters = []) {
        $where = [];
        $params = [];
        
        if (!empty($filters['role'])) {
            $where[] = "u.role = ?";
            $params[] = $filters['role'];
        }
        
        if (!empty($filters['status'])) {
            $where[] = "u.status = ?";
            $params[] = $filters['status'];
        }
        
        if (!empty($filters['search'])) {
            $where[] = "(u.full_name LIKE ? OR u.email LIKE ? OR u.username LIKE ?)";
            $searchTerm = "%{$filters['search']}%";
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $params[] = $searchTerm;
        }
        
        $whereClause = $where ? "WHERE " . implode(" AND ", $where) : "";
        
        $sql = "SELECT u.*, 
                (SELECT COUNT(*) FROM student_projects WHERE student_id = u.id) as project_count,
                (SELECT COUNT(*) FROM stories WHERE author_id = u.id) as story_count,
                (SELECT COUNT(*) FROM applications WHERE user_id = u.id) as application_count
                FROM users u 
                $whereClause 
                ORDER BY u.created_at DESC 
                LIMIT 100";
                
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function updateUserStatus($userId, $status, $adminId) {
        try {
            $sql = "UPDATE users SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?";
            $stmt = $this->pdo->prepare($sql);
            $result = $stmt->execute([$status, $userId]);
            
            if ($result) {
                $this->logUserAction($adminId, $userId, "status_change", "Changed status to $status");
            }
            
            return $result;
        } catch (Exception $e) {
            error_log("Update user status error: " . $e->getMessage());
            return false;
        }
    }
    
    // CONTENT MODERATION
    public function moderateContent($type, $id, $action, $adminId, $notes = '') {
        try {
            switch ($type) {
                case 'project':
                    return $this->moderateProject($id, $action, $adminId, $notes);
                case 'story':
                    return $this->moderateStory($id, $action, $adminId, $notes);
                case 'comment':
                    return $this->moderateComment($id, $action, $adminId, $notes);
                case 'achievement':
                    return $this->moderateAchievement($id, $action, $adminId, $notes);
                default:
                    return false;
            }
        } catch (Exception $e) {
            error_log("Moderation error: " . $e->getMessage());
            return false;
        }
    }
    
    private function moderateProject($projectId, $action, $adminId, $notes) {
        $statusMap = [
            'approve' => ['approved' => 1, 'approved_by' => $adminId, 'approved_at' => date('Y-m-d H:i:s')],
            'reject' => ['approved' => 0, 'approved_by' => $adminId, 'approved_at' => date('Y-m-d H:i:s')],
            'feature' => ['featured' => 1],
            'unfeature' => ['featured' => 0]
        ];
        
        if (!isset($statusMap[$action])) return false;
        
        $updates = $statusMap[$action];
        $setParts = [];
        $params = [];
        foreach ($updates as $key => $value) {
            $setParts[] = "$key = ?";
            $params[] = $value;
        }
        $setClause = implode(', ', $setParts);
        $params[] = $projectId;
        
        $sql = "UPDATE student_projects SET $setClause WHERE id = ?";
        $stmt = $this->pdo->prepare($sql);
        $result = $stmt->execute($params);
        
        if ($result) {
            $this->logModerationAction($adminId, 'project', $projectId, $action, $notes);
        }
        
        return $result;
    }
    
    private function moderateStory($storyId, $action, $adminId, $notes) {
        $statusMap = [
            'approve' => ['status' => 'published', 'published_by' => $adminId, 'published_at' => date('Y-m-d H:i:s')],
            'reject' => ['status' => 'rejected', 'published_by' => $adminId],
            'feature' => ['featured' => 1],
            'unfeature' => ['featured' => 0]
        ];
        
        if (!isset($statusMap[$action])) return false;
        
        $updates = $statusMap[$action];
        $setParts = [];
        $params = [];
        foreach ($updates as $key => $value) {
            $setParts[] = "$key = ?";
            $params[] = $value;
        }
        $setClause = implode(', ', $setParts);
        $params[] = $storyId;
        
        $sql = "UPDATE stories SET $setClause WHERE id = ?";
        $stmt = $this->pdo->prepare($sql);
        $result = $stmt->execute($params);
        
        if ($result) {
            $this->logModerationAction($adminId, 'story', $storyId, $action, $notes);
        }
        
        return $result;
    }
    
    private function moderateComment($commentId, $action, $adminId, $notes) {
        $statusMap = [
            'approve' => ['status' => 'approved'],
            'reject' => ['status' => 'rejected'],
            'delete' => ['status' => 'deleted']
        ];
        
        if (!isset($statusMap[$action])) return false;
        
        $updates = $statusMap[$action];
        $setParts = [];
        $params = [];
        foreach ($updates as $key => $value) {
            $setParts[] = "$key = ?";
            $params[] = $value;
        }
        $setClause = implode(', ', $setParts);
        $params[] = $commentId;
        
        $sql = "UPDATE comments SET $setClause WHERE id = ?";
        $stmt = $this->pdo->prepare($sql);
        $result = $stmt->execute($params);
        
        if ($result) {
            $this->logModerationAction($adminId, 'comment', $commentId, $action, $notes);
        }
        
        return $result;
    }
    
    private function moderateAchievement($achievementId, $action, $adminId, $notes) {
        $statusMap = [
            'approve' => ['verified' => 1, 'verified_by' => $adminId, 'verified_at' => date('Y-m-d H:i:s')],
            'reject' => ['verified' => 0, 'verified_by' => $adminId],
            'feature' => ['featured' => 1],
            'unfeature' => ['featured' => 0]
        ];
        
        if (!isset($statusMap[$action])) return false;
        
        $updates = $statusMap[$action];
        $setParts = [];
        $params = [];
        foreach ($updates as $key => $value) {
            $setParts[] = "$key = ?";
            $params[] = $value;
        }
        $setClause = implode(', ', $setParts);
        $params[] = $achievementId;
        
        $sql = "UPDATE student_achievements SET $setClause WHERE id = ?";
        $stmt = $this->pdo->prepare($sql);
        $result = $stmt->execute($params);
        
        if ($result) {
            $this->logModerationAction($adminId, 'achievement', $achievementId, $action, $notes);
        }
        
        return $result;
    }
    
    // SYSTEM MAINTENANCE - FIXED VERSION
    public function runMaintenanceTask($task) {
        switch ($task) {
            case 'cleanup_temp_files':
                return $this->cleanupTempFiles();
            case 'optimize_tables':
                return $this->optimizeDatabaseTables();
            case 'clear_cache':
                return $this->clearSystemCache();
            case 'backup_database':
                return $this->backupDatabase();
            default:
                return ['status' => 'error', 'message' => 'Unknown task'];
        }
    }
    
    private function cleanupTempFiles() {
        $tempDir = __DIR__ . '/../../assets/temp/';
        if (!is_dir($tempDir)) {
            return ['deleted' => 0, 'status' => 'success', 'message' => 'Temp directory does not exist'];
        }
        
        $files = glob($tempDir . '*');
        $deleted = 0;
        
        foreach ($files as $file) {
            if (is_file($file)) {
                if (time() - filemtime($file) > 24 * 3600) {
                    if (@unlink($file)) {
                        $deleted++;
                    }
                }
            }
        }
        
        return ['deleted' => $deleted, 'status' => 'success'];
    }
    
    private function optimizeDatabaseTables() {
        try {
            // Close any open statements first
            $this->pdo->query("SELECT 1")->fetchAll();
            
            $stmt = $this->pdo->query("SHOW TABLES");
            $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
            $stmt->closeCursor(); // Important: close the cursor
            
            $optimized = 0;
            $results = [];
            
            foreach ($tables as $table) {
                $stmt = $this->pdo->query("OPTIMIZE TABLE `$table`");
                $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
                $stmt->closeCursor(); // Close cursor after each query
                $optimized++;
                $results[$table] = $result;
            }
            
            return ['optimized' => $optimized, 'status' => 'success', 'results' => $results];
        } catch (Exception $e) {
            return ['status' => 'error', 'message' => $e->getMessage()];
        }
    }
    
    private function clearSystemCache() {
        // Use a safer approach for session cleanup
        $sessionDir = session_save_path();
        if (empty($sessionDir) || !is_dir($sessionDir)) {
            $sessionDir = sys_get_temp_dir();
        }
        
        // Check if we have permission to delete files in this directory
        if (!is_writable($sessionDir)) {
            return [
                'deleted_sessions' => 0, 
                'status' => 'warning', 
                'message' => 'No permission to delete session files in ' . $sessionDir
            ];
        }
        
        $files = @glob($sessionDir . '/sess_*');
        if ($files === false) {
            return ['deleted_sessions' => 0, 'status' => 'error', 'message' => 'Cannot read session directory'];
        }
        
        $deleted = 0;
        $errors = 0;
        
        foreach ($files as $file) {
            if (is_file($file) && time() - filemtime($file) > 24 * 3600) {
                // Use error suppression and proper file checking
                if (@unlink($file)) {
                    $deleted++;
                } else {
                    $errors++;
                    // Don't log every single error to avoid flooding
                    if ($errors <= 5) {
                        error_log("Cannot delete session file: " . basename($file));
                    }
                }
            }
        }
        
        $result = [
            'deleted_sessions' => $deleted, 
            'errors' => $errors,
            'status' => 'success'
        ];
        
        if ($errors > 0) {
            $result['status'] = 'warning';
            $result['message'] = "Deleted $deleted sessions, $errors files could not be deleted (permission issues)";
        }
        
        return $result;
    }
    
    private function backupDatabase() {
        $backupDir = __DIR__ . '/../../backups/';
        if (!is_dir($backupDir)) {
            if (!mkdir($backupDir, 0755, true)) {
                return ['status' => 'error', 'message' => 'Cannot create backup directory'];
            }
        }
        
        if (!is_writable($backupDir)) {
            return ['status' => 'error', 'message' => 'Backup directory is not writable'];
        }
        
        $backupFile = $backupDir . 'backup_' . date('Y-m-d_H-i-s') . '.sql';
        
        try {
            // Get all tables
            $stmt = $this->pdo->query("SHOW TABLES");
            $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
            $stmt->closeCursor();
            
            $backupContent = "";
            $backupContent .= "-- Database Backup\n";
            $backupContent .= "-- Generated: " . date('Y-m-d H:i:s') . "\n";
            $backupContent .= "-- Tables: " . count($tables) . "\n\n";
            
            foreach ($tables as $table) {
                $backupContent .= "-- Table: $table\n";
                
                // Get table structure
                $stmt = $this->pdo->query("SHOW CREATE TABLE `$table`");
                $createTable = $stmt->fetch(PDO::FETCH_ASSOC);
                $stmt->closeCursor();
                
                if (isset($createTable['Create Table'])) {
                    $backupContent .= $createTable['Create Table'] . ";\n\n";
                }
                
                // Get table data
                $stmt = $this->pdo->query("SELECT * FROM `$table`");
                $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
                $stmt->closeCursor();
                
                if (count($rows) > 0) {
                    foreach ($rows as $row) {
                        $columns = implode("`, `", array_keys($row));
                        $values = implode("', '", array_map(function($value) {
                            if ($value === null) return 'NULL';
                            return str_replace("'", "\\'", $value);
                        }, array_values($row)));
                        $backupContent .= "INSERT INTO `$table` (`$columns`) VALUES ('$values');\n";
                    }
                    $backupContent .= "\n";
                }
            }
            
            if (file_put_contents($backupFile, $backupContent)) {
                return [
                    'status' => 'success', 
                    'file' => basename($backupFile), 
                    'size' => filesize($backupFile),
                    'tables' => count($tables)
                ];
            } else {
                return ['status' => 'error', 'message' => 'Failed to write backup file'];
            }
        } catch (Exception $e) {
            return ['status' => 'error', 'message' => $e->getMessage()];
        }
    }
    
    // AUDIT LOGGING METHODS
    private function logUserAction($adminId, $userId, $action, $details) {
        try {
            $this->pdo->query("
                CREATE TABLE IF NOT EXISTS audit_logs (
                    id INT PRIMARY KEY AUTO_INCREMENT,
                    user_id INT,
                    action VARCHAR(100) NOT NULL,
                    table_name VARCHAR(50) NOT NULL,
                    record_id INT,
                    old_values TEXT,
                    new_values TEXT,
                    ip_address VARCHAR(45),
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_user_id (user_id),
                    INDEX idx_action (action),
                    INDEX idx_created_at (created_at)
                )
            ");
            
            $sql = "INSERT INTO audit_logs (user_id, action, table_name, record_id, new_values, ip_address) 
                    VALUES (?, ?, 'users', ?, ?, ?)";
            $stmt = $this->pdo->prepare($sql);
            return $stmt->execute([
                $adminId, 
                $action, 
                $userId, 
                json_encode(['details' => $details]),
                $_SERVER['REMOTE_ADDR'] ?? 'unknown'
            ]);
        } catch (Exception $e) {
            error_log("Audit log error: " . $e->getMessage());
            return false;
        }
    }
    
    private function logModerationAction($adminId, $entityType, $entityId, $action, $notes) {
        try {
            $sql = "INSERT INTO audit_logs (user_id, action, table_name, record_id, new_values, ip_address) 
                    VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = $this->pdo->prepare($sql);
            return $stmt->execute([
                $adminId,
                "moderate_$action",
                $entityType . 's',
                $entityId,
                json_encode(['notes' => $notes, 'action' => $action]),
                $_SERVER['REMOTE_ADDR'] ?? 'unknown'
            ]);
        } catch (Exception $e) {
            error_log("Moderation log error: " . $e->getMessage());
            return false;
        }
    }
}

// Initialize System Control
$systemControl = new SystemControl($pdo);

// Initialize AdminControl if it exists and is needed
$adminControl = null;
if (class_exists('AdminControl')) {
    $adminControl = new AdminControl($pdo);
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        case 'update_setting':
            $key = $_POST['key'] ?? '';
            $value = $_POST['value'] ?? '';
            if (!empty($key) && $systemControl->updateSystemSetting($key, $value, $currentUser['id'])) {
                $_SESSION['flash_message'] = 'Setting updated successfully';
                $_SESSION['flash_type'] = 'success';
            } else {
                $_SESSION['flash_message'] = 'Failed to update setting';
                $_SESSION['flash_type'] = 'error';
            }
            break;
            
        case 'update_user_status':
            $userId = $_POST['user_id'] ?? 0;
            $status = $_POST['status'] ?? '';
            if ($userId && $status && $systemControl->updateUserStatus($userId, $status, $currentUser['id'])) {
                $_SESSION['flash_message'] = 'User status updated';
                $_SESSION['flash_type'] = 'success';
            } else {
                $_SESSION['flash_message'] = 'Failed to update user status';
                $_SESSION['flash_type'] = 'error';
            }
            break;
            
        case 'moderate_content':
            $type = $_POST['content_type'] ?? '';
            $id = $_POST['content_id'] ?? 0;
            $modAction = $_POST['mod_action'] ?? '';
            $notes = $_POST['notes'] ?? '';
            if ($type && $id && $modAction && $systemControl->moderateContent($type, $id, $modAction, $currentUser['id'], $notes)) {
                $_SESSION['flash_message'] = 'Content moderated successfully';
                $_SESSION['flash_type'] = 'success';
            } else {
                $_SESSION['flash_message'] = 'Failed to moderate content';
                $_SESSION['flash_type'] = 'error';
            }
            break;
            
        case 'run_maintenance':
            $task = $_POST['task'] ?? '';
            if ($task) {
                $result = $systemControl->runMaintenanceTask($task);
                $message = "Maintenance task completed";
                if (isset($result['message'])) {
                    $message .= ": " . $result['message'];
                }
                $_SESSION['flash_message'] = $message;
                $_SESSION['flash_type'] = $result['status'] ?? 'info';
            }
            break;
    }
    
    header('Location: control-panel.php');
    exit;
}

// Get data for display
$systemSettings = $systemControl->getSystemSettings();
$allUsers = $systemControl->getAllUsers();

// Get pending approvals if adminControl is available
$pendingApprovals = [];
if ($adminControl && method_exists($adminControl, 'getPendingApprovals')) {
    $pendingApprovals = $adminControl->getPendingApprovals();
} else {
    // Fallback if AdminControl doesn't exist or method is missing
    $pendingApprovals = [
        'projects' => [],
        'stories' => [],
        'achievements' => [],
        'applications' => [],
        'comments' => []
    ];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Control Panel</title>
    <style>
        .admin-container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        .section { background: white; padding: 20px; margin: 20px 0; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .flash-message { padding: 10px; margin: 10px 0; border-radius: 4px; }
        .flash-success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .flash-error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .flash-info { background: #cce7ff; color: #004085; border: 1px solid #b3d7ff; }
        .flash-warning { background: #fff3cd; color: #856404; border: 1px solid #ffeaa7; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background-color: #f8f9fa; }
        .btn { padding: 8px 16px; margin: 2px; border: none; border-radius: 4px; cursor: pointer; text-decoration: none; display: inline-block; }
        .btn-primary { background: #007bff; color: white; }
        .btn-success { background: #28a745; color: white; }
        .btn-warning { background: #ffc107; color: black; }
        .btn-danger { background: #dc3545; color: white; }
        .tabs { display: flex; border-bottom: 1px solid #ddd; margin-bottom: 20px; }
        .tab { padding: 10px 20px; cursor: pointer; border: 1px solid transparent; }
        .tab.active { border-color: #ddd #ddd #fff #ddd; border-radius: 4px 4px 0 0; background: white; }
        .tab-content { display: none; }
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin: 20px 0; }
        .stat-card { background: #f8f9fa; padding: 20px; border-radius: 8px; text-align: center; }
        .stat-number { font-size: 2em; font-weight: bold; color: #007bff; }
        .stat-label { color: #6c757d; }
    </style>
</head>
<body>
    <div class="admin-container">
        <h1>Admin Control Panel</h1>
        
        <?php if (isset($_SESSION['flash_message'])): ?>
            <div class="flash-message flash-<?php echo $_SESSION['flash_type']; ?>">
                <?php echo htmlspecialchars($_SESSION['flash_message']); ?>
            </div>
            <?php unset($_SESSION['flash_message'], $_SESSION['flash_type']); ?>
        <?php endif; ?>

        <div class="tabs">
            <div class="tab active" onclick="showTab('dashboard')">Dashboard</div>
            <div class="tab" onclick="showTab('users')">User Management</div>
            <div class="tab" onclick="showTab('content')">Content Moderation</div>
            <div class="tab" onclick="showTab('settings')">System Settings</div>
            <div class="tab" onclick="showTab('maintenance')">Maintenance</div>
        </div>

        <!-- Dashboard Tab -->
        <div id="dashboard-tab" class="tab-content">
            <div class="section">
                <h2>System Overview</h2>
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-number"><?php echo count($allUsers); ?></div>
                        <div class="stat-label">Total Users</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number"><?php echo count($pendingApprovals['projects']); ?></div>
                        <div class="stat-label">Pending Projects</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number"><?php echo count($pendingApprovals['stories']); ?></div>
                        <div class="stat-label">Pending Stories</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number"><?php echo count($systemSettings); ?></div>
                        <div class="stat-label">System Settings</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- User Management Tab -->
        <div id="users-tab" class="tab-content" style="display: none;">
            <div class="section">
                <h2>User Management</h2>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Status</th>
                            <th>Projects</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($allUsers as $user): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($user['id']); ?></td>
                            <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                            <td><?php echo htmlspecialchars($user['role']); ?></td>
                            <td><?php echo htmlspecialchars($user['status']); ?></td>
                            <td><?php echo htmlspecialchars($user['project_count']); ?></td>
                            <td>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="action" value="update_user_status">
                                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                    <select name="status" onchange="this.form.submit()">
                                        <option value="active" <?php echo $user['status'] === 'active' ? 'selected' : ''; ?>>Active</option>
                                        <option value="inactive" <?php echo $user['status'] === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                                        <option value="suspended" <?php echo $user['status'] === 'suspended' ? 'selected' : ''; ?>>Suspended</option>
                                    </select>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Content Moderation Tab -->
        <div id="content-tab" class="tab-content" style="display: none;">
            <div class="section">
                <h2>Content Moderation</h2>
                <p>Content moderation features will be implemented here.</p>
                <!-- Add content moderation interface here -->
            </div>
        </div>

        <!-- System Settings Tab -->
        <div id="settings-tab" class="tab-content" style="display: none;">
            <div class="section">
                <h2>System Settings</h2>
                <?php if (empty($systemSettings)): ?>
                    <p>No system settings found. They will be created when you add your first setting.</p>
                <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>Key</th>
                            <th>Value</th>
                            <th>Description</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($systemSettings as $setting): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($setting['setting_key']); ?></td>
                            <td>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="action" value="update_setting">
                                    <input type="hidden" name="key" value="<?php echo $setting['setting_key']; ?>">
                                    <input type="text" name="value" value="<?php echo htmlspecialchars($setting['setting_value']); ?>" style="width: 300px;">
                            </td>
                            <td>
                                <?php echo htmlspecialchars($setting['description'] ?? 'No description'); ?>
                            </td>
                            <td>
                                    <button type="submit" class="btn btn-primary">Update</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php endif; ?>
                
                <div style="margin-top: 20px;">
                    <h3>Add New Setting</h3>
                    <form method="POST">
                        <input type="hidden" name="action" value="update_setting">
                        <input type="text" name="key" placeholder="Setting Key" required>
                        <input type="text" name="value" placeholder="Setting Value" required>
                        <button type="submit" class="btn btn-success">Add Setting</button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Maintenance Tab -->
        <div id="maintenance-tab" class="tab-content" style="display: none;">
            <div class="section">
                <h2>System Maintenance</h2>
                <p>Use these tools to maintain and optimize your system.</p>
                
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 15px; margin: 20px 0;">
                    <div style="border: 1px solid #ddd; padding: 15px; border-radius: 8px;">
                        <h4>Cleanup Temp Files</h4>
                        <p>Remove temporary files older than 24 hours</p>
                        <form method="POST">
                            <input type="hidden" name="action" value="run_maintenance">
                            <input type="hidden" name="task" value="cleanup_temp_files">
                            <button type="submit" class="btn btn-warning">Run Cleanup</button>
                        </form>
                    </div>
                    
                    <div style="border: 1px solid #ddd; padding: 15px; border-radius: 8px;">
                        <h4>Optimize Database</h4>
                        <p>Optimize all database tables for better performance</p>
                        <form method="POST">
                            <input type="hidden" name="action" value="run_maintenance">
                            <input type="hidden" name="task" value="optimize_tables">
                            <button type="submit" class="btn btn-warning">Optimize Now</button>
                        </form>
                    </div>
                    
                    <div style="border: 1px solid #ddd; padding: 15px; border-radius: 8px;">
                        <h4>Clear Cache</h4>
                        <p>Clear system cache and old session files</p>
                        <form method="POST">
                            <input type="hidden" name="action" value="run_maintenance">
                            <input type="hidden" name="task" value="clear_cache">
                            <button type="submit" class="btn btn-warning">Clear Cache</button>
                        </form>
                    </div>
                    
                    <div style="border: 1px solid #ddd; padding: 15px; border-radius: 8px;">
                        <h4>Backup Database</h4>
                        <p>Create a complete database backup</p>
                        <form method="POST">
                            <input type="hidden" name="action" value="run_maintenance">
                            <input type="hidden" name="task" value="backup_database">
                            <button type="submit" class="btn btn-primary">Create Backup</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function showTab(tabName) {
            // Hide all tabs
            document.querySelectorAll('.tab-content').forEach(tab => {
                tab.style.display = 'none';
            });
            
            // Remove active class from all tabs
            document.querySelectorAll('.tab').forEach(tab => {
                tab.classList.remove('active');
            });
            
            // Show selected tab and set active class
            document.getElementById(tabName + '-tab').style.display = 'block';
            event.currentTarget.classList.add('active');
        }
        
        // Show dashboard by default
        document.addEventListener('DOMContentLoaded', function() {
            showTab('dashboard');
        });
    </script>
</body>
</html>