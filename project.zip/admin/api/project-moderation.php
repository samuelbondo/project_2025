<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/database.php';
require_once '../includes/auth.php';

header('Content-Type: application/json');

if (!$auth->isLoggedIn() || !$auth->hasAnyRole(['admin', 'staff'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit;
}

class ProjectModerationAPI {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    public function moderateProject($projectId, $action, $adminId, $notes = '') {
        try {
            $this->pdo->beginTransaction();
            
            $project = $this->getProjectDetails($projectId);
            if (!$project) {
                throw new Exception('Project not found');
            }
            
            $result = $this->processModeration($projectId, $action, $adminId, $notes);
            
            if ($result) {
                $this->logModeration($projectId, $action, $adminId, $notes);
                $this->notifyStudent($projectId, $action, $notes);
                $this->updateProjectStats($projectId, $action);
            }
            
            $this->pdo->commit();
            
            return [
                'success' => true,
                'message' => "Project {$action}d successfully",
                'action' => $action,
                'project_id' => $projectId
            ];
            
        } catch (Exception $e) {
            $this->pdo->rollBack();
            error_log("Moderation error: " . $e->getMessage());
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
    
    public function bulkModerateProjects($projectIds, $action, $adminId, $notes = '') {
        try {
            $this->pdo->beginTransaction();
            
            $results = [];
            foreach ($projectIds as $projectId) {
                $result = $this->processModeration($projectId, $action, $adminId, $notes);
                if ($result) {
                    $this->logModeration($projectId, $action, $adminId, $notes);
                    $results[] = $projectId;
                }
            }
            
            $this->pdo->commit();
            
            return [
                'success' => true,
                'message' => "Bulk action completed: {$action}",
                'action' => $action,
                'processed_count' => count($results),
                'project_ids' => $results
            ];
            
        } catch (Exception $e) {
            $this->pdo->rollBack();
            error_log("Bulk moderation error: " . $e->getMessage());
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
    
    public function getProjectAnalytics($filters = []) {
        try {
            $whereConditions = ["1=1"];
            $params = [];
            
            // Date filters
            if (!empty($filters['date_from'])) {
                $whereConditions[] = "p.created_at >= ?";
                $params[] = $filters['date_from'];
            }
            
            if (!empty($filters['date_to'])) {
                $whereConditions[] = "p.created_at <= ?";
                $params[] = $filters['date_to'] . ' 23:59:59';
            }
            
            $whereClause = implode(' AND ', $whereConditions);
            
            $sql = "SELECT 
                    COUNT(*) as total_projects,
                    SUM(p.approved = 1) as approved_count,
                    SUM(p.approved = 0) as pending_count,
                    SUM(p.status = 'on_hold') as on_hold_count,
                    AVG(TIMESTAMPDIFF(HOUR, p.created_at, COALESCE(p.approved_at, NOW()))) as avg_review_hours,
                    p.project_type,
                    DATE(p.created_at) as date_group,
                    sp.university,
                    COUNT(DISTINCT p.student_id) as unique_students
                FROM student_projects p
                LEFT JOIN student_profiles sp ON p.student_id = sp.user_id
                WHERE $whereClause
                GROUP BY p.project_type, DATE(p.created_at), sp.university
                ORDER BY date_group DESC";
                
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            return $this->processAnalyticsData($data);
            
        } catch (Exception $e) {
            error_log("Analytics error: " . $e->getMessage());
            return [];
        }
    }
    
    private function processModeration($projectId, $action, $adminId, $notes) {
        $currentTime = date('Y-m-d H:i:s');
        
        switch ($action) {
            case 'approve':
                $sql = "UPDATE student_projects SET 
                        approved = 1, 
                        approved_by = ?, 
                        approved_at = ?,
                        status = 'in_progress',
                        moderation_notes = ?
                    WHERE id = ?";
                break;
                
            case 'reject':
                $sql = "UPDATE student_projects SET 
                        approved = 0, 
                        approved_by = ?, 
                        approved_at = ?,
                        status = 'on_hold',
                        moderation_notes = ?
                    WHERE id = ?";
                break;
                
            case 'request_revision':
                $sql = "UPDATE student_projects SET 
                        approved = 0,
                        status = 'revision_required',
                        moderation_notes = ?,
                        revision_requested_at = ?
                    WHERE id = ?";
                $params = [$notes, $currentTime, $projectId];
                $stmt = $this->pdo->prepare($sql);
                return $stmt->execute($params);
                
            default:
                throw new Exception('Invalid moderation action');
        }
        
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([$adminId, $currentTime, $notes, $projectId]);
    }
    
    private function getProjectDetails($projectId) {
        $sql = "SELECT p.*, u.full_name, u.email 
                FROM student_projects p 
                JOIN users u ON p.student_id = u.id 
                WHERE p.id = ?";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$projectId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    private function logModeration($projectId, $action, $adminId, $notes) {
        $sql = "INSERT INTO activity_log (user_id, action, description, ip_address) 
                VALUES (?, ?, ?, ?)";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([
            $adminId,
            "project_{$action}",
            "Project ID {$projectId}: {$action}" . ($notes ? " - {$notes}" : ""),
            $_SERVER['REMOTE_ADDR']
        ]);
    }
    
    private function notifyStudent($projectId, $action, $notes) {
        $project = $this->getProjectDetails($projectId);
        if (!$project) return;
        
        $message = $this->generateNotificationMessage($action, $project['title'], $notes);
        
        $sql = "INSERT INTO notifications (user_id, title, message, type, related_entity_type, related_entity_id) 
                VALUES (?, ?, ?, ?, 'project', ?)";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([
            $project['student_id'],
            "Project Update: " . ucfirst($action),
            $message,
            $action === 'approve' ? 'success' : 'warning',
            $projectId
        ]);
    }
    
    private function generateNotificationMessage($action, $projectTitle, $notes) {
        $messages = [
            'approve' => "Your project '{$projectTitle}' has been approved and is now active!",
            'reject' => "Your project '{$projectTitle}' requires changes before approval.",
            'request_revision' => "Your project '{$projectTitle}' needs revisions before approval."
        ];
        
        $message = $messages[$action] ?? "Your project '{$projectTitle}' status has been updated.";
        
        if (!empty($notes)) {
            $message .= " Admin notes: {$notes}";
        }
        
        return $message;
    }
    
    private function updateProjectStats($projectId, $action) {
        // Update any statistics or counters
        $sql = "UPDATE system_stats SET 
                projects_approved = projects_approved + ?,
                projects_rejected = projects_rejected + ?,
                last_moderation_date = NOW()
                WHERE id = 1";
        
        $approved = $action === 'approve' ? 1 : 0;
        $rejected = $action === 'reject' ? 1 : 0;
        
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$approved, $rejected]);
        } catch (Exception $e) {
            // Stats table might not exist, that's okay
        }
    }
    
    private function processAnalyticsData($data) {
        $analytics = [
            'summary' => [
                'total_projects' => 0,
                'approved' => 0,
                'pending' => 0,
                'on_hold' => 0,
                'avg_review_time_hours' => 0
            ],
            'by_type' => [],
            'by_university' => [],
            'daily_trends' => []
        ];
        
        foreach ($data as $row) {
            // Summary
            $analytics['summary']['total_projects'] += $row['total_projects'];
            $analytics['summary']['approved'] += $row['approved_count'];
            $analytics['summary']['pending'] += $row['pending_count'];
            $analytics['summary']['on_hold'] += $row['on_hold_count'];
            
            // By type
            $type = $row['project_type'] ?: 'other';
            if (!isset($analytics['by_type'][$type])) {
                $analytics['by_type'][$type] = 0;
            }
            $analytics['by_type'][$type] += $row['total_projects'];
            
            // By university
            $university = $row['university'] ?: 'Unknown';
            if (!isset($analytics['by_university'][$university])) {
                $analytics['by_university'][$university] = 0;
            }
            $analytics['by_university'][$university] += $row['total_projects'];
            
            // Daily trends
            $date = $row['date_group'];
            if (!isset($analytics['daily_trends'][$date])) {
                $analytics['daily_trends'][$date] = 0;
            }
            $analytics['daily_trends'][$date] += $row['total_projects'];
        }
        
        // Calculate averages
        if ($analytics['summary']['total_projects'] > 0) {
            $analytics['summary']['approval_rate'] = 
                round(($analytics['summary']['approved'] / $analytics['summary']['total_projects']) * 100, 1);
        }
        
        return $analytics;
    }
}

// Handle API requests
try {
    $api = new ProjectModerationAPI($pdo);
    $currentUser = $auth->getCurrentUser();
    
    $method = $_SERVER['REQUEST_METHOD'];
    $input = json_decode(file_get_contents('php://input'), true) ?? $_POST;
    
    switch ($method) {
        case 'POST':
            if (isset($input['action']) && $input['action'] === 'bulk_moderate') {
                $projectIds = $input['project_ids'] ?? [];
                $action = $input['moderation_action'] ?? '';
                $notes = $input['notes'] ?? '';
                
                if (empty($projectIds) || empty($action)) {
                    throw new Exception('Missing required parameters');
                }
                
                $result = $api->bulkModerateProjects($projectIds, $action, $currentUser['id'], $notes);
            } else {
                $projectId = $input['project_id'] ?? null;
                $action = $input['action'] ?? '';
                $notes = $input['notes'] ?? '';
                
                if (!$projectId || empty($action)) {
                    throw new Exception('Missing required parameters');
                }
                
                $result = $api->moderateProject($projectId, $action, $currentUser['id'], $notes);
            }
            break;
            
        case 'GET':
            $filters = [
                'date_from' => $_GET['date_from'] ?? '',
                'date_to' => $_GET['date_to'] ?? ''
            ];
            $result = [
                'success' => true,
                'analytics' => $api->getProjectAnalytics($filters)
            ];
            break;
            
        default:
            http_response_code(405);
            $result = ['success' => false, 'message' => 'Method not allowed'];
    }
    
    echo json_encode($result);
    
} catch (Exception $e) {
    error_log("Moderation API Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false, 
        'message' => 'Internal server error: ' . $e->getMessage()
    ]);
}
?>