<?php
include '../../includes/config.php';
include '../../includes/auth.php';
$auth->checkRole(['super_admin', 'admin', 'partnership_manager']);

$stmt = $pdo->query("SELECT * FROM partners ORDER BY created_at DESC");
$partners = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Partnership Management - REACH Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../../assets/css/admin.css" rel="stylesheet">
</head>
<body class="admin-dashboard">
    <?php include '../partials/admin-header.php'; ?>
    <?php include '../partials/admin-sidebar.php'; ?>

    <main class="admin-main">
        <div class="admin-header">
            <h1><i class="fas fa-handshake me-2"></i>Partnership Management</h1>
            <div class="admin-actions">
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addPartnerModal">
                    <i class="fas fa-plus me-2"></i>Add Partner
                </button>
            </div>
        </div>

        <div class="admin-card">
            <div class="card-header">
                <h5 class="mb-0">Partners (<?php echo count($partners); ?>)</h5>
            </div>
            <div class="card-body">
                <?php if ($partners): ?>
                    <div class="row g-3">
                        <?php foreach ($partners as $partner): ?>
                        <div class="col-md-6 col-lg-4">
                            <div class="card h-100">
                                <div class="card-body text-center">
                                    <?php if ($partner['logo']): ?>
                                    <img src="../../assets/uploads/partners/<?php echo $partner['logo']; ?>" 
                                         alt="<?php echo htmlspecialchars($partner['name']); ?>" 
                                         class="img-fluid mb-3" style="max-height: 80px;">
                                    <?php else: ?>
                                    <div class="bg-light rounded p-4 mb-3">
                                        <i class="fas fa-building fa-2x text-muted"></i>
                                    </div>
                                    <?php endif; ?>
                                    
                                    <h5><?php echo htmlspecialchars($partner['name']); ?></h5>
                                    <p class="text-muted small"><?php echo ucfirst($partner['partnership_type']); ?> Partner</p>
                                    
                                    <div class="mb-2">
                                        <span class="badge bg-<?php echo $partner['status'] === 'active' ? 'success' : 'secondary'; ?>">
                                            <?php echo ucfirst($partner['status']); ?>
                                        </span>
                                    </div>
                                    
                                    <?php if ($partner['contact_person']): ?>
                                    <p class="small mb-1">
                                        <i class="fas fa-user me-1"></i>
                                        <?php echo htmlspecialchars($partner['contact_person']); ?>
                                    </p>
                                    <?php endif; ?>
                                    
                                    <?php if ($partner['contact_email']): ?>
                                    <p class="small mb-1">
                                        <i class="fas fa-envelope me-1"></i>
                                        <?php echo $partner['contact_email']; ?>
                                    </p>
                                    <?php endif; ?>
                                    
                                    <?php if ($partner['agreement_date']): ?>
                                    <p class="small text-muted">
                                        Since <?php echo date('M Y', strtotime($partner['agreement_date'])); ?>
                                    </p>
                                    <?php endif; ?>
                                    
                                    <div class="btn-group mt-2">
                                        <button class="btn btn-sm btn-outline-primary edit-partner" 
                                                data-partner-id="<?php echo $partner['id']; ?>">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-danger delete-partner" 
                                                data-partner-id="<?php echo $partner['id']; ?>"
                                                data-partner-name="<?php echo htmlspecialchars($partner['name']); ?>">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="text-center py-5">
                        <i class="fas fa-handshake fa-3x text-muted mb-3"></i>
                        <h5>No Partners Yet</h5>
                        <p class="text-muted">There are no partnership records in the system.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <!-- Add Partner Modal -->
    <div class="modal fade" id="addPartnerModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Partner</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="addPartnerForm">
                        <div class="mb-3">
                            <label class="form-label">Organization Name *</label>
                            <input type="text" class="form-control" name="name" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Partnership Type</label>
                            <select class="form-select" name="partnership_type">
                                <option value="corporate">Corporate</option>
                                <option value="educational">Educational</option>
                                <option value="community">Community</option>
                                <option value="government">Government</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Website</label>
                            <input type="url" class="form-control" name="website">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Contact Person</label>
                            <input type="text" class="form-control" name="contact_person">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Contact Email</label>
                            <input type="email" class="form-control" name="contact_email">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Agreement Date</label>
                            <input type="date" class="form-control" name="agreement_date">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Status</label>
                            <select class="form-select" name="status">
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                                <option value="pending">Pending</option>
                            </select>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-toggle="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="addPartnerBtn">Add Partner</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    document.getElementById('addPartnerBtn').addEventListener('click', function() {
        const form = document.getElementById('addPartnerForm');
        const formData = new FormData(form);
        
        fetch('../../api/partners/create.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert(data.message);
            }
        });
    });

    // Delete partner
    document.querySelectorAll('.delete-partner').forEach(button => {
        button.addEventListener('click', function() {
            const partnerId = this.getAttribute('data-partner-id');
            const partnerName = this.getAttribute('data-partner-name');
            
            if (confirm(`Are you sure you want to delete partner "${partnerName}"?`)) {
                fetch(`../../api/partners/delete.php?id=${partnerId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        location.reload();
                    } else {
                        alert(data.message);
                    }
                });
            }
        });
    });
    </script>
</body>
</html>