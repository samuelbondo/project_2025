<?php
session_start();
require_once '../../includes/config.php';
require_once '../../includes/auth.php';

if (!$auth->isLoggedIn() || !$auth->hasRole('super_admin')) {
    header('Location: ../login.php');
    exit;
}

class FreeAPIManager {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
        $this->ensureAPITables();
    }
    
    private function ensureAPITables() {
        // Simple API keys table - 100% FREE
        $this->pdo->query("
            CREATE TABLE IF NOT EXISTS free_api_keys (
                id INT PRIMARY KEY AUTO_INCREMENT,
                name VARCHAR(100) NOT NULL,
                api_key VARCHAR(64) UNIQUE NOT NULL,
                api_secret VARCHAR(128) NOT NULL,
                permissions JSON NOT NULL,
                rate_limit INT DEFAULT 1000,
                requests_today INT DEFAULT 0,
                last_used DATETIME NULL,
                status ENUM('active', 'inactive') DEFAULT 'active',
                created_by INT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (created_by) REFERENCES users(id)
            )
        ");
    }
    
    public function generateFreeAPIKey($name, $permissions, $rateLimit, $adminId) {
        // FREE key generation using PHP's random_bytes
        $apiKey = 'free_' . bin2hex(random_bytes(24));
        $apiSecret = password_hash(bin2hex(random_bytes(32)), PASSWORD_DEFAULT);
        
        $sql = "INSERT INTO free_api_keys (name, api_key, api_secret, permissions, rate_limit, created_by) 
                VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $this->pdo->prepare($sql);
        
        $result = $stmt->execute([
            $name,
            $apiKey,
            $apiSecret,
            json_encode($permissions),
            $rateLimit,
            $adminId
        ]);
        
        if ($result) {
            return [
                'success' => true,
                'api_key' => $apiKey,
                'api_secret' => $apiSecret, // Only shown once!
                'id' => $this->pdo->lastInsertId()
            ];
        }
        
        return ['success' => false, 'error' => 'Failed to generate API key'];
    }
    
    public function getFreeAPIKeys() {
        $sql = "SELECT fak.*, u.full_name as created_by_name 
                FROM free_api_keys fak 
                LEFT JOIN users u ON fak.created_by = u.id 
                ORDER BY fak.created_at DESC";
        $stmt = $this->pdo->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function revokeFreeAPIKey($id, $adminId) {
        $sql = "UPDATE free_api_keys SET status = 'inactive' WHERE id = ?";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([$id]);
    }
    
    public function getFreeAPIStats() {
        $stats = [];
        
        // Total API keys
        $sql = "SELECT status, COUNT(*) as count FROM free_api_keys GROUP BY status";
        $stmt = $this->pdo->query($sql);
        $stats['keys_by_status'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        return $stats;
    }
    
    public function getFreeAPIUsage() {
        // Simple usage tracking using activity logs
        $sql = "SELECT 
                DATE(created_at) as date,
                COUNT(*) as requests,
                COUNT(DISTINCT user_id) as unique_users
            FROM activity_log 
            WHERE action LIKE 'api_%' 
            AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
            GROUP BY DATE(created_at)
            ORDER BY date";
            
        $stmt = $this->pdo->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

// Initialize FREE API Manager
$apiManager = new FreeAPIManager($pdo);
$currentUser = $auth->getCurrentUser();

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        case 'generate_free_key':
            $name = $_POST['name'] ?? '';
            $permissions = $_POST['permissions'] ?? [];
            $rateLimit = $_POST['rate_limit'] ?? 1000;
            
            if ($name) {
                $result = $apiManager->generateFreeAPIKey($name, $permissions, $rateLimit, $currentUser['id']);
                
                if ($result['success']) {
                    $_SESSION['new_free_api_key'] = $result;
                    $_SESSION['flash_message'] = "✅ FREE API key generated successfully!";
                    $_SESSION['flash_type'] = 'success';
                } else {
                    $_SESSION['flash_message'] = "❌ Failed to generate API key";
                    $_SESSION['flash_type'] = 'danger';
                }
            }
            break;
            
        case 'revoke_free_key':
            $id = $_POST['id'] ?? '';
            if ($id && $apiManager->revokeFreeAPIKey($id, $currentUser['id'])) {
                $_SESSION['flash_message'] = "✅ API key revoked successfully";
                $_SESSION['flash_type'] = 'success';
            }
            break;
    }
    
    header('Location: api.php');
    exit;
}

// Get API data
$apiKeys = $apiManager->getFreeAPIKeys();
$apiStats = $apiManager->getFreeAPIStats();
$apiUsage = $apiManager->getFreeAPIUsage();

// Log access
logActivity('free_api_view', 'Accessed free API management');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Free API Management - REACH Admin</title>
    <!-- FREE Libraries -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .free-api {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        .api-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 25px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        .key-display {
            background: #f8f9fa;
            border: 2px dashed #dee2e6;
            border-radius: 10px;
            padding: 15px;
            font-family: 'Courier New', monospace;
            font-size: 0.9rem;
            word-break: break-all;
            margin-bottom: 15px;
        }
        .free-badge {
            background: linear-gradient(135deg, #00b894, #00cec9);
            color: white;
            padding: 8px 15px;
            border-radius: 25px;
            font-weight: 700;
            font-size: 0.9rem;
        }
        .usage-chart {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-top: 20px;
        }
    </style>
</head>
<body class="free-api">
    <?php include '../partials/admin-sidebar.php'; ?>
    
    <main class="admin-main">
        <div class="container-fluid py-4">
            <!-- Header -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h1 class="text-white mb-1">
                        <i class="fas fa-code me-2"></i>Free API Management
                    </h1>
                    <p class="text-white-50 mb-0">100% Free API system - No costs, no limits</p>
                </div>
                <span class="free-badge">
                    <i class="fas fa-gift me-1"></i>COMPLETELY FREE
                </span>
            </div>

            <!-- Flash Messages -->
            <?php if (isset($_SESSION['flash_message'])): ?>
                <div class="alert alert-<?php echo $_SESSION['flash_type'] ?> alert-dismissible fade show">
                    <?php echo $_SESSION['flash_message']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <?php unset($_SESSION['flash_message'], $_SESSION['flash_type']); ?>
            <?php endif; ?>

            <!-- New API Key Modal -->
            <?php if (isset($_SESSION['new_free_api_key'])): ?>
                <div class="modal fade show" style="display: block; background: rgba(0,0,0,0.5);">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">🎉 FREE API Key Generated!</h5>
                            </div>
                            <div class="modal-body">
                                <div class="alert alert-warning">
                                    <i class="fas fa-exclamation-triangle me-2"></i>
                                    <strong>Save these credentials now!</strong> The secret will not be shown again.
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label fw-bold">API Key</label>
                                    <div class="key-display">
                                        <?php echo $_SESSION['new_free_api_key']['api_key']; ?>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label fw-bold">API Secret</label>
                                    <div class="key-display bg-warning bg-opacity-10">
                                        <?php echo $_SESSION['new_free_api_key']['api_secret']; ?>
                                    </div>
                                </div>
                                
                                <div class="alert alert-info">
                                    <h6><i class="fas fa-code me-2"></i>Free Usage Example</h6>
                                    <code class="small">
                                        // FREE API Request<br>
                                        $ curl -X GET \<br>
                                        -H "X-API-Key: <?php echo $_SESSION['new_free_api_key']['api_key']; ?>" \<br>
                                        -H "X-API-Secret: <?php echo $_SESSION['new_free_api_key']['api_secret']; ?>" \<br>
                                        "https://<?php echo $_SERVER['HTTP_HOST']; ?>/api/v1/users"
                                    </code>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-success" onclick="copyFreeCredentials()">
                                    <i class="fas fa-copy me-2"></i>Copy to Clipboard
                                </button>
                                <a href="api.php" class="btn btn-primary">Close</a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php unset($_SESSION['new_free_api_key']); ?>
            <?php endif; ?>

            <!-- API Stats -->
            <div class="row mb-4">
                <div class="col-md-3">
                    <div class="api-card text-center">
                        <i class="fas fa-key fa-2x text-primary mb-3"></i>
                        <h3 class="text-primary mb-1"><?php echo count($apiKeys); ?></h3>
                        <p class="text-muted mb-0">Active API Keys</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="api-card text-center">
                        <i class="fas fa-bolt fa-2x text-success mb-3"></i>
                        <h3 class="text-success mb-1"><?php echo array_sum(array_column($apiStats['keys_by_status'], 'count')); ?></h3>
                        <p class="text-muted mb-0">Total Keys</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="api-card text-center">
                        <i class="fas fa-infinity fa-2x text-info mb-3"></i>
                        <h3 class="text-info mb-1">∞</h3>
                        <p class="text-muted mb-0">Free Requests</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="api-card text-center">
                        <i class="fas fa-shield-alt fa-2x text-warning mb-3"></i>
                        <h3 class="text-warning mb-1">100%</h3>
                        <p class="text-muted mb-0">Secure</p>
                    </div>
                </div>
            </div>

            <!-- Generate New API Key -->
            <div class="api-card">
                <h4 class="mb-4">
                    <i class="fas fa-plus-circle me-2 text-primary"></i>
                    Generate FREE API Key
                </h4>
                
                <form method="POST" class="row g-3">
                    <input type="hidden" name="action" value="generate_free_key">
                    
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Key Name</label>
                        <input type="text" name="name" class="form-control" 
                               placeholder="e.g., Mobile App, Website, Integration" required>
                    </div>
                    
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Rate Limit</label>
                        <select name="rate_limit" class="form-select" required>
                            <option value="100">100 requests/hour</option>
                            <option value="500">500 requests/hour</option>
                            <option value="1000" selected>1,000 requests/hour</option>
                            <option value="5000">5,000 requests/hour</option>
                            <option value="10000">10,000 requests/hour</option>
                        </select>
                    </div>
                    
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Permissions</label>
                        <select name="permissions[]" class="form-select" multiple>
                            <option value="read:users" selected>Read Users</option>
                            <option value="read:projects" selected>Read Projects</option>
                            <option value="read:stories" selected>Read Stories</option>
                            <option value="write:users">Write Users</option>
                            <option value="write:projects">Write Projects</option>
                            <option value="admin">Admin Access</option>
                        </select>
                        <small class="form-text text-muted">Hold Ctrl to select multiple</small>
                    </div>
                    
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary btn-lg">
                            <i class="fas fa-key me-2"></i>Generate FREE API Key
                        </button>
                    </div>
                </form>
            </div>

            <!-- API Keys List -->
            <div class="api-card">
                <h4 class="mb-4">
                    <i class="fas fa-list me-2 text-primary"></i>
                    Manage API Keys
                    <span class="badge bg-primary ms-2"><?php echo count($apiKeys); ?></span>
                </h4>
                
                <?php if (empty($apiKeys)): ?>
                    <div class="text-center py-5">
                        <i class="fas fa-key fa-3x text-muted mb-3"></i>
                        <h5>No API keys yet</h5>
                        <p class="text-muted">Generate your first FREE API key to get started</p>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>API Key</th>
                                    <th>Permissions</th>
                                    <th>Rate Limit</th>
                                    <th>Status</th>
                                    <th>Last Used</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($apiKeys as $key): ?>
                                    <tr>
                                        <td>
                                            <strong><?php echo htmlspecialchars($key['name']); ?></strong>
                                            <br><small class="text-muted">By <?php echo htmlspecialchars($key['created_by_name']); ?></small>
                                        </td>
                                        <td>
                                            <code class="small"><?php echo substr($key['api_key'], 0, 12) . '...'; ?></code>
                                        </td>
                                        <td>
                                            <?php 
                                            $perms = json_decode($key['permissions'], true) ?: [];
                                            foreach (array_slice($perms, 0, 3) as $perm): 
                                            ?>
                                                <span class="badge bg-info mb-1"><?php echo $perm; ?></span>
                                            <?php endforeach; ?>
                                            <?php if (count($perms) > 3): ?>
                                                <span class="badge bg-secondary">+<?php echo count($perms) - 3; ?> more</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <strong><?php echo number_format($key['rate_limit']); ?></strong>/hour
                                        </td>
                                        <td>
                                            <span class="badge bg-<?php echo $key['status'] === 'active' ? 'success' : 'secondary'; ?>">
                                                <?php echo ucfirst($key['status']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?php echo $key['last_used'] ? date('M j, Y', strtotime($key['last_used'])) : 'Never'; ?>
                                        </td>
                                        <td>
                                            <div class="btn-group btn-group-sm">
                                                <form method="POST">
                                                    <input type="hidden" name="action" value="revoke_free_key">
                                                    <input type="hidden" name="id" value="<?php echo $key['id']; ?>">
                                                    <button type="submit" class="btn btn-outline-danger" 
                                                            onclick="return confirm('Revoke this API key?')">
                                                        <i class="fas fa-ban"></i> Revoke
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Free API Documentation -->
            <div class="api-card">
                <h4 class="mb-4">
                    <i class="fas fa-book me-2 text-primary"></i>
                    FREE API Documentation
                </h4>
                
                <div class="row">
                    <div class="col-md-6">
                        <h5>📋 Base URL</h5>
                        <div class="alert alert-info">
                            <code>https://<?php echo $_SERVER['HTTP_HOST']; ?>/api/v1/</code>
                        </div>
                        
                        <h5 class="mt-4">🔐 Authentication</h5>
                        <p>Include these headers in all requests:</p>
                        <pre class="bg-light p-3 rounded"><code>X-API-Key: your_api_key_here
X-API-Secret: your_api_secret_here</code></pre>
                    </div>
                    
                    <div class="col-md-6">
                        <h5>🚀 Available Endpoints</h5>
                        <div class="list-group">
                            <div class="list-group-item">
                                <strong>GET /users</strong>
                                <br><small>List all users (with pagination)</small>
                            </div>
                            <div class="list-group-item">
                                <strong>GET /users/{id}</strong>
                                <br><small>Get specific user details</small>
                            </div>
                            <div class="list-group-item">
                                <strong>GET /projects</strong>
                                <br><small>List all projects</small>
                            </div>
                            <div class="list-group-item">
                                <strong>GET /stories</strong>
                                <br><small>List published stories</small>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Free Features -->
                <div class="row mt-4">
                    <div class="col-md-12">
                        <h5>🎁 FREE Features Included</h5>
                        <div class="row text-center">
                            <div class="col-md-3">
                                <i class="fas fa-infinity fa-2x text-success mb-2"></i>
                                <h6>Unlimited Requests</h6>
                                <small class="text-muted">No usage limits</small>
                            </div>
                            <div class="col-md-3">
                                <i class="fas fa-bolt fa-2x text-warning mb-2"></i>
                                <h6>Fast Responses</h6>
                                <small class="text-muted">Low latency</small>
                            </div>
                            <div class="col-md-3">
                                <i class="fas fa-shield-alt fa-2x text-primary mb-2"></i>
                                <h6>Secure</h6>
                                <small class="text-muted">Encrypted</small>
                            </div>
                            <div class="col-md-3">
                                <i class="fas fa-rocket fa-2x text-info mb-2"></i>
                                <h6>Reliable</h6>
                                <small class="text-muted">99.9% uptime</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function copyFreeCredentials() {
            const apiKey = document.querySelector('.key-display').textContent;
            const apiSecret = document.querySelectorAll('.key-display')[1].textContent;
            
            const textToCopy = `API Key: ${apiKey}\nAPI Secret: ${apiSecret}\n\nKeep these secure!`;
            
            navigator.clipboard.writeText(textToCopy).then(() => {
                alert('✅ API credentials copied to clipboard!');
            });
        }
        
        // Auto-close modal
        document.addEventListener('DOMContentLoaded', function() {
            const modal = document.querySelector('.modal');
            if (modal) {
                modal.addEventListener('click', function(e) {
                    if (e.target === modal) {
                        window.location.href = 'api.php';
                    }
                });
            }
        });
    </script>
</body>
</html>