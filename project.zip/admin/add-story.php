<?php
include '../includes/config.php';
include '../includes/auth.php';
include '../includes/classes/StoryManager.php';
include '../includes/classes/UserManager.php';

$auth->checkRole(['super_admin', 'admin', 'content_manager']);

$storyManager = new StoryManager($pdo);
$userManager = new UserManager($pdo);

// Get students for author dropdown
$students = $userManager->getUsers(['role' => 'student']);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'title' => trim($_POST['title']),
        'excerpt' => trim($_POST['excerpt']),
        'content' => $_POST['content'],
        'featured_image' => $_POST['featured_image'] ?? 'default.jpg',
        'author_id' => intval($_POST['author_id']),
        'story_type' => $_POST['story_type'],
        'featured' => isset($_POST['featured']) ? 1 : 0,
        'status' => $_POST['status'],
        'seo_title' => trim($_POST['seo_title']),
        'seo_description' => trim($_POST['seo_description']),
        'tags' => trim($_POST['tags'])
    ];
    
    if (empty($data['title'])) {
        $_SESSION['error'] = "Story title is required.";
    } else {
        if ($storyManager->createStory($data)) {
            $_SESSION['success'] = "Story created successfully!";
            header("Location: manage-stories.php");
            exit;
        } else {
            $_SESSION['error'] = "Failed to create story. Please try again.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Story - REACH Organization</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
    <link href="../assets/css/admin.css" rel="stylesheet">
</head>
<body class="admin-dashboard">
    <?php include 'partials/admin-header.php'; ?>
    <?php include 'partials/admin-sidebar.php'; ?>

    <main class="admin-main">
        <div class="admin-header">
            <h1><i class="fas fa-plus me-2"></i>Add New Story</h1>
            <div class="admin-actions">
                <a href="manage-stories.php" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-2"></i>Back to Stories
                </a>
            </div>
        </div>

        <div class="dashboard-card">
            <div class="card-body">
                <?php if (isset($_SESSION['error'])): ?>
                    <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
                <?php endif; ?>

                <form method="POST" id="storyForm">
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="mb-3">
                                <label class="form-label">Story Title *</label>
                                <input type="text" name="title" class="form-control" required 
                                       value="<?php echo htmlspecialchars($_POST['title'] ?? ''); ?>">
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Story Excerpt</label>
                                <textarea name="excerpt" class="form-control" rows="3" 
                                          placeholder="Brief description of the story..."><?php echo htmlspecialchars($_POST['excerpt'] ?? ''); ?></textarea>
                                <div class="form-text">A short summary of your story (optional but recommended).</div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Story Content *</label>
                                <div id="editor" style="height: 400px;"></div>
                                <textarea name="content" id="content" hidden required><?php echo htmlspecialchars($_POST['content'] ?? ''); ?></textarea>
                            </div>
                        </div>

                        <div class="col-lg-4">
                            <div class="card">
                                <div class="card-header">
                                    <h6 class="mb-0">Story Settings</h6>
                                </div>
                                <div class="card-body">
                                    <div class="mb-3">
                                        <label class="form-label">Author *</label>
                                        <select name="author_id" class="form-select" required>
                                            <option value="">Select Author</option>
                                            <?php foreach ($students as $student): ?>
                                                <option value="<?php echo $student['id']; ?>" 
                                                    <?php echo ($_POST['author_id'] ?? '') == $student['id'] ? 'selected' : ''; ?>>
                                                    <?php echo htmlspecialchars($student['full_name']); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Story Type *</label>
                                        <select name="story_type" class="form-select" required>
                                            <option value="student" <?php echo ($_POST['story_type'] ?? '') == 'student' ? 'selected' : ''; ?>>Student Story</option>
                                            <option value="project" <?php echo ($_POST['story_type'] ?? '') == 'project' ? 'selected' : ''; ?>>Project</option>
                                            <option value="achievement" <?php echo ($_POST['story_type'] ?? '') == 'achievement' ? 'selected' : ''; ?>>Achievement</option>
                                            <option value="community" <?php echo ($_POST['story_type'] ?? '') == 'community' ? 'selected' : ''; ?>>Community</option>
                                            <option value="news" <?php echo ($_POST['story_type'] ?? '') == 'news' ? 'selected' : ''; ?>>News</option>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Status *</label>
                                        <select name="status" class="form-select" required>
                                            <option value="draft" <?php echo ($_POST['status'] ?? '') == 'draft' ? 'selected' : ''; ?>>Draft</option>
                                            <option value="published" <?php echo ($_POST['status'] ?? '') == 'published' ? 'selected' : ''; ?>>Published</option>
                                            <option value="pending" <?php echo ($_POST['status'] ?? '') == 'pending' ? 'selected' : ''; ?>>Pending Review</option>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <div class="form-check form-switch">
                                            <input class="form-check-input" type="checkbox" name="featured" id="featured" 
                                                   <?php echo isset($_POST['featured']) ? 'checked' : ''; ?>>
                                            <label class="form-check-label" for="featured">
                                                Feature this story
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card mt-3">
                                <div class="card-header">
                                    <h6 class="mb-0">SEO Settings</h6>
                                </div>
                                <div class="card-body">
                                    <div class="mb-3">
                                        <label class="form-label">SEO Title</label>
                                        <input type="text" name="seo_title" class="form-control" 
                                               value="<?php echo htmlspecialchars($_POST['seo_title'] ?? ''); ?>">
                                        <div class="form-text">Optional. If empty, story title will be used.</div>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">SEO Description</label>
                                        <textarea name="seo_description" class="form-control" rows="3"><?php echo htmlspecialchars($_POST['seo_description'] ?? ''); ?></textarea>
                                        <div class="form-text">Optional. If empty, excerpt will be used.</div>
                                    </div>
                                </div>
                            </div>

                            <div class="card mt-3">
                                <div class="card-header">
                                    <h6 class="mb-0">Tags & Categories</h6>
                                </div>
                                <div class="card-body">
                                    <div class="mb-3">
                                        <label class="form-label">Tags</label>
                                        <input type="text" name="tags" class="form-control" 
                                               value="<?php echo htmlspecialchars($_POST['tags'] ?? ''); ?>"
                                               placeholder="education, scholarship, rwanda...">
                                        <div class="form-text">Separate tags with commas.</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="mt-4">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>Save Story
                        </button>
                        <a href="manage-stories.php" class="btn btn-secondary">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.quilljs.com/1.3.6/quill.min.js"></script>
    
    <script>
        // Initialize Quill editor
        const quill = new Quill('#editor', {
            theme: 'snow',
            modules: {
                toolbar: [
                    [{ 'header': [1, 2, 3, false] }],
                    ['bold', 'italic', 'underline', 'strike'],
                    [{ 'list': 'ordered'}, { 'list': 'bullet' }],
                    ['link', 'image', 'video'],
                    ['clean']
                ]
            }
        });

        // Set initial content if exists
        const initialContent = document.getElementById('content').value;
        if (initialContent) {
            quill.root.innerHTML = initialContent;
        }

        // Update hidden textarea before form submission
        document.getElementById('storyForm').addEventListener('submit', function() {
            document.getElementById('content').value = quill.root.innerHTML;
        });
    </script>
</body>
</html>