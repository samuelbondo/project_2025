<?php
include '../includes/config.php';
include '../includes/auth.php';
include '../includes/classes/StoryManager.php';

$auth->checkRole(['super_admin', 'admin', 'content_manager']);

$storyManager = new StoryManager($pdo);

// Handle actions
if (isset($_GET['action']) && isset($_GET['id'])) {
    $action = $_GET['action'];
    $storyId = intval($_GET['id']);
    
    switch ($action) {
        case 'publish':
            if ($storyManager->updateStoryStatus($storyId, 'published')) {
                $_SESSION['success'] = "Story published successfully!";
            } else {
                $_SESSION['error'] = "Failed to publish story.";
            }
            break;
            
        case 'unpublish':
            if ($storyManager->updateStoryStatus($storyId, 'draft')) {
                $_SESSION['success'] = "Story unpublished successfully!";
            } else {
                $_SESSION['error'] = "Failed to unpublish story.";
            }
            break;
            
        case 'feature':
            if ($storyManager->toggleFeatured($storyId)) {
                $_SESSION['success'] = "Story featured status updated!";
            } else {
                $_SESSION['error'] = "Failed to update featured status.";
            }
            break;
            
        case 'delete':
            if ($storyManager->deleteStory($storyId)) {
                $_SESSION['success'] = "Story deleted successfully!";
            } else {
                $_SESSION['error'] = "Failed to delete story.";
            }
            break;
    }
    
    header("Location: manage-stories.php");
    exit;
}

// Get filters
$statusFilter = $_GET['status'] ?? 'all';
$typeFilter = $_GET['story_type'] ?? 'all';
$searchQuery = $_GET['search'] ?? '';
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$perPage = 10;
$offset = ($page - 1) * $perPage;

// Build filters
$filters = [];
if ($statusFilter !== 'all') {
    $filters['status'] = $statusFilter;
}
if ($typeFilter !== 'all') {
    $filters['story_type'] = $typeFilter;
}
if (!empty($searchQuery)) {
    $filters['search'] = $searchQuery;
}

// Get stories and total count
$stories = $storyManager->getStories($filters, $perPage, $offset);
$totalStories = $storyManager->getTotalStories($filters);
$totalPages = ceil($totalStories / $perPage);

// Get story statistics
$storyStats = $storyManager->getStoryStats();

// Helper function for status colors
function getStatusColor($status) {
    switch ($status) {
        case 'published': return 'success';
        case 'draft': return 'secondary';
        case 'pending': return 'warning';
        default: return 'light';
    }
}

function getStoryTypeColor($type) {
    switch ($type) {
        case 'student': return 'primary';
        case 'project': return 'info';
        case 'achievement': return 'success';
        case 'community': return 'warning';
        case 'news': return 'danger';
        default: return 'secondary';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Stories - REACH Organization</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/admin.css" rel="stylesheet">
    
    <style>
        .story-image {
            width: 60px;
            height: 40px;
            object-fit: cover;
            border-radius: 4px;
        }
        .stats-grid .stat-card {
            transition: transform 0.2s;
        }
        .stats-grid .stat-card:hover {
            transform: translateY(-2px);
        }
        .badge-featured {
            background: linear-gradient(45deg, #FFD700, #FFA500);
            color: #000;
        }
    </style>
</head>
<body class="admin-dashboard">
    <?php include 'partials/admin-header.php'; ?>
    <?php include 'partials/admin-sidebar.php'; ?>

    <main class="admin-main">
        <div class="admin-header">
            <h1><i class="fas fa-book-open me-2"></i>Manage Stories</h1>
            <div class="admin-actions">
                <a href="add-story.php" class="btn btn-primary">
                    <i class="fas fa-plus me-2"></i>Add New Story
                </a>
            </div>
        </div>

        <!-- Statistics Cards -->
        <div class="stats-grid mb-4">
            <div class="row g-3">
                <div class="col-xl-2 col-lg-4 col-md-6">
                    <div class="stat-card bg-primary text-white">
                        <div class="stat-icon">
                            <i class="fas fa-file-alt"></i>
                        </div>
                        <div class="stat-content">
                            <h3><?php echo number_format($storyStats['total']); ?></h3>
                            <p>Total Stories</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-2 col-lg-4 col-md-6">
                    <div class="stat-card bg-success text-white">
                        <div class="stat-icon">
                            <i class="fas fa-check-circle"></i>
                        </div>
                        <div class="stat-content">
                            <h3><?php echo number_format($storyStats['published']); ?></h3>
                            <p>Published</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-2 col-lg-4 col-md-6">
                    <div class="stat-card bg-secondary text-white">
                        <div class="stat-icon">
                            <i class="fas fa-edit"></i>
                        </div>
                        <div class="stat-content">
                            <h3><?php echo number_format($storyStats['draft']); ?></h3>
                            <p>Drafts</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-2 col-lg-4 col-md-6">
                    <div class="stat-card bg-warning text-dark">
                        <div class="stat-icon">
                            <i class="fas fa-star"></i>
                        </div>
                        <div class="stat-content">
                            <h3><?php echo number_format($storyStats['featured']); ?></h3>
                            <p>Featured</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-2 col-lg-4 col-md-6">
                    <div class="stat-card bg-info text-white">
                        <div class="stat-icon">
                            <i class="fas fa-eye"></i>
                        </div>
                        <div class="stat-content">
                            <h3><?php echo number_format($storyStats['total_views']); ?></h3>
                            <p>Total Views</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Filters and Search -->
        <div class="dashboard-card mb-4">
            <div class="card-body">
                <form method="GET" class="row g-3 align-items-end">
                    <div class="col-md-3">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-select">
                            <option value="all" <?php echo $statusFilter === 'all' ? 'selected' : ''; ?>>All Statuses</option>
                            <option value="published" <?php echo $statusFilter === 'published' ? 'selected' : ''; ?>>Published</option>
                            <option value="draft" <?php echo $statusFilter === 'draft' ? 'selected' : ''; ?>>Draft</option>
                            <option value="pending" <?php echo $statusFilter === 'pending' ? 'selected' : ''; ?>>Pending</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Story Type</label>
                        <select name="story_type" class="form-select">
                            <option value="all" <?php echo $typeFilter === 'all' ? 'selected' : ''; ?>>All Types</option>
                            <option value="student" <?php echo $typeFilter === 'student' ? 'selected' : ''; ?>>Student Stories</option>
                            <option value="project" <?php echo $typeFilter === 'project' ? 'selected' : ''; ?>>Projects</option>
                            <option value="achievement" <?php echo $typeFilter === 'achievement' ? 'selected' : ''; ?>>Achievements</option>
                            <option value="community" <?php echo $typeFilter === 'community' ? 'selected' : ''; ?>>Community</option>
                            <option value="news" <?php echo $typeFilter === 'news' ? 'selected' : ''; ?>>News</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Search Stories</label>
                        <input type="text" name="search" class="form-control" placeholder="Search by title, content..." value="<?php echo htmlspecialchars($searchQuery); ?>">
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-filter me-2"></i>Filter
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Stories Table -->
        <div class="dashboard-card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Stories (<?php echo number_format($totalStories); ?>)</h5>
                <div class="text-muted small">
                    Page <?php echo $page; ?> of <?php echo $totalPages; ?>
                </div>
            </div>
            <div class="card-body">
                <?php if (isset($_SESSION['success'])): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <?php if (isset($_SESSION['error'])): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?php if (empty($stories)): ?>
                    <div class="empty-state text-center py-5">
                        <i class="fas fa-book-open fa-4x text-muted mb-3"></i>
                        <h5>No stories found</h5>
                        <p class="text-muted mb-4"><?php echo empty($filters) ? 'Get started by creating your first story.' : 'Try adjusting your filters.'; ?></p>
                        <?php if (empty($filters)): ?>
                            <a href="add-story.php" class="btn btn-primary">
                                <i class="fas fa-plus me-2"></i>Add New Story
                            </a>
                        <?php else: ?>
                            <a href="manage-stories.php" class="btn btn-outline-primary">
                                <i class="fas fa-times me-2"></i>Clear Filters
                            </a>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Story</th>
                                    <th>Author</th>
                                    <th>Type</th>
                                    <th>Status</th>
                                    <th>Views</th>
                                    <th>Comments</th>
                                    <th>Created</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($stories as $story): ?>
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <?php if (!empty($story['featured_image']) && $story['featured_image'] !== 'default.jpg'): ?>
                                                <img src="../assets/uploads/stories/<?php echo htmlspecialchars($story['featured_image']); ?>" 
                                                     alt="<?php echo htmlspecialchars($story['title']); ?>" 
                                                     class="story-image me-3">
                                            <?php else: ?>
                                                <div class="story-image bg-light d-flex align-items-center justify-content-center me-3">
                                                    <i class="fas fa-image text-muted"></i>
                                                </div>
                                            <?php endif; ?>
                                            <div>
                                                <strong class="d-block"><?php echo htmlspecialchars($story['title']); ?></strong>
                                                <?php if ($story['featured']): ?>
                                                    <span class="badge badge-featured small">Featured</span>
                                                <?php endif; ?>
                                                <?php if (!empty($story['excerpt'])): ?>
                                                    <div class="text-muted small mt-1"><?php echo substr(htmlspecialchars($story['excerpt']), 0, 100); ?>...</div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="small">
                                            <div><?php echo htmlspecialchars($story['author_name'] ?? 'Unknown'); ?></div>
                                            <div class="text-muted"><?php echo htmlspecialchars($story['author_email'] ?? ''); ?></div>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?php echo getStoryTypeColor($story['story_type']); ?>">
                                            <?php echo ucfirst($story['story_type']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?php echo getStatusColor($story['status']); ?>">
                                            <?php echo ucfirst($story['status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <i class="fas fa-eye text-muted me-1"></i>
                                        <?php echo number_format($story['view_count']); ?>
                                    </td>
                                    <td>
                                        <i class="fas fa-comment text-muted me-1"></i>
                                        <?php echo number_format($story['comment_count']); ?>
                                    </td>
                                    <td>
                                        <div class="small">
                                            <?php echo date('M j, Y', strtotime($story['created_at'])); ?>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <a href="../story.php?slug=<?php echo urlencode($story['slug']); ?>" 
                                               class="btn btn-outline-primary" target="_blank" title="View">
                                                <i class="fas fa-external-link-alt"></i>
                                            </a>
                                            <a href="edit-story.php?id=<?php echo $story['id']; ?>" 
                                               class="btn btn-outline-warning" title="Edit">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <?php if ($story['status'] === 'published'): ?>
                                                <a href="manage-stories.php?action=unpublish&id=<?php echo $story['id']; ?>" 
                                                   class="btn btn-outline-secondary" 
                                                   onclick="return confirm('Unpublish this story?')"
                                                   title="Unpublish">
                                                    <i class="fas fa-eye-slash"></i>
                                                </a>
                                            <?php else: ?>
                                                <a href="manage-stories.php?action=publish&id=<?php echo $story['id']; ?>" 
                                                   class="btn btn-outline-success"
                                                   onclick="return confirm('Publish this story?')"
                                                   title="Publish">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                            <?php endif; ?>
                                            <a href="manage-stories.php?action=feature&id=<?php echo $story['id']; ?>" 
                                               class="btn btn-outline-info <?php echo $story['featured'] ? 'active' : ''; ?>"
                                               title="<?php echo $story['featured'] ? 'Remove from featured' : 'Mark as featured'; ?>">
                                                <i class="fas fa-star"></i>
                                            </a>
                                            <a href="manage-stories.php?action=delete&id=<?php echo $story['id']; ?>" 
                                               class="btn btn-outline-danger"
                                               onclick="return confirm('Are you sure you want to delete this story? This action cannot be undone.')"
                                               title="Delete">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination -->
                    <?php if ($totalPages > 1): ?>
                    <nav aria-label="Stories pagination" class="mt-4">
                        <ul class="pagination justify-content-center">
                            <?php if ($page > 1): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page - 1])); ?>">
                                        <i class="fas fa-chevron-left me-1"></i> Previous
                                    </a>
                                </li>
                            <?php endif; ?>
                            
                            <?php 
                            $startPage = max(1, $page - 2);
                            $endPage = min($totalPages, $page + 2);
                            
                            for ($i = $startPage; $i <= $endPage; $i++): ?>
                                <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                    <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $i])); ?>">
                                        <?php echo $i; ?>
                                    </a>
                                </li>
                            <?php endfor; ?>
                            
                            <?php if ($page < $totalPages): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page + 1])); ?>">
                                        Next <i class="fas fa-chevron-right ms-1"></i>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/admin.js"></script>
    
    <script>
        // Quick actions with confirmation
        document.addEventListener('DOMContentLoaded', function() {
            // Auto-dismiss alerts after 5 seconds
            setTimeout(() => {
                const alerts = document.querySelectorAll('.alert');
                alerts.forEach(alert => {
                    const bsAlert = new bootstrap.Alert(alert);
                    bsAlert.close();
                });
            }, 5000);
            
            // Add loading states to action buttons
            document.querySelectorAll('a[href*="action="]').forEach(link => {
                link.addEventListener('click', function(e) {
                    if (!confirm(this.getAttribute('data-confirm') || 'Are you sure?')) {
                        e.preventDefault();
                    }
                });
            });
        });
    </script>
</body>
</html>