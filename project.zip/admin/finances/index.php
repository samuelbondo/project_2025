<?php
include '../../includes/config.php';
include '../../includes/auth.php';
$auth->checkRole(['super_admin', 'admin', 'finance_manager']);

include '../../includes/classes/DonationManager.php';

$donationManager = new DonationManager($pdo);
$donations = $donationManager->getDonations();
$stats = $donationManager->getDonationStatistics();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Financial Management - REACH Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../../assets/css/admin.css" rel="stylesheet">
</head>
<body class="admin-dashboard">
    <?php include '../partials/admin-header.php'; ?>
    <?php include '../partials/admin-sidebar.php'; ?>

    <main class="admin-main">
        <div class="admin-header">
            <h1><i class="fas fa-dollar-sign me-2"></i>Financial Management</h1>
            <div class="admin-actions">
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exportFinancialModal">
                    <i class="fas fa-download me-2"></i>Export Report
                </button>
            </div>
        </div>

        <!-- Financial Overview -->
        <div class="stats-grid mb-4">
            <div class="row g-3">
                <div class="col-xl-3 col-lg-4 col-md-6">
                    <div class="stat-card">
                        <div class="stat-icon success">
                            <i class="fas fa-money-bill-wave"></i>
                        </div>
                        <div class="stat-content">
                            <h3>$<?php echo number_format($stats['total_amount'] ?? 0, 2); ?></h3>
                            <p>Total Donations</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-4 col-md-6">
                    <div class="stat-card">
                        <div class="stat-icon primary">
                            <i class="fas fa-hand-holding-usd"></i>
                        </div>
                        <div class="stat-content">
                            <h3><?php echo number_format($stats['total_donations'] ?? 0); ?></h3>
                            <p>Total Transactions</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-4 col-md-6">
                    <div class="stat-card">
                        <div class="stat-icon info">
                            <i class="fas fa-chart-line"></i>
                        </div>
                        <div class="stat-content">
                            <h3>$<?php echo number_format($stats['average_amount'] ?? 0, 2); ?></h3>
                            <p>Average Donation</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-4 col-md-6">
                    <div class="stat-card">
                        <div class="stat-icon warning">
                            <i class="fas fa-calendar"></i>
                        </div>
                        <div class="stat-content">
                            <h3>$<?php echo number_format($stats['monthly_amount'] ?? 0, 2); ?></h3>
                            <p>Monthly Recurring</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Donations Table -->
        <div class="admin-card">
            <div class="card-header">
                <h5 class="mb-0">Recent Donations</h5>
            </div>
            <div class="card-body">
                <?php if ($donations): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Donor</th>
                                    <th>Email</th>
                                    <th>Amount</th>
                                    <th>Type</th>
                                    <th>Payment Method</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($donations as $donation): ?>
                                <tr>
                                    <td>
                                        <?php if ($donation['is_anonymous']): ?>
                                            <span class="text-muted">Anonymous</span>
                                        <?php else: ?>
                                            <?php echo htmlspecialchars($donation['donor_name']); ?>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo $donation['donor_email']; ?></td>
                                    <td>
                                        <strong>$<?php echo number_format($donation['amount'], 2); ?></strong>
                                    </td>
                                    <td>
                                        <span class="badge bg-light text-dark">
                                            <?php echo ucfirst($donation['donation_type']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge bg-secondary">
                                            <?php echo ucfirst(str_replace('_', ' ', $donation['payment_method'])); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?php echo $donation['payment_status'] === 'completed' ? 'success' : 'warning'; ?>">
                                            <?php echo ucfirst($donation['payment_status']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo formatDate($donation['created_at']); ?></td>
                                    <td>
                                        <div class="btn-group">
                                            <button class="btn btn-sm btn-outline-primary view-donation" 
                                                    data-donation-id="<?php echo $donation['id']; ?>">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                            <?php if ($donation['payment_status'] === 'pending'): ?>
                                                <button class="btn btn-sm btn-outline-success update-status" 
                                                        data-donation-id="<?php echo $donation['id']; ?>" 
                                                        data-status="completed">
                                                    <i class="fas fa-check"></i>
                                                </button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="text-center py-5">
                        <i class="fas fa-donate fa-3x text-muted mb-3"></i>
                        <h5>No Donations Yet</h5>
                        <p class="text-muted">There are no donation records in the system.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <!-- Export Modal -->
    <div class="modal fade" id="exportFinancialModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Export Financial Report</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="exportFinancialForm">
                        <div class="mb-3">
                            <label class="form-label">Report Type</label>
                            <select class="form-select" name="report_type">
                                <option value="donations">Donations Report</option>
                                <option value="financial_summary">Financial Summary</option>
                                <option value="revenue_analysis">Revenue Analysis</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Date Range</label>
                            <div class="row">
                                <div class="col-md-6">
                                    <input type="date" class="form-control" name="date_from">
                                </div>
                                <div class="col-md-6">
                                    <input type="date" class="form-control" name="date_to">
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Format</label>
                            <select class="form-select" name="format">
                                <option value="csv">CSV</option>
                                <option value="excel">Excel</option>
                                <option value="pdf">PDF</option>
                            </select>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="exportFinancialBtn">Export</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Update donation status
        document.querySelectorAll('.update-status').forEach(button => {
            button.addEventListener('click', function() {
                const donationId = this.getAttribute('data-donation-id');
                const status = this.getAttribute('data-status');
                
                if (confirm('Mark this donation as completed?')) {
                    fetch('../../api/donations/update-status.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            donation_id: donationId,
                            status: status
                        })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            location.reload();
                        } else {
                            alert('Error: ' + data.message);
                        }
                    });
                }
            });
        });

        // Export financial report
        document.getElementById('exportFinancialBtn').addEventListener('click', function() {
            const form = document.getElementById('exportFinancialForm');
            const formData = new FormData(form);
            
            // Simulate export
            alert('Financial report export functionality would be implemented here');
            bootstrap.Modal.getInstance(document.getElementById('exportFinancialModal')).hide();
        });
    });
    </script>
</body>
</html>