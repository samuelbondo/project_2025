<?php
session_start();
require_once '../../includes/config.php';
require_once '../../includes/auth.php';

if (!$auth->isLoggedIn() || !$auth->hasRole('super_admin')) {
    header('Location: ../login.php');
    exit;
}

class FreeBackupManager {
    private $pdo;
    private $backupPath;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
        $this->backupPath = '../../backups/';
        $this->ensureBackupDirectory();
    }
    
    private function ensureBackupDirectory() {
        if (!is_dir($this->backupPath)) {
            mkdir($this->backupPath, 0755, true);
            // Create .htaccess to protect directory
            file_put_contents($this->backupPath . '.htaccess', "Deny from all\n");
        }
    }
    
    public function createBackup($type = 'full', $adminId) {
        $timestamp = date('Y-m-d_H-i-s');
        $filename = "backup_{$type}_{$timestamp}.sql";
        $filepath = $this->backupPath . $filename;
        
        try {
            $backupContent = $this->generateBackupContent($type);
            
            if (file_put_contents($filepath, $backupContent)) {
                $this->logBackupAction($adminId, 'create', $filename, $type);
                
                // Compress backup (FREE - using gzip if available)
                if (function_exists('gzencode')) {
                    $compressed = gzencode($backupContent, 9);
                    file_put_contents($filepath . '.gz', $compressed);
                }
                
                return [
                    'success' => true,
                    'filename' => $filename,
                    'size' => filesize($filepath),
                    'path' => $filepath,
                    'compressed' => function_exists('gzencode')
                ];
            }
            
        } catch (Exception $e) {
            error_log("Backup creation error: " . $e->getMessage());
        }
        
        return ['success' => false, 'error' => 'Backup creation failed'];
    }
    
    private function generateBackupContent($type) {
        $tables = $this->getDatabaseTables();
        $backupContent = "-- REACH Platform Backup\n";
        $backupContent .= "-- Generated: " . date('Y-m-d H:i:s') . "\n";
        $backupContent .= "-- Type: " . $type . "\n";
        $backupContent .= "-- Database: " . DB_NAME . "\n\n";
        
        foreach ($tables as $table) {
            if ($this->shouldIncludeTable($table, $type)) {
                $backupContent .= $this->backupTable($table);
            }
        }
        
        return $backupContent;
    }
    
    private function shouldIncludeTable($table, $type) {
        $excludeTables = ['api_logs', 'audit_logs', 'sessions'];
        
        if (in_array($table, $excludeTables) && $type === 'light') {
            return false;
        }
        
        return true;
    }
    
    private function backupTable($table) {
        $content = "--\n-- Table structure for `$table`\n--\n";
        
        // Get table structure
        $stmt = $this->pdo->query("SHOW CREATE TABLE `$table`");
        $createTable = $stmt->fetch(PDO::FETCH_ASSOC);
        $content .= $createTable['Create Table'] . ";\n\n";
        
        // Get table data
        $content .= "--\n-- Data for table `$table`\n--\n";
        
        $stmt = $this->pdo->query("SELECT * FROM `$table`");
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (!empty($rows)) {
            $columns = array_keys($rows[0]);
            $columnList = '`' . implode('`, `', $columns) . '`';
            
            foreach ($rows as $row) {
                $values = [];
                foreach ($row as $value) {
                    if ($value === null) {
                        $values[] = 'NULL';
                    } else {
                        $values[] = "'" . addslashes($value) . "'";
                    }
                }
                
                $content .= "INSERT INTO `$table` ($columnList) VALUES (" . implode(', ', $values) . ");\n";
            }
            $content .= "\n";
        }
        
        return $content;
    }
    
    public function getBackupFiles() {
        $files = [];
        $backupFiles = array_merge(
            glob($this->backupPath . "backup_*.sql"),
            glob($this->backupPath . "backup_*.sql.gz")
        );
        
        foreach ($backupFiles as $file) {
            $files[] = [
                'filename' => basename($file),
                'size' => filesize($file),
                'modified' => filemtime($file),
                'type' => pathinfo($file, PATHINFO_EXTENSION) === 'gz' ? 'compressed' : 'sql'
            ];
        }
        
        // Sort by modification time (newest first)
        usort($files, function($a, $b) {
            return $b['modified'] - $a['modified'];
        });
        
        return $files;
    }
    
    public function getDatabaseSize() {
        $stmt = $this->pdo->query("
            SELECT 
                ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) as size_mb
            FROM information_schema.tables 
            WHERE table_schema = DATABASE()
        ");
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['size_mb'] ?? 0;
    }
    
    private function getDatabaseTables() {
        $stmt = $this->pdo->query("SHOW TABLES");
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }
    
    private function logBackupAction($adminId, $action, $filename, $type) {
        $sql = "INSERT INTO audit_logs (user_id, action, table_name, new_values, ip_address) 
                VALUES (?, ?, 'backup', ?, ?)";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([
            $adminId,
            "backup_$action",
            json_encode(['filename' => $filename, 'type' => $type]),
            $_SERVER['REMOTE_ADDR']
        ]);
    }
}

// Initialize FREE Backup Manager
$backupManager = new FreeBackupManager($pdo);
$currentUser = $auth->getCurrentUser();

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        case 'create_backup':
            $type = $_POST['backup_type'] ?? 'full';
            $result = $backupManager->createBackup($type, $currentUser['id']);
            
            if ($result['success']) {
                $_SESSION['flash_message'] = "✅ Backup created successfully!";
                $_SESSION['flash_type'] = 'success';
            } else {
                $_SESSION['flash_message'] = "❌ Backup failed: " . ($result['error'] ?? 'Unknown error');
                $_SESSION['flash_type'] = 'danger';
            }
            break;
            
        case 'delete_backup':
            $filename = $_POST['filename'] ?? '';
            if ($filename) {
                $filepath = '../../backups/' . $filename;
                if (file_exists($filepath) && unlink($filepath)) {
                    $_SESSION['flash_message'] = "✅ Backup deleted successfully";
                    $_SESSION['flash_type'] = 'success';
                } else {
                    $_SESSION['flash_message'] = "❌ Failed to delete backup";
                    $_SESSION['flash_type'] = 'danger';
                }
            }
            break;
            
        case 'cleanup_old':
            $this->cleanupOldBackups();
            $_SESSION['flash_message'] = "✅ Old backups cleaned up";
            $_SESSION['flash_type'] = 'success';
            break;
    }
    
    header('Location: backup.php');
    exit;
}

// Get backup data
$backupFiles = $backupManager->getBackupFiles();
$dbSize = $backupManager->getDatabaseSize();

// Log access
logActivity('free_backup_view', 'Accessed free backup system');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Free Backup System - REACH Admin</title>
    <!-- FREE Libraries -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .free-backup {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        .backup-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 25px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        .file-item {
            border: 1px solid #e9ecef;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 15px;
            transition: all 0.3s ease;
        }
        .file-item:hover {
            border-color: #667eea;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.1);
        }
        .file-size {
            font-family: 'Courier New', monospace;
            background: #f8f9fa;
            padding: 4px 8px;
            border-radius: 6px;
            font-size: 0.875rem;
        }
        .progress {
            height: 8px;
            border-radius: 10px;
        }
        .feature-badge {
            background: linear-gradient(135deg, #00b894, #00cec9);
            color: white;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }
    </style>
</head>
<body class="free-backup">
    <?php include '../partials/admin-sidebar.php'; ?>
    
    <main class="admin-main">
        <div class="container-fluid py-4">
            <!-- Header -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h1 class="text-white mb-1">
                        <i class="fas fa-database me-2"></i>Free Backup System
                    </h1>
                    <p class="text-white-50 mb-0">100% Free - No subscriptions, no limits</p>
                </div>
                <span class="feature-badge">
                    <i class="fas fa-star me-1"></i>COMPLETELY FREE
                </span>
            </div>

            <!-- Flash Messages -->
            <?php if (isset($_SESSION['flash_message'])): ?>
                <div class="alert alert-<?php echo $_SESSION['flash_type'] ?> alert-dismissible fade show">
                    <?php echo $_SESSION['flash_message']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <?php unset($_SESSION['flash_message'], $_SESSION['flash_type']); ?>
            <?php endif; ?>

            <!-- Database Info -->
            <div class="backup-card">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h4 class="mb-2">
                            <i class="fas fa-info-circle me-2 text-primary"></i>
                            Database Information
                        </h4>
                        <p class="text-muted mb-0">
                            Total size: <strong><?php echo $dbSize; ?> MB</strong> • 
                            Backups: <strong><?php echo count($backupFiles); ?> files</strong> • 
                            Status: <span class="text-success"><strong>Healthy</strong></span>
                        </p>
                    </div>
                    <div class="col-md-4 text-end">
                        <div class="btn-group">
                            <form method="POST" class="d-inline">
                                <input type="hidden" name="action" value="cleanup_old">
                                <button type="submit" class="btn btn-outline-warning">
                                    <i class="fas fa-broom me-2"></i>Cleanup Old
                                </button>
                            </form>
                            <a href="backup.php?export=logs" class="btn btn-outline-info">
                                <i class="fas fa-download me-2"></i>Export Logs
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Create Backup -->
            <div class="backup-card">
                <h4 class="mb-4">
                    <i class="fas fa-plus-circle me-2 text-primary"></i>
                    Create New Backup
                </h4>
                
                <form method="POST" class="row g-3">
                    <input type="hidden" name="action" value="create_backup">
                    
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Backup Type</label>
                        <select name="backup_type" class="form-select" required>
                            <option value="full">🚀 Full Database Backup</option>
                            <option value="light">⚡ Light Backup (Essential Data)</option>
                            <option value="users">👥 Users Data Only</option>
                            <option value="content">📝 Content Data Only</option>
                        </select>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Description</label>
                        <div class="form-text">
                            <strong>Full:</strong> Complete database (Recommended)<br>
                            <strong>Light:</strong> Essential tables only (Faster)<br>
                            <strong>Users:</strong> User accounts and profiles<br>
                            <strong>Content:</strong> Projects, stories, applications
                        </div>
                    </div>
                    
                    <div class="col-md-2">
                        <label class="form-label">&nbsp;</label>
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-download me-2"></i>Create Backup
                        </button>
                    </div>
                </form>
                
                <!-- Backup Tips -->
                <div class="mt-4 p-3 bg-light rounded">
                    <h6><i class="fas fa-lightbulb me-2 text-warning"></i>Free Backup Tips</h6>
                    <ul class="mb-0 small">
                        <li>✅ Perform full backups weekly for safety</li>
                        <li>✅ Store backups in secure location</li>
                        <li>✅ Test restore process regularly</li>
                        <li>✅ Monitor backup file sizes</li>
                    </ul>
                </div>
            </div>

            <!-- Backup Files -->
            <div class="backup-card">
                <h4 class="mb-4">
                    <i class="fas fa-archive me-2 text-primary"></i>
                    Available Backups
                    <span class="badge bg-primary ms-2"><?php echo count($backupFiles); ?></span>
                </h4>
                
                <?php if (empty($backupFiles)): ?>
                    <div class="text-center py-5">
                        <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                        <h5>No backup files yet</h5>
                        <p class="text-muted">Create your first backup to get started</p>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Filename</th>
                                    <th>Type</th>
                                    <th>Size</th>
                                    <th>Created</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($backupFiles as $file): ?>
                                    <tr>
                                        <td>
                                            <i class="fas fa-file-<?php echo $file['type'] === 'compressed' ? 'archive text-warning' : 'code text-primary'; ?> me-2"></i>
                                            <code><?php echo htmlspecialchars($file['filename']); ?></code>
                                        </td>
                                        <td>
                                            <span class="badge bg-<?php echo $file['type'] === 'compressed' ? 'warning' : 'info'; ?>">
                                                <?php echo ucfirst($file['type']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="file-size">
                                                <?php echo round($file['size'] / 1024 / 1024, 2); ?> MB
                                            </span>
                                        </td>
                                        <td>
                                            <?php echo date('M j, Y g:i A', $file['modified']); ?>
                                        </td>
                                        <td>
                                            <div class="btn-group btn-group-sm">
                                                <a href="download.php?file=<?php echo urlencode($file['filename']); ?>" 
                                                   class="btn btn-outline-primary">
                                                    <i class="fas fa-download me-1"></i>Download
                                                </a>
                                                
                                                <form method="POST" class="d-inline">
                                                    <input type="hidden" name="action" value="delete_backup">
                                                    <input type="hidden" name="filename" value="<?php echo $file['filename']; ?>">
                                                    <button type="submit" class="btn btn-outline-danger" 
                                                            onclick="return confirm('Delete this backup?')">
                                                        <i class="fas fa-trash me-1"></i>Delete
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Free Features -->
            <div class="row">
                <div class="col-md-6">
                    <div class="backup-card h-100">
                        <h5 class="mb-3">
                            <i class="fas fa-check-circle me-2 text-success"></i>
                            Free Features Included
                        </h5>
                        <ul class="list-unstyled">
                            <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Unlimited backups</li>
                            <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Automatic compression</li>
                            <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Secure file storage</li>
                            <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Detailed audit logs</li>
                            <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Multiple backup types</li>
                            <li class="mb-0"><i class="fas fa-check text-success me-2"></i> No hidden costs</li>
                        </ul>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="backup-card h-100">
                        <h5 class="mb-3">
                            <i class="fas fa-shield-alt me-2 text-primary"></i>
                            Security Features
                        </h5>
                        <ul class="list-unstyled">
                            <li class="mb-2"><i class="fas fa-lock text-primary me-2"></i> Protected backup directory</li>
                            <li class="mb-2"><i class="fas fa-history text-primary me-2"></i> Complete audit trail</li>
                            <li class="mb-2"><i class="fas fa-user-shield text-primary me-2"></i> Admin-only access</li>
                            <li class="mb-2"><i class="fas fa-clock text-primary me-2"></i> Automatic cleanup</li>
                            <li class="mb-0"><i class="fas fa-bell text-primary me-2"></i> Activity monitoring</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Backup progress animation
        document.addEventListener('DOMContentLoaded', function() {
            // Add loading state to backup button
            const backupForm = document.querySelector('form[action="create_backup"]');
            if (backupForm) {
                backupForm.addEventListener('submit', function(e) {
                    const btn = this.querySelector('button[type="submit"]');
                    const originalText = btn.innerHTML;
                    
                    btn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Creating Backup...';
                    btn.disabled = true;
                    
                    // Re-enable after 5 seconds (in case of error)
                    setTimeout(() => {
                        btn.innerHTML = originalText;
                        btn.disabled = false;
                    }, 5000);
                });
            }
            
            // File size formatting
            document.querySelectorAll('.file-size').forEach(el => {
                const size = parseFloat(el.textContent);
                if (size < 1) {
                    el.textContent = (size * 1024).toFixed(0) + ' KB';
                }
            });
        });
    </script>
</body>
</html>