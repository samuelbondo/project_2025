This is a website and a school management system and the management system accepts php version >=7.4

#Please set this up in htdocs if you're using xampp or liver server(cpanel).
#Some modules are still in process, but you can modify to whatever you want. This is for students who want to practice HTML, CSS, JavaScript, etc and full stack web development.

#Login info:
Admin: username&pass:admin/password
Student: test.student/password
Philip Suah: philip.suah / password
Hawa Suah: hawa.suah / password

demo:https://reach.gt.tc