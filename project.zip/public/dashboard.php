<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Redirect based on user role
$role = $_SESSION['role'];
switch ($role) {
    case 'super_admin':
    case 'admin':
        header('Location: admin/dashboard.php');
        break;
    case 'staff':
        header('Location: staff/dashboard.php');
        break;
    case 'student':
        header('Location: student/dashboard.php');
        break;
    case 'sponsor':
        header('Location: sponsor/dashboard.php');
        break;
    case 'partner':
        header('Location: partner/dashboard.php');
        break;
    case 'reviewer':
        header('Location: reviewer/dashboard.php');
        break;
    default:
        header('Location: login.php');
        break;
}
exit;
?>