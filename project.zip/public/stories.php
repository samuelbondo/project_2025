<?php
// public/stories.php
session_start();

// Include configuration
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Enhanced function to get stories with fallback data
function getStories($filters = [], $limit = 9, $offset = 0) {
    global $pdo;
    
    try {
        $where = "WHERE s.status = 'published'";
        $params = [];
        
        if (isset($filters['story_type']) && $filters['story_type'] !== 'all') {
            $where .= " AND s.story_type = ?";
            $params[] = $filters['story_type'];
        }
        
        $sql = "SELECT s.*, u.full_name as author_name, u.profile_picture as author_image 
                FROM stories s 
                LEFT JOIN users u ON s.author_id = u.id 
                $where 
                ORDER BY s.published_at DESC 
                LIMIT ? OFFSET ?";
        
        $params[] = $limit;
        $params[] = $offset;
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $stories = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // If no stories found, return empty array
        return $stories ?: [];
        
    } catch (PDOException $e) {
        error_log("Database error in getStories: " . $e->getMessage());
        return [];
    }
}

function getTotalStories($filters = []) {
    global $pdo;
    
    try {
        $where = "WHERE status = 'published'";
        $params = [];
        
        if (isset($filters['story_type']) && $filters['story_type'] !== 'all') {
            $where .= " AND story_type = ?";
            $params[] = $filters['story_type'];
        }
        
        $sql = "SELECT COUNT(*) as total FROM stories $where";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        return $result['total'] ?? 0;
        
    } catch (PDOException $e) {
        error_log("Database error in getTotalStories: " . $e->getMessage());
        return 0;
    }
}

function getFeaturedStories($limit = 3) {
    global $pdo;
    
    try {
        $sql = "SELECT s.*, u.full_name as author_name 
                FROM stories s 
                LEFT JOIN users u ON s.author_id = u.id 
                WHERE s.status = 'published' AND s.featured = 1 
                ORDER BY s.published_at DESC 
                LIMIT ?";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$limit]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
        
    } catch (PDOException $e) {
        error_log("Database error in getFeaturedStories: " . $e->getMessage());
        return [];
    }
}

function getStoriesCount($filters = []) {
    global $pdo;
    
    try {
        $where = "WHERE status = 'published'";
        $params = [];
        
        if (isset($filters['story_type'])) {
            $where .= " AND story_type = ?";
            $params[] = $filters['story_type'];
        }
        
        $sql = "SELECT COUNT(*) as count FROM stories $where";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        return $result['count'] ?? 0;
        
    } catch (PDOException $e) {
        error_log("Database error in getStoriesCount: " . $e->getMessage());
        return 0;
    }
}

// Get filter parameters
$type = $_GET['type'] ?? 'all';
$page = max(1, intval($_GET['page'] ?? 1));
$limit = 9;
$offset = ($page - 1) * $limit;

// Get stories based on filters
$filters = [];
if ($type !== 'all') {
    $filters['story_type'] = $type;
}

$stories = getStories($filters, $limit, $offset);
$totalStories = getTotalStories($filters);
$totalPages = ceil($totalStories / $limit);

// Get featured stories for sidebar
$featuredStories = getFeaturedStories(3);

// Get story counts for each category
$studentCount = getStoriesCount(['story_type' => 'student']);
$projectCount = getStoriesCount(['story_type' => 'project']);
$achievementCount = getStoriesCount(['story_type' => 'achievement']);
$communityCount = getStoriesCount(['story_type' => 'community']);

// Fallback data if no stories exist
$fallbackStories = [
    [
        'id' => 1,
        'title' => 'From Rural Village to University Graduate',
        'slug' => 'rural-village-university-graduate',
        'excerpt' => 'How REACH helped me overcome financial barriers and achieve my dream of becoming a software engineer.',
        'featured_image' => '',
        'author_name' => 'Philip Suah',
        'author_image' => '',
        'story_type' => 'student',
        'view_count' => 1250,
        'like_count' => 89,
        'published_at' => date('Y-m-d H:i:s', strtotime('-30 days'))
    ],
    [
        'id' => 2,
        'title' => 'Building a Brighter Future Together',
        'slug' => 'building-brighter-future-together',
        'excerpt' => 'Our community\'s transformation through REACH\'s educational programs and infrastructure development.',
        'featured_image' => '',
        'author_name' => 'Hawa Suah',
        'author_image' => '',
        'story_type' => 'community',
        'view_count' => 890,
        'like_count' => 67,
        'published_at' => date('Y-m-d H:i:s', strtotime('-25 days'))
    ],
    [
        'id' => 3,
        'title' => 'The Power of Education in Transforming Lives',
        'slug' => 'power-education-transforming-lives',
        'excerpt' => 'How access to quality education through REACH changed not just my life, but my entire family\'s future.',
        'featured_image' => '',
        'author_name' => 'Philip Suah',
        'author_image' => '',
        'story_type' => 'achievement',
        'view_count' => 1100,
        'like_count' => 92,
        'published_at' => date('Y-m-d H:i:s', strtotime('-20 days'))
    ]
];

// Use fallback data if no stories in database
if (empty($stories)) {
    $stories = array_slice($fallbackStories, $offset, $limit);
    $totalStories = count($fallbackStories);
    $totalPages = ceil($totalStories / $limit);
    
    // Update counts for fallback data
    $studentCount = count(array_filter($fallbackStories, fn($s) => $s['story_type'] === 'student'));
    $projectCount = count(array_filter($fallbackStories, fn($s) => $s['story_type'] === 'project'));
    $achievementCount = count(array_filter($fallbackStories, fn($s) => $s['story_type'] === 'achievement'));
    $communityCount = count(array_filter($fallbackStories, fn($s) => $s['story_type'] === 'community'));
    
    // Set featured stories for fallback
    $featuredStories = array_slice($fallbackStories, 0, 3);
}
?>
<!DOCTYPE html>
<html lang="en" class="h-100">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Success Stories | REACH - Recognizing Each Action Can Help</title>
    
    <!-- Meta Tags -->
    <meta name="description" content="Read inspiring success stories from students and communities transformed by REACH Organization's programs in Rwanda.">
    <meta name="keywords" content="REACH stories, student success, Rwanda education, community impact, transformation stories">
    <meta name="author" content="REACH Organization">
    
    <!-- Open Graph -->
    <meta property="og:title" content="Success Stories | REACH Organization">
    <meta property="og:description" content="Inspiring stories of transformation through education and community support">
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://reach.org/stories">
    
    <!-- PWA Meta Tags -->
    <meta name="theme-color" content="#3498db">
    
    <!-- Preload Resources -->
    <link rel="preload" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" as="style">
    <link rel="preload" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" as="style">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css" rel="stylesheet">
    
    <style>
        /* Reuse the same CSS variables and base styles from index */
        :root {
            --primary: #3498db;
            --secondary: #2c3e50;
            --success: #27ae60;
            --light: #f8f9fa;
            --reach-accent: #ea4335;
            --reach-warning: #f39c12;
            --gradient-primary: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            --gradient-dark: linear-gradient(135deg, #2980b9 0%, #1c2833 100%);
            --gradient-light: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            --shadow-sm: 0 2px 8px rgba(0,0,0,0.08);
            --shadow-md: 0 8px 30px rgba(0,0,0,0.12);
            --shadow-lg: 0 15px 35px rgba(0,0,0,0.15);
            --border-radius-sm: 12px;
            --border-radius-md: 20px;
            --border-radius-lg: 28px;
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html {
            height: 100%;
            font-size: 16px;
            scroll-behavior: smooth;
        }

        body {
            min-height: 100vh;
            min-height: 100dvh;
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            line-height: 1.6;
            color: var(--secondary);
            overflow-x: hidden;
            padding-top: 80px; /* Add padding for fixed navbar */
        }

        /* Enhanced Navigation - Same as index */
        .navbar {
            background: rgba(44, 62, 80, 0.95) !important;
            backdrop-filter: blur(20px);
            padding: 1rem 0;
            transition: var(--transition);
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .navbar.scrolled {
            background: rgba(44, 62, 80, 0.98) !important;
            padding: 0.75rem 0;
            box-shadow: var(--shadow-md);
        }

        .brand-content {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .brand-text {
            line-height: 1.2;
        }

        .brand-text strong {
            font-size: 1.4rem;
            font-weight: 700;
            display: block;
            color: white;
        }

        .brand-text small {
            font-size: 0.75rem;
            opacity: 0.8;
            font-weight: 400;
            color: rgba(255,255,255,0.8);
        }

        .navbar-brand i {
            font-size: 1.8rem;
            color: var(--success);
        }

        .nav-link {
            font-weight: 500;
            padding: 0.5rem 1rem !important;
            border-radius: var(--border-radius-sm);
            transition: var(--transition);
            margin: 0.125rem;
            color: rgba(255,255,255,0.9);
        }

        .nav-link:hover,
        .nav-link.active {
            background: rgba(255,255,255,0.1);
            transform: translateY(-1px);
            color: white;
        }

        .dropdown-menu {
            background: rgba(255,255,255,0.95);
            backdrop-filter: blur(20px);
            border: none;
            border-radius: var(--border-radius-sm);
            box-shadow: var(--shadow-lg);
            padding: 0.5rem;
        }

        .dropdown-item {
            border-radius: 8px;
            padding: 0.75rem 1rem;
            transition: var(--transition);
        }

        .dropdown-item:hover {
            background: var(--primary);
            color: white;
            transform: translateX(5px);
        }

        .navbar-actions {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            flex-wrap: wrap;
        }

        .navbar-actions .btn {
            padding: 0.5rem 1.25rem;
            border-radius: var(--border-radius-sm);
            font-weight: 500;
            transition: var(--transition);
            white-space: nowrap;
        }

        /* Stories Hero Section */
        .stories-hero {
            background: var(--gradient-primary);
            color: white;
            min-height: 60vh;
            display: flex;
            align-items: center;
            position: relative;
            overflow: hidden;
            padding: 100px 0;
            margin-top: -80px; /* Compensate for body padding */
        }

        .stories-hero::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 800" opacity="0.1"><polygon fill="white" points="0,800 1200,400 1200,800"/></svg>');
            background-size: cover;
            animation: float 20s ease-in-out infinite;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0px) rotate(0deg); }
            50% { transform: translateY(-20px) rotate(1deg); }
        }

        .hero-content {
            position: relative;
            z-index: 2;
        }

        .hero-title {
            font-size: clamp(2.5rem, 6vw, 4rem);
            font-weight: 800;
            line-height: 1.1;
            margin-bottom: 1.5rem;
            color: white;
            text-shadow: 0 2px 15px rgba(0,0,0,0.3);
        }

        .hero-title .highlight {
            color: #ffd700;
            display: inline-block;
            text-shadow: 0 2px 10px rgba(0,0,0,0.4);
        }

        .hero-description {
            font-size: clamp(1.1rem, 2.5vw, 1.3rem);
            margin-bottom: 2.5rem;
            opacity: 0.95;
            max-width: 600px;
            line-height: 1.6;
            margin-left: auto;
            margin-right: auto;
            text-shadow: 0 1px 5px rgba(0,0,0,0.2);
        }

        /* Stories Filter */
        .stories-filter {
            background: white;
            padding: 2rem;
            border-radius: var(--border-radius-md);
            box-shadow: var(--shadow-sm);
            margin-bottom: 3rem;
            transition: var(--transition);
        }

        .stories-filter:hover {
            box-shadow: var(--shadow-md);
        }

        .filter-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            flex-wrap: wrap;
            gap: 1rem;
        }

        .filter-header h4 {
            margin: 0;
            color: var(--secondary);
            font-weight: 600;
        }

        .stories-count {
            color: var(--secondary);
            font-weight: 500;
            background: var(--light);
            padding: 0.5rem 1rem;
            border-radius: var(--border-radius-sm);
        }

        .filter-options {
            display: flex;
            gap: 0.75rem;
            flex-wrap: wrap;
        }

        .filter-btn {
            padding: 0.75rem 1.5rem;
            background: var(--light);
            color: var(--secondary);
            text-decoration: none;
            border-radius: var(--border-radius-sm);
            transition: var(--transition);
            border: 2px solid transparent;
            font-weight: 500;
        }

        .filter-btn:hover,
        .filter-btn.active {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
            transform: translateY(-2px);
        }

        /* Story Cards - Enhanced from index */
        .stories-grid {
            margin-bottom: 3rem;
        }

        .story-card {
            background: white;
            border-radius: var(--border-radius-md);
            overflow: hidden;
            box-shadow: var(--shadow-sm);
            transition: var(--transition);
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        .story-card:hover {
            transform: translateY(-10px);
            box-shadow: var(--shadow-lg);
        }

        .story-image {
            position: relative;
            overflow: hidden;
            aspect-ratio: 16/9;
        }

        .story-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: var(--transition);
        }

        .story-card:hover .story-image img {
            transform: scale(1.05);
        }

        .story-overlay {
            position: absolute;
            top: 1rem;
            left: 1rem;
            right: 1rem;
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
        }

        .story-type-badge .badge {
            font-size: 0.75rem;
            padding: 0.5rem 0.75rem;
            border-radius: 20px;
            background: var(--primary);
            color: white;
        }

        .story-content {
            padding: 1.5rem;
            flex: 1;
            display: flex;
            flex-direction: column;
        }

        .story-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
            flex-wrap: wrap;
            gap: 0.5rem;
        }

        .author-info {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .author-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #f8f9fa;
        }

        .author-name {
            font-weight: 500;
            font-size: 0.9rem;
            color: var(--secondary);
        }

        .story-date {
            color: #6c757d;
            font-size: 0.85rem;
        }

        .story-title {
            font-size: 1.25rem;
            font-weight: 600;
            margin-bottom: 1rem;
            line-height: 1.4;
        }

        .story-title a {
            color: inherit;
            text-decoration: none;
            transition: var(--transition);
        }

        .story-title a:hover {
            color: var(--primary);
        }

        .story-excerpt {
            color: #6c757d;
            margin-bottom: 1.5rem;
            flex: 1;
            line-height: 1.6;
        }

        .story-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 1rem;
            padding-top: 1rem;
            border-top: 1px solid #e9ecef;
        }

        .story-stats {
            display: flex;
            gap: 1rem;
            font-size: 0.85rem;
            color: #6c757d;
        }

        .story-stats span {
            display: flex;
            align-items: center;
            gap: 0.25rem;
        }

        .read-more {
            color: var(--primary);
            text-decoration: none;
            font-weight: 500;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .read-more:hover {
            color: var(--secondary);
            transform: translateX(3px);
        }

        /* Sidebar Widgets */
        .sidebar-widget {
            background: white;
            padding: 1.5rem;
            border-radius: var(--border-radius-md);
            box-shadow: var(--shadow-sm);
            margin-bottom: 2rem;
            transition: var(--transition);
        }

        .sidebar-widget:hover {
            box-shadow: var(--shadow-md);
        }

        .widget-title {
            font-size: 1.25rem;
            font-weight: 600;
            margin-bottom: 1.5rem;
            color: var(--secondary);
            border-bottom: 2px solid var(--primary);
            padding-bottom: 0.5rem;
        }

        .featured-stories-list {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }

        .featured-story-item {
            display: flex;
            gap: 1rem;
            padding: 0.75rem 0;
            border-bottom: 1px solid #e9ecef;
            transition: var(--transition);
        }

        .featured-story-item:hover {
            transform: translateX(5px);
        }

        .featured-story-item:last-child {
            border-bottom: none;
        }

        .featured-image {
            width: 80px;
            height: 60px;
            border-radius: 8px;
            overflow: hidden;
            flex-shrink: 0;
        }

        .featured-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: var(--transition);
        }

        .featured-story-item:hover .featured-image img {
            transform: scale(1.1);
        }

        .featured-content h6 {
            margin: 0 0 0.25rem 0;
            line-height: 1.3;
            font-size: 0.9rem;
        }

        .featured-content h6 a {
            color: var(--secondary);
            text-decoration: none;
            transition: var(--transition);
        }

        .featured-content h6 a:hover {
            color: var(--primary);
        }

        .featured-meta {
            display: flex;
            gap: 1rem;
            font-size: 0.75rem;
            color: #6c757d;
        }

        /* Categories */
        .categories-list {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .category-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0.75rem 1rem;
            background: var(--light);
            border-radius: var(--border-radius-sm);
            color: var(--secondary);
            text-decoration: none;
            transition: var(--transition);
            font-weight: 500;
        }

        .category-item:hover {
            background: var(--primary);
            color: white;
            transform: translateX(5px);
        }

        .category-count {
            background: var(--primary);
            color: white;
            padding: 0.25rem 0.5rem;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 600;
            min-width: 30px;
            text-align: center;
        }

        .category-item:hover .category-count {
            background: white;
            color: var(--primary);
        }

        /* Newsletter */
        .newsletter-form .form-control {
            border-radius: var(--border-radius-sm);
            border: 1px solid #e9ecef;
            padding: 0.75rem 1rem;
            margin-bottom: 1rem;
            transition: var(--transition);
        }

        .newsletter-form .form-control:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.2rem rgba(52, 152, 219, 0.25);
        }

        .newsletter-form .btn {
            border-radius: var(--border-radius-sm);
            padding: 0.75rem 1rem;
            font-weight: 500;
            width: 100%;
        }

        /* CTA Widget */
        .cta-widget {
            text-align: center;
            padding: 2rem 1rem;
            background: var(--gradient-primary);
            color: white;
            border-radius: var(--border-radius-md);
        }

        .cta-widget i {
            font-size: 2rem;
            margin-bottom: 1rem;
            color: #ffd700;
        }

        .cta-widget h5 {
            margin-bottom: 0.5rem;
            color: white;
        }

        .cta-widget p {
            margin-bottom: 1.5rem;
            opacity: 0.9;
        }

        /* Pagination */
        .stories-pagination {
            margin-top: 3rem;
        }

        .pagination .page-link {
            padding: 0.75rem 1rem;
            border: 1px solid #e9ecef;
            color: var(--secondary);
            margin: 0 0.25rem;
            border-radius: var(--border-radius-sm);
            transition: var(--transition);
            font-weight: 500;
        }

        .pagination .page-item.active .page-link {
            background: var(--primary);
            border-color: var(--primary);
            color: white;
        }

        .pagination .page-link:hover {
            background: var(--light);
            border-color: var(--primary);
            color: var(--primary);
        }

        /* Empty State */
        .empty-state {
            padding: 4rem 2rem;
            text-align: center;
            background: white;
            border-radius: var(--border-radius-md);
            box-shadow: var(--shadow-sm);
        }

        .empty-state i {
            font-size: 3rem;
            margin-bottom: 1rem;
            opacity: 0.5;
            color: var(--secondary);
        }

        .empty-state h4 {
            margin-bottom: 1rem;
            color: var(--secondary);
        }

        .empty-state p {
            color: #6c757d;
            margin-bottom: 2rem;
        }

        /* Section Styles */
        .section {
            padding: 80px 0;
        }

        .section-title {
            font-size: 2.5rem;
            font-weight: bold;
            color: var(--secondary);
        }

        .section-subtitle {
            font-size: 1.2rem;
            color: #6c757d;
        }

        /* Footer - Same as index */
        footer {
            background: var(--secondary);
            color: white;
            padding: 3rem 0 1rem;
        }

        .footer-links a {
            color: #bdc3c7;
            text-decoration: none;
            transition: color 0.3s;
        }

        .footer-links a:hover {
            color: white;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .navbar-actions {
                justify-content: center;
                margin-top: 1rem;
                width: 100%;
            }

            .navbar-actions .btn {
                flex: 1;
                min-width: 120px;
                text-align: center;
            }

            .filter-header {
                flex-direction: column;
                align-items: flex-start;
            }

            .filter-options {
                width: 100%;
                justify-content: center;
            }

            .filter-btn {
                flex: 1;
                min-width: 120px;
                text-align: center;
            }

            .story-meta {
                flex-direction: column;
                align-items: flex-start;
                gap: 0.5rem;
            }

            .story-footer {
                flex-direction: column;
                gap: 1rem;
                align-items: flex-start;
            }

            .story-stats {
                width: 100%;
                justify-content: space-between;
            }
        }

        @media (max-width: 576px) {
            .brand-text strong {
                font-size: 1.2rem;
            }

            .brand-text small {
                font-size: 0.7rem;
            }

            .hero-title {
                font-size: 2rem;
            }

            .section-title {
                font-size: 1.5rem;
            }

            .filter-options {
                flex-direction: column;
            }

            .filter-btn {
                width: 100%;
                text-align: center;
            }
        }

        /* Focus styles for accessibility */
        .btn:focus,
        .nav-link:focus,
        .form-control:focus {
            outline: 2px solid var(--primary);
            outline-offset: 2px;
        }
    </style>
</head>
<body class="h-100">
    <!-- Enhanced Navigation - Same as index -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
        <div class="container">
            <a class="navbar-brand" href="../index.php">
                <div class="brand-content">
                    <i class="fas fa-hands-helping"></i>
                    <div class="brand-text">
                        <strong>REACH</strong>
                        <small>Recognizing Each Action Can Help</small>
                    </div>
                </div>
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMain"
                    aria-controls="navbarMain" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarMain">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item"><a class="nav-link" href="../index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="about.php">About</a></li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Programs
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="programs.php#scholarships">Scholarships</a></li>
                            <li><a class="dropdown-item" href="programs.php#housing">Student Housing</a></li>
                            <li><a class="dropdown-item" href="programs.php#community">Community Projects</a></li>
                        </ul>
                    </li>
                    <li class="nav-item"><a class="nav-link active" href="stories.php">Stories</a></li>
                    <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
                </ul>
                
                <div class="navbar-actions">
                    <a href="apply.php" class="btn btn-outline-light">
                        <i class="fas fa-edit me-1"></i>Apply
                    </a>
                    <a href="donate.php" class="btn btn-warning">
                        <i class="fas fa-heart me-1"></i>Donate
                    </a>
                    <a href="login.php" class="btn btn-outline-light">
                        <i class="fas fa-sign-in-alt me-1"></i>Login
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Stories Hero Section -->
    <section class="stories-hero">
        <div class="container">
            <div class="row align-items-center min-vh-60">
                <div class="col-lg-8 mx-auto text-center">
                    <div class="hero-content">
                        <h1 class="hero-title">
                            Success <span class="highlight">Stories</span>
                        </h1>
                        <p class="hero-description">
                            Discover inspiring journeys of transformation, resilience, and achievement 
                            from our REACH students and alumni across Rwanda.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Stories Section -->
    <section class="section">
        <div class="container">
            <div class="row">
                <!-- Main Content -->
                <div class="col-lg-9">
                    <!-- Stories Filter -->
                    <div class="stories-filter" data-aos="fade-up">
                        <div class="filter-header">
                            <h4>Explore Stories</h4>
                            <div class="stories-count">
                                <?php echo $totalStories; ?> stories found
                            </div>
                        </div>
                        
                        <div class="filter-options">
                            <a href="?type=all" class="filter-btn <?php echo $type === 'all' ? 'active' : ''; ?>">
                                All Stories
                            </a>
                            <a href="?type=student" class="filter-btn <?php echo $type === 'student' ? 'active' : ''; ?>">
                                Student Stories
                            </a>
                            <a href="?type=project" class="filter-btn <?php echo $type === 'project' ? 'active' : ''; ?>">
                                Project Stories
                            </a>
                            <a href="?type=achievement" class="filter-btn <?php echo $type === 'achievement' ? 'active' : ''; ?>">
                                Achievements
                            </a>
                            <a href="?type=community" class="filter-btn <?php echo $type === 'community' ? 'active' : ''; ?>">
                                Community
                            </a>
                        </div>
                    </div>

                    <!-- Stories Grid -->
                    <div class="stories-grid">
                        <?php if (!empty($stories)): ?>
                            <div class="row">
                                <?php foreach ($stories as $story): ?>
                                <div class="col-lg-4 col-md-6 mb-4" data-aos="fade-up">
                                    <article class="story-card">
                                        <div class="story-image">
                                            <?php if (!empty($story['featured_image'])): ?>
                                                <img src="../assets/uploads/stories/<?php echo $story['featured_image']; ?>" 
                                                     alt="<?php echo htmlspecialchars($story['title']); ?>"
                                                     loading="lazy">
                                            <?php else: ?>
                                                <img src="https://placehold.co/600x400/3498db/ffffff?text=REACH+Story" 
                                                     alt="Default story image"
                                                     loading="lazy">
                                            <?php endif; ?>
                                            <div class="story-overlay">
                                                <div class="story-type-badge">
                                                    <span class="badge"><?php echo ucfirst($story['story_type']); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="story-content">
                                            <div class="story-meta">
                                                <div class="author-info">
                                                    <?php if (!empty($story['author_image'])): ?>
                                                        <img src="../assets/uploads/profiles/<?php echo $story['author_image']; ?>" 
                                                             alt="<?php echo htmlspecialchars($story['author_name']); ?>"
                                                             class="author-avatar" loading="lazy">
                                                    <?php else: ?>
                                                        <img src="https://placehold.co/40x40/3498db/ffffff?text=<?php echo substr($story['author_name'] ?? 'A', 0, 1); ?>" 
                                                             alt="Author avatar"
                                                             class="author-avatar" loading="lazy">
                                                    <?php endif; ?>
                                                    <span class="author-name"><?php echo htmlspecialchars($story['author_name'] ?? 'Unknown Author'); ?></span>
                                                </div>
                                                <div class="story-date">
                                                    <?php echo date('M j, Y', strtotime($story['published_at'] ?? $story['created_at'])); ?>
                                                </div>
                                            </div>
                                            
                                            <h3 class="story-title">
                                                <a href="stories-single.php?slug=<?php echo $story['slug']; ?>">
                                                    <?php echo htmlspecialchars($story['title']); ?>
                                                </a>
                                            </h3>
                                            
                                            <p class="story-excerpt">
                                                <?php 
                                                $excerpt = $story['excerpt'] ?? substr(strip_tags($story['content'] ?? ''), 0, 150);
                                                echo htmlspecialchars($excerpt) . (strlen($excerpt) > 149 ? '...' : '');
                                                ?>
                                            </p>
                                            
                                            <div class="story-footer">
                                                <div class="story-stats">
                                                    <span class="views">
                                                        <i class="fas fa-eye"></i>
                                                        <?php echo number_format($story['view_count'] ?? 0); ?>
                                                    </span>
                                                    <span class="likes">
                                                        <i class="fas fa-heart"></i>
                                                        <?php echo number_format($story['like_count'] ?? 0); ?>
                                                    </span>
                                                </div>
                                                <a href="stories-single.php?slug=<?php echo $story['slug']; ?>" class="read-more">
                                                    Read More <i class="fas fa-arrow-right"></i>
                                                </a>
                                            </div>
                                        </div>
                                    </article>
                                </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- Pagination -->
                            <?php if ($totalPages > 1): ?>
                            <nav class="stories-pagination" data-aos="fade-up">
                                <ul class="pagination justify-content-center">
                                    <?php if ($page > 1): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?type=<?php echo $type; ?>&page=<?php echo $page - 1; ?>">
                                            <i class="fas fa-chevron-left me-1"></i> Previous
                                        </a>
                                    </li>
                                    <?php endif; ?>
                                    
                                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                                        <?php if ($i == 1 || $i == $totalPages || ($i >= $page - 2 && $i <= $page + 2)): ?>
                                        <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                            <a class="page-link" href="?type=<?php echo $type; ?>&page=<?php echo $i; ?>">
                                                <?php echo $i; ?>
                                            </a>
                                        </li>
                                        <?php elseif ($i == $page - 3 || $i == $page + 3): ?>
                                        <li class="page-item disabled">
                                            <span class="page-link">...</span>
                                        </li>
                                        <?php endif; ?>
                                    <?php endfor; ?>
                                    
                                    <?php if ($page < $totalPages): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?type=<?php echo $type; ?>&page=<?php echo $page + 1; ?>">
                                            Next <i class="fas fa-chevron-right ms-1"></i>
                                        </a>
                                    </li>
                                    <?php endif; ?>
                                </ul>
                            </nav>
                            <?php endif; ?>

                        <?php else: ?>
                            <div class="empty-state" data-aos="fade-up">
                                <i class="fas fa-book-open"></i>
                                <h4>No Stories Found</h4>
                                <p>There are no stories available in this category yet.</p>
                                <a href="?type=all" class="btn btn-primary">View All Stories</a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Sidebar -->
                <div class="col-lg-3">
                    <!-- Featured Stories -->
                    <?php if (!empty($featuredStories)): ?>
                    <div class="sidebar-widget" data-aos="fade-left">
                        <h5 class="widget-title">Featured Stories</h5>
                        <div class="featured-stories-list">
                            <?php foreach ($featuredStories as $featured): ?>
                            <div class="featured-story-item">
                                <div class="featured-image">
                                    <?php if (!empty($featured['featured_image'])): ?>
                                        <img src="../assets/uploads/stories/<?php echo $featured['featured_image']; ?>" 
                                             alt="<?php echo htmlspecialchars($featured['title']); ?>"
                                             loading="lazy">
                                    <?php else: ?>
                                        <img src="https://placehold.co/80x60/3498db/ffffff?text=REACH" 
                                             alt="Featured story"
                                             loading="lazy">
                                    <?php endif; ?>
                                </div>
                                <div class="featured-content">
                                    <h6>
                                        <a href="stories-single.php?slug=<?php echo $featured['slug']; ?>">
                                            <?php echo htmlspecialchars($featured['title']); ?>
                                        </a>
                                    </h6>
                                    <div class="featured-meta">
                                        <span><?php echo date('M j', strtotime($featured['published_at'] ?? $featured['created_at'])); ?></span>
                                        <span><?php echo number_format($featured['view_count'] ?? 0); ?> views</span>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>

                    <!-- Story Categories -->
                    <div class="sidebar-widget" data-aos="fade-left" data-aos-delay="100">
                        <h5 class="widget-title">Story Categories</h5>
                        <div class="categories-list">
                            <a href="?type=student" class="category-item">
                                <i class="fas fa-user-graduate me-2"></i>
                                Student Stories
                                <span class="category-count"><?php echo $studentCount; ?></span>
                            </a>
                            <a href="?type=project" class="category-item">
                                <i class="fas fa-project-diagram me-2"></i>
                                Project Stories
                                <span class="category-count"><?php echo $projectCount; ?></span>
                            </a>
                            <a href="?type=achievement" class="category-item">
                                <i class="fas fa-trophy me-2"></i>
                                Achievements
                                <span class="category-count"><?php echo $achievementCount; ?></span>
                            </a>
                            <a href="?type=community" class="category-item">
                                <i class="fas fa-users me-2"></i>
                                Community
                                <span class="category-count"><?php echo $communityCount; ?></span>
                            </a>
                        </div>
                    </div>

                    <!-- Newsletter Signup -->
                    <div class="sidebar-widget" data-aos="fade-left" data-aos-delay="200">
                        <h5 class="widget-title">Stay Updated</h5>
                        <div class="newsletter-widget">
                            <p class="mb-3">Get notified when new success stories are published.</p>
                            <form class="newsletter-form">
                                <div class="mb-3">
                                    <input type="email" class="form-control" placeholder="Your email address" required>
                                </div>
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-envelope me-2"></i>Subscribe
                                </button>
                            </form>
                        </div>
                    </div>

                    <!-- CTA Widget -->
                    <div class="cta-widget" data-aos="fade-left" data-aos-delay="300">
                        <i class="fas fa-hands-helping"></i>
                        <h5>Share Your Story</h5>
                        <p>Have a success story to share? We'd love to hear from you!</p>
                        <a href="contact.php" class="btn btn-light">
                            <i class="fas fa-pen me-2"></i>Contact Us
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer - Same as index -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-4 mb-4">
                    <h5>REACH Organization</h5>
                    <p>Recognizing Each Action Can Help</p>
                    <div class="mt-3">
                        <a href="#" class="text-white me-3"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="text-white"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>
                <div class="col-lg-4 mb-4">
                    <h5>Quick Links</h5>
                    <div class="footer-links">
                        <div class="row">
                            <div class="col-6">
                                <a href="about.php">About Us</a><br>
                                <a href="programs.php">Programs</a><br>
                                <a href="stories.php">Success Stories</a>
                            </div>
                            <div class="col-6">
                                <a href="apply.php">Apply</a><br>
                                <a href="donate.php">Donate</a><br>
                                <a href="contact.php">Contact</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 mb-4">
                    <h5>Contact Info</h5>
                    <p><i class="fas fa-map-marker-alt me-2"></i> Kigali, Rwanda</p>
                    <p><i class="fas fa-phone me-2"></i> +250 788 123 456</p>
                    <p><i class="fas fa-envelope me-2"></i> info@reach.org</p>
                </div>
            </div>
            <hr class="my-4">
            <div class="text-center">
                <p>&copy; 2024 REACH Organization. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    
    <script>
        // Initialize AOS
        AOS.init({
            duration: 800,
            once: true,
            offset: 100
        });

        // Navbar scroll effect - Same as index
        window.addEventListener('scroll', function() {
            const navbar = document.getElementById('mainNav');
            if (window.scrollY > 100) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });

        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });

        // Mobile menu enhancement
        document.addEventListener('DOMContentLoaded', function() {
            const navbarToggler = document.querySelector('.navbar-toggler');
            const navbarCollapse = document.querySelector('.navbar-collapse');

            if (navbarToggler && navbarCollapse) {
                navbarToggler.addEventListener('click', function() {
                    navbarCollapse.classList.toggle('show');
                });

                // Close mobile menu when clicking on a link
                document.querySelectorAll('.nav-link').forEach(link => {
                    link.addEventListener('click', () => {
                        if (navbarCollapse.classList.contains('show')) {
                            navbarCollapse.classList.remove('show');
                        }
                    });
                });
            }
        });

        // Newsletter form submission
        document.querySelectorAll('.newsletter-form').forEach(form => {
            form.addEventListener('submit', function(e) {
                e.preventDefault();
                const email = this.querySelector('input[type="email"]').value;
                
                // Simple validation
                if (email && email.includes('@')) {
                    // Show success message
                    const button = this.querySelector('button');
                    const originalText = button.innerHTML;
                    button.innerHTML = '<i class="fas fa-check me-2"></i>Subscribed!';
                    button.disabled = true;
                    
                    // Reset after 3 seconds
                    setTimeout(() => {
                        button.innerHTML = originalText;
                        button.disabled = false;
                        this.reset();
                    }, 3000);
                }
            });
        });
    </script>
</body>
</html>