<?php
// Enable all error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h3>Debug Information</h3>";

try {
    // Test includes
    echo "Testing includes...<br>";
    include '../includes/config.php';
    echo "✅ config.php loaded<br>";
    
    include '../includes/database.php';
    echo "✅ database.php loaded<br>";
    
    include '../includes/auth.php';
    echo "✅ auth.php loaded<br>";
    
    include '../includes/functions.php';
    echo "✅ functions.php loaded<br>";
    
    // Test database connection
    echo "Testing database connection...<br>";
    $db = new Database();
    echo "✅ Database connected<br>";
    
    // Test simple query
    echo "Testing query...<br>";
    $db->query("SELECT 1 as test");
    $result = $db->single();
    echo "✅ Query executed: " . $result['test'] . "<br>";
    
    echo "<h4 style='color: green;'>✅ All systems working!</h4>";
    
} catch (Exception $e) {
    echo "<h4 style='color: red;'>❌ Error Found:</h4>";
    echo "<pre>";
    echo "Message: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . "\n";
    echo "Line: " . $e->getLine() . "\n";
    echo "Trace: " . $e->getTraceAsString() . "\n";
    echo "</pre>";
}
?>