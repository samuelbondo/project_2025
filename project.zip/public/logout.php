<?php
// public/logout.php
session_start();

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Log logout attempt
error_log("Logout initiated - User: " . ($_SESSION['username'] ?? 'Unknown') . ", IP: " . ($_SERVER['REMOTE_ADDR'] ?? 'Unknown'));

// Store user info for logging
$user_info = [
    'username' => $_SESSION['username'] ?? 'Unknown',
    'user_id' => $_SESSION['user_id'] ?? 'Unknown'
];

// Clear all session variables
$_SESSION = [];

// Destroy the session
if (session_destroy()) {
    error_log("Session destroyed successfully for user: " . $user_info['username']);
} else {
    error_log("Session destruction failed for user: " . $user_info['username']);
}

// Clear session cookie
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], 
        $params["domain"], 
        $params["secure"], 
        $params["httponly"]
    );
}

// Clear any remember me tokens
setcookie('remember_token', '', time() - 3600, '/');

// Force redirect to login page with cache busting
header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");
header('Location: login.php?logout=success&t=' . time());
exit;
?>