<!DOCTYPE html>
<html lang="en" class="h-100">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact REACH Organization | Get in Touch</title>
    
    <!-- Advanced Meta Tags -->
    <meta name="description" content="Contact REACH Organization for inquiries, partnerships, or support. We're here to help transform lives by giving back to society.">
    <meta name="keywords" content="contact REACH, USA NGO contact, education support, partnership inquiry">
    <meta name="author" content="REACH Organization">
    
    <!-- Open Graph -->
    <meta property="og:title" content="Contact REACH Organization">
    <meta property="og:description" content="Get in touch with REACH Organization for inquiries, partnerships, or support">
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://reach.org/contact">
    
    <!-- PWA Meta Tags -->
    <meta name="theme-color" content="#3498db">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    
    <!-- Preload Critical Resources -->
    <link rel="preload" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" as="style">
    <link rel="preload" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" as="style">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    
    <style>
        :root {
            --primary: #3498db;
            --secondary: #2c3e50;
            --success: #27ae60;
            --light: #f8f9fa;
            --reach-accent: #ea4335;
            --reach-warning: #f39c12;
            --gradient-primary: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            --gradient-dark: linear-gradient(135deg, #2980b9 0%, #1c2833 100%);
            --gradient-light: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            --shadow-sm: 0 2px 8px rgba(0,0,0,0.08);
            --shadow-md: 0 8px 30px rgba(0,0,0,0.12);
            --shadow-lg: 0 15px 35px rgba(0,0,0,0.15);
            --border-radius-sm: 12px;
            --border-radius-md: 20px;
            --border-radius-lg: 28px;
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html {
            height: 100%;
            font-size: 16px;
            scroll-behavior: smooth;
        }

        body {
            min-height: 100vh;
            min-height: 100dvh;
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            line-height: 1.6;
            color: var(--secondary);
            overflow-x: hidden;
            padding-top: 80px;
        }

        /* Enhanced Navigation */
        .navbar {
            background: rgba(44, 62, 80, 0.95) !important;
            backdrop-filter: blur(20px);
            padding: 1rem 0;
            transition: var(--transition);
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .navbar.scrolled {
            background: rgba(44, 62, 80, 0.98) !important;
            padding: 0.75rem 0;
            box-shadow: var(--shadow-md);
        }

        .brand-content {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .brand-text {
            line-height: 1.2;
        }

        .brand-text strong {
            font-size: 1.4rem;
            font-weight: 700;
            display: block;
            color: white;
        }

        .brand-text small {
            font-size: 0.75rem;
            opacity: 0.8;
            font-weight: 400;
            color: rgba(255,255,255,0.8);
        }

        .navbar-brand i {
            font-size: 1.8rem;
            color: var(--success);
        }

        .nav-link {
            font-weight: 500;
            padding: 0.5rem 1rem !important;
            border-radius: var(--border-radius-sm);
            transition: var(--transition);
            margin: 0.125rem;
            color: rgba(255,255,255,0.9);
        }

        .nav-link:hover,
        .nav-link.active {
            background: rgba(255,255,255,0.1);
            transform: translateY(-1px);
            color: white;
        }

        .dropdown-menu {
            background: rgba(255,255,255,0.95);
            backdrop-filter: blur(20px);
            border: none;
            border-radius: var(--border-radius-sm);
            box-shadow: var(--shadow-lg);
            padding: 0.5rem;
        }

        .dropdown-item {
            border-radius: 8px;
            padding: 0.75rem 1rem;
            transition: var(--transition);
        }

        .dropdown-item:hover {
            background: var(--primary);
            color: white;
            transform: translateX(5px);
        }

        .navbar-actions {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            flex-wrap: wrap;
        }

        .navbar-actions .btn {
            padding: 0.5rem 1.25rem;
            border-radius: var(--border-radius-sm);
            font-weight: 500;
            transition: var(--transition);
            white-space: nowrap;
        }

        /* Contact Hero Section */
        .contact-hero {
            background: var(--gradient-primary);
            color: white;
            padding: 100px 0 60px;
            position: relative;
            overflow: hidden;
        }

        .contact-hero::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 800" opacity="0.1"><polygon fill="white" points="0,800 1200,400 1200,800"/></svg>');
            background-size: cover;
            animation: float 20s ease-in-out infinite;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0px) rotate(0deg); }
            50% { transform: translateY(-20px) rotate(1deg); }
        }

        .contact-hero-content {
            position: relative;
            z-index: 2;
        }

        .hero-title {
            font-size: clamp(2.5rem, 6vw, 4rem);
            font-weight: 800;
            line-height: 1.1;
            margin-bottom: 1.5rem;
            color: white;
            text-shadow: 0 2px 15px rgba(0,0,0,0.3);
        }

        .hero-description {
            font-size: clamp(1.1rem, 2.5vw, 1.3rem);
            margin-bottom: 2.5rem;
            opacity: 0.95;
            max-width: 600px;
            line-height: 1.6;
            margin-left: auto;
            margin-right: auto;
            text-shadow: 0 1px 5px rgba(0,0,0,0.2);
        }

        /* Contact Information Cards */
        .contact-info-section {
            padding: 80px 0;
            background: var(--light);
        }

        .contact-info-card {
            background: white;
            padding: 2.5rem 2rem;
            border-radius: var(--border-radius-md);
            box-shadow: var(--shadow-sm);
            transition: var(--transition);
            height: 100%;
            text-align: center;
            border: 1px solid rgba(0,0,0,0.05);
        }

        .contact-info-card:hover {
            transform: translateY(-8px);
            box-shadow: var(--shadow-md);
        }

        .contact-icon {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, var(--primary), #3b71ca);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 2rem;
            color: white;
            font-size: 1.8rem;
            box-shadow: 0 5px 15px rgba(44, 90, 160, 0.3);
        }

        /* Contact Form Section */
        .contact-form-section {
            padding: 80px 0;
        }

        .contact-form-card {
            background: white;
            padding: 3rem;
            border-radius: var(--border-radius-md);
            box-shadow: var(--shadow-md);
            border: 1px solid rgba(0,0,0,0.05);
        }

        .info-card {
            background: white;
            padding: 2rem;
            border-radius: var(--border-radius-sm);
            box-shadow: var(--shadow-sm);
            margin-bottom: 2rem;
            border: 1px solid rgba(0,0,0,0.05);
        }

        .card-title {
            color: var(--primary);
            font-weight: 700;
            margin-bottom: 1.5rem;
            font-size: 1.3rem;
            border-bottom: 2px solid var(--primary);
            padding-bottom: 0.5rem;
        }

        .office-hours .hour-item {
            display: flex;
            justify-content: space-between;
            padding: 1rem 0;
            border-bottom: 1px solid #eee;
            font-weight: 500;
        }

        .office-hours .hour-item:last-child {
            border-bottom: none;
        }

        .quick-links .quick-link {
            display: flex;
            align-items: center;
            padding: 1rem 0;
            color: #555;
            text-decoration: none;
            border-bottom: 1px solid #eee;
            transition: var(--transition);
            font-weight: 500;
        }

        .quick-links .quick-link:hover {
            color: var(--primary);
            transform: translateX(5px);
            background-color: #f8f9fa;
            padding-left: 1rem;
            border-radius: 5px;
        }

        .quick-links .quick-link:last-child {
            border-bottom: none;
        }

        .emergency-contact {
            border-left: 5px solid var(--reach-accent);
            background: linear-gradient(135deg, #fff, #fff5f5);
        }

        .emergency-number {
            font-size: 1.4rem;
            color: var(--reach-accent);
            margin: 1.5rem 0;
            font-weight: 700;
        }

        /* Team Contact Section */
        .team-contact-section {
            padding: 80px 0;
            background: var(--light);
        }

        .team-contact-card {
            background: white;
            padding: 2.5rem 2rem;
            border-radius: var(--border-radius-md);
            box-shadow: var(--shadow-sm);
            transition: var(--transition);
            height: 100%;
            text-align: center;
            border: 1px solid rgba(0,0,0,0.05);
        }

        .team-contact-card:hover {
            transform: translateY(-8px);
            box-shadow: var(--shadow-md);
        }

        .team-avatar {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            overflow: hidden;
            margin: 0 auto 1.5rem;
            background: linear-gradient(135deg, #f8f9fa, #e9ecef);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2.5rem;
            color: var(--primary);
            border: 4px solid white;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .contact-details .contact-item {
            margin: 0.8rem 0;
            color: #666;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.95rem;
        }

        /* FAQ Section */
        .faq-section {
            padding: 80px 0;
        }

        .accordion-button {
            font-weight: 600;
            padding: 1.2rem 1.5rem;
            font-size: 1.05rem;
        }

        .accordion-button:not(.collapsed) {
            background-color: var(--primary);
            color: white;
        }

        /* Map Section */
        .map-section {
            padding: 80px 0;
            background: var(--light);
        }

        .map-container {
            background: white;
            border-radius: var(--border-radius-md);
            overflow: hidden;
            box-shadow: var(--shadow-md);
            border: 1px solid rgba(0,0,0,0.05);
        }

        .map-placeholder {
            padding: 5rem 2rem;
            text-align: center;
            background: linear-gradient(135deg, #f8f9fa, #e9ecef);
        }

        /* Section Styles */
        .section {
            padding: 80px 0;
        }

        .section-title {
            font-size: 2.5rem;
            font-weight: bold;
            color: var(--secondary);
        }

        .section-subtitle {
            font-size: 1.2rem;
            color: #6c757d;
        }

        /* Buttons */
        .btn-primary {
            background: var(--primary);
            border-color: var(--primary);
            padding: 0.75rem 2rem;
        }

        .btn-primary:hover {
            background: #2980b9;
            border-color: #2980b9;
        }

        .form-control, .form-select {
            padding: 1rem 1.2rem;
            border: 2px solid #e9ecef;
            border-radius: var(--border-radius-sm);
            font-size: 1rem;
            transition: var(--transition);
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.3rem rgba(52, 152, 219, 0.15);
            transform: translateY(-2px);
        }

        .form-check-input:checked {
            background-color: var(--primary);
            border-color: var(--primary);
        }

        .alert {
            border-radius: var(--border-radius-sm);
            border: none;
            padding: 1.2rem 1.5rem;
            font-size: 1rem;
            box-shadow: var(--shadow-sm);
        }

        .is-valid {
            border-color: var(--success) !important;
        }

        .is-invalid {
            border-color: var(--reach-accent) !important;
        }

        .email-notification {
            background: linear-gradient(135deg, #e8f5e8, #f0f8f0);
            border-left: 4px solid var(--success);
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
        }

        /* Footer */
        footer {
            background: var(--secondary);
            color: white;
            padding: 3rem 0 1rem;
        }

        .footer-links a {
            color: #bdc3c7;
            text-decoration: none;
            transition: color 0.3s;
        }

        .footer-links a:hover {
            color: white;
        }

        /* Ultra-Responsive Design */
        @media (max-width: 768px) {
            .navbar-actions {
                justify-content: center;
                margin-top: 1rem;
                width: 100%;
            }

            .navbar-actions .btn {
                flex: 1;
                min-width: 120px;
                text-align: center;
            }

            .contact-form-card {
                padding: 2rem 1.5rem;
            }

            .contact-info-card,
            .team-contact-card {
                padding: 2rem 1.5rem;
            }

            .hero-title {
                font-size: 2.5rem;
            }

            .section-title {
                font-size: 2.2rem;
            }
        }

        @media (max-width: 576px) {
            .brand-text strong {
                font-size: 1.2rem;
            }

            .brand-text small {
                font-size: 0.7rem;
            }

            .hero-title {
                font-size: 2rem;
            }

            .section-title {
                font-size: 1.8rem;
            }

            .contact-hero {
                padding: 80px 0 40px;
            }
        }

        @media (max-width: 360px) {
            .navbar-brand {
                font-size: 0.9rem;
            }

            .hero-title {
                font-size: 1.8rem;
            }

            .section-title {
                font-size: 1.5rem;
            }
        }

        /* Reduced motion support */
        @media (prefers-reduced-motion: reduce) {
            * {
                animation-duration: 0.01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: 0.01ms !important;
            }
        }

        /* Focus styles for accessibility */
        .btn:focus,
        .nav-link:focus,
        .form-control:focus {
            outline: 2px solid var(--primary);
            outline-offset: 2px;
        }
    </style>
</head>
<body class="h-100">
    <!-- Enhanced Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <div class="brand-content">
                    <i class="fas fa-hands-helping"></i>
                    <div class="brand-text">
                        <strong>REACH</strong>
                        <small>Recognizing Each Action Can Help</small>
                    </div>
                </div>
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMain"
                    aria-controls="navbarMain" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarMain">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="about.php">About</a></li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Programs
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="programs.php#scholarships">Scholarships</a></li>
                            <li><a class="dropdown-item" href="programs.php#housing">Student Housing</a></li>
                            <li><a class="dropdown-item" href="programs.php#community">Community Projects</a></li>
                        </ul>
                    </li>
                    <li class="nav-item"><a class="nav-link" href="stories.php">Stories</a></li>
                    <li class="nav-item"><a class="nav-link active" href="contact.php">Contact</a></li>
                </ul>
                
                <div class="navbar-actions">
                    <a href="apply.php" class="btn btn-outline-light">
                        <i class="fas fa-edit me-1"></i>Apply
                    </a>
                    <a href="donate.php" class="btn btn-warning">
                        <i class="fas fa-heart me-1"></i>Donate
                    </a>
                    <a href="login.php" class="btn btn-outline-light">
                        <i class="fas fa-sign-in-alt me-1"></i>Login
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Contact Hero Section -->
    <section class="contact-hero">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-8 mx-auto text-center">
                    <div class="contact-hero-content">
                        <h1 class="hero-title">
                            Get in <span style="color: #ffd700;">Touch</span> With Us
                        </h1>
                        <p class="hero-description">
                            We'd love to hear from you. Whether you have questions about our programs, want to partner with us, 
                            or need support, our team is here to help transform lives.
                        </p>
                        <div class="email-notification mt-4">
                            <i class="fas fa-envelope-circle-check text-success me-2"></i>
                            <strong>Instant Response:</strong> You'll receive an automatic confirmation email when you contact us!
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Information -->
    <section class="contact-info-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 mb-4">
                    <div class="contact-info-card">
                        <div class="contact-icon">
                            <i class="fas fa-map-marker-alt"></i>
                        </div>
                        <h5>Our Location</h5>
                        <p class="mb-1">NY, USA</p>
                        <small class="text-muted">Main Office: KN 123 St</small>
                    </div>
                </div>
                
                <div class="col-lg-4 mb-4">
                    <div class="contact-info-card">
                        <div class="contact-icon">
                            <i class="fas fa-phone"></i>
                        </div>
                        <h5>Phone Number</h5>
                        <p class="mb-1">+250 794 047 261</p>
                        <small class="text-muted">Mon - Fri, 9:00 AM - 5:00 PM</small>
                    </div>
                </div>
                
                <div class="col-lg-4 mb-4">
                    <div class="contact-info-card">
                        <div class="contact-icon">
                            <i class="fas fa-envelope"></i>
                        </div>
                        <h5>Email Address</h5>
                        <p class="mb-1">info@reach.org</p>
                        <small class="text-muted">We respond within 24 hours</small>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Form & Information -->
    <section class="contact-form-section">
        <div class="container">
            <div class="row">
                <!-- Contact Form -->
                <div class="col-lg-8">
                    <div class="contact-form-card">
                        <h4 class="mb-4">Send us a Message</h4>
                        <p class="text-muted mb-4">
                            <i class="fas fa-info-circle me-2"></i>
                            After submitting, you'll receive an automatic confirmation email.
                        </p>
                        
                        <form id="contactForm" method="POST">
                            <input type="hidden" name="contact_form" value="1">
                            <input type="hidden" name="csrf_token" value="<?php echo bin2hex(random_bytes(32)); ?>">
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Full Name *</label>
                                        <input type="text" class="form-control" name="name" required 
                                               minlength="2" maxlength="100" placeholder="Enter your full name">
                                        <div class="form-text">Minimum 2 characters required</div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Email Address *</label>
                                        <input type="email" class="form-control" name="email" required 
                                               placeholder="your.email@example.com">
                                        <div class="form-text">We'll send confirmation to this email</div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Phone Number</label>
                                        <input type="tel" class="form-control" name="phone" 
                                               pattern="^[\+]?[0-9\s\-\(\)]{10,20}$" 
                                               placeholder="+250 794 047 261">
                                        <div class="form-text">Optional</div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Subject *</label>
                                        <select class="form-select" name="subject" required>
                                            <option value="">Select a subject</option>
                                            <option value="general">General Inquiry</option>
                                            <option value="application">Application Support</option>
                                            <option value="partnership">Partnership Opportunity</option>
                                            <option value="donation">Donation Question</option>
                                            <option value="volunteer">Volunteer Opportunity</option>
                                            <option value="media">Media Inquiry</option>
                                            <option value="other">Other</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mb-4">
                                <label class="form-label">Message *</label>
                                <textarea class="form-control" name="message" rows="6" 
                                          placeholder="Please provide details about your inquiry..." 
                                          required minlength="10" maxlength="2000"></textarea>
                                <div class="form-text">Minimum 10 characters required</div>
                            </div>
                            
                            <div class="mb-4">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="newsletter" id="newsletter" checked>
                                    <label class="form-check-label" for="newsletter">
                                        <i class="fas fa-newspaper me-1"></i>
                                        Subscribe to our newsletter for updates and success stories
                                    </label>
                                </div>
                            </div>
                            
                            <div class="text-center">
                                <button type="submit" class="btn btn-primary btn-lg">
                                    <i class="fas fa-paper-plane me-2"></i>Send Message
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
                
                <!-- Additional Information -->
                <div class="col-lg-4">
                    <!-- Office Hours -->
                    <div class="info-card mb-4">
                        <h5 class="card-title">
                            <i class="fas fa-clock me-2"></i>Office Hours
                        </h5>
                        <div class="office-hours">
                            <div class="hour-item">
                                <span>Monday - Friday</span>
                                <span>9:00 AM - 5:00 PM</span>
                            </div>
                            <div class="hour-item">
                                <span>Saturday</span>
                                <span>10:00 AM - 2:00 PM</span>
                            </div>
                            <div class="hour-item">
                                <span>Sunday</span>
                                <span>Closed</span>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Quick Links -->
                    <div class="info-card mb-4">
                        <h5 class="card-title">
                            <i class="fas fa-link me-2"></i>Quick Links
                        </h5>
                        <div class="quick-links">
                            <a href="apply.php" class="quick-link">
                                <i class="fas fa-edit me-2"></i>Apply for Support
                            </a>
                            <a href="donate.php" class="quick-link">
                                <i class="fas fa-heart me-2"></i>Make a Donation
                            </a>
                            <a href="programs.php" class="quick-link">
                                <i class="fas fa-project-diagram me-2"></i>Our Programs
                            </a>
                            <a href="stories.php" class="quick-link">
                                <i class="fas fa-book-open me-2"></i>Success Stories
                            </a>
                        </div>
                    </div>
                    
                    <!-- Emergency Contact -->
                    <div class="info-card emergency-contact">
                        <h5 class="card-title">
                            <i class="fas fa-exclamation-triangle me-2"></i>Emergency Contact
                        </h5>
                        <p class="emergency-text">
                            For urgent matters regarding current students or program participants, 
                            please call our emergency line:
                        </p>
                        <div class="emergency-number">
                            <i class="fas fa-phone-alt me-2"></i>
                            <strong>+250 794 047 261</strong>
                        </div>
                        <small class="text-muted">Available 24/7 for emergencies only</small>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Team Contact -->
    <section class="team-contact-section">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="section-title">Contact Our Team</h2>
                <p class="section-subtitle">Reach out to specific team members for specialized inquiries</p>
            </div>
            
            <div class="row">
                <!-- Team Member 1 -->
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="team-contact-card text-center">
                        <div class="team-avatar">
                            <i class="fas fa-user-graduate"></i>
                        </div>
                        <h5>Admissions Team</h5>
                        <p class="text-muted">Application & Program Inquiries</p>
                        <div class="contact-details">
                            <div class="contact-item">
                                <i class="fas fa-envelope me-2"></i>
                                <span>admissions@reach.org</span>
                            </div>
                            <div class="contact-item">
                                <i class="fas fa-phone me-2"></i>
                                <span>+250 794 047 261</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Team Member 2 -->
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="team-contact-card text-center">
                        <div class="team-avatar">
                            <i class="fas fa-handshake"></i>
                        </div>
                        <h5>Partnerships Team</h5>
                        <p class="text-muted">Corporate & Organization Partners</p>
                        <div class="contact-details">
                            <div class="contact-item">
                                <i class="fas fa-envelope me-2"></i>
                                <span>partnerships@reach.org</span>
                            </div>
                            <div class="contact-item">
                                <i class="fas fa-phone me-2"></i>
                                <span>+250 794 047 261</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Team Member 3 -->
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="team-contact-card text-center">
                        <div class="team-avatar">
                            <i class="fas fa-donate"></i>
                        </div>
                        <h5>Donor Relations</h5>
                        <p class="text-muted">Donations & Sponsorship</p>
                        <div class="contact-details">
                            <div class="contact-item">
                                <i class="fas fa-envelope me-2"></i>
                                <span>donors@reach.org</span>
                            </div>
                            <div class="contact-item">
                                <i class="fas fa-phone me-2"></i>
                                <span>+250 794 047 261</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Team Member 4 -->
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="team-contact-card text-center">
                        <div class="team-avatar">
                            <i class="fas fa-newspaper"></i>
                        </div>
                        <h5>Media Relations</h5>
                        <p class="text-muted">Press & Media Inquiries</p>
                        <div class="contact-details">
                            <div class="contact-item">
                                <i class="fas fa-envelope me-2"></i>
                                <span>media@reach.org</span>
                            </div>
                            <div class="contact-item">
                                <i class="fas fa-phone me-2"></i>
                                <span>+250 794 047 261</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- FAQ Section -->
    <section class="faq-section">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="section-title">Common Questions</h2>
                <p class="section-subtitle">Quick answers to frequently asked questions</p>
            </div>
            
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="accordion" id="contactFAQ">
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#faq1">
                                    How long does it take to process applications?
                                </button>
                            </h2>
                            <div id="faq1" class="accordion-collapse collapse show" data-bs-parent="#contactFAQ">
                                <div class="accordion-body">
                                    Application processing typically takes 2-3 weeks. We review each application thoroughly 
                                    and may contact you for additional information. You'll receive an email notification 
                                    once a decision has been made.
                                </div>
                            </div>
                        </div>
                        
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq2">
                                    Can I visit your office in person?
                                </button>
                            </h2>
                            <div id="faq2" class="accordion-collapse collapse" data-bs-parent="#contactFAQ">
                                <div class="accordion-body">
                                    Yes, we welcome visitors during office hours. However, we recommend scheduling an 
                                    appointment in advance to ensure the appropriate team member is available to assist you. 
                                    Please call us to schedule your visit.
                                </div>
                            </div>
                        </div>
                        
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq3">
                                    Do you offer internships or volunteer opportunities?
                                </button>
                            </h2>
                            <div id="faq3" class="accordion-collapse collapse" data-bs-parent="#contactFAQ">
                                <div class="accordion-body">
                                    Yes, we regularly offer internships and volunteer positions in various departments. 
                                    Please check our Careers page for current opportunities or contact our volunteer 
                                    coordinator at volunteers@reach.org for more information.
                                </div>
                            </div>
                        </div>
                        
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq4">
                                    How can my organization partner with REACH?
                                </button>
                            </h2>
                            <div id="faq4" class="accordion-collapse collapse" data-bs-parent="#contactFAQ">
                                <div class="accordion-body">
                                    We welcome partnerships with organizations that share our mission. Please contact our 
                                    partnerships team at partnerships@reach.org with details about your organization and 
                                    proposed collaboration. We'll schedule a meeting to discuss potential opportunities.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Map Section -->
    <section class="map-section">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="section-title">Find Our Office</h2>
                <p class="section-subtitle">USA</p>
            </div>
            
            <div class="row">
                <div class="col-12">
                    <div class="map-container">
                        <div class="map-placeholder">
                            <i class="fas fa-map-marked-alt fa-3x text-muted mb-3"></i>
                            <h5>REACH Organization Headquarters</h5>
                            <p class="text-muted">USA</p>
                            <div class="map-actions mt-4">
                                <a href="https://maps.google.com/?q=NY,USA" target="_blank" class="btn btn-outline-primary">
                                    <i class="fas fa-directions me-2"></i>Get Directions
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-4 mb-4">
                    <h5>REACH Organization</h5>
                    <p>Recognizing Each Action Can Help</p>
                    <div class="mt-3">
                        <a href="#" class="text-white me-3"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="text-white"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>
                <div class="col-lg-4 mb-4">
                    <h5>Quick Links</h5>
                    <div class="footer-links">
                        <div class="row">
                            <div class="col-6">
                                <a href="about.php">About Us</a><br>
                                <a href="programs.php">Programs</a><br>
                                <a href="stories.php">Success Stories</a>
                            </div>
                            <div class="col-6">
                                <a href="apply.php">Apply</a><br>
                                <a href="donate.php">Donate</a><br>
                                <a href="contact.php">Contact</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 mb-4">
                    <h5>Contact Info</h5>
                    <p><i class="fas fa-map-marker-alt me-2"></i> NY, USA</p>
                    <p><i class="fas fa-phone me-2"></i> +250 794 047 261</p>
                    <p><i class="fas fa-envelope me-2"></i> info@reach.org</p>
                </div>
            </div>
            <hr class="my-4">
            <div class="text-center">
                <p>&copy; 2024 REACH Organization. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Navbar scroll effect
        window.addEventListener('scroll', function() {
            const navbar = document.getElementById('mainNav');
            if (window.scrollY > 100) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });

        // Contact form handling - ULTRA SIMPLE VERSION
        document.getElementById('contactForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const submitBtn = this.querySelector('button[type="submit"]');
            const originalText = submitBtn.innerHTML;
            
            try {
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Sending...';
                submitBtn.disabled = true;
                
                // Validate all fields first
                if (!validateAllFields()) {
                    throw new Error('Please fix the validation errors above.');
                }
                
                // Create form data
                const formData = new FormData(this);
                
                console.log('Submitting form...');
                
                // Submit to a separate PHP file
                const response = await fetch('contact-processor.php', {
                    method: 'POST',
                    body: formData
                });
                
                // Get response as text first
                const responseText = await response.text();
                console.log('Raw response:', responseText);
                
                // Try to parse as JSON
                let result;
                try {
                    result = JSON.parse(responseText);
                } catch (parseError) {
                    console.error('JSON parse error:', parseError);
                    // If JSON parsing fails, check if it's HTML
                    if (responseText.includes('<!DOCTYPE') || responseText.includes('<html')) {
                        throw new Error('Server returned HTML instead of JSON. There might be a PHP error.');
                    } else {
                        throw new Error('Server returned an invalid response: ' + responseText.substring(0, 100));
                    }
                }
                
                if (result.success) {
                    let successMessage = result.message;
                    if (result.emails_sent) {
                        successMessage += ' Check your inbox (and spam folder) for the confirmation.';
                    }
                    
                    showAlert(successMessage, 'success');
                    this.reset();
                    resetValidationStates();
                    
                } else {
                    throw new Error(result.message);
                }
                
            } catch (error) {
                console.error('Form submission error:', error);
                showAlert('Error: ' + error.message, 'danger');
            } finally {
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
            }
        });

        function showAlert(message, type) {
            const existingAlerts = document.querySelectorAll('.alert');
            existingAlerts.forEach(alert => alert.remove());
            
            const alertDiv = document.createElement('div');
            alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
            alertDiv.innerHTML = `
                ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            `;
            
            document.querySelector('.contact-form-card').prepend(alertDiv);
            
            setTimeout(() => {
                if (alertDiv.parentNode) {
                    alertDiv.remove();
                }
            }, type === 'success' ? 10000 : 15000);
        }

        // Form validation
        document.querySelectorAll('#contactForm input, #contactForm textarea, #contactForm select').forEach(input => {
            input.addEventListener('blur', function() {
                validateField(this);
            });
            
            input.addEventListener('input', function() {
                if (this.classList.contains('is-invalid')) {
                    validateField(this);
                }
            });
        });

        function validateField(field) {
            const value = field.value.trim();
            let isValid = true;
            let errorMessage = '';

            switch(field.name) {
                case 'name':
                    if (value.length < 2) {
                        isValid = false;
                        errorMessage = 'Name must be at least 2 characters long';
                    }
                    break;
                case 'email':
                    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
                        isValid = false;
                        errorMessage = 'Please enter a valid email address';
                    }
                    break;
                case 'phone':
                    if (value && !/^[\+]?[0-9\s\-\(\)]{10,20}$/.test(value)) {
                        isValid = false;
                        errorMessage = 'Please enter a valid phone number';
                    }
                    break;
                case 'subject':
                    if (!value) {
                        isValid = false;
                        errorMessage = 'Please select a subject';
                    }
                    break;
                case 'message':
                    if (value.length < 10) {
                        isValid = false;
                        errorMessage = 'Message must be at least 10 characters long';
                    }
                    break;
            }

            if (field.name !== 'newsletter') {
                field.classList.remove('is-valid', 'is-invalid');
                if (value) {
                    field.classList.add(isValid ? 'is-valid' : 'is-invalid');
                }
                
                const existingFeedback = field.parentNode.querySelector('.invalid-feedback, .valid-feedback');
                if (existingFeedback) {
                    existingFeedback.remove();
                }
                
                if (!isValid) {
                    const feedbackDiv = document.createElement('div');
                    feedbackDiv.className = 'invalid-feedback';
                    feedbackDiv.textContent = errorMessage;
                    field.parentNode.appendChild(feedbackDiv);
                } else if (value && isValid) {
                    const feedbackDiv = document.createElement('div');
                    feedbackDiv.className = 'valid-feedback';
                    feedbackDiv.textContent = 'Looks good!';
                    field.parentNode.appendChild(feedbackDiv);
                }
            }
            
            return isValid;
        }

        function validateAllFields() {
            let allValid = true;
            document.querySelectorAll('#contactForm input, #contactForm textarea, #contactForm select').forEach(field => {
                if (field.name !== 'newsletter') {
                    const isValid = validateField(field);
                    if (!isValid) allValid = false;
                }
            });
            return allValid;
        }

        function resetValidationStates() {
            document.querySelectorAll('#contactForm input, #contactForm textarea, #contactForm select').forEach(field => {
                field.classList.remove('is-valid', 'is-invalid');
                const existingFeedback = field.parentNode.querySelector('.invalid-feedback, .valid-feedback');
                if (existingFeedback) {
                    existingFeedback.remove();
                }
            });
        }

        // Mobile menu enhancement
        document.addEventListener('DOMContentLoaded', function() {
            const navbarToggler = document.querySelector('.navbar-toggler');
            const navbarCollapse = document.querySelector('.navbar-collapse');

            if (navbarToggler && navbarCollapse) {
                navbarToggler.addEventListener('click', function() {
                    navbarCollapse.classList.toggle('show');
                });

                document.querySelectorAll('.nav-link').forEach(link => {
                    link.addEventListener('click', () => {
                        if (navbarCollapse.classList.contains('show')) {
                            navbarCollapse.classList.remove('show');
                        }
                    });
                });
            }
        });
    </script>
</body>
</html>