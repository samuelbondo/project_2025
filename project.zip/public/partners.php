<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

// Include necessary files
include '../includes/config.php';
include '../includes/database.php';
include '../includes/auth.php';

// Initialize database
$db = new Database();

// Get active partners from database
try {
    $db->query("SELECT * FROM partners WHERE status = 'active' ORDER BY name ASC");
    $partners = $db->resultSet();
} catch (Exception $e) {
    $partners = [];
    error_log("Partners query error: " . $e->getMessage());
}

// Group partners by type
$partnerTypes = [
    'corporate' => [],
    'educational' => [],
    'community' => [],
    'government' => [],
    'non_profit' => []
];

foreach ($partners as $partner) {
    $type = $partner['partnership_type'] ?? 'corporate';
    if (isset($partnerTypes[$type])) {
        $partnerTypes[$type][] = $partner;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Our Partners - REACH Organization</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body class="reach-theme">
    <!-- Navigation -->
    <?php include '../includes/header.php'; ?>

    <!-- Page Header -->
    <section class="page-header bg-primary text-white py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h1 class="display-4">Our Valued Partners</h1>
                    <p class="lead">Collaborating to create lasting impact in our communities</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Partners Overview -->
    <section class="partners-overview py-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-10 text-center">
                    <h2 class="mb-4">Strategic Collaborations</h2>
                    <p class="lead mb-5">
                        REACH Organization works with diverse partners who share our vision of transforming lives 
                        through education and community development. Together, we create sustainable impact.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <!-- Partners by Type -->
    <section class="partners-by-type py-5 bg-light">
        <div class="container">
            <?php foreach ($partnerTypes as $type => $typePartners): ?>
                <?php if (!empty($typePartners)): ?>
                    <div class="partner-type-section mb-5" data-aos="fade-up">
                        <h3 class="text-center mb-4 text-capitalize">
                            <i class="fas fa-<?php echo getPartnerTypeIcon($type); ?> me-2"></i>
                            <?php echo ucfirst(str_replace('_', ' ', $type)); ?> Partners
                        </h3>
                        
                        <div class="row g-4">
                            <?php foreach ($typePartners as $partner): ?>
                            <div class="col-lg-4 col-md-6">
                                <div class="partner-card card h-100 shadow-sm">
                                    <div class="card-body text-center p-4">
                                        <!-- Partner Logo -->
                                        <?php if (!empty($partner['logo'])): ?>
                                            <div class="partner-logo-container mb-3">
                                                <img src="../assets/uploads/partners/<?php echo $partner['logo']; ?>" 
                                                     alt="<?php echo htmlspecialchars($partner['name']); ?>" 
                                                     class="partner-logo img-fluid"
                                                     style="max-height: 80px; width: auto;">
                                            </div>
                                        <?php else: ?>
                                            <div class="partner-placeholder mb-3">
                                                <i class="fas fa-<?php echo getPartnerTypeIcon($type); ?> fa-3x text-primary"></i>
                                            </div>
                                        <?php endif; ?>
                                        
                                        <!-- Partner Name -->
                                        <h5 class="card-title mb-2"><?php echo htmlspecialchars($partner['name']); ?></h5>
                                        
                                        <!-- Partner Description -->
                                        <?php if (!empty($partner['description'])): ?>
                                            <p class="card-text text-muted small mb-3">
                                                <?php echo htmlspecialchars(truncateText($partner['description'], 120)); ?>
                                            </p>
                                        <?php endif; ?>
                                        
                                        <!-- Partner Actions -->
                                        <div class="partner-actions">
                                            <?php if (!empty($partner['website'])): ?>
                                                <a href="<?php echo $partner['website']; ?>" 
                                                   target="_blank" 
                                                   class="btn btn-outline-primary btn-sm me-2"
                                                   rel="noopener noreferrer">
                                                    <i class="fas fa-external-link-alt me-1"></i>Website
                                                </a>
                                            <?php endif; ?>
                                            
                                            <?php if (!empty($partner['contact_email'])): ?>
                                                <a href="mailto:<?php echo $partner['contact_email']; ?>" 
                                                   class="btn btn-outline-secondary btn-sm">
                                                    <i class="fas fa-envelope me-1"></i>Contact
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                        
                                        <!-- Partnership Info -->
                                        <div class="partner-meta mt-3 pt-3 border-top">
                                            <?php if (!empty($partner['agreement_date'])): ?>
                                                <small class="text-muted">
                                                    <i class="fas fa-calendar me-1"></i>
                                                    Partner since <?php echo date('M Y', strtotime($partner['agreement_date'])); ?>
                                                </small>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; ?>
            
            <!-- No Partners Message -->
            <?php if (empty($partners)): ?>
                <div class="text-center py-5">
                    <i class="fas fa-handshake fa-4x text-muted mb-3"></i>
                    <h4>Partners Information Coming Soon</h4>
                    <p class="text-muted">We're currently updating our partners information. Please check back later.</p>
                    <a href="index.php" class="btn btn-primary">Return to Homepage</a>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- Partnership Call to Action -->
    <section class="cta-section py-5 bg-primary text-white">
        <div class="container">
            <div class="row justify-content-center text-center">
                <div class="col-lg-8">
                    <h3>Interested in Partnering with REACH?</h3>
                    <p class="lead mb-4">Join us in our mission to transform lives through education and community development.</p>
                    <div class="cta-buttons">
                        <a href="contact.php" class="btn btn-light btn-lg me-3">
                            <i class="fas fa-envelope me-2"></i>Contact Us
                        </a>
                        <a href="about.php" class="btn btn-outline-light btn-lg">
                            <i class="fas fa-info-circle me-2"></i>Learn More
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include '../includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    <script>
        // Initialize animations
        AOS.init({
            duration: 1000,
            once: true
        });
    </script>
</body>
</html>

<?php
// Helper function to get icon for partner type
function getPartnerTypeIcon($type) {
    $icons = [
        'corporate' => 'building',
        'educational' => 'graduation-cap',
        'community' => 'users',
        'government' => 'landmark',
        'non_profit' => 'hands-helping'
    ];
    return $icons[$type] ?? 'handshake';
}
?>