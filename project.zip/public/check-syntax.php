<?php
echo "<h3>PHP Syntax Check</h3>";

$file = '../includes/functions.php';
echo "Checking: $file<br>";

// Check if file exists
if (!file_exists($file)) {
    echo "❌ File does not exist<br>";
    exit;
}

// Check file size
$size = filesize($file);
echo "File size: $size bytes<br>";

// Check if file is readable
if (!is_readable($file)) {
    echo "❌ File is not readable<br>";
    exit;
}

// Use PHP lint to check syntax
$output = [];
$return_var = 0;
exec("php -l " . escapeshellarg($file) . " 2>&1", $output, $return_var);

if ($return_var === 0) {
    echo "✅ Syntax is valid<br>";
    foreach ($output as $line) {
        echo htmlspecialchars($line) . "<br>";
    }
} else {
    echo "❌ Syntax error found:<br>";
    foreach ($output as $line) {
        echo htmlspecialchars($line) . "<br>";
    }
}

// Check for BOM (Byte Order Mark)
$content = file_get_contents($file);
if (substr($content, 0, 3) === "\xEF\xBB\xBF") {
    echo "❌ File has BOM (Byte Order Mark) - this can cause issues<br>";
} else {
    echo "✅ No BOM detected<br>";
}
?>