<!DOCTYPE html>
<html lang="en" class="h-100">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>REACH - Recognizing Each Action Can Help | Transforming Lives</title>
    
    <!-- Advanced Meta Tags -->
    <meta name="description" content="REACH Organization provides educational opportunities, housing support, and community development programs to empower deserving students in Africa and beyond.">
    <meta name="keywords" content="REACH, scholarship, education Africa student support, NGO USA, Philip Suah, Hawa Suah">
    <meta name="author" content="REACH Organization">
    
    <!-- Open Graph -->
    <meta property="og:title" content="REACH - Recognizing Each Action Can Help">
    <meta property="og:description" content="Transforming lives through education and community support in Africa">
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://reach.org">
    
    <!-- PWA Meta Tags -->
    <meta name="theme-color" content="#3498db">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    
    <!-- Preload Critical Resources -->
    <link rel="preload" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" as="style">
    <link rel="preload" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" as="style">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    
    <style>
        :root {
            --primary: #3498db;
            --secondary: #2c3e50;
            --success: #27ae60;
            --light: #f8f9fa;
            --reach-accent: #ea4335;
            --reach-warning: #f39c12;
            --gradient-primary: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            --gradient-dark: linear-gradient(135deg, #2980b9 0%, #1c2833 100%);
            --gradient-light: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            --shadow-sm: 0 2px 8px rgba(0,0,0,0.08);
            --shadow-md: 0 8px 30px rgba(0,0,0,0.12);
            --shadow-lg: 0 15px 35px rgba(0,0,0,0.15);
            --border-radius-sm: 12px;
            --border-radius-md: 20px;
            --border-radius-lg: 28px;
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html {
            height: 100%;
            font-size: 16px;
            scroll-behavior: smooth;
        }

        body {
            min-height: 100vh;
            min-height: 100dvh;
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            line-height: 1.6;
            color: var(--secondary);
            overflow-x: hidden;
            padding-top: 80px; /* Add padding for fixed navbar */
        }

        /* Enhanced Navigation */
        .navbar {
            background: rgba(44, 62, 80, 0.95) !important;
            backdrop-filter: blur(20px);
            padding: 1rem 0;
            transition: var(--transition);
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .navbar.scrolled {
            background: rgba(44, 62, 80, 0.98) !important;
            padding: 0.75rem 0;
            box-shadow: var(--shadow-md);
        }

        .brand-content {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .brand-text {
            line-height: 1.2;
        }

        .brand-text strong {
            font-size: 1.4rem;
            font-weight: 700;
            display: block;
            color: white;
        }

        .brand-text small {
            font-size: 0.75rem;
            opacity: 0.8;
            font-weight: 400;
            color: rgba(255,255,255,0.8);
        }

        .navbar-brand i {
            font-size: 1.8rem;
            color: var(--success);
        }

        .nav-link {
            font-weight: 500;
            padding: 0.5rem 1rem !important;
            border-radius: var(--border-radius-sm);
            transition: var(--transition);
            margin: 0.125rem;
            color: rgba(255,255,255,0.9);
        }

        .nav-link:hover,
        .nav-link.active {
            background: rgba(255,255,255,0.1);
            transform: translateY(-1px);
            color: white;
        }

        .dropdown-menu {
            background: rgba(255,255,255,0.95);
            backdrop-filter: blur(20px);
            border: none;
            border-radius: var(--border-radius-sm);
            box-shadow: var(--shadow-lg);
            padding: 0.5rem;
        }

        .dropdown-item {
            border-radius: 8px;
            padding: 0.75rem 1rem;
            transition: var(--transition);
        }

        .dropdown-item:hover {
            background: var(--primary);
            color: white;
            transform: translateX(5px);
        }

        .navbar-actions {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            flex-wrap: wrap;
        }

        .navbar-actions .btn {
            padding: 0.5rem 1.25rem;
            border-radius: var(--border-radius-sm);
            font-weight: 500;
            transition: var(--transition);
            white-space: nowrap;
        }

        /* Enhanced Hero Section - FIXED with your CSS */
        .hero-section {
            background: var(--gradient-primary);
            color: white;
            min-height: 100vh;
            min-height: 100dvh;
            display: flex;
            align-items: center;
            position: relative;
            overflow: hidden;
            padding: 100px 0;
            margin-top: -80px; /* Compensate for body padding */
        }

        .hero-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 800" opacity="0.1"><polygon fill="white" points="0,800 1200,400 1200,800"/></svg>');
            background-size: cover;
            animation: float 20s ease-in-out infinite;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0px) rotate(0deg); }
            50% { transform: translateY(-20px) rotate(1deg); }
        }

        .hero-content {
            position: relative;
            z-index: 2;
        }

        /* FIXED HERO TITLE - Full visibility on all screens */
        .hero-title {
            font-size: clamp(2.5rem, 6vw, 4rem);
            font-weight: 800;
            line-height: 1.1;
            margin-bottom: 1.5rem;
            color: white;
            text-shadow: 0 2px 15px rgba(0,0,0,0.3);
        }

        .hero-title .highlight {
            color: #ffd700;
            display: inline-block;
            text-shadow: 0 2px 10px rgba(0,0,0,0.4);
        }

        .hero-description {
            font-size: clamp(1.1rem, 2.5vw, 1.3rem);
            margin-bottom: 2.5rem;
            opacity: 0.95;
            max-width: 600px;
            line-height: 1.6;
            margin-left: auto;
            margin-right: auto;
            text-shadow: 0 1px 5px rgba(0,0,0,0.2);
        }

        .hero-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2.5rem;
        }

        .stat-item {
            text-align: center;
            padding: 1rem;
            background: rgba(255,255,255,0.1);
            backdrop-filter: blur(10px);
            border-radius: var(--border-radius-sm);
            border: 1px solid rgba(255,255,255,0.2);
            transition: var(--transition);
        }

        .stat-item:hover {
            transform: translateY(-5px);
            background: rgba(255,255,255,0.15);
        }

        .stat-item h3 {
            font-size: clamp(1.8rem, 4vw, 2.5rem);
            font-weight: 700;
            margin-bottom: 0.5rem;
            color: var(--reach-warning);
        }

        .stat-item p {
            font-size: 0.9rem;
            opacity: 0.9;
            margin: 0;
        }

        .hero-actions {
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
            justify-content: center;
        }

        .btn-hero {
            padding: 1rem 2rem;
            border-radius: var(--border-radius-sm);
            font-weight: 600;
            font-size: 1.1rem;
            transition: var(--transition);
            border: 2px solid transparent;
            position: relative;
            overflow: hidden;
        }

        .btn-hero::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
            transition: left 0.5s;
        }

        .btn-hero:hover::before {
            left: 100%;
        }

        .btn-hero-primary {
            background: white;
            color: var(--primary);
        }

        .btn-hero-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
        }

        .btn-hero-outline {
            border-color: white;
            color: white;
            background: transparent;
        }

        .btn-hero-outline:hover {
            background: white;
            color: var(--primary);
            transform: translateY(-2px);
        }

        .pulse-animation {
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0% { box-shadow: 0 0 0 0 rgba(255,255,255,0.4); }
            70% { box-shadow: 0 0 0 15px rgba(255,255,255,0); }
            100% { box-shadow: 0 0 0 0 rgba(255,255,255,0); }
        }

        /* Section Styles */
        .section {
            padding: 80px 0;
        }

        .min-vh-80 {
            min-height: 80vh;
        }

        .section-title {
            font-size: 2.5rem;
            font-weight: bold;
            color: var(--secondary);
        }

        .section-subtitle {
            font-size: 1.2rem;
            color: #6c757d;
        }

        /* Program Cards */
        .program-card {
            padding: 2rem 1rem;
            border-radius: 10px;
            transition: transform 0.3s, box-shadow 0.3s;
            border: 1px solid #e9ecef;
            height: 100%;
        }

        .program-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }

        .program-icon {
            width: 80px;
            height: 80px;
            background: var(--primary);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1rem;
            color: white;
            font-size: 2rem;
        }

        /* Stats */
        .stat-number {
            font-size: 3rem;
            font-weight: bold;
            color: var(--primary);
            margin-bottom: 0.5rem;
        }

        .stat-label {
            font-size: 1.1rem;
            color: var(--secondary);
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        /* Buttons */
        .btn-primary {
            background: var(--primary);
            border-color: var(--primary);
            padding: 0.75rem 2rem;
        }

        .btn-primary:hover {
            background: #2980b9;
            border-color: #2980b9;
        }

        /* Enhanced Story Cards */
        .featured-stories-section {
            padding: clamp(4rem, 8vw, 6rem) 0;
            background: var(--light);
        }

        .story-card {
            background: white;
            border-radius: var(--border-radius-md);
            overflow: hidden;
            box-shadow: var(--shadow-sm);
            transition: var(--transition);
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        .story-card:hover {
            transform: translateY(-10px);
            box-shadow: var(--shadow-lg);
        }

        .story-image {
            position: relative;
            overflow: hidden;
            aspect-ratio: 16/9;
        }

        .story-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: var(--transition);
        }

        .story-card:hover .story-image img {
            transform: scale(1.05);
        }

        .story-overlay {
            position: absolute;
            top: 1rem;
            left: 1rem;
            right: 1rem;
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
        }

        .story-type-badge .badge {
            font-size: 0.75rem;
            padding: 0.5rem 0.75rem;
            border-radius: 20px;
            background: var(--primary);
        }

        .story-content {
            padding: 1.5rem;
            flex: 1;
            display: flex;
            flex-direction: column;
        }

        .story-meta {
            display: flex;
            justify-content: between;
            align-items: center;
            margin-bottom: 1rem;
        }

        .author-info {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .author-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #f8f9fa;
        }

        .author-name {
            font-weight: 500;
            font-size: 0.9rem;
        }

        .story-stats {
            font-size: 0.85rem;
        }

        .story-title {
            font-size: 1.25rem;
            font-weight: 600;
            margin-bottom: 1rem;
            line-height: 1.4;
        }

        .story-title a {
            color: inherit;
            text-decoration: none;
            transition: var(--transition);
        }

        .story-title a:hover {
            color: var(--primary);
        }

        .story-excerpt {
            color: #6c757d;
            margin-bottom: 1.5rem;
            flex: 1;
        }

        .story-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 1rem;
        }

        .story-actions {
            display: flex;
            gap: 0.5rem;
        }

        .story-actions .btn {
            padding: 0.5rem;
            border-radius: 8px;
            font-size: 0.8rem;
        }

        /* Enhanced Projects Section */
        .featured-projects-section {
            padding: clamp(4rem, 8vw, 6rem) 0;
        }

        .project-card {
            background: white;
            border-radius: var(--border-radius-md);
            overflow: hidden;
            box-shadow: var(--shadow-sm);
            transition: var(--transition);
            height: 100%;
        }

        .project-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-md);
        }

        .project-image {
            position: relative;
            aspect-ratio: 16/9;
            overflow: hidden;
        }

        .project-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: var(--transition);
        }

        .project-card:hover .project-image img {
            transform: scale(1.05);
        }

        .project-status {
            position: absolute;
            top: 1rem;
            right: 1rem;
        }

        .project-content {
            padding: 1.5rem;
        }

        .project-title {
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 1rem;
        }

        .project-title a {
            color: inherit;
            text-decoration: none;
            transition: var(--transition);
        }

        .project-title a:hover {
            color: var(--primary);
        }

        .project-description {
            color: #6c757d;
            margin-bottom: 1.5rem;
            line-height: 1.5;
        }

        .project-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            font-size: 0.9rem;
            color: #6c757d;
        }

        .project-footer {
            text-align: center;
        }

        /* Impact Section */
        .impact-section {
            padding: clamp(4rem, 8vw, 6rem) 0;
            background: var(--gradient-light);
            color: white;
        }

        .impact-stats-interactive {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 2rem;
            margin-top: 2rem;
        }

        .impact-stat {
            text-align: center;
            padding: 2rem 1rem;
            background: rgba(255,255,255,0.1);
            backdrop-filter: blur(10px);
            border-radius: var(--border-radius-md);
            border: 1px solid rgba(255,255,255,0.2);
            transition: var(--transition);
        }

        .impact-stat:hover {
            transform: translateY(-5px);
            background: rgba(255,255,255,0.15);
        }

        .impact-stat h3 {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            color: var(--reach-warning);
        }

        /* Newsletter Section */
        .newsletter-section {
            padding: clamp(3rem, 6vw, 4rem) 0;
        }

        .newsletter-form .input-group {
            background: rgba(255,255,255,0.1);
            backdrop-filter: blur(10px);
            border-radius: var(--border-radius-sm);
            padding: 0.5rem;
            border: 1px solid rgba(255,255,255,0.2);
        }

        .newsletter-form .form-control {
            background: transparent;
            border: none;
            color: white;
            padding: 1rem;
        }

        .newsletter-form .form-control::placeholder {
            color: rgba(255,255,255,0.7);
        }

        .newsletter-form .form-control:focus {
            background: rgba(255,255,255,0.1);
            color: white;
            box-shadow: none;
        }

        /* Footer */
        footer {
            background: var(--secondary);
            color: white;
            padding: 3rem 0 1rem;
        }

        .footer-links a {
            color: #bdc3c7;
            text-decoration: none;
            transition: color 0.3s;
        }

        .footer-links a:hover {
            color: white;
        }

        /* Ultra-Responsive Design */
        @media (max-width: 768px) {
            .navbar-actions {
                justify-content: center;
                margin-top: 1rem;
                width: 100%;
            }

            .navbar-actions .btn {
                flex: 1;
                min-width: 120px;
                text-align: center;
            }

            .hero-stats {
                grid-template-columns: repeat(2, 1fr);
                gap: 1rem;
            }

            .hero-actions {
                flex-direction: column;
                align-items: center;
            }

            .hero-actions .btn {
                width: 100%;
                max-width: 280px;
            }

            .story-footer {
                flex-direction: column;
                gap: 1rem;
            }

            .story-actions {
                justify-content: center;
            }

            .impact-stats-interactive {
                grid-template-columns: repeat(2, 1fr);
                gap: 1rem;
            }
        }

        @media (max-width: 576px) {
            .brand-text strong {
                font-size: 1.2rem;
            }

            .brand-text small {
                font-size: 0.7rem;
            }

            .hero-stats {
                grid-template-columns: 1fr;
            }

            .stat-item {
                padding: 1.5rem 1rem;
            }

            .impact-stats-interactive {
                grid-template-columns: 1fr;
            }

            .newsletter-form .input-group {
                flex-direction: column;
                gap: 0.5rem;
            }

            .newsletter-form .btn {
                width: 100%;
            }
        }

        @media (max-width: 360px) {
            .navbar-brand {
                font-size: 0.9rem;
            }

            .hero-title {
                font-size: 2rem;
            }

            .section-title {
                font-size: 1.5rem;
            }
        }

        /* Reduced motion support */
        @media (prefers-reduced-motion: reduce) {
            * {
                animation-duration: 0.01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: 0.01ms !important;
            }
        }

        /* Dark mode support */
        @media (prefers-color-scheme: dark) {
            .featured-stories-section,
            .featured-projects-section {
                background: #1a1d23;
            }

            .story-card,
            .project-card {
                background: #2d3748;
                color: #e2e8f0;
            }

            .story-excerpt,
            .project-description {
                color: #a0aec0;
            }
        }

        /* Focus styles for accessibility */
        .btn:focus,
        .nav-link:focus,
        .form-control:focus {
            outline: 2px solid var(--primary);
            outline-offset: 2px;
        }
    </style>
</head>
<body class="h-100">
    <!-- Enhanced Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <div class="brand-content">
                    <i class="fas fa-hands-helping"></i>
                    <div class="brand-text">
                        <strong>REACH</strong>
                        <small>Recognizing Each Action Can Help</small>
                    </div>
                </div>
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMain"
                    aria-controls="navbarMain" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarMain">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item"><a class="nav-link active" href="index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="about.php">About</a></li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Programs
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="programs.php#scholarships">Scholarships</a></li>
                            <li><a class="dropdown-item" href="programs.php#housing">Student Housing</a></li>
                            <li><a class="dropdown-item" href="programs.php#community">Community Projects</a></li>
                        </ul>
                    </li>
                    <li class="nav-item"><a class="nav-link" href="stories.php">Stories</a></li>
                    <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
                </ul>
                
                <div class="navbar-actions">
                    <a href="apply.php" class="btn btn-outline-light">
                        <i class="fas fa-edit me-1"></i>Apply
                    </a>
                    <a href="donate.php" class="btn btn-warning">
                        <i class="fas fa-heart me-1"></i>Donate
                    </a>
                    <a href="login.php" class="btn btn-outline-light">
                        <i class="fas fa-sign-in-alt me-1"></i>Login
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- FIXED Hero Section -->
    <section class="hero-section">
        <div class="container">
            <div class="row align-items-center min-vh-100">
                <div class="col-lg-8 mx-auto text-center">
                    <div class="hero-content">
                        <h1 class="hero-title">
                            Recognizing Each <span class="highlight"> Action </span> Can Help
                        </h1>
                        <p class="hero-description">
                            REACH Organization provides educational opportunities, housing support, 
                            and community development programs to empower deserving individuals 
                            and create lasting positive change in Africa and beyond.
                        </p>
                        
                        <div class="hero-stats">
                            <div class="stat-item">
                                <h3>40+</h3>
                                <p>Students Supported</p>
                            </div>
                            <div class="stat-item">
                                <h3>15</h3>
                                <p>Active Programs</p>
                            </div>
                            <div class="stat-item">
                                <h3>95%</h3>
                                <p>Success Rate</p>
                            </div>
                            <div class="stat-item">
                                <h3>100+</h3>
                                <p>Success Stories</p>
                            </div>
                        </div>
                        
                        <div class="hero-actions">
                            <a href="apply.php" class="btn btn-hero btn-hero-primary pulse-animation">
                                <i class="fas fa-rocket me-2"></i>Apply for Support
                            </a>
                            <a href="about.php" class="btn btn-hero btn-hero-outline">
                                <i class="fas fa-info-circle me-2"></i>Learn More
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Featured Stories Section -->
    <section class="featured-stories-section section">
        <div class="container">
            <div class="section-header text-center">
                <h2 class="section-title">Inspiring Success Stories</h2>
                <p class="section-subtitle">Discover how REACH is transforming lives</p>
            </div>
            
            <div class="row g-4">
                <div class="col-lg-4 col-md-6">
                    <article class="story-card">
                        <div class="story-image">
                            <img src="https://placehold.co/600x400/3498db/ffffff?text=Student+Success" 
                                 alt="Student Success Story"
                                 loading="lazy">
                            <div class="story-overlay">
                                <div class="story-type-badge">
                                    <span class="badge">Success Story</span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="story-content">
                            <div class="story-meta">
                                <div class="author-info">
                                    <img src="https://placehold.co/40x40/3498db/ffffff?text=PS" 
                                         alt="Philip Suah"
                                         class="author-avatar" loading="lazy">
                                    <span class="author-name">Philip Suah</span>
                                </div>
                            </div>
                            
                            <h3 class="story-title">
                                <a href="stories.php?type=student">
                                    From Rural Village to University Graduate
                                </a>
                            </h3>
                            
                            <p class="story-excerpt">
                                How REACH helped me overcome financial barriers and achieve my dream of becoming a software engineer...
                            </p>
                            
                            <div class="story-footer">
                                <a href="stories.php?type=student" class="btn btn-primary btn-sm">
                                    Read More <i class="fas fa-arrow-right ms-1"></i>
                                </a>
                            </div>
                        </div>
                    </article>
                </div>
                
                <div class="col-lg-4 col-md-6">
                    <article class="story-card">
                        <div class="story-image">
                            <img src="https://placehold.co/600x400/2c3e50/ffffff?text=Community+Impact" 
                                 alt="Community Impact Story"
                                 loading="lazy">
                            <div class="story-overlay">
                                <div class="story-type-badge">
                                    <span class="badge">Community</span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="story-content">
                            <div class="story-meta">
                                <div class="author-info">
                                    <img src="https://placehold.co/40x40/2c3e50/ffffff?text=HS" 
                                         alt="Hawa Suah"
                                         class="author-avatar" loading="lazy">
                                    <span class="author-name">Hawa Suah</span>
                                </div>
                            </div>
                            
                            <h3 class="story-title">
                                <a href="stories.php?type=community">
                                    Building a Brighter Future Together
                                </a>
                            </h3>
                            
                            <p class="story-excerpt">
                                Our community's transformation through REACH's educational programs and infrastructure development...
                            </p>
                            
                            <div class="story-footer">
                                <a href="stories.php?type=community" class="btn btn-primary btn-sm">
                                    Read More <i class="fas fa-arrow-right ms-1"></i>
                                </a>
                            </div>
                        </div>
                    </article>
                </div>
                
                <div class="col-lg-4 col-md-6">
                    <article class="story-card">
                        <div class="story-image">
                            <img src="https://placehold.co/600x400/27ae60/ffffff?text=Education+Matters" 
                                 alt="Education Story"
                                 loading="lazy">
                            <div class="story-overlay">
                                <div class="story-type-badge">
                                    <span class="badge">Education</span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="story-content">
                            <div class="story-meta">
                                <div class="author-info">
                                    <img src="https://placehold.co/40x40/27ae60/ffffff?text=PS" 
                                         alt="Philip Suah"
                                         class="author-avatar" loading="lazy">
                                    <span class="author-name">Philip Suah</span>
                                </div>
                            </div>
                            
                            <h3 class="story-title">
                                <a href="stories.php?type=achievement">
                                    The Power of Education in Transforming Lives
                                </a>
                            </h3>
                            
                            <p class="story-excerpt">
                                How access to quality education through REACH changed not just my life, but my entire family's future...
                            </p>
                            
                            <div class="story-footer">
                                <a href="stories.php?type=achievement" class="btn btn-primary btn-sm">
                                    Read More <i class="fas fa-arrow-right ms-1"></i>
                                </a>
                            </div>
                        </div>
                    </article>
                </div>
            </div>

            <div class="text-center mt-4">
                <a href="stories.php" class="btn btn-outline-primary">
                    View All Stories <i class="fas fa-arrow-right ms-2"></i>
                </a>
            </div>
        </div>
    </section>

    <!-- Programs Section -->
    <section class="section bg-light">
        <div class="container">
            <div class="section-header text-center">
                <h2 class="section-title">Our Programs</h2>
                <p class="section-subtitle">Comprehensive support for students and communities</p>
            </div>
            
            <div class="row g-4">
                <div class="col-lg-4 col-md-6">
                    <div class="program-card text-center">
                        <div class="program-icon">
                            <i class="fas fa-graduation-cap"></i>
                        </div>
                        <h3>Scholarships</h3>
                        <p>Full and partial scholarships for deserving students to pursue higher education and vocational training.</p>
                        <a href="programs.php#scholarships" class="btn btn-primary mt-3">Learn More</a>
                    </div>
                </div>
                
                <div class="col-lg-4 col-md-6">
                    <div class="program-card text-center">
                        <div class="program-icon">
                            <i class="fas fa-home"></i>
                        </div>
                        <h3>Student Housing</h3>
                        <p>Safe and affordable accommodation for students from rural areas pursuing education in urban centers.</p>
                        <a href="programs.php#housing" class="btn btn-primary mt-3">Learn More</a>
                    </div>
                </div>
                
                <div class="col-lg-4 col-md-6">
                    <div class="program-card text-center">
                        <div class="program-icon">
                            <i class="fas fa-hands-helping"></i>
                        </div>
                        <h3>Community Projects</h3>
                        <p>Development initiatives that benefit entire communities while providing practical experience for students.</p>
                        <a href="programs.php#community" class="btn btn-primary mt-3">Learn More</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Call to Action Section -->
    <section class="impact-section">
        <div class="container text-center">
            <h2 class="section-title text-white">Ready to Make a Difference?</h2>
            <p class="lead text-white mb-4">Join REACH Organization today and be part of the transformative change</p>
            <div class="hero-actions justify-content-center">
                <a href="apply.php" class="btn btn-hero btn-hero-primary">
                    <i class="fas fa-user-graduate me-2"></i>Apply Now
                </a>
                <a href="donate.php" class="btn btn-hero btn-hero-outline">
                    <i class="fas fa-hand-holding-heart me-2"></i>Support Our Mission
                </a>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-4 mb-4">
                    <h5>REACH Organization</h5>
                    <p>Recognizing Each Action Can Help</p>
                    <div class="mt-3">
                        <a href="#" class="text-white me-3"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="text-white"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>
                <div class="col-lg-4 mb-4">
                    <h5>Quick Links</h5>
                    <div class="footer-links">
                        <div class="row">
                            <div class="col-6">
                                <a href="about.php">About Us</a><br>
                                <a href="programs.php">Programs</a><br>
                                <a href="stories.php">Success Stories</a>
                            </div>
                            <div class="col-6">
                                <a href="apply.php">Apply</a><br>
                                <a href="donate.php">Donate</a><br>
                                <a href="contact.php">Contact</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 mb-4">
                    <h5>Contact Info</h5>
                    <p><i class="fas fa-map-marker-alt me-2"></i> NY, USA</p>
                    <p><i class="fas fa-phone me-2"></i> +1 788 123 123</p>
                    <p><i class="fas fa-envelope me-2"></i> info@reach.org</p>
                </div>
            </div>
            <hr class="my-4">
            <div class="text-center">
                <p>&copy; 2024 REACH Organization. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Error debugging
        console.log("Page loaded successfully");
        
        // Navbar scroll effect
        window.addEventListener('scroll', function() {
            const navbar = document.getElementById('mainNav');
            if (window.scrollY > 100) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });

        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });

        // Mobile menu enhancement
        document.addEventListener('DOMContentLoaded', function() {
            const navbarToggler = document.querySelector('.navbar-toggler');
            const navbarCollapse = document.querySelector('.navbar-collapse');

            if (navbarToggler && navbarCollapse) {
                navbarToggler.addEventListener('click', function() {
                    navbarCollapse.classList.toggle('show');
                });

                // Close mobile menu when clicking on a link
                document.querySelectorAll('.nav-link').forEach(link => {
                    link.addEventListener('click', () => {
                        if (navbarCollapse.classList.contains('show')) {
                            navbarCollapse.classList.remove('show');
                        }
                    });
                });
            } else {
                console.error("Navbar elements not found");
            }
        });

        // Add loading state to buttons
        document.querySelectorAll('.btn').forEach(button => {
            button.addEventListener('click', function(e) {
                if (this.href && !this.href.startsWith('javascript')) {
                    this.classList.add('loading');
                    const originalText = this.innerHTML;
                    this.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Loading...';
                    
                    // Reset after 2 seconds for demo purposes
                    setTimeout(() => {
                        this.classList.remove('loading');
                        this.innerHTML = originalText;
                    }, 2000);
                }
            });
        });

        // Check if all images loaded properly
        window.addEventListener('load', function() {
            const images = document.querySelectorAll('img');
            images.forEach(img => {
                if (!img.complete || img.naturalHeight === 0) {
                    console.warn('Image failed to load:', img.src);
                    img.alt = 'Image not available';
                }
            });
            console.log('All page resources loaded');
        });
    </script>
</body>
</html>