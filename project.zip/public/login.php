<?php
// Enable comprehensive error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', '../logs/php_errors.log');

session_start();

// Define constant to allow config.php inclusion
define('INCLUDE_GUARD', true);

// Debug function to log variables
function debug_log($message, $data = null) {
    $log_message = "[" . date('Y-m-d H:i:s') . "] " . $message;
    if ($data !== null) {
        $log_message .= " - " . (is_array($data) ? json_encode($data) : $data);
    }
    $log_message .= "\n";
    
    $log_dir = __DIR__ . '/../logs/';
    if (!is_dir($log_dir)) {
        mkdir($log_dir, 0755, true);
    }
    
    file_put_contents($log_dir . 'debug.log', $log_message, FILE_APPEND | LOCK_EX);
}

// Debug function to display errors in development
function debug_display($data, $label = 'Debug') {
    if (isset($_GET['debug']) && $_GET['debug'] === '1') {
        echo "<div style='background: #f8d7da; border: 1px solid #f5c6cb; padding: 10px; margin: 10px 0; border-radius: 5px;'>";
        echo "<strong>{$label}:</strong><br>";
        echo "<pre style='background: white; padding: 10px; border-radius: 3px; overflow: auto;'>";
        var_dump($data);
        echo "</pre>";
        echo "</div>";
    }
}

try {
    debug_log("Login page accessed", [
        'session_id' => session_id(),
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown',
        'ip' => $_SERVER['REMOTE_ADDR'] ?? 'Unknown'
    ]);

    // Include configuration files with error handling
    $config_file = '../includes/config.php';
    $database_file = '../includes/database.php';
    
    if (!file_exists($config_file)) {
        throw new Exception("Configuration file not found: " . $config_file);
    }
    
    if (!file_exists($database_file)) {
        throw new Exception("Database file not found: " . $database_file);
    }
    
    require_once $config_file;
    require_once $database_file;
    
    debug_log("Configuration files loaded successfully");

    // Check if database connection is established
    if (!isset($pdo) || !$pdo) {
        throw new Exception("Database connection failed. PDO object not available.");
    }
    
    // Test database connection
    try {
        $pdo->query("SELECT 1");
        debug_log("Database connection test successful");
    } catch (PDOException $e) {
        throw new Exception("Database connection test failed: " . $e->getMessage());
    }

} catch (Exception $e) {
    $critical_error = $e->getMessage();
    debug_log("Critical error during initialization", $critical_error);
    error_log("Login Page Critical Error: " . $e->getMessage());
}

// Get available programs for display
$programs = [];
try {
    $stmt = $pdo->query("
        SELECT name, type, description 
        FROM programs 
        WHERE status = 'active' 
        ORDER BY name
    ");
    $programs = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    // Fallback programs if database query fails
    $programs = [
        ['name' => 'Education Scholarship', 'type' => 'scholarship', 'description' => 'Full tuition coverage'],
        ['name' => 'Student Housing', 'type' => 'housing', 'description' => 'Safe accommodation'],
        ['name' => 'Community Program', 'type' => 'community', 'description' => 'Skills training'],
        ['name' => 'Mentorship Program', 'type' => 'mentorship', 'description' => 'Career guidance']
    ];
    error_log("Programs loading error: " . $e->getMessage());
}

// Simple sanitize function to avoid conflicts
function cleanInput($data) {
    if ($data === null) return '';
    return htmlspecialchars(strip_tags(trim($data)), ENT_QUOTES, 'UTF-8');
}

// Function to get dashboard URL (enhanced version)
if (!function_exists('getDashboardUrl')) {
    function getDashboardUrl($role) {
        $dashboards = [
            'super_admin' => '../admin/dashboard.php',
            'admin' => '../admin/dashboard.php',
            'staff' => '../staff/dashboard.php',
            'student' => '../student/dashboard.php',
            'sponsor' => '../sponsor/dashboard.php',
            'partner' => '../partner/dashboard.php',
            'reviewer' => '../reviewer/dashboard.php',
            'volunteer' => '../volunteer/dashboard.php'
        ];
        
        // Default fallback
        return $dashboards[$role] ?? '../student/dashboard.php';
    }
}

// Redirect if already logged in
if (isset($_SESSION['user_id']) && isset($_SESSION['role'])) {
    debug_log("User already logged in, redirecting to dashboard", [
        'user_id' => $_SESSION['user_id'],
        'role' => $_SESSION['role']
    ]);
    
    try {
        $redirect_url = getDashboardUrl($_SESSION['role']);
        header('Location: ' . $redirect_url);
        exit;
    } catch (Exception $e) {
        debug_log("Redirect failed", $e->getMessage());
        // Continue with login page if redirect fails
    }
}

// Handle login form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    debug_log("Login form submitted", [
        'username' => $_POST['username'] ?? 'Not provided',
        'has_password' => !empty($_POST['password']),
        'post_data' => array_keys($_POST)
    ]);

    $username = cleanInput($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $remember = isset($_POST['remember']);
    
    // Validate input
    if (empty($username) || empty($password)) {
        $error = "Username and password are required";
        debug_log("Login validation failed - empty fields");
    } else {
        try {
            // Check if users table exists
            $table_check = $pdo->query("SHOW TABLES LIKE 'users'");
            if ($table_check->rowCount() === 0) {
                throw new Exception("Users table does not exist. Please run database setup.");
            }
            
            // Find user by username or email
            $stmt = $pdo->prepare("SELECT * FROM users WHERE (username = ? OR email = ?) AND (status = 'active' OR status IS NULL)");
            $stmt->execute([$username, $username]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            debug_log("User query executed", [
                'username_provided' => $username,
                'user_found' => $user ? 'Yes' : 'No',
                'user_data' => $user ? ['id' => $user['id'], 'username' => $user['username'], 'role' => $user['role']] : 'No user found'
            ]);

            if (!$user) {
                throw new Exception("Invalid username or password");
            }
            
            // Debug password verification
            debug_log("Password verification", [
                'password_provided_length' => strlen($password),
                'stored_hash' => $user['password'] ? 'Set' : 'Not set',
                'stored_hash_length' => $user['password'] ? strlen($user['password']) : 0
            ]);

            // Verify password
            if (!password_verify($password, $user['password'])) {
                // Check if it's the default password for development
                $default_passwords = ['password', '123456', 'admin'];
                $is_default_password = in_array($password, $default_passwords);
                
                if ($is_default_password && password_verify('password', $user['password'])) {
                    debug_log("Using default password for development");
                    // Allow login with default password in development
                } else {
                    throw new Exception("Invalid username or password");
                }
            }
            
            // Update last login
            $updateStmt = $pdo->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
            $updateStmt->execute([$user['id']]);
            
            debug_log("Last login updated for user", $user['id']);

            // Set session variables
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['profile_picture'] = $user['profile_picture'];
            $_SESSION['program_interest'] = $user['program_interest'] ?? '';
            $_SESSION['logged_in'] = true;
            $_SESSION['login_time'] = time();
            
            // Set remember me cookie if requested
            if ($remember) {
                $token = bin2hex(random_bytes(32));
                $expiry = time() + (30 * 24 * 60 * 60); // 30 days
                setcookie('remember_token', $token, $expiry, '/', '', true, true);
                
                // Store token in database (create table if needed)
                try {
                    $tokenStmt = $pdo->prepare("INSERT INTO user_tokens (user_id, token, expires_at) VALUES (?, ?, FROM_UNIXTIME(?))");
                    $tokenStmt->execute([$user['id'], $token, $expiry]);
                } catch (Exception $e) {
                    // Log but continue if token storage fails
                    error_log("Token storage failed: " . $e->getMessage());
                }
                
                debug_log("Remember me token set", $token);
            }

            debug_log("Login successful", [
                'user_id' => $user['id'],
                'username' => $user['username'],
                'role' => $user['role'],
                'program_interest' => $user['program_interest'] ?? 'None'
            ]);

            // Redirect based on role
            $redirect = getDashboardUrl($user['role']);
            debug_log("Redirecting to", $redirect);
            
            header('Location: ' . $redirect);
            exit;
            
        } catch (Exception $e) {
            $error = $e->getMessage();
            debug_log("Login failed", $error);
            error_log("Login Error: " . $e->getMessage());
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - REACH Organization | Transforming Lives</title>
    
    <!-- Advanced Meta Tags -->
    <meta name="description" content="Login to your REACH Organization account to access scholarships, housing applications, and community programs in Rwanda.">
    <meta name="keywords" content="REACH login, student portal, scholarship application, Rwanda education, REACH organization">
    <meta name="author" content="REACH Organization">
    
    <!-- Open Graph -->
    <meta property="og:title" content="Login - REACH Organization">
    <meta property="og:description" content="Access your REACH Organization account to continue your educational journey">
    <meta property="og:type" content="website">
    
    <!-- PWA Meta Tags -->
    <meta name="theme-color" content="#3498db">
    <meta name="apple-mobile-web-app-capable" content="yes">
    
    <!-- Preload Critical Resources -->
    <link rel="preload" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" as="style">
    <link rel="preload" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" as="style">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    
    <style>
        :root {
            --primary: #3498db;
            --secondary: #2c3e50;
            --success: #27ae60;
            --light: #f8f9fa;
            --reach-accent: #ea4335;
            --reach-warning: #f39c12;
            --gradient-primary: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            --shadow-sm: 0 2px 8px rgba(0,0,0,0.08);
            --shadow-md: 0 8px 30px rgba(0,0,0,0.12);
            --shadow-lg: 0 15px 35px rgba(0,0,0,0.15);
            --border-radius-sm: 12px;
            --border-radius-md: 20px;
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            line-height: 1.6;
            color: var(--secondary);
            background: var(--light);
            min-height: 100vh;
            display: flex;
            align-items: center;
            background: var(--gradient-primary);
            position: relative;
            overflow-x: hidden;
        }

        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 800" opacity="0.05"><polygon fill="white" points="0,800 1200,400 1200,800"/></svg>');
            background-size: cover;
            animation: float 20s ease-in-out infinite;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0px) rotate(0deg); }
            50% { transform: translateY(-20px) rotate(1deg); }
        }

        .auth-container {
            width: 100%;
            max-width: 450px;
            margin: 2rem auto;
            padding: 1rem;
            position: relative;
            z-index: 2;
        }

        .auth-card {
            background: white;
            border-radius: var(--border-radius-md);
            box-shadow: var(--shadow-lg);
            overflow: hidden;
            transition: var(--transition);
        }

        .auth-card:hover {
            box-shadow: 0 20px 40px rgba(0,0,0,0.2);
            transform: translateY(-5px);
        }

        .auth-header {
            background: var(--gradient-primary);
            color: white;
            padding: 2.5rem 2rem;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .auth-header::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            right: -50%;
            bottom: -50%;
            background: linear-gradient(45deg, transparent, rgba(255,255,255,0.1), transparent);
            animation: shimmer 3s infinite;
        }

        @keyframes shimmer {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(100%); }
        }

        .auth-icon {
            font-size: 3rem;
            margin-bottom: 1rem;
            display: block;
            color: rgba(255,255,255,0.9);
        }

        .auth-header h3 {
            font-size: 1.75rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            color: white;
        }

        .auth-header p {
            opacity: 0.9;
            font-size: 1rem;
        }

        .auth-body {
            padding: 2.5rem 2rem;
        }

        .auth-footer {
            background: #f8f9fa;
            padding: 1.5rem 2rem;
            text-align: center;
            border-top: 1px solid #e9ecef;
        }

        /* Form Styles */
        .form-label {
            font-weight: 600;
            color: var(--secondary);
            margin-bottom: 0.5rem;
            font-size: 0.95rem;
        }

        .form-control {
            border-radius: var(--border-radius-sm);
            border: 2px solid #e9ecef;
            padding: 0.75rem 1rem;
            transition: var(--transition);
            font-size: 1rem;
        }

        .form-control:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.2rem rgba(52, 152, 219, 0.25);
        }

        .input-group-text {
            background: #f8f9fa;
            border: 2px solid #e9ecef;
            border-right: none;
            border-radius: var(--border-radius-sm) 0 0 var(--border-radius-sm);
        }

        .input-group .form-control {
            border-left: none;
            border-radius: 0 var(--border-radius-sm) var(--border-radius-sm) 0;
        }

        /* Button Styles */
        .btn {
            border-radius: var(--border-radius-sm);
            font-weight: 500;
            transition: var(--transition);
            border: 2px solid transparent;
            padding: 0.75rem 1.5rem;
            font-size: 1rem;
        }

        .btn-reach {
            background: var(--primary);
            border-color: var(--primary);
            color: white;
            width: 100%;
        }

        .btn-reach:hover {
            background: #2980b9;
            border-color: #2980b9;
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
        }

        .btn-outline-secondary {
            border-color: #6c757d;
            color: #6c757d;
        }

        .btn-outline-secondary:hover {
            background: #6c757d;
            color: white;
            transform: translateY(-2px);
        }

        /* Alert Styles */
        .alert {
            border-radius: var(--border-radius-sm);
            border: none;
            padding: 1rem 1.25rem;
            margin-bottom: 1.5rem;
        }

        .alert-danger {
            background: rgba(220, 53, 69, 0.1);
            color: #dc3545;
            border-left: 4px solid #dc3545;
        }

        .alert-warning {
            background: rgba(255, 193, 7, 0.1);
            color: #856404;
            border-left: 4px solid #ffc107;
        }

        .alert-success {
            background: rgba(40, 167, 69, 0.1);
            color: #155724;
            border-left: 4px solid #28a745;
        }

        /* Program Context */
        .program-context {
            background: #f8f9fa;
            border-radius: var(--border-radius-sm);
            padding: 1.5rem;
            margin-top: 1.5rem;
            border-left: 4px solid var(--primary);
        }

        .program-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 0.75rem;
            margin-top: 1rem;
        }

        .program-item {
            background: white;
            border: 1px solid #e9ecef;
            border-radius: var(--border-radius-sm);
            padding: 1rem;
            text-align: center;
            transition: var(--transition);
        }

        .program-item:hover {
            border-color: var(--primary);
            transform: translateY(-2px);
        }

        .program-icon {
            font-size: 1.5rem;
            margin-bottom: 0.5rem;
        }

        .program-name {
            font-size: 0.875rem;
            font-weight: 600;
            color: var(--secondary);
            margin-bottom: 0.25rem;
        }

        .program-desc {
            font-size: 0.75rem;
            color: #6c757d;
        }

        /* Toggle Password */
        .toggle-password {
            background: #f8f9fa;
            border: 2px solid #e9ecef;
            border-left: none;
            border-radius: 0 var(--border-radius-sm) var(--border-radius-sm) 0;
            padding: 0.75rem 1rem;
            cursor: pointer;
            transition: var(--transition);
        }

        .toggle-password:hover {
            background: #e9ecef;
        }

        /* Divider */
        .auth-divider {
            text-align: center;
            margin: 2rem 0;
            position: relative;
        }

        .auth-divider::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 0;
            right: 0;
            height: 1px;
            background: #e9ecef;
        }

        .auth-divider span {
            background: white;
            padding: 0 1rem;
            color: #6c757d;
            font-size: 0.875rem;
        }

        /* Social Auth */
        .social-auth {
            display: flex;
            flex-direction: column;
            gap: 0.75rem;
        }

        /* Default Credentials */
        .default-credentials {
            background: #f8f9fa;
            border-radius: var(--border-radius-sm);
            padding: 1.25rem;
            margin-bottom: 1.5rem;
            border-left: 4px solid var(--primary);
        }

        .default-credentials h6 {
            color: var(--primary);
            margin-bottom: 0.75rem;
            font-size: 0.9rem;
        }

        .credential-item {
            padding: 0.5rem 0;
            border-bottom: 1px solid #e9ecef;
            font-size: 0.85rem;
        }

        .credential-item:last-child {
            border-bottom: none;
        }

        .credential-item strong {
            color: var(--secondary);
        }

        /* Loading State */
        .btn-loading {
            position: relative;
            color: transparent !important;
        }

        .btn-loading::after {
            content: '';
            position: absolute;
            width: 20px;
            height: 20px;
            top: 50%;
            left: 50%;
            margin-left: -10px;
            margin-top: -10px;
            border: 2px solid transparent;
            border-top-color: currentColor;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        /* Form Check */
        .form-check-input:checked {
            background-color: var(--primary);
            border-color: var(--primary);
        }

        .form-check-label {
            font-size: 0.9rem;
            color: #6c757d;
        }

        /* Links */
        a {
            color: var(--primary);
            text-decoration: none;
            transition: var(--transition);
        }

        a:hover {
            color: #2980b9;
        }

        /* Responsive Design */
        @media (max-width: 576px) {
            .auth-container {
                margin: 1rem auto;
                padding: 0.5rem;
            }

            .auth-header {
                padding: 2rem 1.5rem;
            }

            .auth-body {
                padding: 2rem 1.5rem;
            }

            .auth-footer {
                padding: 1.25rem 1.5rem;
            }

            .auth-header h3 {
                font-size: 1.5rem;
            }

            .auth-icon {
                font-size: 2.5rem;
            }

            .program-grid {
                grid-template-columns: 1fr;
            }
        }

        /* Focus styles for accessibility */
        .btn:focus,
        .form-control:focus,
        .form-check-input:focus {
            outline: 2px solid var(--primary);
            outline-offset: 2px;
        }
    </style>
</head>
<body>
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-header">
                <i class="fas fa-hands-helping auth-icon"></i>
                <h3>Welcome to REACH</h3>
                <p class="mb-0">Sign in to your account</p>
            </div>
            
            <div class="auth-body">
                <!-- System Status Alert -->
                <?php if (isset($critical_error)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    <strong>System Error:</strong> <?php echo htmlspecialchars($critical_error); ?>
                    <br><small>Please contact system administrator.</small>
                </div>
                <?php endif; ?>
                
                <!-- Available Accounts Notice -->
                <div class="default-credentials">
                    <h6><i class="fas fa-info-circle me-2"></i>Available Accounts</h6>
                    <div class="credential-item">
                        <strong>Admin:</strong> admin / password
                    </div>
                    <div class="credential-item">
                        <strong>Philip Suah:</strong> philip.suah / password
                    </div>
                    <div class="credential-item">
                        <strong>Hawa Suah:</strong> hawa.suah / password
                    </div>
                    
                    <?php if (isset($_GET['debug'])): ?>
                    <div class="credential-item" style="border-top: 2px solid var(--reach-accent); margin-top: 10px; padding-top: 10px;">
                        <strong>Debug Mode:</strong> Active
                        <br><small>Check browser console for details</small>
                    </div>
                    <?php endif; ?>
                </div>
                
                <?php if (isset($error)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    <?php echo htmlspecialchars($error); ?>
                </div>
                <?php endif; ?>
                
                <?php if (isset($_GET['session']) && $_GET['session'] === 'expired'): ?>
                <div class="alert alert-warning">
                    <i class="fas fa-clock me-2"></i>
                    Your session has expired. Please log in again.
                </div>
                <?php endif; ?>
                
                <?php if (isset($_GET['registered'])): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle me-2"></i>
                    Registration successful! Please log in.
                </div>
                <?php endif; ?>
                
                <form method="POST" id="loginForm" novalidate>
                    <div class="mb-3">
                        <label for="username" class="form-label">Username or Email</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-user"></i></span>
                            <input type="text" class="form-control" id="username" name="username" 
                                   value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>" 
                                   placeholder="Enter your username or email" required autocomplete="username" autofocus>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-lock"></i></span>
                            <input type="password" class="form-control" id="password" name="password" 
                                   placeholder="Enter your password" required autocomplete="current-password">
                            <button type="button" class="toggle-password" aria-label="Toggle password visibility">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                    </div>
                    
                    <div class="mb-3 form-check">
                        <input type="checkbox" class="form-check-input" id="remember" name="remember">
                        <label class="form-check-label" for="remember">Remember me on this device</label>
                    </div>
                    
                    <button type="submit" class="btn btn-reach mb-3" id="loginBtn">
                        <span><i class="fas fa-sign-in-alt me-2"></i>Sign In</span>
                    </button>
                </form>
                
                <!-- Program Context Section -->
                <div class="program-context">
                    <h6 class="mb-2"><i class="fas fa-graduation-cap me-2"></i>Available Programs</h6>
                    <p class="small text-muted mb-3">Access scholarships, housing, and community programs</p>
                    
                    <div class="program-grid">
                        <?php foreach ($programs as $program): 
                            $icons = [
                                'scholarship' => 'fa-graduation-cap text-primary',
                                'housing' => 'fa-home text-success',
                                'community' => 'fa-users text-warning',
                                'mentorship' => 'fa-handshake text-info'
                            ];
                            $icon = $icons[$program['type']] ?? 'fa-star text-muted';
                        ?>
                        <div class="program-item">
                            <div class="program-icon">
                                <i class="fas <?php echo $icon; ?>"></i>
                            </div>
                            <div class="program-name"><?php echo htmlspecialchars($program['name']); ?></div>
                            <div class="program-desc"><?php echo htmlspecialchars($program['description']); ?></div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                
                <div class="auth-divider">
                    <span>or continue with</span>
                </div>
                
                <div class="social-auth">
                    <button class="btn btn-outline-secondary" disabled>
                        <i class="fab fa-google me-2"></i>Continue with Google
                    </button>
                    <button class="btn btn-outline-secondary" disabled>
                        <i class="fab fa-facebook me-2"></i>Continue with Facebook
                    </button>
                </div>
                
                <div class="text-center mt-3">
                    <small class="text-muted">
                        <a href="forgot-password.php" class="text-decoration-none">Forgot your password?</a>
                        <?php if (isset($_GET['debug'])): ?>
                        <br>
                        <a href="?debug=1" class="text-decoration-none">Debug Mode: ON</a> | 
                        <a href="?" class="text-decoration-none">Debug Mode: OFF</a>
                        <?php else: ?>
                        <br>
                        <a href="?debug=1" class="text-decoration-none small">Enable Debug Mode</a>
                        <?php endif; ?>
                    </small>
                </div>
            </div>
            
            <div class="auth-footer">
                <p class="mb-2">
                    Don't have an account? 
                    <a href="register.php" class="fw-semibold">
                        Create one here
                    </a>
                </p>
                <small class="text-muted">
                    &copy; <?php echo date('Y'); ?> REACH Organization. All rights reserved.
                </small>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const loginForm = document.getElementById('loginForm');
            const loginBtn = document.getElementById('loginBtn');
            const togglePassword = document.querySelector('.toggle-password');
            const passwordInput = document.getElementById('password');
            
            // Toggle password visibility
            if (togglePassword && passwordInput) {
                togglePassword.addEventListener('click', function() {
                    const icon = this.querySelector('i');
                    const isPassword = passwordInput.type === 'password';
                    
                    passwordInput.type = isPassword ? 'text' : 'password';
                    icon.classList.toggle('fa-eye', !isPassword);
                    icon.classList.toggle('fa-eye-slash', isPassword);
                    
                    // Update aria-label for accessibility
                    this.setAttribute('aria-label', 
                        isPassword ? 'Hide password' : 'Show password'
                    );
                });
            }
            
            // Enhanced form submission
            if (loginForm) {
                loginForm.addEventListener('submit', function(e) {
                    const username = document.getElementById('username').value.trim();
                    const password = document.getElementById('password').value;
                    
                    // Basic client-side validation
                    if (!username || !password) {
                        e.preventDefault();
                        return;
                    }
                    
                    // Show loading state
                    if (loginBtn) {
                        loginBtn.classList.add('btn-loading');
                        loginBtn.disabled = true;
                    }
                });
            }
            
            // Auto-focus on username field with delay for better mobile experience
            setTimeout(() => {
                const usernameField = document.getElementById('username');
                if (usernameField) {
                    usernameField.focus();
                }
            }, 100);
            
            // Enhanced enter key support
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Enter') {
                    const active = document.activeElement;
                    if (active && active.form === loginForm) {
                        loginForm.dispatchEvent(new Event('submit'));
                    }
                }
            });
        });
    </script>
</body>
</html>