<?php
// Completely disable all error handling
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Remove ALL handlers
restore_error_handler();
restore_exception_handler();

echo "<h3>Debug - No Error Handling</h3>";

// Manually include each file with error suppression removed
echo "1. Including config.php...<br>";
include '../includes/config.php';
echo "✅ config.php loaded<br>";

echo "2. Including database.php...<br>";
include '../includes/database.php';
echo "✅ database.php loaded<br>";

echo "3. Including auth.php...<br>";
include '../includes/auth.php';
echo "✅ auth.php loaded<br>";

echo "4. Including functions.php...<br>";

// Try to include functions.php with output buffering to catch any output
ob_start();
try {
    include '../includes/functions.php';
    $output = ob_get_clean();
    echo "✅ functions.php loaded<br>";
    if ($output) {
        echo "Output from functions.php: " . htmlspecialchars($output) . "<br>";
    }
} catch (Exception $e) {
    ob_end_clean();
    echo "❌ Exception in functions.php: " . $e->getMessage() . "<br>";
} catch (Error $e) {
    ob_end_clean();
    echo "❌ Error in functions.php: " . $e->getMessage() . "<br>";
    echo "File: " . $e->getFile() . "<br>";
    echo "Line: " . $e->getLine() . "<br>";
}

echo "<h4>Testing individual functions:</h4>";

// Test each function individually
echo "Testing isLoggedIn()... ";
if (function_exists('isLoggedIn')) {
    echo "✅ exists - returns: " . (isLoggedIn() ? 'true' : 'false') . "<br>";
} else {
    echo "❌ missing<br>";
}

echo "Testing generateRandomString()... ";
if (function_exists('generateRandomString')) {
    echo "✅ exists - returns: " . generateRandomString(5) . "<br>";
} else {
    echo "❌ missing<br>";
}

echo "<h4 style='color: green;'>✅ Debug complete</h4>";
?>