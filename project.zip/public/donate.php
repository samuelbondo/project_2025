<?php
include '../includes/config.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donate - Support REACH Organization</title>
    <meta name="description" content="Support REACH Organization's mission to transform lives through education. Your donation creates lasting impact in Rwanda.">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body class="reach-theme">
    <?php include '../includes/header.php'; ?>

    <!-- Hero Section -->
    <section class="page-hero bg-primary">
        <div class="container">
            <div class="row align-items-center min-vh-60">
                <div class="col-lg-8 mx-auto text-center text-white">
                    <h1 class="hero-title" data-aos="fade-up">Support Our Mission</h1>
                    <p class="hero-description" data-aos="fade-up" data-aos-delay="200">
                        Your donation helps transform lives through education, empowerment, and community development in Rwanda.
                    </p>
                    <div class="impact-stats" data-aos="fade-up" data-aos-delay="400">
                        <div class="stat">
                            <h3>150+</h3>
                            <p>Students Supported</p>
                        </div>
                        <div class="stat">
                            <h3>98%</h3>
                            <p>Success Rate</p>
                        </div>
                        <div class="stat">
                            <h3>45</h3>
                            <p>Communities Reached</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Donation Options -->
    <section class="py-5">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="section-title">Choose Your Impact</h2>
                <p class="section-subtitle">Select a donation option that matches your giving goals</p>
            </div>
            
            <div class="row">
                <!-- Scholarship Fund -->
                <div class="col-lg-4 col-md-6 mb-4" data-aos="fade-up">
                    <div class="donation-option">
                        <div class="option-icon scholarship">
                            <i class="fas fa-graduation-cap"></i>
                        </div>
                        <h4>Scholarship Fund</h4>
                        <p class="option-description">
                            Support a student's entire educational journey with tuition, books, and living expenses.
                        </p>
                        <div class="impact-breakdown">
                            <div class="impact-item">
                                <strong>$500</strong>
                                <span>One semester tuition</span>
                            </div>
                            <div class="impact-item">
                                <strong>$1,000</strong>
                                <span>Full year of education</span>
                            </div>
                            <div class="impact-item">
                                <strong>$2,500</strong>
                                <span>Complete degree support</span>
                            </div>
                        </div>
                        <button class="btn btn-primary w-100" data-amount="500" data-fund="scholarship">
                            Donate to Scholarships
                        </button>
                    </div>
                </div>
                
                <!-- Student Housing -->
                <div class="col-lg-4 col-md-6 mb-4" data-aos="fade-up" data-aos-delay="100">
                    <div class="donation-option">
                        <div class="option-icon housing">
                            <i class="fas fa-home"></i>
                        </div>
                        <h4>Student Housing</h4>
                        <p class="option-description">
                            Provide safe, comfortable accommodation for students focusing on their studies.
                        </p>
                        <div class="impact-breakdown">
                            <div class="impact-item">
                                <strong>$100</strong>
                                <span>One month utilities</span>
                            </div>
                            <div class="impact-item">
                                <strong>$300</strong>
                                <span>Three months rent</span>
                            </div>
                            <div class="impact-item">
                                <strong>$1,200</strong>
                                <span>Year of housing</span>
                            </div>
                        </div>
                        <button class="btn btn-success w-100" data-amount="100" data-fund="housing">
                            Support Housing
                        </button>
                    </div>
                </div>
                
                <!-- Community Development -->
                <div class="col-lg-4 col-md-6 mb-4" data-aos="fade-up" data-aos-delay="200">
                    <div class="donation-option">
                        <div class="option-icon community">
                            <i class="fas fa-hands-helping"></i>
                        </div>
                        <h4>Community Projects</h4>
                        <p class="option-description">
                            Fund sustainable community development initiatives and skills training programs.
                        </p>
                        <div class="impact-breakdown">
                            <div class="impact-item">
                                <strong>$50</strong>
                                <span>Skills workshop</span>
                            </div>
                            <div class="impact-item">
                                <strong>$250</strong>
                                <span>Community project</span>
                            </div>
                            <div class="impact-item">
                                <strong>$1,000</strong>
                                <span>Sustainable initiative</span>
                            </div>
                        </div>
                        <button class="btn btn-warning w-100" data-amount="50" data-fund="community">
                            Fund Community Work
                        </button>
                    </div>
                </div>
            </div>
            
            <!-- Custom Amount -->
            <div class="row justify-content-center mt-4">
                <div class="col-lg-6">
                    <div class="custom-donation" data-aos="fade-up">
                        <h4 class="text-center mb-4">Or Give Any Amount</h4>
                        <div class="quick-amounts">
                            <button class="btn btn-outline-primary amount-btn" data-amount="25">$25</button>
                            <button class="btn btn-outline-primary amount-btn" data-amount="50">$50</button>
                            <button class="btn btn-outline-primary amount-btn" data-amount="100">$100</button>
                            <button class="btn btn-outline-primary amount-btn" data-amount="250">$250</button>
                            <button class="btn btn-outline-primary amount-btn" data-amount="500">$500</button>
                        </div>
                        <div class="input-group mt-3">
                            <span class="input-group-text">$</span>
                            <input type="number" class="form-control" id="customAmount" placeholder="Enter custom amount" min="1">
                            <button class="btn btn-primary" id="customDonateBtn">Donate</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Donation Form Modal -->
    <div class="modal fade" id="donationModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Complete Your Donation</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="donationForm">
                        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                        <input type="hidden" name="amount" id="donationAmount">
                        <input type="hidden" name="fund" id="donationFund">
                        
                        <!-- Donation Summary -->
                        <div class="donation-summary mb-4">
                            <h6>Donation Summary</h6>
                            <div class="summary-details">
                                <div class="summary-item">
                                    <span>Amount:</span>
                                    <strong id="summaryAmount">$0.00</strong>
                                </div>
                                <div class="summary-item">
                                    <span>Fund:</span>
                                    <strong id="summaryFund">General Fund</strong>
                                </div>
                                <div class="summary-item total">
                                    <span>Total:</span>
                                    <strong id="summaryTotal">$0.00</strong>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Donor Information -->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Full Name *</label>
                                    <input type="text" class="form-control" name="donor_name" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Email Address *</label>
                                    <input type="email" class="form-control" name="donor_email" required>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Phone Number</label>
                                    <input type="tel" class="form-control" name="donor_phone">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Country *</label>
                                    <input type="text" class="form-control" name="donor_country" required>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Payment Method -->
                        <div class="mb-4">
                            <label class="form-label">Payment Method *</label>
                            <div class="payment-methods">
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="payment_method" value="card" id="paymentCard" checked>
                                    <label class="form-check-label" for="paymentCard">
                                        <i class="fab fa-cc-visa me-2"></i>Credit/Debit Card
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="payment_method" value="paypal" id="paymentPaypal">
                                    <label class="form-check-label" for="paymentPaypal">
                                        <i class="fab fa-paypal me-2"></i>PayPal
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="payment_method" value="bank" id="paymentBank">
                                    <label class="form-check-label" for="paymentBank">
                                        <i class="fas fa-university me-2"></i>Bank Transfer
                                    </label>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Card Details (shown when card is selected) -->
                        <div id="cardDetails">
                            <div class="row">
                                <div class="col-12">
                                    <div class="mb-3">
                                        <label class="form-label">Card Number *</label>
                                        <input type="text" class="form-control" name="card_number" placeholder="1234 5678 9012 3456">
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Expiry Date *</label>
                                        <input type="text" class="form-control" name="card_expiry" placeholder="MM/YY">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">CVV *</label>
                                        <input type="text" class="form-control" name="card_cvv" placeholder="123">
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-12">
                                    <div class="mb-3">
                                        <label class="form-label">Cardholder Name *</label>
                                        <input type="text" class="form-control" name="card_name">
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Bank Transfer Details (shown when bank is selected) -->
                        <div id="bankDetails" style="display: none;">
                            <div class="alert alert-info">
                                <h6>Bank Transfer Information</h6>
                                <p class="mb-1"><strong>Bank:</strong> Bank of Kigali</p>
                                <p class="mb-1"><strong>Account Name:</strong> REACH Organization</p>
                                <p class="mb-1"><strong>Account Number:</strong> 001-1234567-89</p>
                                <p class="mb-1"><strong>SWIFT Code:</strong> BKIGRWRW</p>
                                <p class="mb-0"><strong>Reference:</strong> DONATION-[Your Name]</p>
                            </div>
                        </div>
                        
                        <!-- Additional Options -->
                        <div class="mb-4">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="recurring_donation" id="recurringDonation">
                                <label class="form-check-label" for="recurringDonation">
                                    Make this a monthly recurring donation
                                </label>
                            </div>
                            
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="anonymous_donation" id="anonymousDonation">
                                <label class="form-check-label" for="anonymousDonation">
                                    Make this donation anonymous
                                </label>
                            </div>
                            
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="newsletter_subscription" id="newsletterSubscription" checked>
                                <label class="form-check-label" for="newsletterSubscription">
                                    Receive updates about our impact and programs
                                </label>
                            </div>
                        </div>
                        
                        <!-- Dedication -->
                        <div class="mb-3">
                            <label class="form-label">Dedication (Optional)</label>
                            <textarea class="form-control" name="dedication" rows="2" 
                                      placeholder="Dedicate this donation in honor or memory of someone"></textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="submitDonation">
                        <i class="fas fa-lock me-2"></i>Complete Donation
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Impact Stories -->
    <section class="py-5 bg-light">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="section-title">See Your Impact</h2>
                <p class="section-subtitle">Read how donations have transformed lives</p>
            </div>
            
            <div class="row">
                <div class="col-lg-4 mb-4" data-aos="fade-up">
                    <div class="impact-story">
                        <div class="story-image">
                            <img src="../assets/images/impact/student1.jpg" alt="Eric's Story" class="img-fluid">
                        </div>
                        <div class="story-content">
                            <h5>Eric's Medical Journey</h5>
                            <p>
                                "Thanks to REACH supporters, I'm now in my third year of medical school. 
                                Your donation isn't just helping me - it's helping future patients I'll serve."
                            </p>
                            <div class="story-meta">
                                <span>Medical Student</span>
                                <span>Sponsored since 2022</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-4 mb-4" data-aos="fade-up" data-aos-delay="100">
                    <div class="impact-story">
                        <div class="story-image">
                            <img src="../assets/images/impact/student2.jpg" alt="Grace's Story" class="img-fluid">
                        </div>
                        <div class="story-content">
                            <h5>Grace's Tech Dream</h5>
                            <p>
                                "From a small village to studying computer science at university - 
                                REACH made it possible. I'm learning skills to transform my community."
                            </p>
                            <div class="story-meta">
                                <span>Computer Science Student</span>
                                <span>Sponsored since 2023</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-4 mb-4" data-aos="fade-up" data-aos-delay="200">
                    <div class="impact-story">
                        <div class="story-image">
                            <img src="../assets/images/impact/community1.jpg" alt="Community Project" class="img-fluid">
                        </div>
                        <div class="story-content">
                            <h5>Community Library Project</h5>
                            <p>
                                "Our village now has a library thanks to REACH donors. 200+ children 
                                now have access to books and learning resources they never had before."
                            </p>
                            <div class="story-meta">
                                <span>Community Project</span>
                                <span>Completed 2023</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Transparency Section -->
    <section class="py-5">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="section-title">Financial Transparency</h2>
                <p class="section-subtitle">We're committed to responsible stewardship of your donations</p>
            </div>
            
            <div class="row">
                <div class="col-lg-3 col-md-6 mb-4" data-aos="fade-up">
                    <div class="transparency-card text-center">
                        <div class="transparency-icon">
                            <i class="fas fa-chart-pie"></i>
                        </div>
                        <h4>85%</h4>
                        <p>Program Expenses</p>
                        <small>Directly supports students and communities</small>
                    </div>
                </div>
                
                <div class="col-lg-3 col-md-6 mb-4" data-aos="fade-up" data-aos-delay="100">
                    <div class="transparency-card text-center">
                        <div class="transparency-icon">
                            <i class="fas fa-cog"></i>
                        </div>
                        <h4>10%</h4>
                        <p>Administrative Costs</p>
                        <small>Essential operational expenses</small>
                    </div>
                </div>
                
                <div class="col-lg-3 col-md-6 mb-4" data-aos="fade-up" data-aos-delay="200">
                    <div class="transparency-card text-center">
                        <div class="transparency-icon">
                            <i class="fas fa-bullhorn"></i>
                        </div>
                        <h4>5%</h4>
                        <p>Fundraising</p>
                        <small>Growing our impact reach</small>
                    </div>
                </div>
                
                <div class="col-lg-3 col-md-6 mb-4" data-aos="fade-up" data-aos-delay="300">
                    <div class="transparency-card text-center">
                        <div class="transparency-icon">
                            <i class="fas fa-award"></i>
                        </div>
                        <h4>4.8/5</h4>
                        <p>Donor Satisfaction</p>
                        <small>Based on donor feedback</small>
                    </div>
                </div>
            </div>
            
            <div class="text-center mt-4">
                <a href="../transparency.php" class="btn btn-outline-primary">
                    <i class="fas fa-file-alt me-2"></i>View Full Financial Reports
                </a>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="py-5 bg-primary text-white">
        <div class="container text-center">
            <h2 class="section-title text-white">Ready to Make a Difference?</h2>
            <p class="section-subtitle text-white mb-4">
                Join thousands of donors who are transforming lives through education
            </p>
            <button class="btn btn-light btn-lg" onclick="openDonationModal(50, 'general')">
                <i class="fas fa-heart me-2"></i>Make a Donation Today
            </button>
        </div>
    </section>

    <?php include '../includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Donation modal functionality
        const donationModal = new bootstrap.Modal(document.getElementById('donationModal'));
        
        function openDonationModal(amount, fund) {
            document.getElementById('donationAmount').value = amount;
            document.getElementById('donationFund').value = fund;
            
            // Update summary
            document.getElementById('summaryAmount').textContent = '$' + amount.toLocaleString();
            document.getElementById('summaryFund').textContent = getFundName(fund);
            document.getElementById('summaryTotal').textContent = '$' + amount.toLocaleString();
            
            donationModal.show();
        }
        
        function getFundName(fund) {
            const funds = {
                'scholarship': 'Scholarship Fund',
                'housing': 'Student Housing',
                'community': 'Community Development',
                'general': 'General Fund'
            };
            return funds[fund] || 'General Fund';
        }
        
        // Event listeners for donation buttons
        document.querySelectorAll('.donation-option button').forEach(button => {
            button.addEventListener('click', function() {
                const amount = parseFloat(this.dataset.amount);
                const fund = this.dataset.fund;
                openDonationModal(amount, fund);
            });
        });
        
        // Quick amount buttons
        document.querySelectorAll('.amount-btn').forEach(button => {
            button.addEventListener('click', function() {
                const amount = parseFloat(this.dataset.amount);
                openDonationModal(amount, 'general');
            });
        });
        
        // Custom amount donation
        document.getElementById('customDonateBtn').addEventListener('click', function() {
            const amount = parseFloat(document.getElementById('customAmount').value);
            if (amount && amount > 0) {
                openDonationModal(amount, 'general');
            } else {
                alert('Please enter a valid amount');
            }
        });
        
        // Payment method toggle
        document.querySelectorAll('input[name="payment_method"]').forEach(radio => {
            radio.addEventListener('change', function() {
                const method = this.value;
                document.getElementById('cardDetails').style.display = method === 'card' ? 'block' : 'none';
                document.getElementById('bankDetails').style.display = method === 'bank' ? 'block' : 'none';
            });
        });
        
        // Form submission
        document.getElementById('submitDonation').addEventListener('click', async function() {
            const form = document.getElementById('donationForm');
            const formData = new FormData(form);
            
            // Basic validation
            if (!formData.get('donor_name') || !formData.get('donor_email')) {
                alert('Please fill in all required fields');
                return;
            }
            
            const submitBtn = this;
            const originalText = submitBtn.innerHTML;
            
            try {
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Processing...';
                submitBtn.disabled = true;
                
                // Simulate API call - in production, integrate with payment gateway
                setTimeout(() => {
                    // Show success message
                    donationModal.hide();
                    showSuccessMessage(formData.get('amount'));
                    
                    submitBtn.innerHTML = originalText;
                    submitBtn.disabled = false;
                }, 2000);
                
            } catch (error) {
                alert('Error processing donation: ' + error.message);
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
            }
        });
        
        function showSuccessMessage(amount) {
            const successDiv = document.createElement('div');
            successDiv.className = 'alert alert-success alert-dismissible fade show';
            successDiv.innerHTML = `
                <h4><i class="fas fa-check-circle me-2"></i>Thank You for Your Donation!</h4>
                <p>Your donation of $${amount} has been received. You will receive a confirmation email shortly.</p>
                <p><strong>Your support is transforming lives!</strong></p>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            `;
            
            document.querySelector('main').prepend(successDiv);
        }
    </script>
</body>
</html>