<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

echo "<h3>REACH Organization - Email Test</h3>";

// Test email details
$to = 'samuelbondo917@gmail.com';
$subject = 'REACH Organization - Email Test';
$body = '
<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: Arial, sans-serif; }
        .header { background: #3498db; color: white; padding: 20px; }
        .content { padding: 20px; }
        .success { color: #27ae60; font-weight: bold; }
    </style>
</head>
<body>
    <div class="header">
        <h2>REACH Organization Email Test</h2>
    </div>
    <div class="content">
        <p class="success">✅ Email system is working correctly!</p>
        <p><strong>Test Details:</strong></p>
        <ul>
            <li>From: no-reply@youngdevsofficial.com</li>
            <li>To: ' . $to . '</li>
            <li>Time: ' . date('Y-m-d H:i:s') . '</li>
            <li>System: REACH Organization Platform</li>
        </ul>
        <p>If you received this email, your REACH organization email system is properly configured.</p>
    </div>
</body>
</html>';

try {
    echo "Sending test email to: $to<br>";
    echo "Using: no-reply@youngdevsofficial.com<br>";
    echo "Password: ********<br><br>";
    
    if (sendEmail($to, $subject, $body, true)) {
        echo "<div style='color: green; font-weight: bold;'>✅ Email sent successfully!</div>";
        echo "<p>Please check your inbox (and spam folder) for the test email.</p>";
    } else {
        echo "<div style='color: red; font-weight: bold;'>❌ Email failed to send.</div>";
        echo "<p>Check the error log at: system/logs/email.log</p>";
    }
    
} catch (Exception $e) {
    echo "<div style='color: red; font-weight: bold;'>❌ Error: " . $e->getMessage() . "</div>";
}

echo "<br><hr>";
echo "<h4>Next Steps:</h4>";
echo "<ol>";
echo "<li>Check your email inbox</li>";
echo "<li>If not received, check spam folder</li>";
echo "<li>View email log: system/logs/email.log</li>";
echo "<li>Remove this test file after testing</li>";
echo "</ol>";
?>