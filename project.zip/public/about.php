<?php
// Increase memory limit at the start
ini_set('memory_limit', '256M');

// Set page-specific variables for header
$pageTitle = "About REACH - Our Story & Mission";
$pageDescription = "Learn about REACH Organization's mission, vision, and the inspiring story behind our work empowering students in Rwanda.";
$additionalCSS = ['https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css'];
$additionalJS = ['https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js'];

include '../includes/config.php';

// Handle includes gracefully with memory optimization
$featuredStories = [];
$organizationStats = [];
$teamMembers = [];
$founders = [];

try {
    // Get organization stats from database first (lightweight query)
    $statsSql = "SELECT 
                (SELECT COUNT(*) FROM applications WHERE status IN ('approved', 'under_review', 'submitted')) as students_supported,
                (SELECT COUNT(DISTINCT program_type) FROM programs WHERE status = 'active') as programs_active,
                (SELECT COUNT(*) FROM stories WHERE status = 'published') as success_stories,
                (SELECT COUNT(*) FROM users WHERE role IN ('admin', 'staff', 'reviewer') AND status = 'active') as team_members";
    
    $stmt = $pdo->query($statsSql);
    $organizationStats = $stmt->fetch(PDO::FETCH_ASSOC);
    unset($stmt); // Free memory immediately
    
    // Get founders (users with admin role) with LIMIT
    $foundersSql = "SELECT id, full_name, role, profile_picture, bio, email 
                   FROM users 
                   WHERE role = 'admin' AND status = 'active' 
                   ORDER BY id ASC 
                   LIMIT 5"; // Added limit for safety
    $foundersStmt = $pdo->query($foundersSql);
    $founders = $foundersStmt->fetchAll(PDO::FETCH_ASSOC);
    unset($foundersStmt); // Free memory
    
    // Get team members (excluding founders) with LIMIT
    $teamSql = "SELECT id, full_name, role, profile_picture, bio 
               FROM users 
               WHERE role IN ('staff', 'reviewer') AND status = 'active' 
               ORDER BY full_name 
               LIMIT 12"; // Added limit to prevent too many records
    $teamStmt = $pdo->query($teamSql);
    $teamMembers = $teamStmt->fetchAll(PDO::FETCH_ASSOC);
    unset($teamStmt); // Free memory
    
    // Include and initialize StoryManager LAST with error handling
    $storyManagerPath = '../includes/classes/StoryManager.php';
    if (file_exists($storyManagerPath)) {
        include $storyManagerPath;
        
        if (class_exists('StoryManager')) {
            $storyManager = new StoryManager($pdo);
            // Get only a small number of featured stories
            $featuredStories = $storyManager->getFeaturedStories(2); // Reduced from 3 to 2
            unset($storyManager); // Free the manager object
        }
    }
    
} catch (Exception $e) {
    error_log("About page data loading error: " . $e->getMessage());
    
    // Fallback data
    $organizationStats = [
        'students_supported' => 150,
        'programs_active' => 4,
        'success_stories' => 25,
        'team_members' => 8
    ];
    
    $featuredStories = [
        [
            'id' => 1,
            'title' => 'From Rural Village to University Graduate',
            'excerpt' => 'How REACH helped me overcome financial barriers and achieve my dream...',
            'featured_image' => 'https://placehold.co/600x400/3498db/ffffff?text=Student+Success',
            'author_name' => 'Philip Suah'
        ],
        [
            'id' => 2,
            'title' => 'Building a Brighter Future Together',
            'excerpt' => 'Our community\'s transformation through REACH\'s educational programs...',
            'featured_image' => 'https://placehold.co/600x400/2c3e50/ffffff?text=Community+Impact',
            'author_name' => 'Hawa Suah'
        ]
    ];
    
    $founders = [
        [
            'id' => 2,
            'full_name' => 'Mr. Philip B. Suah Jr.',
            'role' => 'admin',
            'profile_picture' => 'default.jpg',
            'bio' => 'With a passion for education and youth empowerment, Mr. Suah has dedicated his life to creating opportunities for underprivileged students.',
            'email' => 'philip.suah@reach.org'
        ],
        [
            'id' => 3,
            'full_name' => 'Mrs. Hawa Suah',
            'role' => 'admin',
            'profile_picture' => 'default.jpg',
            'bio' => 'Mrs. Suah brings extensive experience in community development and student mentorship.',
            'email' => 'hawa.suah@reach.org'
        ]
    ];
}

// Helper function to truncate text
function truncateText($text, $length = 100) {
    if (strlen($text) <= $length) {
        return $text;
    }
    return substr($text, 0, $length) . '...';
}

// Include header after setting variables
include '../includes/header.php';
?>

<style>
    :root {
        --primary: #3498db;
        --secondary: #2c3e50;
        --success: #27ae60;
        --light: #f8f9fa;
        --reach-accent: #ea4335;
        --reach-warning: #f39c12;
        --gradient-primary: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
        --shadow-sm: 0 2px 8px rgba(0,0,0,0.08);
        --shadow-md: 0 8px 30px rgba(0,0,0,0.12);
        --shadow-lg: 0 15px 35px rgba(0,0,0,0.15);
        --border-radius-sm: 12px;
        --border-radius-md: 20px;
        --border-radius-lg: 28px;
        --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }

    /* Hero Section */
    .page-hero {
        background: var(--gradient-primary);
        color: white;
        min-height: 60vh;
        display: flex;
        align-items: center;
        position: relative;
        overflow: hidden;
        padding: 100px 0;
        margin-top: -80px;
    }

    .page-hero::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 800" opacity="0.1"><polygon fill="white" points="0,800 1200,400 1200,800"/></svg>');
        background-size: cover;
        animation: float 20s ease-in-out infinite;
    }

    @keyframes float {
        0%, 100% { transform: translateY(0px) rotate(0deg); }
        50% { transform: translateY(-20px) rotate(1deg); }
    }

    .hero-title {
        font-size: clamp(2.5rem, 6vw, 4rem);
        font-weight: 800;
        line-height: 1.1;
        margin-bottom: 1.5rem;
        color: white;
        text-shadow: 0 2px 15px rgba(0,0,0,0.3);
    }

    .hero-description {
        font-size: clamp(1.1rem, 2.5vw, 1.3rem);
        margin-bottom: 2.5rem;
        opacity: 0.95;
        max-width: 600px;
        line-height: 1.6;
        margin-left: auto;
        margin-right: auto;
        text-shadow: 0 1px 5px rgba(0,0,0,0.2);
    }

    /* Section Styles */
    .section {
        padding: 80px 0;
    }

    .section-title {
        font-size: 2.5rem;
        font-weight: bold;
        color: var(--secondary);
        margin-bottom: 1rem;
    }

    .section-subtitle {
        font-size: 1.2rem;
        color: #6c757d;
        margin-bottom: 3rem;
    }

    /* Value Cards */
    .value-card {
        background: white;
        padding: 2.5rem 1.5rem;
        border-radius: var(--border-radius-md);
        box-shadow: var(--shadow-sm);
        transition: var(--transition);
        height: 100%;
        border: 1px solid rgba(0,0,0,0.05);
    }

    .value-card:hover {
        transform: translateY(-10px);
        box-shadow: var(--shadow-lg);
    }

    .value-icon {
        width: 80px;
        height: 80px;
        background: var(--primary);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 1.5rem;
        color: white;
        font-size: 2rem;
        transition: var(--transition);
    }

    .value-card:hover .value-icon {
        transform: scale(1.1);
        background: var(--secondary);
    }

    .value-card h4 {
        color: var(--secondary);
        margin-bottom: 1rem;
        font-weight: 600;
    }

    .value-card p {
        color: #6c757d;
        line-height: 1.6;
    }

    /* Founder Profiles */
    .founder-profile {
        background: white;
        border-radius: var(--border-radius-md);
        overflow: hidden;
        box-shadow: var(--shadow-md);
        transition: var(--transition);
        height: 100%;
    }

    .founder-profile:hover {
        transform: translateY(-5px);
        box-shadow: var(--shadow-lg);
    }

    .founder-image {
        position: relative;
        overflow: hidden;
        aspect-ratio: 1;
    }

    .founder-image img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: var(--transition);
    }

    .founder-profile:hover .founder-image img {
        transform: scale(1.05);
    }

    .founder-info {
        padding: 2rem;
    }

    .founder-info h4 {
        color: var(--secondary);
        margin-bottom: 0.5rem;
        font-weight: 600;
    }

    .founder-role {
        color: var(--primary);
        font-weight: 500;
        margin-bottom: 1rem;
        font-style: italic;
    }

    .founder-bio {
        color: #6c757d;
        margin-bottom: 1.5rem;
        line-height: 1.6;
    }

    .founder-quote {
        background: var(--light);
        padding: 1.5rem;
        border-radius: var(--border-radius-sm);
        border-left: 4px solid var(--primary);
        position: relative;
    }

    .founder-quote i {
        color: var(--primary);
        font-size: 1.5rem;
        margin-bottom: 0.5rem;
        display: block;
    }

    .founder-quote p {
        color: var(--secondary);
        font-style: italic;
        margin: 0;
        line-height: 1.5;
    }

    /* Impact Statistics */
    .impact-stat {
        padding: 2rem 1rem;
    }

    .impact-stat h3 {
        color: white;
        margin-bottom: 1rem;
        text-shadow: 0 2px 10px rgba(0,0,0,0.3);
    }

    .impact-stat p {
        color: rgba(255,255,255,0.9);
        font-size: 1.1rem;
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: 1px;
    }

    /* Team Cards */
    .team-card {
        background: white;
        border-radius: var(--border-radius-md);
        overflow: hidden;
        box-shadow: var(--shadow-sm);
        transition: var(--transition);
        height: 100%;
    }

    .team-card:hover {
        transform: translateY(-10px);
        box-shadow: var(--shadow-lg);
    }

    .team-image {
        position: relative;
        overflow: hidden;
        aspect-ratio: 1;
    }

    .team-image img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: var(--transition);
    }

    .team-card:hover .team-image img {
        transform: scale(1.05);
    }

    .team-info {
        padding: 1.5rem;
        text-align: center;
    }

    .team-info h5 {
        color: var(--secondary);
        margin-bottom: 0.5rem;
        font-weight: 600;
    }

    .team-info p {
        color: #6c757d;
        font-size: 0.9rem;
        line-height: 1.4;
    }

    /* About Visual */
    .about-visual {
        position: relative;
    }

    .about-visual img {
        border-radius: var(--border-radius-md);
        box-shadow: var(--shadow-lg);
        transition: var(--transition);
    }

    .about-visual:hover img {
        transform: scale(1.02);
    }

    /* Responsive Design */
    @media (max-width: 768px) {
        .page-hero {
            min-height: 50vh;
            padding: 80px 0;
        }
        
        .hero-title {
            font-size: 2.5rem;
        }
        
        .section-title {
            font-size: 2rem;
        }
        
        .founder-info {
            padding: 1.5rem;
        }
        
        .value-card {
            padding: 2rem 1rem;
        }
    }

    @media (max-width: 576px) {
        .page-hero {
            min-height: 40vh;
            padding: 60px 0;
        }
        
        .hero-title {
            font-size: 2rem;
        }
        
        .section {
            padding: 60px 0;
        }
        
        .impact-stat h3 {
            font-size: 2.5rem;
        }
    }

    /* Animation delays for better sequencing */
    [data-aos-delay="100"] {
        transition-delay: 100ms;
    }

    [data-aos-delay="200"] {
        transition-delay: 200ms;
    }

    [data-aos-delay="300"] {
        transition-delay: 300ms;
    }
</style>

<!-- Hero Section -->
<section class="page-hero">
    <div class="container">
        <div class="row align-items-center min-vh-60">
            <div class="col-lg-8 mx-auto text-center">
                <h1 class="hero-title" data-aos="fade-up">Our Story & Mission</h1>
                <p class="hero-description" data-aos="fade-up" data-aos-delay="200">
                    Transforming lives through education, empowerment, and community development in Rwanda and beyond.
                </p>
            </div>
        </div>
    </div>
</section>

<!-- Our Story Section -->
<section class="section">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6" data-aos="fade-right">
                <h2 class="section-title">Our Humble Beginnings</h2>
                <p class="lead">
                    REACH Organization was founded with a simple yet powerful belief: every action, no matter how small, 
                    can create meaningful change in someone's life.
                </p>
                <p>
                    Established by Mr. Philip B. Suah Jr. and Mrs. Hawa Suah, REACH began as a vision to provide 
                    educational opportunities to deserving students in Rwanda who showed exceptional promise but 
                    faced financial barriers to achieving their dreams.
                </p>
                <p>
                    What started with supporting a few students has grown into a comprehensive organization 
                    providing scholarships, housing, mentorship, and community development programs.
                </p>
            </div>
            <div class="col-lg-6" data-aos="fade-left">
                <div class="about-visual">
                    <img src="../assets/images/about-story.jpg" alt="REACH Story" class="img-fluid rounded shadow" 
                         onerror="this.src='https://placehold.co/600x400/3498db/ffffff?text=REACH+Story'">
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Mission & Vision -->
<section class="section bg-light">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 mb-4" data-aos="fade-up">
                <div class="value-card text-center">
                    <div class="value-icon">
                        <i class="fas fa-bullseye"></i>
                    </div>
                    <h4>Our Mission</h4>
                    <p>
                        To identify, support, and empower deserving students through comprehensive educational 
                        programs, creating future leaders who will drive positive change in their communities.
                    </p>
                </div>
            </div>
            <div class="col-lg-4 mb-4" data-aos="fade-up" data-aos-delay="100">
                <div class="value-card text-center">
                    <div class="value-icon">
                        <i class="fas fa-eye"></i>
                    </div>
                    <h4>Our Vision</h4>
                    <p>
                        A world where every talented individual has access to quality education and the opportunity 
                        to reach their full potential, regardless of their financial circumstances.
                    </p>
                </div>
            </div>
            <div class="col-lg-4 mb-4" data-aos="fade-up" data-aos-delay="200">
                <div class="value-card text-center">
                    <div class="value-icon">
                        <i class="fas fa-hand-holding-heart"></i>
                    </div>
                    <h4>Our Values</h4>
                    <p>
                        Empowerment, Integrity, Compassion, Excellence, and Community. We believe in creating 
                        sustainable impact through transparent and accountable practices.
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Founders Section -->
<section class="section">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title">Meet Our Founders</h2>
            <p class="section-subtitle">The visionary leaders behind REACH Organization</p>
        </div>
        
        <div class="row justify-content-center">
            <?php if (!empty($founders)): ?>
                <?php foreach ($founders as $index => $founder): ?>
                    <div class="col-lg-5 col-md-6 mb-4" data-aos="fade-up" data-aos-delay="<?php echo $index * 100; ?>">
                        <div class="founder-profile">
                            <div class="founder-image">
                                <img src="<?php echo !empty($founder['profile_picture']) && $founder['profile_picture'] !== 'default.jpg' ? '../assets/images/profiles/' . $founder['profile_picture'] : 'https://placehold.co/400x400/3498db/ffffff?text=' . urlencode(explode(' ', $founder['full_name'])[0]); ?>" 
                                     alt="<?php echo htmlspecialchars($founder['full_name']); ?>"
                                     onerror="this.src='https://placehold.co/400x400/3498db/ffffff?text=<?php echo urlencode(explode(' ', $founder['full_name'])[0]); ?>'">
                            </div>
                            <div class="founder-info">
                                <h4><?php echo htmlspecialchars($founder['full_name']); ?></h4>
                                <p class="founder-role">
                                    <?php echo $founder['role'] === 'admin' ? 'Co-Founder & Visionary Leader' : 'Co-Founder & Program Director'; ?>
                                </p>
                                <p class="founder-bio">
                                    <?php echo !empty($founder['bio']) ? htmlspecialchars($founder['bio']) : 'Dedicated to transforming lives through education and community empowerment.'; ?>
                                </p>
                                <div class="founder-quote">
                                    <i class="fas fa-quote-left"></i>
                                    <p>
                                        <?php if ($founder['full_name'] === 'Mr. Philip B. Suah Jr.'): ?>
                                            Education is the most powerful investment we can make in our future generations.
                                        <?php else: ?>
                                            When you educate one person, you transform an entire community.
                                        <?php endif; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <!-- Fallback founders -->
                <div class="col-lg-5 col-md-6 mb-4" data-aos="fade-up">
                    <div class="founder-profile">
                        <div class="founder-image">
                            <img src="https://placehold.co/400x400/3498db/ffffff?text=Philip+B.+Suah+Jr." 
                                 alt="Mr. Philip B. Suah Jr.">
                        </div>
                        <div class="founder-info">
                            <h4>Mr. Philip B. Suah Jr.</h4>
                            <p class="founder-role">Co-Founder & Visionary Leader</p>
                            <p class="founder-bio">
                                With a passion for education and youth empowerment, Mr. Suah has dedicated his life to 
                                creating opportunities for underprivileged students. His visionary leadership and 
                                commitment to social change have been the driving force behind REACH's success.
                            </p>
                            <div class="founder-quote">
                                <i class="fas fa-quote-left"></i>
                                <p>Education is the most powerful investment we can make in our future generations.</p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-5 col-md-6 mb-4" data-aos="fade-up" data-aos-delay="100">
                    <div class="founder-profile">
                        <div class="founder-image">
                            <img src="https://placehold.co/400x400/2c3e50/ffffff?text=Hawa+Suah"
                                 alt="Mrs. Hawa Suah">
                        </div>
                        <div class="founder-info">
                            <h4>Mrs. Hawa Suah</h4>
                            <p class="founder-role">Co-Founder & Program Director</p>
                            <p class="founder-bio">
                                Mrs. Suah brings extensive experience in community development and student mentorship. 
                                Her compassionate approach and dedication to holistic student support ensure that every 
                                REACH beneficiary receives comprehensive care and guidance.
                            </p>
                            <div class="founder-quote">
                                <i class="fas fa-quote-left"></i>
                                <p>When you educate one person, you transform an entire community.</p>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Impact Statistics -->
<section class="section bg-primary text-white">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title text-white">Our Impact</h2>
            <p class="section-subtitle text-white">Creating measurable change in communities</p>
        </div>
        
        <div class="row text-center">
            <div class="col-lg-3 col-md-6 mb-4" data-aos="zoom-in">
                <div class="impact-stat">
                    <h3 class="display-4 fw-bold"><?php echo $organizationStats['students_supported'] ?? '150+'; ?></h3>
                    <p>Students Supported</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-4" data-aos="zoom-in" data-aos-delay="100">
                <div class="impact-stat">
                    <h3 class="display-4 fw-bold"><?php echo $organizationStats['programs_active'] ?? '15'; ?></h3>
                    <p>Active Programs</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-4" data-aos="zoom-in" data-aos-delay="200">
                <div class="impact-stat">
                    <h3 class="display-4 fw-bold"><?php echo $organizationStats['success_stories'] ?? '98%'; ?></h3>
                    <p>Success Stories</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-4" data-aos="zoom-in" data-aos-delay="300">
                <div class="impact-stat">
                    <h3 class="display-4 fw-bold"><?php echo $organizationStats['team_members'] ?? '25+'; ?></h3>
                    <p>Team Members</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Team Section -->
<section class="section">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title">Our Leadership Team</h2>
            <p class="section-subtitle">Dedicated professionals driving our mission forward</p>
        </div>
        
        <div class="row">
            <?php if (!empty($teamMembers)): ?>
                <?php foreach ($teamMembers as $index => $member): ?>
                    <div class="col-lg-3 col-md-6 mb-4" data-aos="fade-up" data-aos-delay="<?php echo $index * 100; ?>">
                        <div class="team-card text-center">
                            <div class="team-image">
                                <img src="<?php echo !empty($member['profile_picture']) && $member['profile_picture'] !== 'default.jpg' ? '../assets/images/profiles/' . $member['profile_picture'] : 'https://placehold.co/400x400/3498db/ffffff?text=' . urlencode(explode(' ', $member['full_name'])[0]); ?>" 
                                     alt="<?php echo htmlspecialchars($member['full_name']); ?>"
                                     onerror="this.src='https://placehold.co/400x400/3498db/ffffff?text=<?php echo urlencode(explode(' ', $member['full_name'])[0]); ?>'">
                            </div>
                            <div class="team-info">
                                <h5><?php echo htmlspecialchars($member['full_name']); ?></h5>
                                <p class="text-muted"><?php echo htmlspecialchars(ucfirst($member['role'])); ?></p>
                                <?php if (!empty($member['bio'])): ?>
                                    <p class="small text-muted"><?php echo htmlspecialchars(truncateText($member['bio'], 100)); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <!-- Fallback team members -->
                <div class="col-lg-3 col-md-6 mb-4" data-aos="fade-up">
                    <div class="team-card text-center">
                        <div class="team-image">
                            <img src="https://placehold.co/400x400/3498db/ffffff?text=Financial+Secretary" 
                                 alt="Financial Secretary">
                        </div>
                        <div class="team-info">
                            <h5>Financial Secretary</h5>
                            <p class="text-muted">Financial Management & Transparency</p>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-3 col-md-6 mb-4" data-aos="fade-up" data-aos-delay="100">
                    <div class="team-card text-center">
                        <div class="team-image">
                            <img src="https://placehold.co/400x400/2c3e50/ffffff?text=Program+Coordinator" 
                                 alt="Program Coordinator">
                        </div>
                        <div class="team-info">
                            <h5>Program Coordinator</h5>
                            <p class="text-muted">Student Programs & Activities</p>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-3 col-md-6 mb-4" data-aos="fade-up" data-aos-delay="200">
                    <div class="team-card text-center">
                        <div class="team-image">
                            <img src="https://placehold.co/400x400/27ae60/ffffff?text=Legal+Advisor" 
                                 alt="Legal Advisor">
                        </div>
                        <div class="team-info">
                            <h5>Legal Advisor</h5>
                            <p class="text-muted">Legal Compliance & Governance</p>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-3 col-md-6 mb-4" data-aos="fade-up" data-aos-delay="300">
                    <div class="team-card text-center">
                        <div class="team-image">
                            <img src="https://placehold.co/400x400/e74c3c/ffffff?text=Community+Manager" 
                                 alt="Community Manager">
                        </div>
                        <div class="team-info">
                            <h5>Community Manager</h5>
                            <p class="text-muted">Community Engagement & Partnerships</p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<?php 
// Free memory before including footer
unset($featuredStories, $organizationStats, $teamMembers, $founders);
include '../includes/footer.php'; 
?>

<script>
    // Initialize AOS animations
    AOS.init({
        duration: 1000,
        once: true,
        offset: 100
    });

    // Error handling for images
    document.addEventListener('DOMContentLoaded', function() {
        const images = document.querySelectorAll('img');
        images.forEach(img => {
            if (!img.complete || img.naturalHeight === 0) {
                console.warn('Image failed to load:', img.src);
            }
        });
    });

    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
</script>