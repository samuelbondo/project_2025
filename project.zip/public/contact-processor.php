<?php
// Simple Contact Form Processor
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');

// Start session for CSRF protection
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Turn off display errors
ini_set('display_errors', 0);
error_reporting(E_ALL);

// Simple CSRF validation
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Basic CSRF check (you can enhance this)
    $csrf_token = $_POST['csrf_token'] ?? '';
    if (empty($csrf_token)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Security token missing.']);
        exit;
    }
    
    try {
        // Get and sanitize form data
        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $subject = trim($_POST['subject'] ?? '');
        $message = trim($_POST['message'] ?? '');
        $newsletter = isset($_POST['newsletter']) ? 1 : 0;
        
        // Server-side validation
        $errors = [];
        
        if (empty($name) || strlen($name) < 2) {
            $errors[] = 'Please enter a valid name (minimum 2 characters)';
        }
        
        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Please enter a valid email address';
        }
        
        if (empty($subject)) {
            $errors[] = 'Please select a subject';
        }
        
        if (empty($message) || strlen($message) < 10) {
            $errors[] = 'Please enter a message (minimum 10 characters)';
        }
        
        if (!empty($errors)) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => implode('<br>', $errors)]);
            exit;
        }
        
        // Include PHPMailer setup
        $root_path = dirname(__DIR__);
        $mailer_path = $root_path . '/includes/phpmailer-setup.php';
        
        if (!file_exists($mailer_path)) {
            throw new Exception('Email system not configured properly.');
        }
        
        require_once $mailer_path;
        
        // Prepare contact data
        $contact_data = [
            'id' => 'CONTACT-' . time(),
            'name' => $name,
            'email' => $email,
            'phone' => $phone,
            'subject' => $subject,
            'message' => $message,
            'date' => date('F j, Y \a\t g:i A'),
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'unknown'
        ];
        
        // Send emails
        $admin_sent = sendAdminNotification($contact_data);
        $auto_reply_sent = sendAutoReply($contact_data);
        $emails_sent = $admin_sent && $auto_reply_sent;
        
        // Prepare success message
        if ($emails_sent) {
            $success_message = 'Thank you for your message! We have sent a confirmation email to your inbox.';
        } else {
            $success_message = 'Thank you for your message! We will get back to you within 24 hours.';
        }
        
        echo json_encode([
            'success' => true, 
            'message' => $success_message,
            'contact_id' => $contact_data['id'],
            'emails_sent' => $emails_sent
        ]);
        
    } catch (Exception $e) {
        error_log("Contact form error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode([
            'success' => false, 
            'message' => 'An error occurred while sending your message. Please try again later.'
        ]);
    }
} else {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed.']);
}
?>