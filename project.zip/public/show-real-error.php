<?php
// Completely bypass all error handling
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Remove any existing error handlers
restore_error_handler();
restore_exception_handler();

echo "<h3>Raw Error Display - No Handlers</h3>";

// Test loading files directly
echo "Loading config.php...<br>";
include '../includes/config.php';
echo "✅ config.php loaded<br>";

echo "Loading database.php...<br>";
include '../includes/database.php';
echo "✅ database.php loaded<br>";

echo "Loading auth.php...<br>";
include '../includes/auth.php';
echo "✅ auth.php loaded<br>";

echo "Loading functions.php...<br>";
include '../includes/functions.php';
echo "✅ functions.php loaded<br>";

echo "<h4 style='color: green;'>✅ All files loaded successfully!</h4>";
?>