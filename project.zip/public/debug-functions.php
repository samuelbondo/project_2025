<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h3>Functions.php Debug</h3>";

try {
    include '../includes/config.php';
    include '../includes/database.php';
    echo "✅ Config and Database loaded<br>";
    
    // Test functions.php line by line
    echo "Loading functions.php...<br>";
    
    // Test each function individually
    echo "Testing getCurrentUser()...<br>";
    function getCurrentUser() {
        if (!isset($_SESSION['user_id'])) {
            return null;
        }
        
        $db = new Database();
        $db->query("SELECT * FROM users WHERE id = ?");
        $db->bind(1, $_SESSION['user_id']);
        return $db->single();
    }
    echo "✅ getCurrentUser() defined<br>";
    
    echo "Testing generateRandomString()...<br>";
    function generateRandomString($length = 10) {
        return bin2hex(random_bytes($length));
    }
    echo "✅ generateRandomString() defined<br>";
    
    echo "<h4 style='color: green;'>✅ Basic functions working</h4>";
    
} catch (Exception $e) {
    echo "<h4 style='color: red;'>❌ Error in functions:</h4>";
    echo "<pre>";
    echo "Message: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . "\n"; 
    echo "Line: " . $e->getLine() . "\n";
    echo "</pre>";
}
?>