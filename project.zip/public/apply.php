<?php
// Start session at the very top
session_start();

// Generate CSRF token if not exists
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

include '../includes/config.php';

// Get program from URL parameter or user's session
$selected_program = $_GET['program'] ?? ($_SESSION['program_interest'] ?? '');
$program_details = null;

// Enhanced error handling for programs
$activePrograms = [];
try {
    // Get program details if a specific program is selected
    if ($selected_program) {
        $stmt = $pdo->prepare("
            SELECT id, name, type, description, eligibility_criteria, benefits, status 
            FROM programs 
            WHERE type = ? AND status = 'active'
        ");
        $stmt->execute([$selected_program]);
        $program_details = $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    // Get all active programs for fallback
    $stmt = $pdo->query("
        SELECT id, name, type, description, status 
        FROM programs 
        WHERE status = 'active' 
        ORDER BY name
    ");
    $activePrograms = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (Exception $e) {
    // Log the error but don't break the page
    error_log("Programs loading error: " . $e->getMessage());
    
    // Fallback: Provide basic program data
    $activePrograms = [
        [
            'id' => 1,
            'name' => 'Education Scholarship Program',
            'type' => 'scholarship',
            'description' => 'Full tuition coverage for underprivileged students',
            'status' => 'active'
        ],
        [
            'id' => 2,
            'name' => 'Student Housing Initiative',
            'type' => 'housing',
            'description' => 'Safe and affordable housing for students',
            'status' => 'active'
        ],
        [
            'id' => 3,
            'name' => 'Community Development Program',
            'type' => 'community',
            'description' => 'Skills training and community building',
            'status' => 'active'
        ],
        [
            'id' => 4,
            'name' => 'Youth Mentorship Program',
            'type' => 'mentorship',
            'description' => 'One-on-one mentoring for career development',
            'status' => 'active'
        ]
    ];
}

// If user is logged in and has program interest, use that as default
if (isset($_SESSION['user_id']) && isset($_SESSION['program_interest']) && !$selected_program) {
    $selected_program = $_SESSION['program_interest'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apply for Support - REACH Organization | Transforming Lives</title>
    
    <!-- Advanced Meta Tags -->
    <meta name="description" content="Apply for REACH Organization scholarships, housing, and community programs. Start your journey to educational empowerment in Rwanda.">
    <meta name="keywords" content="REACH application, scholarship application, student housing, community programs, Rwanda education">
    <meta name="author" content="REACH Organization">
    
    <!-- Open Graph -->
    <meta property="og:title" content="Apply for Support - REACH Organization">
    <meta property="og:description" content="Begin your journey to educational empowerment with REACH Organization">
    <meta property="og:type" content="website">
    
    <!-- PWA Meta Tags -->
    <meta name="theme-color" content="#3498db">
    <meta name="apple-mobile-web-app-capable" content="yes">
    
    <!-- Preload Critical Resources -->
    <link rel="preload" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" as="style">
    <link rel="preload" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" as="style">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    
    <style>
        :root {
            --primary: #3498db;
            --secondary: #2c3e50;
            --success: #27ae60;
            --light: #f8f9fa;
            --reach-accent: #ea4335;
            --reach-warning: #f39c12;
            --gradient-primary: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            --shadow-sm: 0 2px 8px rgba(0,0,0,0.08);
            --shadow-md: 0 8px 30px rgba(0,0,0,0.12);
            --shadow-lg: 0 15px 35px rgba(0,0,0,0.15);
            --border-radius-sm: 12px;
            --border-radius-md: 20px;
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            line-height: 1.6;
            color: var(--secondary);
            overflow-x: hidden;
            padding-top: 80px;
            background: var(--light);
        }

        /* Enhanced Navigation */
        .navbar {
            background: rgba(44, 62, 80, 0.95) !important;
            backdrop-filter: blur(20px);
            padding: 1rem 0;
            transition: var(--transition);
            border-bottom: 1px solid rgba(255,255,255,0.1);
            height: 80px;
        }

        .navbar.scrolled {
            background: rgba(44, 62, 80, 0.98) !important;
            padding: 0.75rem 0;
            box-shadow: var(--shadow-md);
        }

        .brand-content {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .brand-text {
            line-height: 1.2;
        }

        .brand-text strong {
            font-size: 1.4rem;
            font-weight: 700;
            display: block;
            color: white;
        }

        .brand-text small {
            font-size: 0.75rem;
            opacity: 0.8;
            font-weight: 400;
            color: rgba(255,255,255,0.8);
        }

        .navbar-brand i {
            font-size: 1.8rem;
            color: var(--success);
        }

        .nav-link {
            font-weight: 500;
            padding: 0.5rem 1rem !important;
            border-radius: var(--border-radius-sm);
            transition: var(--transition);
            margin: 0.125rem;
            color: rgba(255,255,255,0.9);
        }

        .nav-link:hover,
        .nav-link.active {
            background: rgba(255,255,255,0.1);
            transform: translateY(-1px);
            color: white;
        }

        .navbar-actions {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            flex-wrap: wrap;
        }

        .navbar-actions .btn {
            padding: 0.5rem 1.25rem;
            border-radius: var(--border-radius-sm);
            font-weight: 500;
            transition: var(--transition);
            white-space: nowrap;
        }

        /* Enhanced Hero Section */
        .page-hero {
            background: var(--gradient-primary);
            color: white;
            min-height: 60vh;
            display: flex;
            align-items: center;
            position: relative;
            overflow: hidden;
            padding: 120px 0 80px;
            margin-top: -80px;
        }

        .page-hero::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 800" opacity="0.1"><polygon fill="white" points="0,800 1200,400 1200,800"/></svg>');
            background-size: cover;
            animation: float 20s ease-in-out infinite;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0px) rotate(0deg); }
            50% { transform: translateY(-20px) rotate(1deg); }
        }

        .hero-title {
            font-size: clamp(2.5rem, 6vw, 3.5rem);
            font-weight: 800;
            line-height: 1.1;
            margin-bottom: 1.5rem;
            color: white;
            text-shadow: 0 2px 15px rgba(0,0,0,0.3);
        }

        .hero-description {
            font-size: clamp(1.1rem, 2.5vw, 1.3rem);
            margin-bottom: 2rem;
            opacity: 0.95;
            max-width: 600px;
            line-height: 1.6;
            margin-left: auto;
            margin-right: auto;
            text-shadow: 0 1px 5px rgba(0,0,0,0.2);
        }

        /* Section Styles */
        .section {
            padding: 80px 0;
        }

        .section-title {
            font-size: clamp(2rem, 4vw, 2.5rem);
            font-weight: bold;
            color: var(--secondary);
            margin-bottom: 1rem;
            text-align: center;
        }

        .section-subtitle {
            font-size: clamp(1rem, 2vw, 1.2rem);
            color: #6c757d;
            margin-bottom: 3rem;
            text-align: center;
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
        }

        /* Process Steps */
        .process-step {
            padding: 2rem 1rem;
            text-align: center;
            transition: var(--transition);
        }

        .process-step:hover {
            transform: translateY(-5px);
        }

        .step-number {
            width: 60px;
            height: 60px;
            background: var(--primary);
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            font-weight: bold;
            margin: 0 auto 1rem;
        }

        .step-icon {
            width: 80px;
            height: 80px;
            background: var(--gradient-primary);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1rem;
            color: white;
            font-size: 2rem;
        }

        .process-step h5 {
            font-size: 1.25rem;
            font-weight: 600;
            margin-bottom: 1rem;
            color: var(--secondary);
        }

        /* Application Card */
        .application-card {
            background: white;
            border-radius: var(--border-radius-md);
            box-shadow: var(--shadow-md);
            overflow: hidden;
            transition: var(--transition);
            margin: 2rem 0;
        }

        .application-card:hover {
            box-shadow: var(--shadow-lg);
        }

        .card-header {
            background: var(--gradient-primary);
            color: white;
            padding: 2rem;
            text-align: center;
        }

        .card-header h4 {
            font-size: clamp(1.5rem, 3vw, 1.75rem);
            font-weight: 700;
            margin-bottom: 0.5rem;
        }

        .card-body {
            padding: clamp(1.5rem, 3vw, 3rem);
        }

        /* Form Sections */
        .form-section {
            background: white;
            border-radius: var(--border-radius-sm);
            padding: clamp(1rem, 2vw, 2rem);
            margin-bottom: 2rem;
            border: 1px solid #e9ecef;
            transition: var(--transition);
        }

        .form-section:hover {
            border-color: var(--primary);
            box-shadow: var(--shadow-sm);
        }

        .form-section .section-title {
            font-size: 1.25rem;
            color: var(--primary);
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            text-align: left;
        }

        .form-section .section-title i {
            margin-right: 0.5rem;
        }

        .form-label {
            font-weight: 600;
            color: var(--secondary);
            margin-bottom: 0.5rem;
        }

        .form-control, .form-select {
            border-radius: var(--border-radius-sm);
            border: 2px solid #e9ecef;
            padding: 0.75rem 1rem;
            transition: var(--transition);
            font-size: 1rem;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.2rem rgba(52, 152, 219, 0.25);
        }

        /* Buttons */
        .btn {
            border-radius: var(--border-radius-sm);
            font-weight: 500;
            transition: var(--transition);
            border: 2px solid transparent;
            font-size: 1rem;
        }

        .btn-primary {
            background: var(--primary);
            border-color: var(--primary);
        }

        .btn-primary:hover {
            background: #2980b9;
            border-color: #2980b9;
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
        }

        .btn-outline-primary {
            border-color: var(--primary);
            color: var(--primary);
        }

        .btn-outline-primary:hover {
            background: var(--primary);
            color: white;
            transform: translateY(-2px);
        }

        .btn-lg {
            padding: 1rem 2rem;
            font-size: 1.1rem;
        }

        /* Auth Actions */
        .auth-actions {
            display: flex;
            gap: 1rem;
            justify-content: center;
            flex-wrap: wrap;
        }

        /* Support Actions */
        .support-actions {
            display: flex;
            gap: 1rem;
            justify-content: center;
            flex-wrap: wrap;
        }

        /* FAQ Accordion */
        .accordion-button {
            font-weight: 600;
            padding: 1.25rem;
            border-radius: var(--border-radius-sm) !important;
            font-size: 1rem;
        }

        .accordion-button:not(.collapsed) {
            background: var(--primary);
            color: white;
        }

        .accordion-body {
            padding: 1.5rem;
        }

        /* Alert Styles */
        .alert {
            border-radius: var(--border-radius-sm);
            border: none;
            padding: 1rem 1.5rem;
            margin: 1rem 0;
        }

        .alert-info {
            background: rgba(52, 152, 219, 0.1);
            color: var(--primary);
        }

        .alert-success {
            background: rgba(39, 174, 96, 0.1);
            color: var(--success);
            border-left: 4px solid var(--success);
        }

        /* Program Info Display */
        .program-info-card {
            background: rgba(52, 152, 219, 0.05);
            border: 2px solid var(--primary);
            border-radius: var(--border-radius-sm);
            padding: 1.5rem;
            margin-bottom: 1.5rem;
        }

        .program-icon-large {
            font-size: 3rem;
            color: var(--primary);
            margin-bottom: 1rem;
        }

        /* Validation styles */
        .is-invalid {
            border-color: #dc3545 !important;
        }

        .is-valid {
            border-color: #198754 !important;
        }

        .invalid-feedback {
            display: block;
            width: 100%;
            margin-top: 0.25rem;
            font-size: 0.875em;
            color: #dc3545;
        }

        .form-check-input.is-invalid {
            border-color: #dc3545;
        }

        .form-check-input.is-valid {
            border-color: #198754;
        }

        /* File upload preview */
        .file-preview {
            margin-top: 0.5rem;
            padding: 0.5rem;
            background: #f8f9fa;
            border-radius: var(--border-radius-sm);
            border: 1px dashed #dee2e6;
        }

        .file-preview-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0.5rem;
            border-bottom: 1px solid #dee2e6;
        }

        .file-preview-item:last-child {
            border-bottom: none;
        }

        .file-preview-item .file-name {
            flex: 1;
            margin-right: 1rem;
        }

        .file-actions {
            display: flex;
            gap: 0.5rem;
        }

        /* Character count styles */
        .char-count.text-warning {
            color: #f39c12 !important;
            font-weight: bold;
        }

        /* Loading overlay */
        .loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255,255,255,0.9);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 9999;
            backdrop-filter: blur(5px);
        }

        /* Footer */
        footer {
            background: var(--secondary);
            color: white;
            padding: 3rem 0 1rem;
        }

        .footer-links a {
            color: #bdc3c7;
            text-decoration: none;
            transition: color 0.3s;
        }

        .footer-links a:hover {
            color: white;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            body {
                padding-top: 70px;
            }

            .navbar {
                height: 70px;
                padding: 0.75rem 0;
            }

            .page-hero {
                padding: 100px 0 60px;
                margin-top: -70px;
                min-height: 50vh;
            }

            .card-body {
                padding: 1.5rem;
            }

            .form-section {
                padding: 1rem;
            }

            .auth-actions, .support-actions {
                flex-direction: column;
                align-items: center;
            }

            .auth-actions .btn, .support-actions .btn {
                width: 100%;
                max-width: 280px;
            }

            .navbar-actions {
                justify-content: center;
                margin-top: 1rem;
                width: 100%;
            }

            .navbar-actions .btn {
                flex: 1;
                min-width: 120px;
                text-align: center;
            }

            .section {
                padding: 60px 0;
            }

            .process-step {
                padding: 1.5rem 0.5rem;
            }

            .step-icon {
                width: 60px;
                height: 60px;
                font-size: 1.5rem;
            }

            .step-number {
                width: 50px;
                height: 50px;
                font-size: 1.25rem;
            }
        }

        @media (max-width: 576px) {
            body {
                padding-top: 60px;
            }

            .navbar {
                height: 60px;
            }

            .page-hero {
                padding: 80px 0 40px;
                margin-top: -60px;
                min-height: 40vh;
            }

            .hero-title {
                font-size: 2rem;
            }

            .card-body {
                padding: 1rem;
            }

            .form-section {
                padding: 0.75rem;
            }

            .section {
                padding: 40px 0;
            }

            .btn-lg {
                padding: 0.75rem 1.5rem;
                font-size: 1rem;
            }

            .card-header {
                padding: 1.5rem;
            }

            .card-header h4 {
                font-size: 1.25rem;
            }
        }

        /* Extra small devices */
        @media (max-width: 400px) {
            .brand-text strong {
                font-size: 1.2rem;
            }

            .navbar-brand i {
                font-size: 1.5rem;
            }

            .hero-title {
                font-size: 1.75rem;
            }

            .hero-description {
                font-size: 1rem;
            }
        }

        /* Focus styles for accessibility */
        .btn:focus,
        .nav-link:focus,
        .form-control:focus,
        .form-select:focus {
            outline: 2px solid var(--primary);
            outline-offset: 2px;
        }

        /* Loading states */
        .btn.loading {
            pointer-events: none;
            opacity: 0.8;
        }

        /* Ensure content is properly spaced */
        .main-content {
            min-height: calc(100vh - 80px);
        }

        /* Mobile menu improvements */
        .navbar-collapse {
            background: rgba(44, 62, 80, 0.98);
            padding: 1rem;
            border-radius: var(--border-radius-sm);
            margin-top: 1rem;
        }

        @media (max-width: 768px) {
            .navbar-collapse {
                box-shadow: var(--shadow-lg);
                border: 1px solid rgba(255,255,255,0.1);
            }
        }
    </style>
</head>
<body class="reach-theme">
    <!-- Enhanced Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
        <div class="container">
            <a class="navbar-brand" href="../index.php">
                <div class="brand-content">
                    <i class="fas fa-hands-helping"></i>
                    <div class="brand-text">
                        <strong>REACH</strong>
                        <small>Recognizing Each Action Can Help</small>
                    </div>
                </div>
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMain"
                    aria-controls="navbarMain" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarMain">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item"><a class="nav-link" href="../index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="../about.php">About</a></li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Programs
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="../programs.php#scholarships">Scholarships</a></li>
                            <li><a class="dropdown-item" href="../programs.php#housing">Student Housing</a></li>
                            <li><a class="dropdown-item" href="../programs.php#community">Community Projects</a></li>
                        </ul>
                    </li>
                    <li class="nav-item"><a class="nav-link" href="../stories.php">Stories</a></li>
                    <li class="nav-item"><a class="nav-link active" href="apply.php">Apply</a></li>
                    <li class="nav-item"><a class="nav-link" href="../contact.php">Contact</a></li>
                </ul>
                
                <div class="navbar-actions">
                    <a href="apply.php" class="btn btn-outline-light">
                        <i class="fas fa-edit me-1"></i>Apply
                    </a>
                    <a href="../donate.php" class="btn btn-warning">
                        <i class="fas fa-heart me-1"></i>Donate
                    </a>
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <div class="d-flex align-items-center gap-2">
                            <span class="text-light me-2">Welcome, <?php echo htmlspecialchars($_SESSION['full_name'] ?? 'User'); ?></span>
                            <a href="../portal/student/dashboard.php" class="btn btn-outline-light">
                                <i class="fas fa-tachometer-alt me-1"></i>Dashboard
                            </a>
                            <a href="../logout.php" class="btn btn-outline-light">
                                <i class="fas fa-sign-out-alt me-1"></i>Logout
                            </a>
                        </div>
                    <?php else: ?>
                        <a href="../login.php?redirect=apply.php" class="btn btn-outline-light">
                            <i class="fas fa-sign-in-alt me-1"></i>Login
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Hero Section -->
        <section class="page-hero">
            <div class="container">
                <div class="row align-items-center min-vh-60">
                    <div class="col-lg-8 mx-auto text-center">
                        <h1 class="hero-title" data-aos="fade-up">Apply for Support</h1>
                        <p class="hero-description" data-aos="fade-up" data-aos-delay="200">
                            Begin your journey to educational empowerment. Our application process is designed to identify 
                            talented individuals who will benefit most from REACH Organization's support.
                        </p>
                       
                    </div>
                </div>
            </div>
        </section>

        <!-- Application Process -->
        <section class="py-5 bg-light">
            <div class="container">
                <div class="text-center mb-5">
                    <h2 class="section-title">Application Process</h2>
                    <p class="section-subtitle">Follow these simple steps to submit your application</p>
                </div>
                
                <div class="row">
                    <div class="col-lg-3 col-md-6 mb-4" data-aos="fade-up">
                        <div class="process-step text-center">
                            <div class="step-number">1</div>
                            <div class="step-icon">
                                <i class="fas fa-user-check"></i>
                            </div>
                            <h5>Create Account</h5>
                            <p>Register for an account to access the application system</p>
                        </div>
                    </div>
                    
                    <div class="col-lg-3 col-md-6 mb-4" data-aos="fade-up" data-aos-delay="100">
                        <div class="process-step text-center">
                            <div class="step-number">2</div>
                            <div class="step-icon">
                                <i class="fas fa-file-alt"></i>
                            </div>
                            <h5>Prepare Documents</h5>
                            <p>Gather academic records, identification, and recommendation letters</p>
                        </div>
                    </div>
                    
                    <div class="col-lg-3 col-md-6 mb-4" data-aos="fade-up" data-aos-delay="200">
                        <div class="process-step text-center">
                            <div class="step-number">3</div>
                            <div class="step-icon">
                                <i class="fas fa-edit"></i>
                            </div>
                            <h5>Complete Application</h5>
                            <p>Fill out the online form with your personal and academic information</p>
                        </div>
                    </div>
                    
                    <div class="col-lg-3 col-md-6 mb-4" data-aos="fade-up" data-aos-delay="300">
                        <div class="process-step text-center">
                            <div class="step-number">4</div>
                            <div class="step-icon">
                                <i class="fas fa-paper-plane"></i>
                            </div>
                            <h5>Submit & Wait</h5>
                            <p>Submit your application and await our review team's response</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Application Form -->
        <section class="py-5">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-10">
                        <div class="application-card">
                            <div class="card-header">
                                <h4>REACH Organization Application Form</h4>
                                <p class="text-white mb-0">Please fill out all sections completely and accurately</p>
                            </div>
                            
                            <div class="card-body">
                                <?php if (isset($_SESSION['user_id'])): ?>
                                    <!-- Success Message for Registration Redirect -->
                                    <?php if (isset($_GET['registered']) && $_GET['registered'] === 'success'): ?>
                                        <div class="alert alert-success">
                                            <i class="fas fa-check-circle me-2"></i>
                                            Welcome! You can now complete your application for the program.
                                        </div>
                                    <?php endif; ?>

                                    <!-- Program Information Display -->
                                    <?php if ($selected_program && $program_details): ?>
                                        <div class="program-info-card text-center">
                                            <div class="program-icon-large">
                                                <?php 
                                                $icons = [
                                                    'scholarship' => 'fa-graduation-cap',
                                                    'housing' => 'fa-home',
                                                    'community' => 'fa-users',
                                                    'mentorship' => 'fa-handshake'
                                                ];
                                                $icon = $icons[$selected_program] ?? 'fa-star';
                                                ?>
                                                <i class="fas <?php echo $icon; ?>"></i>
                                            </div>
                                            <h5 class="text-primary mb-2">Applying for: <?php echo htmlspecialchars($program_details['name']); ?></h5>
                                            <p class="mb-2"><?php echo htmlspecialchars($program_details['description']); ?></p>
                                            <?php if ($program_details['eligibility_criteria']): ?>
                                                <p class="small text-muted mb-0">
                                                    <strong>Eligibility:</strong> <?php echo htmlspecialchars($program_details['eligibility_criteria']); ?>
                                                </p>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>

                                    <!-- Application Form for Logged-in Users -->
                                    <form id="applicationForm" enctype="multipart/form-data">
                                        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                        
                                        <!-- Program Selection -->
                                        <div class="form-section">
                                            <h5 class="section-title">
                                                <i class="fas fa-project-diagram me-2"></i>Program Selection
                                            </h5>
                                            
                                            <?php if ($selected_program): ?>
                                                <!-- Hidden field for pre-selected program -->
                                                <input type="hidden" name="program_type" value="<?php echo htmlspecialchars($selected_program); ?>">
                                                <div class="alert alert-info">
                                                    <i class="fas fa-info-circle me-2"></i>
                                                    You are applying for the <strong><?php echo htmlspecialchars($program_details['name'] ?? ucfirst($selected_program)); ?></strong> program.
                                                    <a href="apply.php" class="alert-link ms-2">Change program</a>
                                                </div>
                                            <?php else: ?>
                                                <!-- Program Selection Dropdown -->
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="mb-3">
                                                            <label class="form-label">Program Type *</label>
                                                            <select class="form-select" name="program_type" id="program_type" required>
                                                                <option value="">Select a program</option>
                                                                <?php foreach ($activePrograms as $program): ?>
                                                                    <option value="<?php echo htmlspecialchars($program['type']); ?>" 
                                                                            <?php echo ($selected_program === $program['type']) ? 'selected' : ''; ?>>
                                                                        <?php echo htmlspecialchars($program['name']); ?>
                                                                    </option>
                                                                <?php endforeach; ?>
                                                            </select>
                                                            <div class="program-info alert alert-info mt-2" id="program_info" style="display: none;"></div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="mb-3">
                                                            <label class="form-label">Academic Level *</label>
                                                            <select class="form-select" name="academic_level" required>
                                                                <option value="">Select academic level</option>
                                                                <option value="high_school">High School</option>
                                                                <option value="undergraduate">Undergraduate</option>
                                                                <option value="masters">Masters</option>
                                                                <option value="phd">PhD</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                            
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label class="form-label">Institution Applying To *</label>
                                                        <input type="text" class="form-control" name="institution_applying" 
                                                               placeholder="e.g., University of Rwanda, Kepler College" required>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label class="form-label">Intended Major/Field *</label>
                                                        <input type="text" class="form-control" name="intended_major" 
                                                               placeholder="e.g., Computer Science, Medicine, Business" required>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Academic Information -->
                                        <div class="form-section">
                                            <h5 class="section-title">
                                                <i class="fas fa-graduation-cap me-2"></i>Academic Information
                                            </h5>
                                            
                                            <div class="mb-3">
                                                <label class="form-label">Academic History *</label>
                                                <textarea class="form-control" name="academic_history" rows="4" maxlength="2000"
                                                          placeholder="Describe your academic background, schools attended, qualifications, achievements, and any relevant academic experiences" required></textarea>
                                                <div class="form-text text-end">
                                                    <span class="char-count">0</span> / <span class="char-max">2000</span> characters
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Financial Information -->
                                        <div class="form-section">
                                            <h5 class="section-title">
                                                <i class="fas fa-money-bill-wave me-2"></i>Financial Information
                                            </h5>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label class="form-label">Annual Family Income (USD) *</label>
                                                        <input type="number" class="form-control" name="family_income" step="0.01" min="0" max="1000000"
                                                               placeholder="e.g., 5000.00" required>
                                                        <div class="form-text">Please enter the total annual income for your family</div>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label class="form-label">Financial Needs *</label>
                                                <textarea class="form-control" name="financial_needs" rows="4" maxlength="1500"
                                                          placeholder="Describe your financial situation, challenges, why you need support, and how this program will help you" required></textarea>
                                                <div class="form-text text-end">
                                                    <span class="char-count">0</span> / <span class="char-max">1500</span> characters
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Personal Statement -->
                                        <div class="form-section">
                                            <h5 class="section-title">
                                                <i class="fas fa-edit me-2"></i>Personal Statement
                                            </h5>
                                            <div class="mb-4">
                                                <label class="form-label">Personal Statement *</label>
                                                <textarea class="form-control" name="personal_statement" rows="6" maxlength="3000"
                                                          placeholder="Tell us about yourself, your goals, motivations, community involvement, and why you deserve this opportunity. Include your future aspirations and how you plan to give back to the community." required></textarea>
                                                <div class="form-text text-end">
                                                    <span class="char-count">0</span> / <span class="char-max">3000</span> characters
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Document Upload -->
                                        <div class="form-section">
                                            <h5 class="section-title">
                                                <i class="fas fa-file-upload me-2"></i>Required Documents
                                            </h5>
                                            <div class="alert alert-info">
                                                <i class="fas fa-info-circle me-2"></i>
                                                Please upload clear scanned copies of the following documents (PDF, JPG, PNG, max 5MB each, max 5 files total)
                                            </div>
                                            
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label class="form-label">Supporting Documents</label>
                                                        <input type="file" class="form-control" name="documents[]" multiple 
                                                               accept=".pdf,.jpg,.jpeg,.png,.doc,.docx">
                                                        <small class="form-text text-muted">Upload required documents: ID, transcripts, certificates, etc.</small>
                                                        <div class="file-preview" id="documents-preview"></div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label class="form-label">Reference Letters</label>
                                                        <input type="file" class="form-control" name="reference_letters[]" multiple 
                                                               accept=".pdf,.jpg,.jpeg,.png,.doc,.docx">
                                                        <small class="form-text text-muted">Recommendation letters from teachers, mentors, or community leaders</small>
                                                        <div class="file-preview" id="references-preview"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Declaration -->
                                        <div class="form-section">
                                            <div class="form-check mb-3">
                                                <input class="form-check-input" type="checkbox" name="declaration" id="declaration" required>
                                                <label class="form-check-label" for="declaration">
                                                    I hereby declare that all information provided in this application is true and accurate to the best of my knowledge. 
                                                    I understand that providing false information may lead to disqualification from the program.
                                                </label>
                                            </div>
                                            
                                            <div class="form-check mb-4">
                                                <input class="form-check-input" type="checkbox" name="privacy_agreement" id="privacy_agreement" required>
                                                <label class="form-check-label" for="privacy_agreement">
                                                    I agree to the processing of my personal data for the purpose of this application and program administration, 
                                                    in accordance with REACH Organization's Privacy Policy.
                                                </label>
                                            </div>
                                        </div>

                                        <!-- Submit Button -->
                                        <div class="text-center">
                                            <button type="submit" class="btn btn-primary btn-lg">
                                                <i class="fas fa-paper-plane me-2"></i>Submit Application
                                            </button>
                                        </div>
                                    </form>
                                <?php else: ?>
                                    <!-- Login/Register Prompt -->
                                    <div class="text-center py-5">
                                        <i class="fas fa-lock fa-3x text-muted mb-3"></i>
                                        <h4>Authentication Required</h4>
                                        <p class="text-muted mb-4">
                                            Please log in to your account or create a new one to access the application form.
                                        </p>
                                        <div class="auth-actions">
                                            <a href="../login.php?redirect=<?php echo urlencode($_SERVER['REQUEST_URI']); ?>" class="btn btn-primary me-3">
                                                <i class="fas fa-sign-in-alt me-2"></i>Login to Apply
                                            </a>
                                            <a href="../register.php?redirect=<?php echo urlencode($_SERVER['REQUEST_URI']); ?>" class="btn btn-outline-primary">
                                                <i class="fas fa-user-plus me-2"></i>Create Account
                                            </a>
                                        </div>
                                        <div class="mt-4">
                                            <small class="text-muted">
                                                Don't have an account? <a href="../register.php?redirect=<?php echo urlencode($_SERVER['REQUEST_URI']); ?>">Register here</a>
                                            </small>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- FAQ Section -->
        <section class="py-5 bg-light">
            <div class="container">
                <div class="text-center mb-5">
                    <h2 class="section-title">Frequently Asked Questions</h2>
                    <p class="section-subtitle">Find answers to common questions about our application process</p>
                </div>
                
                <div class="row justify-content-center">
                    <div class="col-lg-8">
                        <div class="accordion" id="applicationFAQ">
                            <div class="accordion-item">
                                <h2 class="accordion-header">
                                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#faq1">
                                        Do I need an account to apply?
                                    </button>
                                </h2>
                                <div id="faq1" class="accordion-collapse collapse show" data-bs-parent="#applicationFAQ">
                                    <div class="accordion-body">
                                        Yes, you need to create a free account to access the application form. This allows us to securely store your application and enables you to track its status.
                                    </div>
                                </div>
                            </div>
                            
                            <div class="accordion-item">
                                <h2 class="accordion-header">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq2">
                                        What are the eligibility criteria for REACH programs?
                                    </button>
                                </h2>
                                <div id="faq2" class="accordion-collapse collapse" data-bs-parent="#applicationFAQ">
                                    <div class="accordion-body">
                                        Eligibility varies by program, but generally includes: Rwandan citizenship or legal residency, 
                                        demonstrated financial need, strong academic record, acceptance to an accredited institution 
                                        (for scholarships), and commitment to community service.
                                    </div>
                                </div>
                            </div>
                            
                            <div class="accordion-item">
                                <h2 class="accordion-header">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq3">
                                        How long does the application review process take?
                                    </button>
                                </h2>
                                <div id="faq3" class="accordion-collapse collapse" data-bs-parent="#applicationFAQ">
                                    <div class="accordion-body">
                                        The review process typically takes 2-3 weeks. You will receive an email notification once 
                                        your application has been reviewed. Shortlisted candidates may be invited for an interview.
                                    </div>
                                </div>
                            </div>
                            
                            <div class="accordion-item">
                                <h2 class="accordion-header">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq4">
                                        Can I apply for multiple programs?
                                    </button>
                                </h2>
                                <div id="faq4" class="accordion-collapse collapse" data-bs-parent="#applicationFAQ">
                                    <div class="accordion-body">
                                        Yes, you can apply for multiple programs, but you must submit separate applications for each. 
                                        Please note that receiving one type of support may affect eligibility for others.
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Contact Support -->
        <section class="py-5">
            <div class="container text-center">
                <h2 class="section-title">Need Help with Your Application?</h2>
                <p class="section-subtitle mb-4">Our support team is here to assist you</p>
                <div class="support-actions">
                    <a href="../contact.php" class="btn btn-outline-primary me-3">
                        <i class="fas fa-envelope me-2"></i>Contact Support
                    </a>
                    <a href="../programs.php" class="btn btn-primary">
                        <i class="fas fa-info-circle me-2"></i>View Program Details
                    </a>
                </div>
            </div>
        </section>
    </div>

    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-4 mb-4">
                    <h5>REACH Organization</h5>
                    <p>Recognizing Each Action Can Help</p>
                    <div class="mt-3">
                        <a href="#" class="text-white me-3"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="text-white"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>
                <div class="col-lg-4 mb-4">
                    <h5>Quick Links</h5>
                    <div class="footer-links">
                        <div class="row">
                            <div class="col-6">
                                <a href="../about.php">About Us</a><br>
                                <a href="../programs.php">Programs</a><br>
                                <a href="../stories.php">Success Stories</a>
                            </div>
                            <div class="col-6">
                                <a href="apply.php">Apply</a><br>
                                <a href="../donate.php">Donate</a><br>
                                <a href="../contact.php">Contact</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 mb-4">
                    <h5>Contact Info</h5>
                    <p><i class="fas fa-map-marker-alt me-2"></i> Kigali, Rwanda</p>
                    <p><i class="fas fa-phone me-2"></i> +250 788 123 456</p>
                    <p><i class="fas fa-envelope me-2"></i> info@reach.org</p>
                </div>
            </div>
            <hr class="my-4">
            <div class="text-center">
                <p>&copy; 2024 REACH Organization. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Navbar scroll effect
        window.addEventListener('scroll', function() {
            const navbar = document.getElementById('mainNav');
            if (window.scrollY > 100) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });

        // Mobile menu enhancement
        document.addEventListener('DOMContentLoaded', function() {
            const navbarToggler = document.querySelector('.navbar-toggler');
            const navbarCollapse = document.querySelector('.navbar-collapse');

            if (navbarToggler && navbarCollapse) {
                navbarToggler.addEventListener('click', function() {
                    navbarCollapse.classList.toggle('show');
                });

                // Close mobile menu when clicking on a link
                document.querySelectorAll('.nav-link').forEach(link => {
                    link.addEventListener('click', () => {
                        if (navbarCollapse.classList.contains('show')) {
                            navbarCollapse.classList.remove('show');
                        }
                    });
                });
            }

            // Initialize all enhanced features
            initializeFilePreviews();
            initializeRealTimeValidation();
            initializeProgramInfo();
        });

        // Enhanced form validation and submission
        document.getElementById('applicationForm')?.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            console.log('Form submission started');
            
            // Clear previous errors
            clearValidationErrors();
            
            // Validate form
            if (!validateForm()) {
                console.log('Form validation failed');
                showAlert('Please fix the errors in the form before submitting.', 'warning');
                return;
            }
            
            console.log('Form validation passed');
            
            // Validate file uploads (files are now optional)
            try {
                validateFileUploads();
                console.log('File validation passed');
            } catch (error) {
                console.log('File validation failed:', error.message);
                showAlert(error.message, 'danger');
                return;
            }
            
            const submitBtn = this.querySelector('button[type="submit"]');
            const originalText = submitBtn.innerHTML;
            let loadingOverlay = null;
            
            try {
                console.log('Starting submission process');
                
                // Show loading overlay
                loadingOverlay = showLoadingOverlay();
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Submitting...';
                submitBtn.disabled = true;
                submitBtn.classList.add('loading');
                
                const formData = new FormData(this);
                
                // Debug: Log form data
                console.log('FormData created, entries:', Array.from(formData.entries()));
                console.log('Submitting to: ../../api/applications/submit.php');
                
                const response = await fetch('../../api/applications/submit.php', {
                    method: 'POST',
                    body: formData
                });
                
                console.log('Response received, status:', response.status);
                
                if (!response.ok) {
                    throw new Error(`Server returned ${response.status}: ${response.statusText}`);
                }
                
                const result = await response.json();
                console.log('Response JSON:', result);
                
                if (result.success) {
                    console.log('Submission successful');
                    showAlert(`Application submitted successfully! Your application code: ${result.application_code}`, 'success');
                    
                    // Redirect to application status page after 3 seconds
                    setTimeout(() => {
                        window.location.href = result.redirect || '../../portal/student/dashboard.php';
                    }, 3000);
                } else {
                    console.log('Submission failed:', result.message);
                    throw new Error(result.message || 'Unknown error occurred');
                }
                
            } catch (error) {
                console.error('Submission error:', error);
                showAlert('Error: ' + error.message, 'danger');
            } finally {
                console.log('Cleaning up...');
                if (loadingOverlay) {
                    hideLoadingOverlay(loadingOverlay);
                }
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
                submitBtn.classList.remove('loading');
            }
        });

        // Enhanced file validation - files are now optional
        function validateFileUploads() {
            const maxFiles = 5;
            const maxFileSize = 5 * 1024 * 1024; // 5MB per file
            const allowedTypes = ['application/pdf', 'image/jpeg', 'image/png', 'image/jpg', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
            
            const documents = document.querySelector('input[name="documents[]"]').files;
            const references = document.querySelector('input[name="reference_letters[]"]').files;
            
            let totalFiles = documents.length + references.length;
            
            // Files are now optional - no error if no files
            if (totalFiles === 0) {
                console.log('No files uploaded - this is optional');
                return true;
            }
            
            if (totalFiles > maxFiles) {
                throw new Error(`Maximum ${maxFiles} files allowed total`);
            }
            
            // Check all files if any are uploaded
            for (let file of documents) {
                if (file.size > maxFileSize) {
                    throw new Error(`File too large: ${file.name}. Maximum size is 5MB per file.`);
                }
                if (!allowedTypes.includes(file.type)) {
                    throw new Error(`Invalid file type: ${file.name}. Only PDF, JPG, PNG, DOC, DOCX allowed.`);
                }
            }
            
            for (let file of references) {
                if (file.size > maxFileSize) {
                    throw new Error(`File too large: ${file.name}. Maximum size is 5MB per file.`);
                }
                if (!allowedTypes.includes(file.type)) {
                    throw new Error(`Invalid file type: ${file.name}. Only PDF, JPG, PNG, DOC, DOCX allowed.`);
                }
            }
            
            return true;
        }

        function validateForm() {
            let isValid = true;
            const form = document.getElementById('applicationForm');
            
            // Required fields validation
            const requiredFields = form.querySelectorAll('[required]');
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    markFieldInvalid(field, 'This field is required');
                    isValid = false;
                } else {
                    markFieldValid(field);
                }
            });
            
            // File validation - files are now optional, so no validation needed
            const documents = form.querySelector('input[name="documents[]"]');
            const references = form.querySelector('input[name="reference_letters[]"]');
            
            // Mark file fields as valid regardless (they're optional)
            markFieldValid(documents);
            markFieldValid(references);
            
            // Income validation
            const incomeField = form.querySelector('input[name="family_income"]');
            if (incomeField && incomeField.value) {
                const income = parseFloat(incomeField.value);
                if (income < 0) {
                    markFieldInvalid(incomeField, 'Income cannot be negative');
                    isValid = false;
                } else if (income > 1000000) {
                    markFieldInvalid(incomeField, 'Please enter a reasonable income amount');
                    isValid = false;
                }
            }
            
            // Checkbox validation
            const declaration = form.querySelector('#declaration');
            const privacy = form.querySelector('#privacy_agreement');
            
            if (!declaration.checked) {
                markFieldInvalid(declaration, 'You must accept the declaration');
                isValid = false;
            } else {
                markFieldValid(declaration);
            }
            
            if (!privacy.checked) {
                markFieldInvalid(privacy, 'You must accept the privacy agreement');
                isValid = false;
            } else {
                markFieldValid(privacy);
            }
            
            return isValid;
        }

        function markFieldInvalid(field, message) {
            field.classList.add('is-invalid');
            field.classList.remove('is-valid');
            
            // Remove existing feedback
            const existingFeedback = field.parentNode.querySelector('.invalid-feedback');
            if (existingFeedback) {
                existingFeedback.remove();
            }
            
            // Add feedback message
            const feedback = document.createElement('div');
            feedback.className = 'invalid-feedback';
            feedback.textContent = message;
            field.parentNode.appendChild(feedback);
        }

        function markFieldValid(field) {
            field.classList.remove('is-invalid');
            field.classList.add('is-valid');
            
            // Remove existing feedback
            const existingFeedback = field.parentNode.querySelector('.invalid-feedback');
            if (existingFeedback) {
                existingFeedback.remove();
            }
        }

        function clearValidationErrors() {
            const form = document.getElementById('applicationForm');
            const invalidFields = form.querySelectorAll('.is-invalid');
            invalidFields.forEach(field => {
                field.classList.remove('is-invalid');
                const feedback = field.parentNode.querySelector('.invalid-feedback');
                if (feedback) {
                    feedback.remove();
                }
            });
        }

        function showAlert(message, type) {
            // Remove existing alerts
            const existingAlerts = document.querySelectorAll('.alert');
            existingAlerts.forEach(alert => alert.remove());
            
            const alertDiv = document.createElement('div');
            alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
            alertDiv.innerHTML = `
                ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            `;
            
            document.querySelector('.application-card').prepend(alertDiv);
            
            // Auto-remove after 5 seconds
            setTimeout(() => {
                if (alertDiv.parentNode) {
                    alertDiv.remove();
                }
            }, 5000);
        }

        // File preview functionality
        function initializeFilePreviews() {
            const documentsInput = document.querySelector('input[name="documents[]"]');
            const referencesInput = document.querySelector('input[name="reference_letters[]"]');
            const documentsPreview = document.getElementById('documents-preview');
            const referencesPreview = document.getElementById('references-preview');

            if (documentsInput) {
                documentsInput.addEventListener('change', function() {
                    updateFilePreview(this, documentsPreview);
                });
            }

            if (referencesInput) {
                referencesInput.addEventListener('change', function() {
                    updateFilePreview(this, referencesPreview);
                });
            }
        }

        function updateFilePreview(input, previewContainer) {
            previewContainer.innerHTML = '';
            
            if (input.files.length > 0) {
                const fileList = document.createElement('div');
                fileList.className = 'file-list';
                
                for (let file of input.files) {
                    const fileItem = document.createElement('div');
                    fileItem.className = 'file-preview-item';
                    
                    const fileName = document.createElement('span');
                    fileName.className = 'file-name';
                    fileName.textContent = file.name;
                    
                    const fileSize = document.createElement('span');
                    fileSize.className = 'file-size text-muted';
                    fileSize.textContent = formatFileSize(file.size);
                    
                    fileItem.appendChild(fileName);
                    fileItem.appendChild(fileSize);
                    fileList.appendChild(fileItem);
                }
                
                previewContainer.appendChild(fileList);
            }
        }

        function formatFileSize(bytes) {
            if (bytes === 0) return '0 Bytes';
            const k = 1024;
            const sizes = ['Bytes', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
        }

        // Real-time validation and character counters
        function initializeRealTimeValidation() {
            const textareas = document.querySelectorAll('textarea[required]');
            textareas.forEach(textarea => {
                const charCount = textarea.parentNode.querySelector('.char-count');
                const charMax = textarea.parentNode.querySelector('.char-max');
                
                if (charCount && charMax) {
                    textarea.addEventListener('input', function() {
                        const count = this.value.length;
                        charCount.textContent = count;
                        
                        if (this.maxLength && count > this.maxLength * 0.8) {
                            charCount.classList.add('text-warning');
                        } else {
                            charCount.classList.remove('text-warning');
                        }
                    });
                }
            });
            
            // Income field validation
            const incomeField = document.querySelector('input[name="family_income"]');
            if (incomeField) {
                incomeField.addEventListener('blur', function() {
                    const value = parseFloat(this.value);
                    if (value < 0) {
                        markFieldInvalid(this, 'Income cannot be negative');
                    } else if (value > 1000000) {
                        markFieldInvalid(this, 'Please enter a reasonable income amount');
                    } else {
                        markFieldValid(this);
                    }
                });
            }
        }

        // Program information display
        function initializeProgramInfo() {
            const programSelect = document.querySelector('#program_type');
            const programInfo = document.querySelector('#program_info');
            
            const programData = {
                scholarship: {
                    description: 'Full or partial tuition coverage for academic programs',
                    requirements: 'Academic transcripts, admission letter, financial need documentation',
                    deadline: 'Rolling admissions'
                },
                housing: {
                    description: 'Safe and affordable accommodation for students',
                    requirements: 'Proof of enrollment, housing need assessment',
                    deadline: 'Before semester start'
                },
                community: {
                    description: 'Community development and skills training programs',
                    requirements: 'Community involvement, project proposal',
                    deadline: 'Quarterly cycles'
                },
                mentorship: {
                    description: 'One-on-one guidance and career development',
                    requirements: 'Career goals statement, availability commitment',
                    deadline: 'Monthly intakes'
                }
            };
            
            programSelect?.addEventListener('change', function() {
                const selectedProgram = this.value;
                if (selectedProgram && programData[selectedProgram]) {
                    const info = programData[selectedProgram];
                    programInfo.innerHTML = `
                        <strong>${this.options[this.selectedIndex].text}</strong><br>
                        ${info.description}<br>
                        <small><strong>Requirements:</strong> ${info.requirements}</small><br>
                        <small><strong>Deadline:</strong> ${info.deadline}</small>
                    `;
                    programInfo.style.display = 'block';
                } else {
                    programInfo.style.display = 'none';
                }
            });
        }

        // Loading overlay functions
        function showLoadingOverlay() {
            const overlay = document.createElement('div');
            overlay.className = 'loading-overlay';
            overlay.innerHTML = `
                <div class="text-center">
                    <div class="spinner-border text-primary mb-3" style="width: 3rem; height: 3rem;" role="status"></div>
                    <h5 class="text-primary">Submitting your application...</h5>
                    <p class="text-muted">Please don't close this window</p>
                </div>
            `;
            document.body.appendChild(overlay);
            return overlay;
        }
        function hideLoadingOverlay(overlay) {
            if (overlay && overlay.parentNode) {
                overlay.parentNode.removeChild(overlay);
            }
        }
    </script>
</body>
</html>