<?php
// public/stories-single.php
session_start();

require_once '../includes/config.php';
require_once '../includes/functions.php';

$slug = $_GET['slug'] ?? '';

if (empty($slug)) {
    header('Location: stories.php');
    exit;
}

// Get story by slug
function getStoryBySlug($slug) {
    global $pdo;
    
    try {
        $sql = "SELECT s.*, u.full_name as author_name, u.profile_picture as author_image 
                FROM stories s 
                LEFT JOIN users u ON s.author_id = u.id 
                WHERE s.slug = ? AND s.status = 'published'";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$slug]);
        $story = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Increment view count
        if ($story) {
            $update_sql = "UPDATE stories SET view_count = view_count + 1 WHERE id = ?";
            $update_stmt = $pdo->prepare($update_sql);
            $update_stmt->execute([$story['id']]);
        }
        
        return $story;
        
    } catch (PDOException $e) {
        error_log("Database error in getStoryBySlug: " . $e->getMessage());
        return null;
    }
}

$story = getStoryBySlug($slug);

if (!$story) {
    header('Location: stories.php');
    exit;
}

// Get related stories
function getRelatedStories($current_story_id, $story_type, $limit = 3) {
    global $pdo;
    
    try {
        $sql = "SELECT s.*, u.full_name as author_name 
                FROM stories s 
                LEFT JOIN users u ON s.author_id = u.id 
                WHERE s.id != ? AND s.story_type = ? AND s.status = 'published' 
                ORDER BY s.published_at DESC 
                LIMIT ?";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$current_story_id, $story_type, $limit]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
        
    } catch (PDOException $e) {
        error_log("Database error in getRelatedStories: " . $e->getMessage());
        return [];
    }
}

$relatedStories = getRelatedStories($story['id'], $story['story_type'], 3);
?>
<!DOCTYPE html>
<html lang="en" class="h-100">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($story['title']); ?> | REACH - Recognizing Each Action Can Help</title>
    
    <!-- Meta Tags -->
    <meta name="description" content="<?php echo htmlspecialchars($story['excerpt'] ?? $story['seo_description'] ?? 'Read this inspiring success story from REACH Organization'); ?>">
    <meta name="keywords" content="REACH story, <?php echo htmlspecialchars($story['story_type']); ?>, student success, Rwanda education, transformation story">
    <meta name="author" content="REACH Organization">
    
    <!-- Open Graph -->
    <meta property="og:title" content="<?php echo htmlspecialchars($story['title']); ?> | REACH Organization">
    <meta property="og:description" content="<?php echo htmlspecialchars($story['excerpt'] ?? 'Inspiring story of transformation through education and community support'); ?>">
    <meta property="og:type" content="article">
    <meta property="og:url" content="https://reach.org/stories-single.php?slug=<?php echo $slug; ?>">
    
    <!-- PWA Meta Tags -->
    <meta name="theme-color" content="#3498db">
    
    <!-- Preload Resources -->
    <link rel="preload" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" as="style">
    <link rel="preload" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" as="style">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css" rel="stylesheet">
    
    <style>
        /* Reuse the same CSS variables and base styles from index */
        :root {
            --primary: #3498db;
            --secondary: #2c3e50;
            --success: #27ae60;
            --light: #f8f9fa;
            --reach-accent: #ea4335;
            --reach-warning: #f39c12;
            --gradient-primary: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            --gradient-dark: linear-gradient(135deg, #2980b9 0%, #1c2833 100%);
            --gradient-light: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            --shadow-sm: 0 2px 8px rgba(0,0,0,0.08);
            --shadow-md: 0 8px 30px rgba(0,0,0,0.12);
            --shadow-lg: 0 15px 35px rgba(0,0,0,0.15);
            --border-radius-sm: 12px;
            --border-radius-md: 20px;
            --border-radius-lg: 28px;
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html {
            height: 100%;
            font-size: 16px;
            scroll-behavior: smooth;
        }

        body {
            min-height: 100vh;
            min-height: 100dvh;
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            line-height: 1.6;
            color: var(--secondary);
            overflow-x: hidden;
            padding-top: 80px; /* Add padding for fixed navbar */
        }

        /* Enhanced Navigation - Same as index */
        .navbar {
            background: rgba(44, 62, 80, 0.95) !important;
            backdrop-filter: blur(20px);
            padding: 1rem 0;
            transition: var(--transition);
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .navbar.scrolled {
            background: rgba(44, 62, 80, 0.98) !important;
            padding: 0.75rem 0;
            box-shadow: var(--shadow-md);
        }

        .brand-content {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .brand-text {
            line-height: 1.2;
        }

        .brand-text strong {
            font-size: 1.4rem;
            font-weight: 700;
            display: block;
            color: white;
        }

        .brand-text small {
            font-size: 0.75rem;
            opacity: 0.8;
            font-weight: 400;
            color: rgba(255,255,255,0.8);
        }

        .navbar-brand i {
            font-size: 1.8rem;
            color: var(--success);
        }

        .nav-link {
            font-weight: 500;
            padding: 0.5rem 1rem !important;
            border-radius: var(--border-radius-sm);
            transition: var(--transition);
            margin: 0.125rem;
            color: rgba(255,255,255,0.9);
        }

        .nav-link:hover,
        .nav-link.active {
            background: rgba(255,255,255,0.1);
            transform: translateY(-1px);
            color: white;
        }

        .dropdown-menu {
            background: rgba(255,255,255,0.95);
            backdrop-filter: blur(20px);
            border: none;
            border-radius: var(--border-radius-sm);
            box-shadow: var(--shadow-lg);
            padding: 0.5rem;
        }

        .dropdown-item {
            border-radius: 8px;
            padding: 0.75rem 1rem;
            transition: var(--transition);
        }

        .dropdown-item:hover {
            background: var(--primary);
            color: white;
            transform: translateX(5px);
        }

        .navbar-actions {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            flex-wrap: wrap;
        }

        .navbar-actions .btn {
            padding: 0.5rem 1.25rem;
            border-radius: var(--border-radius-sm);
            font-weight: 500;
            transition: var(--transition);
            white-space: nowrap;
        }

        /* Story Hero Section */
        .story-hero {
            background: var(--gradient-primary);
            color: white;
            padding: 80px 0;
            margin-top: -80px; /* Compensate for body padding */
        }

        .story-hero::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 800" opacity="0.1"><polygon fill="white" points="0,800 1200,400 1200,800"/></svg>');
            background-size: cover;
            animation: float 20s ease-in-out infinite;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0px) rotate(0deg); }
            50% { transform: translateY(-20px) rotate(1deg); }
        }

        .story-hero-content {
            position: relative;
            z-index: 2;
        }

        .story-type-badge {
            font-size: 0.875rem;
            padding: 0.5rem 1rem;
            border-radius: 20px;
            background: rgba(255,255,255,0.2);
            color: white;
            display: inline-block;
            margin-bottom: 1.5rem;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255,255,255,0.3);
        }

        .story-title {
            font-size: clamp(2rem, 5vw, 3.5rem);
            font-weight: 800;
            line-height: 1.1;
            margin-bottom: 1.5rem;
            color: white;
            text-shadow: 0 2px 15px rgba(0,0,0,0.3);
        }

        .story-meta {
            display: flex;
            gap: 2rem;
            flex-wrap: wrap;
            margin-bottom: 2rem;
        }

        .meta-item {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.95rem;
            opacity: 0.9;
        }

        .meta-item i {
            color: #ffd700;
        }

        .author-info {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem;
            background: rgba(255,255,255,0.1);
            border-radius: var(--border-radius-sm);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255,255,255,0.2);
        }

        .author-avatar {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid rgba(255,255,255,0.3);
        }

        .author-details h5 {
            margin: 0;
            color: white;
            font-weight: 600;
        }

        .author-details p {
            margin: 0;
            opacity: 0.9;
            font-size: 0.9rem;
        }

        /* Story Content Section */
        .story-content-section {
            padding: 80px 0;
        }

        .story-featured-image {
            margin-bottom: 3rem;
            border-radius: var(--border-radius-md);
            overflow: hidden;
            box-shadow: var(--shadow-lg);
        }

        .story-featured-image img {
            width: 100%;
            height: auto;
            display: block;
        }

        .story-content {
            font-size: 1.1rem;
            line-height: 1.8;
            color: var(--secondary);
        }

        .story-content h2 {
            font-size: 1.8rem;
            font-weight: 700;
            margin: 2.5rem 0 1.5rem 0;
            color: var(--secondary);
            border-bottom: 2px solid var(--primary);
            padding-bottom: 0.5rem;
        }

        .story-content h3 {
            font-size: 1.5rem;
            font-weight: 600;
            margin: 2rem 0 1rem 0;
            color: var(--secondary);
        }

        .story-content p {
            margin-bottom: 1.5rem;
        }

        .story-content blockquote {
            border-left: 4px solid var(--primary);
            padding-left: 1.5rem;
            margin: 2rem 0;
            font-style: italic;
            color: #6c757d;
            background: var(--light);
            padding: 1.5rem;
            border-radius: var(--border-radius-sm);
        }

        .story-content img {
            max-width: 100%;
            height: auto;
            border-radius: var(--border-radius-sm);
            margin: 1.5rem 0;
            box-shadow: var(--shadow-sm);
        }

        /* Story Footer */
        .story-footer {
            background: var(--light);
            padding: 3rem 0;
            margin-top: 4rem;
            border-radius: var(--border-radius-md);
        }

        .tags-container .badge {
            font-size: 0.8rem;
            padding: 0.5rem 1rem;
            margin: 0.25rem;
            background: var(--primary);
            color: white;
            border-radius: 20px;
            transition: var(--transition);
        }

        .tags-container .badge:hover {
            background: var(--secondary);
            transform: translateY(-2px);
        }

        .social-share .btn {
            border-radius: 50%;
            width: 45px;
            height: 45px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin: 0 0.25rem;
            transition: var(--transition);
        }

        .social-share .btn:hover {
            transform: translateY(-3px);
        }

        /* Related Stories */
        .related-stories-section {
            padding: 80px 0;
            background: var(--light);
        }

        .section-title {
            font-size: 2.5rem;
            font-weight: bold;
            color: var(--secondary);
            margin-bottom: 3rem;
            text-align: center;
        }

        .related-story-card {
            background: white;
            border-radius: var(--border-radius-md);
            overflow: hidden;
            box-shadow: var(--shadow-sm);
            transition: var(--transition);
            height: 100%;
        }

        .related-story-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-md);
        }

        .related-story-image {
            position: relative;
            height: 200px;
            overflow: hidden;
        }

        .related-story-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: var(--transition);
        }

        .related-story-card:hover .related-story-image img {
            transform: scale(1.05);
        }

        .related-story-content {
            padding: 1.5rem;
        }

        .related-story-title {
            font-size: 1.1rem;
            font-weight: 600;
            margin-bottom: 0.75rem;
            line-height: 1.4;
        }

        .related-story-title a {
            color: inherit;
            text-decoration: none;
            transition: var(--transition);
        }

        .related-story-title a:hover {
            color: var(--primary);
        }

        .related-story-meta {
            font-size: 0.85rem;
            color: #6c757d;
        }

        /* CTA Section */
        .cta-section {
            padding: 80px 0;
            background: var(--gradient-primary);
            color: white;
            text-align: center;
        }

        .cta-title {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 1rem;
            color: white;
        }

        .cta-description {
            font-size: 1.2rem;
            margin-bottom: 2.5rem;
            opacity: 0.9;
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
        }

        /* Breadcrumb */
        .breadcrumb-nav {
            background: transparent;
            padding: 0;
            margin-bottom: 2rem;
        }

        .breadcrumb-item a {
            color: var(--primary);
            text-decoration: none;
            transition: var(--transition);
        }

        .breadcrumb-item a:hover {
            color: var(--secondary);
        }

        .breadcrumb-item.active {
            color: var(--secondary);
        }

        /* Footer - Same as index */
        footer {
            background: var(--secondary);
            color: white;
            padding: 3rem 0 1rem;
        }

        .footer-links a {
            color: #bdc3c7;
            text-decoration: none;
            transition: color 0.3s;
        }

        .footer-links a:hover {
            color: white;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .navbar-actions {
                justify-content: center;
                margin-top: 1rem;
                width: 100%;
            }

            .navbar-actions .btn {
                flex: 1;
                min-width: 120px;
                text-align: center;
            }

            .story-meta {
                flex-direction: column;
                gap: 1rem;
            }

            .author-info {
                flex-direction: column;
                text-align: center;
            }

            .story-content {
                font-size: 1rem;
            }
        }

        @media (max-width: 576px) {
            .brand-text strong {
                font-size: 1.2rem;
            }

            .brand-text small {
                font-size: 0.7rem;
            }

            .story-title {
                font-size: 1.8rem;
            }

            .section-title {
                font-size: 1.8rem;
            }

            .cta-title {
                font-size: 2rem;
            }
        }

        /* Focus styles for accessibility */
        .btn:focus,
        .nav-link:focus,
        .form-control:focus {
            outline: 2px solid var(--primary);
            outline-offset: 2px;
        }
    </style>
</head>
<body class="h-100">
    <!-- Enhanced Navigation - Same as index -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
        <div class="container">
            <a class="navbar-brand" href="../index.php">
                <div class="brand-content">
                    <i class="fas fa-hands-helping"></i>
                    <div class="brand-text">
                        <strong>REACH</strong>
                        <small>Recognizing Each Action Can Help</small>
                    </div>
                </div>
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMain"
                    aria-controls="navbarMain" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarMain">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item"><a class="nav-link" href="../index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="about.php">About</a></li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Programs
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="programs.php#scholarships">Scholarships</a></li>
                            <li><a class="dropdown-item" href="programs.php#housing">Student Housing</a></li>
                            <li><a class="dropdown-item" href="programs.php#community">Community Projects</a></li>
                        </ul>
                    </li>
                    <li class="nav-item"><a class="nav-link active" href="stories.php">Stories</a></li>
                    <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
                </ul>
                
                <div class="navbar-actions">
                    <a href="apply.php" class="btn btn-outline-light">
                        <i class="fas fa-edit me-1"></i>Apply
                    </a>
                    <a href="donate.php" class="btn btn-warning">
                        <i class="fas fa-heart me-1"></i>Donate
                    </a>
                    <a href="login.php" class="btn btn-outline-light">
                        <i class="fas fa-sign-in-alt me-1"></i>Login
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Story Hero Section -->
    <section class="story-hero">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 mx-auto">
                    <div class="story-hero-content">
                        <!-- Breadcrumb -->
                        <nav class="breadcrumb-nav" aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                                <li class="breadcrumb-item"><a href="stories.php">Stories</a></li>
                                <li class="breadcrumb-item active"><?php echo htmlspecialchars($story['title']); ?></li>
                            </ol>
                        </nav>

                        <span class="story-type-badge"><?php echo ucfirst($story['story_type']); ?> Story</span>
                        <h1 class="story-title" data-aos="fade-up"><?php echo htmlspecialchars($story['title']); ?></h1>
                        
                        <div class="story-meta" data-aos="fade-up" data-aos-delay="100">
                            <div class="meta-item">
                                <i class="fas fa-calendar"></i>
                                <span><?php echo date('F j, Y', strtotime($story['published_at'] ?? $story['created_at'])); ?></span>
                            </div>
                            <div class="meta-item">
                                <i class="fas fa-eye"></i>
                                <span><?php echo number_format($story['view_count'] ?? 0); ?> views</span>
                            </div>
                            <div class="meta-item">
                                <i class="fas fa-heart"></i>
                                <span><?php echo number_format($story['like_count'] ?? 0); ?> likes</span>
                            </div>
                        </div>

                        <div class="author-info" data-aos="fade-up" data-aos-delay="200">
                            <?php if (!empty($story['author_image'])): ?>
                                <img src="../assets/uploads/profiles/<?php echo $story['author_image']; ?>" 
                                     alt="<?php echo htmlspecialchars($story['author_name']); ?>" 
                                     class="author-avatar">
                            <?php else: ?>
                                <img src="https://placehold.co/60x60/3498db/ffffff?text=<?php echo substr($story['author_name'] ?? 'A', 0, 1); ?>" 
                                     alt="Author avatar" 
                                     class="author-avatar">
                            <?php endif; ?>
                            <div class="author-details">
                                <h5><?php echo htmlspecialchars($story['author_name'] ?? 'Unknown Author'); ?></h5>
                                <p>Story Author</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Story Content Section -->
    <section class="story-content-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 mx-auto">
                    <!-- Featured Image -->
                    <?php if (!empty($story['featured_image'])): ?>
                    <div class="story-featured-image" data-aos="fade-up">
                        <img src="../assets/uploads/stories/<?php echo $story['featured_image']; ?>" 
                             alt="<?php echo htmlspecialchars($story['title']); ?>">
                    </div>
                    <?php endif; ?>

                    <!-- Story Content -->
                    <article class="story-content" data-aos="fade-up" data-aos-delay="100">
                        <?php echo $story['content']; ?>
                    </article>

                    <!-- Story Footer -->
                    <footer class="story-footer" data-aos="fade-up">
                        <div class="row align-items-center">
                            <div class="col-md-6 mb-3 mb-md-0">
                                <div class="tags-container">
                                    <strong class="d-block mb-2">Tags:</strong>
                                    <?php if (!empty($story['tags'])): ?>
                                        <?php 
                                        $tags = json_decode($story['tags'], true) ?: explode(',', $story['tags']);
                                        foreach ($tags as $tag): ?>
                                            <span class="badge"><?php echo trim($tag); ?></span>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <span class="text-muted">No tags available</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6 text-md-end">
                                <div class="social-share">
                                    <strong class="d-block mb-2">Share this story:</strong>
                                    <a href="#" class="btn btn-primary">
                                        <i class="fab fa-facebook-f"></i>
                                    </a>
                                    <a href="#" class="btn btn-info">
                                        <i class="fab fa-twitter"></i>
                                    </a>
                                    <a href="#" class="btn btn-danger">
                                        <i class="fab fa-instagram"></i>
                                    </a>
                                    <a href="#" class="btn btn-secondary">
                                        <i class="fas fa-link"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </footer>
                </div>
            </div>
        </div>
    </section>

    <!-- Related Stories Section -->
    <?php if (!empty($relatedStories)): ?>
    <section class="related-stories-section">
        <div class="container">
            <h2 class="section-title" data-aos="fade-up">Related Stories</h2>
            <div class="row">
                <?php foreach ($relatedStories as $related): ?>
                <div class="col-lg-4 col-md-6 mb-4" data-aos="fade-up" data-aos-delay="<?php echo $loop->index * 100; ?>">
                    <article class="related-story-card">
                        <div class="related-story-image">
                            <?php if (!empty($related['featured_image'])): ?>
                                <img src="../assets/uploads/stories/<?php echo $related['featured_image']; ?>" 
                                     alt="<?php echo htmlspecialchars($related['title']); ?>">
                            <?php else: ?>
                                <img src="https://placehold.co/600x400/3498db/ffffff?text=REACH+Story" 
                                     alt="Default story image">
                            <?php endif; ?>
                        </div>
                        <div class="related-story-content">
                            <h3 class="related-story-title">
                                <a href="stories-single.php?slug=<?php echo $related['slug']; ?>">
                                    <?php echo htmlspecialchars($related['title']); ?>
                                </a>
                            </h3>
                            <div class="related-story-meta">
                                <span><?php echo date('M j, Y', strtotime($related['published_at'] ?? $related['created_at'])); ?></span>
                            </div>
                        </div>
                    </article>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- CTA Section -->
    <section class="cta-section">
        <div class="container">
            <h2 class="cta-title" data-aos="fade-up">Inspired by This Story?</h2>
            <p class="cta-description" data-aos="fade-up" data-aos-delay="100">
                Join REACH Organization and be part of transforming lives through education and community support.
            </p>
            <div class="hero-actions justify-content-center" data-aos="fade-up" data-aos-delay="200">
                <a href="apply.php" class="btn btn-hero btn-hero-primary">
                    <i class="fas fa-user-graduate me-2"></i>Apply Now
                </a>
                <a href="donate.php" class="btn btn-hero btn-hero-outline">
                    <i class="fas fa-hand-holding-heart me-2"></i>Support Our Mission
                </a>
            </div>
        </div>
    </section>

    <!-- Footer - Same as index -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-4 mb-4">
                    <h5>REACH Organization</h5>
                    <p>Recognizing Each Action Can Help</p>
                    <div class="mt-3">
                        <a href="#" class="text-white me-3"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="text-white"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>
                <div class="col-lg-4 mb-4">
                    <h5>Quick Links</h5>
                    <div class="footer-links">
                        <div class="row">
                            <div class="col-6">
                                <a href="about.php">About Us</a><br>
                                <a href="programs.php">Programs</a><br>
                                <a href="stories.php">Success Stories</a>
                            </div>
                            <div class="col-6">
                                <a href="apply.php">Apply</a><br>
                                <a href="donate.php">Donate</a><br>
                                <a href="contact.php">Contact</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 mb-4">
                    <h5>Contact Info</h5>
                    <p><i class="fas fa-map-marker-alt me-2"></i> Kigali, Rwanda</p>
                    <p><i class="fas fa-phone me-2"></i> +250 788 123 456</p>
                    <p><i class="fas fa-envelope me-2"></i> info@reach.org</p>
                </div>
            </div>
            <hr class="my-4">
            <div class="text-center">
                <p>&copy; 2024 REACH Organization. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    
    <script>
        // Initialize AOS
        AOS.init({
            duration: 800,
            once: true,
            offset: 100
        });

        // Navbar scroll effect - Same as index
        window.addEventListener('scroll', function() {
            const navbar = document.getElementById('mainNav');
            if (window.scrollY > 100) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });

        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });

        // Mobile menu enhancement
        document.addEventListener('DOMContentLoaded', function() {
            const navbarToggler = document.querySelector('.navbar-toggler');
            const navbarCollapse = document.querySelector('.navbar-collapse');

            if (navbarToggler && navbarCollapse) {
                navbarToggler.addEventListener('click', function() {
                    navbarCollapse.classList.toggle('show');
                });

                // Close mobile menu when clicking on a link
                document.querySelectorAll('.nav-link').forEach(link => {
                    link.addEventListener('click', () => {
                        if (navbarCollapse.classList.contains('show')) {
                            navbarCollapse.classList.remove('show');
                        }
                    });
                });
            }
        });

        // Social sharing functionality
        document.querySelectorAll('.social-share a').forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const url = window.location.href;
                const title = document.title;
                
                if (this.querySelector('.fa-facebook-f')) {
                    window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`, '_blank');
                } else if (this.querySelector('.fa-twitter')) {
                    window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(title)}&url=${encodeURIComponent(url)}`, '_blank');
                } else if (this.querySelector('.fa-instagram')) {
                    // Instagram doesn't support direct sharing, open in new tab
                    window.open('https://www.instagram.com/', '_blank');
                } else if (this.querySelector('.fa-link')) {
                    // Copy to clipboard
                    navigator.clipboard.writeText(url).then(() => {
                        alert('Link copied to clipboard!');
                    });
                }
            });
        });
    </script>
</body>
</html>