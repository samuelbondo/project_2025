<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include '../includes/config.php';
include '../includes/database.php';

$db = new Database();

$tables = ['users', 'stories', 'student_projects', 'programs'];

foreach ($tables as $table) {
    try {
        $db->query("SELECT 1 FROM $table LIMIT 1");
        $db->execute();
        echo "✅ Table '$table' exists<br>";
    } catch (Exception $e) {
        echo "❌ Table '$table' missing: " . $e->getMessage() . "<br>";
    }
}
?>