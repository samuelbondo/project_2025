<?php
// public/programs.php
session_start();

require_once '../includes/config.php';
require_once '../includes/functions.php';

// Function to get programs from database
function getActivePrograms() {
    global $pdo;
    
    try {
        $sql = "SELECT * FROM programs WHERE status = 'active' ORDER BY type, name";
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
        
    } catch (PDOException $e) {
        error_log("Database error in getActivePrograms: " . $e->getMessage());
        return [];
    }
}

// Get programs from database
$programs = getActivePrograms();

// Group programs by type for easier display
$programsByType = [
    'scholarship' => [],
    'housing' => [],
    'community' => [],
    'mentorship' => []
];

foreach ($programs as $program) {
    if (isset($programsByType[$program['type']])) {
        $programsByType[$program['type']][] = $program;
    }
}

// Fallback data if no programs in database
if (empty($programs)) {
    $fallbackPrograms = [
        [
            'id' => 1,
            'name' => 'Education Scholarship Program',
            'slug' => 'education-scholarship',
            'type' => 'scholarship',
            'description' => 'Full tuition coverage for underprivileged students pursuing higher education in Rwanda.',
            'eligibility_criteria' => 'Family income below $30,000, GPA 3.0+, Demonstrated financial need',
            'benefits' => 'Tuition coverage, Book allowance, Mentoring, Monthly stipend',
            'status' => 'active',
            'featured_image' => ''
        ],
        [
            'id' => 2,
            'name' => 'Student Housing Initiative',
            'slug' => 'student-housing',
            'type' => 'housing',
            'description' => 'Safe and affordable housing for students from rural areas pursuing education in urban centers.',
            'eligibility_criteria' => 'Enrolled in accredited institution, Demonstrated need for accommodation',
            'benefits' => 'Fully furnished housing, Utilities included, Meal plans, Security',
            'status' => 'active',
            'featured_image' => ''
        ],
        [
            'id' => 3,
            'name' => 'Community Development Program',
            'slug' => 'community-development',
            'type' => 'community',
            'description' => 'Skills training and community building initiatives that benefit entire communities.',
            'eligibility_criteria' => 'Age 18-35, Resident of target community, Commitment to program',
            'benefits' => 'Skills training, Job placement, Networking, Community support',
            'status' => 'active',
            'featured_image' => ''
        ],
        [
            'id' => 4,
            'name' => 'Youth Mentorship Program',
            'slug' => 'youth-mentorship',
            'type' => 'mentorship',
            'description' => 'One-on-one mentoring for career development and personal growth.',
            'eligibility_criteria' => 'Age 16-25, Commitment to program duration, Clear goals',
            'benefits' => 'Career guidance, Networking opportunities, Skill development, Personal coaching',
            'status' => 'active',
            'featured_image' => ''
        ]
    ];
    
    foreach ($fallbackPrograms as $program) {
        $programsByType[$program['type']][] = $program;
    }
    $programs = $fallbackPrograms;
}
?>
<!DOCTYPE html>
<html lang="en" class="h-100">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Our Programs | REACH - Recognizing Each Action Can Help</title>
    
    <!-- Meta Tags -->
    <meta name="description" content="Discover REACH Organization's comprehensive programs including scholarships, student housing, community development, and mentorship initiatives in Rwanda.">
    <meta name="keywords" content="REACH programs, scholarships Rwanda, student housing, community development, mentorship, education support">
    <meta name="author" content="REACH Organization">
    
    <!-- Open Graph -->
    <meta property="og:title" content="Our Programs | REACH Organization">
    <meta property="og:description" content="Comprehensive support systems designed to empower students and transform communities through education and development">
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://reach.org/programs">
    
    <!-- PWA Meta Tags -->
    <meta name="theme-color" content="#3498db">
    
    <!-- Preload Resources -->
    <link rel="preload" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" as="style">
    <link rel="preload" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" as="style">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css" rel="stylesheet">
    
    <style>
        /* Reuse the same CSS variables and base styles from index */
        :root {
            --primary: #3498db;
            --secondary: #2c3e50;
            --success: #27ae60;
            --light: #f8f9fa;
            --reach-accent: #ea4335;
            --reach-warning: #f39c12;
            --gradient-primary: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            --gradient-dark: linear-gradient(135deg, #2980b9 0%, #1c2833 100%);
            --gradient-light: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            --shadow-sm: 0 2px 8px rgba(0,0,0,0.08);
            --shadow-md: 0 8px 30px rgba(0,0,0,0.12);
            --shadow-lg: 0 15px 35px rgba(0,0,0,0.15);
            --border-radius-sm: 12px;
            --border-radius-md: 20px;
            --border-radius-lg: 28px;
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html {
            height: 100%;
            font-size: 16px;
            scroll-behavior: smooth;
        }

        body {
            min-height: 100vh;
            min-height: 100dvh;
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            line-height: 1.6;
            color: var(--secondary);
            overflow-x: hidden;
            padding-top: 80px; /* Add padding for fixed navbar */
        }

        /* Enhanced Navigation - Same as index */
        .navbar {
            background: rgba(44, 62, 80, 0.95) !important;
            backdrop-filter: blur(20px);
            padding: 1rem 0;
            transition: var(--transition);
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .navbar.scrolled {
            background: rgba(44, 62, 80, 0.98) !important;
            padding: 0.75rem 0;
            box-shadow: var(--shadow-md);
        }

        .brand-content {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .brand-text {
            line-height: 1.2;
        }

        .brand-text strong {
            font-size: 1.4rem;
            font-weight: 700;
            display: block;
            color: white;
        }

        .brand-text small {
            font-size: 0.75rem;
            opacity: 0.8;
            font-weight: 400;
            color: rgba(255,255,255,0.8);
        }

        .navbar-brand i {
            font-size: 1.8rem;
            color: var(--success);
        }

        .nav-link {
            font-weight: 500;
            padding: 0.5rem 1rem !important;
            border-radius: var(--border-radius-sm);
            transition: var(--transition);
            margin: 0.125rem;
            color: rgba(255,255,255,0.9);
        }

        .nav-link:hover,
        .nav-link.active {
            background: rgba(255,255,255,0.1);
            transform: translateY(-1px);
            color: white;
        }

        .dropdown-menu {
            background: rgba(255,255,255,0.95);
            backdrop-filter: blur(20px);
            border: none;
            border-radius: var(--border-radius-sm);
            box-shadow: var(--shadow-lg);
            padding: 0.5rem;
        }

        .dropdown-item {
            border-radius: 8px;
            padding: 0.75rem 1rem;
            transition: var(--transition);
        }

        .dropdown-item:hover {
            background: var(--primary);
            color: white;
            transform: translateX(5px);
        }

        .navbar-actions {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            flex-wrap: wrap;
        }

        .navbar-actions .btn {
            padding: 0.5rem 1.25rem;
            border-radius: var(--border-radius-sm);
            font-weight: 500;
            transition: var(--transition);
            white-space: nowrap;
        }

        /* Programs Hero Section */
        .programs-hero {
            background: var(--gradient-primary);
            color: white;
            min-height: 60vh;
            display: flex;
            align-items: center;
            position: relative;
            overflow: hidden;
            padding: 100px 0;
            margin-top: -80px; /* Compensate for body padding */
        }

        .programs-hero::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 800" opacity="0.1"><polygon fill="white" points="0,800 1200,400 1200,800"/></svg>');
            background-size: cover;
            animation: float 20s ease-in-out infinite;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0px) rotate(0deg); }
            50% { transform: translateY(-20px) rotate(1deg); }
        }

        .hero-content {
            position: relative;
            z-index: 2;
        }

        .hero-title {
            font-size: clamp(2.5rem, 6vw, 4rem);
            font-weight: 800;
            line-height: 1.1;
            margin-bottom: 1.5rem;
            color: white;
            text-shadow: 0 2px 15px rgba(0,0,0,0.3);
        }

        .hero-title .highlight {
            color: #ffd700;
            display: inline-block;
            text-shadow: 0 2px 10px rgba(0,0,0,0.4);
        }

        .hero-description {
            font-size: clamp(1.1rem, 2.5vw, 1.3rem);
            margin-bottom: 2.5rem;
            opacity: 0.95;
            max-width: 600px;
            line-height: 1.6;
            margin-left: auto;
            margin-right: auto;
            text-shadow: 0 1px 5px rgba(0,0,0,0.2);
        }

        /* Programs Navigation */
        .programs-nav {
            background: white;
            padding: 2rem;
            border-radius: var(--border-radius-md);
            box-shadow: var(--shadow-sm);
            margin: -3rem auto 3rem auto;
            max-width: 1200px;
            position: relative;
            z-index: 10;
        }

        .nav-scroller {
            display: flex;
            gap: 1rem;
            overflow-x: auto;
            padding: 0.5rem 0;
            scrollbar-width: none;
            -ms-overflow-style: none;
        }

        .nav-scroller::-webkit-scrollbar {
            display: none;
        }

        .nav-item {
            padding: 1rem 2rem;
            background: var(--light);
            color: var(--secondary);
            text-decoration: none;
            border-radius: var(--border-radius-sm);
            transition: var(--transition);
            border: 2px solid transparent;
            font-weight: 500;
            white-space: nowrap;
            flex-shrink: 0;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .nav-item:hover,
        .nav-item.active {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
            transform: translateY(-2px);
        }

        .nav-item i {
            font-size: 1.2rem;
        }

        /* Program Sections */
        .program-section {
            padding: 80px 0;
        }

        .program-section:nth-child(even) {
            background: var(--light);
        }

        .section-title {
            font-size: 2.5rem;
            font-weight: bold;
            color: var(--secondary);
            margin-bottom: 1rem;
        }

        .section-subtitle {
            font-size: 1.2rem;
            color: #6c757d;
            margin-bottom: 3rem;
        }

        .program-card {
            background: white;
            border-radius: var(--border-radius-md);
            padding: 3rem 2rem;
            box-shadow: var(--shadow-sm);
            transition: var(--transition);
            height: 100%;
            position: relative;
            overflow: hidden;
        }

        .program-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 5px;
            height: 100%;
            background: var(--primary);
            transition: var(--transition);
        }

        .program-card:hover {
            transform: translateY(-10px);
            box-shadow: var(--shadow-lg);
        }

        .program-card:hover::before {
            width: 8px;
            background: var(--reach-warning);
        }

        .program-icon {
            width: 80px;
            height: 80px;
            background: var(--primary);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 2rem;
            color: white;
            font-size: 2rem;
            transition: var(--transition);
        }

        .program-card:hover .program-icon {
            background: var(--reach-warning);
            transform: scale(1.1);
        }

        .program-title {
            font-size: 1.5rem;
            font-weight: 700;
            margin-bottom: 1rem;
            color: var(--secondary);
        }

        .program-description {
            color: #6c757d;
            margin-bottom: 2rem;
            line-height: 1.6;
        }

        .program-features {
            margin-bottom: 2rem;
        }

        .program-features h5 {
            font-weight: 600;
            margin-bottom: 1rem;
            color: var(--secondary);
        }

        .feature-list {
            list-style: none;
            padding: 0;
        }

        .feature-list li {
            padding: 0.5rem 0;
            display: flex;
            align-items: flex-start;
            gap: 0.75rem;
        }

        .feature-list li i {
            color: var(--success);
            margin-top: 0.25rem;
            flex-shrink: 0;
        }

        .program-actions {
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
        }

        .btn-program {
            padding: 0.75rem 1.5rem;
            border-radius: var(--border-radius-sm);
            font-weight: 500;
            transition: var(--transition);
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        .btn-program-primary {
            background: var(--primary);
            color: white;
            border: 2px solid var(--primary);
        }

        .btn-program-primary:hover {
            background: #2980b9;
            border-color: #2980b9;
            transform: translateY(-2px);
        }

        .btn-program-outline {
            background: transparent;
            color: var(--primary);
            border: 2px solid var(--primary);
        }

        .btn-program-outline:hover {
            background: var(--primary);
            color: white;
            transform: translateY(-2px);
        }

        /* Program Stats */
        .program-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 1.5rem;
            margin-top: 2rem;
        }

        .stat-item {
            text-align: center;
            padding: 1.5rem 1rem;
            background: rgba(52, 152, 219, 0.1);
            border-radius: var(--border-radius-sm);
            transition: var(--transition);
        }

        .stat-item:hover {
            transform: translateY(-5px);
            background: rgba(52, 152, 219, 0.15);
        }

        .stat-item h4 {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            color: var(--primary);
        }

        .stat-item p {
            color: var(--secondary);
            margin: 0;
            font-size: 0.9rem;
        }

        /* Eligibility Criteria */
        .criteria-section {
            padding: 80px 0;
            background: var(--light);
        }

        .criteria-card {
            background: white;
            padding: 2rem;
            border-radius: var(--border-radius-md);
            box-shadow: var(--shadow-sm);
            height: 100%;
            transition: var(--transition);
        }

        .criteria-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-md);
        }

        .criteria-card h5 {
            font-weight: 600;
            margin-bottom: 1rem;
            color: var(--primary);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .criteria-card h5 i {
            color: var(--success);
        }

        .criteria-card ul {
            list-style: none;
            padding: 0;
        }

        .criteria-card li {
            padding: 0.5rem 0;
            border-bottom: 1px solid #f8f9fa;
            display: flex;
            align-items: flex-start;
            gap: 0.75rem;
        }

        .criteria-card li:last-child {
            border-bottom: none;
        }

        .criteria-card li i {
            color: var(--primary);
            margin-top: 0.25rem;
            flex-shrink: 0;
        }

        /* Application Process */
        .process-section {
            padding: 80px 0;
            background: var(--gradient-primary);
            color: white;
        }

        .process-step {
            padding: 2rem 1rem;
        }

        .step-number {
            width: 60px;
            height: 60px;
            background: rgba(255,255,255,0.2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            font-weight: 700;
            margin: 0 auto 1.5rem auto;
            border: 3px solid rgba(255,255,255,0.3);
            transition: var(--transition);
        }

        .process-step:hover .step-number {
            background: var(--reach-warning);
            transform: scale(1.1);
        }

        .process-step h5 {
            font-weight: 600;
            margin-bottom: 1rem;
            color: white;
        }

        .process-step p {
            opacity: 0.9;
            margin: 0;
        }

        /* CTA Section */
        .cta-section {
            padding: 80px 0;
            text-align: center;
        }

        .cta-title {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 1rem;
            color: var(--secondary);
        }

        .cta-description {
            font-size: 1.2rem;
            margin-bottom: 2.5rem;
            color: #6c757d;
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
        }

        /* Footer - Same as index */
        footer {
            background: var(--secondary);
            color: white;
            padding: 3rem 0 1rem;
        }

        .footer-links a {
            color: #bdc3c7;
            text-decoration: none;
            transition: color 0.3s;
        }

        .footer-links a:hover {
            color: white;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .navbar-actions {
                justify-content: center;
                margin-top: 1rem;
                width: 100%;
            }

            .navbar-actions .btn {
                flex: 1;
                min-width: 120px;
                text-align: center;
            }

            .programs-nav {
                margin: -2rem auto 2rem auto;
                padding: 1.5rem;
            }

            .nav-item {
                padding: 0.75rem 1.5rem;
                font-size: 0.9rem;
            }

            .program-card {
                padding: 2rem 1.5rem;
            }

            .program-actions {
                flex-direction: column;
            }

            .btn-program {
                width: 100%;
                justify-content: center;
            }
        }

        @media (max-width: 576px) {
            .brand-text strong {
                font-size: 1.2rem;
            }

            .brand-text small {
                font-size: 0.7rem;
            }

            .hero-title {
                font-size: 2rem;
            }

            .section-title {
                font-size: 1.8rem;
            }

            .program-stats {
                grid-template-columns: 1fr;
            }
        }

        /* Focus styles for accessibility */
        .btn:focus,
        .nav-link:focus,
        .form-control:focus {
            outline: 2px solid var(--primary);
            outline-offset: 2px;
        }
    </style>
</head>
<body class="h-100">
    <!-- Enhanced Navigation - Same as index -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
        <div class="container">
            <a class="navbar-brand" href="../index.php">
                <div class="brand-content">
                    <i class="fas fa-hands-helping"></i>
                    <div class="brand-text">
                        <strong>REACH</strong>
                        <small>Recognizing Each Action Can Help</small>
                    </div>
                </div>
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMain"
                    aria-controls="navbarMain" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarMain">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item"><a class="nav-link" href="../index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="about.php">About</a></li>
                    <li class="nav-item"><a class="nav-link active" href="programs.php">Programs</a></li>
                    <li class="nav-item"><a class="nav-link" href="stories.php">Stories</a></li>
                    <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
                </ul>
                
                <div class="navbar-actions">
                    <a href="apply.php" class="btn btn-outline-light">
                        <i class="fas fa-edit me-1"></i>Apply
                    </a>
                    <a href="donate.php" class="btn btn-warning">
                        <i class="fas fa-heart me-1"></i>Donate
                    </a>
                    <a href="login.php" class="btn btn-outline-light">
                        <i class="fas fa-sign-in-alt me-1"></i>Login
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Programs Hero Section -->
    <section class="programs-hero">
        <div class="container">
            <div class="row align-items-center min-vh-60">
                <div class="col-lg-8 mx-auto text-center">
                    <div class="hero-content">
                        <h1 class="hero-title">
                            Our <span class="highlight">Programs</span>
                        </h1>
                        <p class="hero-description">
                            Comprehensive support systems designed to empower students and transform communities 
                            through education, housing, mentorship, and development initiatives in Rwanda.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Programs Navigation -->
    <div class="container">
        <div class="programs-nav" data-aos="fade-up">
            <div class="nav-scroller">
                <a href="#scholarships" class="nav-item active" data-target="scholarships">
                    <i class="fas fa-graduation-cap"></i>
                    Scholarships
                </a>
                <a href="#housing" class="nav-item" data-target="housing">
                    <i class="fas fa-home"></i>
                    Student Housing
                </a>
                <a href="#community" class="nav-item" data-target="community">
                    <i class="fas fa-users"></i>
                    Community Development
                </a>
                <a href="#mentorship" class="nav-item" data-target="mentorship">
                    <i class="fas fa-chalkboard-teacher"></i>
                    Mentorship
                </a>
            </div>
        </div>
    </div>

    <!-- Scholarships Program -->
    <section id="scholarships" class="program-section">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="section-title" data-aos="fade-up">Scholarship Programs</h2>
                <p class="section-subtitle" data-aos="fade-up" data-aos-delay="100">
                    Empowering students through comprehensive educational support
                </p>
            </div>
            
            <div class="row">
                <?php foreach ($programsByType['scholarship'] as $program): ?>
                <div class="col-lg-6 mb-4" data-aos="fade-up">
                    <div class="program-card">
                        <div class="program-icon">
                            <i class="fas fa-graduation-cap"></i>
                        </div>
                        
                        <h3 class="program-title"><?php echo htmlspecialchars($program['name']); ?></h3>
                        <p class="program-description"><?php echo htmlspecialchars($program['description']); ?></p>
                        
                        <div class="program-features">
                            <h5>Program Benefits:</h5>
                            <ul class="feature-list">
                                <?php
                                $benefits = explode(',', $program['benefits']);
                                foreach ($benefits as $benefit):
                                    if (trim($benefit)): ?>
                                <li>
                                    <i class="fas fa-check"></i>
                                    <span><?php echo htmlspecialchars(trim($benefit)); ?></span>
                                </li>
                                <?php endif;
                                endforeach; ?>
                            </ul>
                        </div>
                        
                        <div class="program-features">
                            <h5>Eligibility Criteria:</h5>
                            <ul class="feature-list">
                                <?php
                                $criteria = explode(',', $program['eligibility_criteria']);
                                foreach ($criteria as $criterion):
                                    if (trim($criterion)): ?>
                                <li>
                                    <i class="fas fa-user-check"></i>
                                    <span><?php echo htmlspecialchars(trim($criterion)); ?></span>
                                </li>
                                <?php endif;
                                endforeach; ?>
                            </ul>
                        </div>
                        
                        <div class="program-actions">
                            <a href="apply.php?program=<?php echo $program['slug']; ?>" class="btn-program btn-program-primary">
                                <i class="fas fa-edit me-1"></i>Apply Now
                            </a>
                            <a href="contact.php" class="btn-program btn-program-outline">
                                <i class="fas fa-info-circle me-1"></i>Learn More
                            </a>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
                
                <?php if (empty($programsByType['scholarship'])): ?>
                <div class="col-12 text-center">
                    <div class="program-card">
                        <div class="program-icon">
                            <i class="fas fa-graduation-cap"></i>
                        </div>
                        <h3 class="program-title">Education Scholarship Program</h3>
                        <p class="program-description">
                            Full tuition coverage for underprivileged students pursuing higher education in Rwanda.
                        </p>
                        <div class="program-stats">
                            <div class="stat-item">
                                <h4>50+</h4>
                                <p>Students Currently Supported</p>
                            </div>
                            <div class="stat-item">
                                <h4>95%</h4>
                                <p>Graduation Rate</p>
                            </div>
                        </div>
                        <div class="program-actions">
                            <a href="apply.php?program=scholarship" class="btn-program btn-program-primary">
                                <i class="fas fa-edit me-1"></i>Apply Now
                            </a>
                            <a href="contact.php" class="btn-program btn-program-outline">
                                <i class="fas fa-info-circle me-1"></i>Learn More
                            </a>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- Student Housing Program -->
    <section id="housing" class="program-section">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="section-title" data-aos="fade-up">Student Housing</h2>
                <p class="section-subtitle" data-aos="fade-up" data-aos-delay="100">
                    Safe and supportive living environments for academic success
                </p>
            </div>
            
            <div class="row">
                <?php foreach ($programsByType['housing'] as $program): ?>
                <div class="col-lg-6 mb-4" data-aos="fade-up">
                    <div class="program-card">
                        <div class="program-icon">
                            <i class="fas fa-home"></i>
                        </div>
                        
                        <h3 class="program-title"><?php echo htmlspecialchars($program['name']); ?></h3>
                        <p class="program-description"><?php echo htmlspecialchars($program['description']); ?></p>
                        
                        <div class="program-features">
                            <h5>Housing Features:</h5>
                            <ul class="feature-list">
                                <?php
                                $benefits = explode(',', $program['benefits']);
                                foreach ($benefits as $benefit):
                                    if (trim($benefit)): ?>
                                <li>
                                    <i class="fas fa-check"></i>
                                    <span><?php echo htmlspecialchars(trim($benefit)); ?></span>
                                </li>
                                <?php endif;
                                endforeach; ?>
                            </ul>
                        </div>
                        
                        <div class="program-actions">
                            <a href="apply.php?program=<?php echo $program['slug']; ?>" class="btn-program btn-program-primary">
                                <i class="fas fa-home me-1"></i>Apply for Housing
                            </a>
                            <a href="contact.php" class="btn-program btn-program-outline">
                                <i class="fas fa-book me-1"></i>View Guidelines
                            </a>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
                
                <?php if (empty($programsByType['housing'])): ?>
                <div class="col-12">
                    <div class="program-card">
                        <div class="program-icon">
                            <i class="fas fa-home"></i>
                        </div>
                        <h3 class="program-title">Student Housing Initiative</h3>
                        <p class="program-description">
                            Safe and affordable housing for students from rural areas pursuing education in urban centers.
                        </p>
                        <div class="program-stats">
                            <div class="stat-item">
                                <h4>120+</h4>
                                <p>Students Housed</p>
                            </div>
                            <div class="stat-item">
                                <h4>5</h4>
                                <p>Housing Locations</p>
                            </div>
                        </div>
                        <div class="program-actions">
                            <a href="apply.php?program=housing" class="btn-program btn-program-primary">
                                <i class="fas fa-home me-1"></i>Apply for Housing
                            </a>
                            <a href="contact.php" class="btn-program btn-program-outline">
                                <i class="fas fa-book me-1"></i>View Guidelines
                            </a>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- Community Development Program -->
    <section id="community" class="program-section">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="section-title" data-aos="fade-up">Community Development</h2>
                <p class="section-subtitle" data-aos="fade-up" data-aos-delay="100">
                    Empowering communities through sustainable initiatives
                </p>
            </div>
            
            <div class="row">
                <?php foreach ($programsByType['community'] as $program): ?>
                <div class="col-lg-6 mb-4" data-aos="fade-up">
                    <div class="program-card">
                        <div class="program-icon">
                            <i class="fas fa-users"></i>
                        </div>
                        
                        <h3 class="program-title"><?php echo htmlspecialchars($program['name']); ?></h3>
                        <p class="program-description"><?php echo htmlspecialchars($program['description']); ?></p>
                        
                        <div class="program-features">
                            <h5>Program Benefits:</h5>
                            <ul class="feature-list">
                                <?php
                                $benefits = explode(',', $program['benefits']);
                                foreach ($benefits as $benefit):
                                    if (trim($benefit)): ?>
                                <li>
                                    <i class="fas fa-check"></i>
                                    <span><?php echo htmlspecialchars(trim($benefit)); ?></span>
                                </li>
                                <?php endif;
                                endforeach; ?>
                            </ul>
                        </div>
                        
                        <div class="program-actions">
                            <a href="contact.php" class="btn-program btn-program-primary">
                                <i class="fas fa-handshake me-1"></i>Partner With Us
                            </a>
                            <a href="stories.php" class="btn-program btn-program-outline">
                                <i class="fas fa-project-diagram me-1"></i>View Projects
                            </a>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
                
                <?php if (empty($programsByType['community'])): ?>
                <div class="col-12">
                    <div class="program-card">
                        <div class="program-icon">
                            <i class="fas fa-users"></i>
                        </div>
                        <h3 class="program-title">Community Development Program</h3>
                        <p class="program-description">
                            Skills training and community building initiatives that benefit entire communities.
                        </p>
                        <div class="program-stats">
                            <div class="stat-item">
                                <h4>25+</h4>
                                <p>Community Projects</p>
                            </div>
                            <div class="stat-item">
                                <h4>500+</h4>
                                <p>Community Members Reached</p>
                            </div>
                        </div>
                        <div class="program-actions">
                            <a href="contact.php" class="btn-program btn-program-primary">
                                <i class="fas fa-handshake me-1"></i>Partner With Us
                            </a>
                            <a href="stories.php" class="btn-program btn-program-outline">
                                <i class="fas fa-project-diagram me-1"></i>View Projects
                            </a>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- Mentorship Program -->
    <section id="mentorship" class="program-section">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="section-title" data-aos="fade-up">Mentorship Programs</h2>
                <p class="section-subtitle" data-aos="fade-up" data-aos-delay="100">
                    Guiding students toward successful careers and personal growth
                </p>
            </div>
            
            <div class="row">
                <?php foreach ($programsByType['mentorship'] as $program): ?>
                <div class="col-lg-6 mb-4" data-aos="fade-up">
                    <div class="program-card">
                        <div class="program-icon">
                            <i class="fas fa-chalkboard-teacher"></i>
                        </div>
                        
                        <h3 class="program-title"><?php echo htmlspecialchars($program['name']); ?></h3>
                        <p class="program-description"><?php echo htmlspecialchars($program['description']); ?></p>
                        
                        <div class="program-features">
                            <h5>Mentorship Benefits:</h5>
                            <ul class="feature-list">
                                <?php
                                $benefits = explode(',', $program['benefits']);
                                foreach ($benefits as $benefit):
                                    if (trim($benefit)): ?>
                                <li>
                                    <i class="fas fa-check"></i>
                                    <span><?php echo htmlspecialchars(trim($benefit)); ?></span>
                                </li>
                                <?php endif;
                                endforeach; ?>
                            </ul>
                        </div>
                        
                        <div class="program-actions">
                            <a href="apply.php?program=<?php echo $program['slug']; ?>" class="btn-program btn-program-primary">
                                <i class="fas fa-user-graduate me-1"></i>Become a Mentee
                            </a>
                            <a href="contact.php" class="btn-program btn-program-outline">
                                <i class="fas fa-chalkboard-teacher me-1"></i>Become a Mentor
                            </a>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
                
                <?php if (empty($programsByType['mentorship'])): ?>
                <div class="col-12">
                    <div class="program-card">
                        <div class="program-icon">
                            <i class="fas fa-chalkboard-teacher"></i>
                        </div>
                        <h3 class="program-title">Youth Mentorship Program</h3>
                        <p class="program-description">
                            One-on-one mentoring for career development and personal growth.
                        </p>
                        <div class="program-stats">
                            <div class="stat-item">
                                <h4>75+</h4>
                                <p>Active Mentorship Pairs</p>
                            </div>
                            <div class="stat-item">
                                <h4>30+</h4>
                                <p>Professional Mentors</p>
                            </div>
                        </div>
                        <div class="program-actions">
                            <a href="apply.php?program=mentorship" class="btn-program btn-program-primary">
                                <i class="fas fa-user-graduate me-1"></i>Become a Mentee
                            </a>
                            <a href="contact.php" class="btn-program btn-program-outline">
                                <i class="fas fa-chalkboard-teacher me-1"></i>Become a Mentor
                            </a>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- Eligibility Criteria -->
    <section class="criteria-section">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="section-title" data-aos="fade-up">Eligibility Criteria</h2>
                <p class="section-subtitle" data-aos="fade-up" data-aos-delay="100">
                    Requirements for our scholarship programs
                </p>
            </div>
            
            <div class="row">
                <div class="col-lg-6 mb-4" data-aos="fade-up">
                    <div class="criteria-card">
                        <h5><i class="fas fa-graduation-cap"></i> Academic Requirements</h5>
                        <ul>
                            <li><i class="fas fa-check"></i> Minimum high school GPA of 3.0 or equivalent</li>
                            <li><i class="fas fa-check"></i> Acceptance letter from accredited university</li>
                            <li><i class="fas fa-check"></i> Strong academic record and recommendations</li>
                            <li><i class="fas fa-check"></i> Demonstrated commitment to chosen field of study</li>
                        </ul>
                    </div>
                </div>
                
                <div class="col-lg-6 mb-4" data-aos="fade-up" data-aos-delay="100">
                    <div class="criteria-card">
                        <h5><i class="fas fa-money-bill-wave"></i> Financial Need</h5>
                        <ul>
                            <li><i class="fas fa-check"></i> Demonstrated financial hardship</li>
                            <li><i class="fas fa-check"></i> Family income below established threshold</li>
                            <li><i class="fas fa-check"></i> Lack of other scholarship opportunities</li>
                            <li><i class="fas fa-check"></i> Willingness to provide financial documentation</li>
                        </ul>
                    </div>
                </div>
                
                <div class="col-lg-6 mb-4" data-aos="fade-up" data-aos-delay="200">
                    <div class="criteria-card">
                        <h5><i class="fas fa-user-check"></i> Personal Qualities</h5>
                        <ul>
                            <li><i class="fas fa-check"></i> Strong leadership potential</li>
                            <li><i class="fas fa-check"></i> Commitment to community service</li>
                            <li><i class="fas fa-check"></i> Clear educational and career goals</li>
                            <li><i class="fas fa-check"></i> Willingness to participate in REACH programs</li>
                        </ul>
                    </div>
                </div>
                
                <div class="col-lg-6 mb-4" data-aos="fade-up" data-aos-delay="300">
                    <div class="criteria-card">
                        <h5><i class="fas fa-clipboard-list"></i> Additional Requirements</h5>
                        <ul>
                            <li><i class="fas fa-check"></i> Rwandan citizenship or legal residency</li>
                            <li><i class="fas fa-check"></i> Age between 18-25 years for undergraduate programs</li>
                            <li><i class="fas fa-check"></i> Commitment to maintain good academic standing</li>
                            <li><i class="fas fa-check"></i> Willingness to give back to the community</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Application Process -->
    <section class="process-section">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="section-title text-white" data-aos="fade-up">Application Process</h2>
                <p class="section-subtitle text-white" data-aos="fade-up" data-aos-delay="100">
                    How to apply for our programs
                </p>
            </div>
            
            <div class="row">
                <div class="col-lg-3 col-md-6 mb-4" data-aos="zoom-in">
                    <div class="process-step text-center">
                        <div class="step-number">1</div>
                        <h5>Check Eligibility</h5>
                        <p>Review requirements and ensure you qualify for the program</p>
                    </div>
                </div>
                
                <div class="col-lg-3 col-md-6 mb-4" data-aos="zoom-in" data-aos-delay="100">
                    <div class="process-step text-center">
                        <div class="step-number">2</div>
                        <h5>Prepare Documents</h5>
                        <p>Gather academic records, recommendations, and required documents</p>
                    </div>
                </div>
                
                <div class="col-lg-3 col-md-6 mb-4" data-aos="zoom-in" data-aos-delay="200">
                    <div class="process-step text-center">
                        <div class="step-number">3</div>
                        <h5>Submit Application</h5>
                        <p>Complete online application form with all required documents</p>
                    </div>
                </div>
                
                <div class="col-lg-3 col-md-6 mb-4" data-aos="zoom-in" data-aos-delay="300">
                    <div class="process-step text-center">
                        <div class="step-number">4</div>
                        <h5>Interview & Selection</h5>
                        <p>Participate in selection process if shortlisted for consideration</p>
                    </div>
                </div>
            </div>
            
            <div class="text-center mt-4" data-aos="fade-up" data-aos-delay="400">
                <a href="apply.php" class="btn btn-light btn-lg">
                    <i class="fas fa-rocket me-2"></i>Start Your Application
                </a>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="cta-section">
        <div class="container">
            <h2 class="cta-title" data-aos="fade-up">Ready to Transform Lives?</h2>
            <p class="cta-description" data-aos="fade-up" data-aos-delay="100">
                Join REACH Organization today and be part of creating lasting positive change through education and community support.
            </p>
            <div class="hero-actions justify-content-center" data-aos="fade-up" data-aos-delay="200">
                <a href="apply.php" class="btn btn-hero btn-hero-primary">
                    <i class="fas fa-user-graduate me-2"></i>Apply Now
                </a>
                <a href="donate.php" class="btn btn-hero btn-hero-outline">
                    <i class="fas fa-hand-holding-heart me-2"></i>Support Our Mission
                </a>
            </div>
        </div>
    </section>

    <!-- Footer - Same as index -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-4 mb-4">
                    <h5>REACH Organization</h5>
                    <p>Recognizing Each Action Can Help</p>
                    <div class="mt-3">
                        <a href="#" class="text-white me-3"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="text-white"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>
                <div class="col-lg-4 mb-4">
                    <h5>Quick Links</h5>
                    <div class="footer-links">
                        <div class="row">
                            <div class="col-6">
                                <a href="about.php">About Us</a><br>
                                <a href="programs.php">Programs</a><br>
                                <a href="stories.php">Success Stories</a>
                            </div>
                            <div class="col-6">
                                <a href="apply.php">Apply</a><br>
                                <a href="donate.php">Donate</a><br>
                                <a href="contact.php">Contact</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 mb-4">
                    <h5>Contact Info</h5>
                    <p><i class="fas fa-map-marker-alt me-2"></i> Kigali, Rwanda</p>
                    <p><i class="fas fa-phone me-2"></i> +250 788 123 456</p>
                    <p><i class="fas fa-envelope me-2"></i> info@reach.org</p>
                </div>
            </div>
            <hr class="my-4">
            <div class="text-center">
                <p>&copy; 2024 REACH Organization. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    
    <script>
        // Initialize AOS
        AOS.init({
            duration: 800,
            once: true,
            offset: 100
        });

        // Navbar scroll effect - Same as index
        window.addEventListener('scroll', function() {
            const navbar = document.getElementById('mainNav');
            if (window.scrollY > 100) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });

        // Programs navigation
        document.querySelectorAll('.programs-nav .nav-item').forEach(item => {
            item.addEventListener('click', function(e) {
                e.preventDefault();
                const target = this.getAttribute('href');
                
                // Update active state
                document.querySelectorAll('.programs-nav .nav-item').forEach(nav => {
                    nav.classList.remove('active');
                });
                this.classList.add('active');
                
                // Scroll to section
                document.querySelector(target).scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            });
        });

        // Update active nav based on scroll position
        window.addEventListener('scroll', function() {
            const sections = document.querySelectorAll('.program-section');
            const navItems = document.querySelectorAll('.programs-nav .nav-item');
            
            let currentSection = '';
            
            sections.forEach(section => {
                const sectionTop = section.offsetTop - 100;
                const sectionHeight = section.clientHeight;
                if (window.scrollY >= sectionTop && window.scrollY < sectionTop + sectionHeight) {
                    currentSection = '#' + section.getAttribute('id');
                }
            });
            
            navItems.forEach(item => {
                item.classList.remove('active');
                if (item.getAttribute('href') === currentSection) {
                    item.classList.add('active');
                }
            });
        });

        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });

        // Mobile menu enhancement
        document.addEventListener('DOMContentLoaded', function() {
            const navbarToggler = document.querySelector('.navbar-toggler');
            const navbarCollapse = document.querySelector('.navbar-collapse');

            if (navbarToggler && navbarCollapse) {
                navbarToggler.addEventListener('click', function() {
                    navbarCollapse.classList.toggle('show');
                });

                // Close mobile menu when clicking on a link
                document.querySelectorAll('.nav-link').forEach(link => {
                    link.addEventListener('click', () => {
                        if (navbarCollapse.classList.contains('show')) {
                            navbarCollapse.classList.remove('show');
                        }
                    });
                });
            }
        });
    </script>
</body>
</html>