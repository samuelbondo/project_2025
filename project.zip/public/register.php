<?php
session_start();
include '../includes/config.php';

$error = '';
$success = '';
$redirect = isset($_GET['redirect']) ? $_GET['redirect'] : 'index.php';
$selected_program = isset($_GET['program']) ? $_GET['program'] : '';

// Get available programs for display
$programs = [];
try {
    $stmt = $pdo->query("
        SELECT id, name, type, description, eligibility_criteria, benefits 
        FROM programs 
        WHERE status = 'active' 
        ORDER BY name
    ");
    $programs = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    // Fallback programs if database query fails
    $programs = [
        ['id' => 1, 'name' => 'Education Scholarship', 'type' => 'scholarship', 'description' => 'Full tuition coverage for underprivileged students', 'eligibility_criteria' => 'High school diploma, Financial need', 'benefits' => 'Full tuition coverage'],
        ['id' => 2, 'name' => 'Student Housing', 'type' => 'housing', 'description' => 'Safe and affordable housing for students', 'eligibility_criteria' => 'Enrolled student, Financial need', 'benefits' => 'Accommodation and meals'],
        ['id' => 3, 'name' => 'Community Program', 'type' => 'community', 'description' => 'Skills training and community building', 'eligibility_criteria' => 'Community involvement', 'benefits' => 'Skills training'],
        ['id' => 4, 'name' => 'Mentorship Program', 'type' => 'mentorship', 'description' => 'One-on-one mentoring for career development', 'eligibility_criteria' => 'Young professional', 'benefits' => 'Career guidance']
    ];
    error_log("Programs loading error: " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = $_POST['full_name'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $program_interest = $_POST['program_interest'] ?? '';
    $role = 'student';

    // Validate inputs
    if (empty($full_name) || empty($email) || empty($password) || empty($confirm_password) || empty($program_interest)) {
        $error = 'Please fill in all required fields';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address';
    } elseif (strlen($full_name) > 100) {
        $error = 'Full name must be less than 100 characters';
    } elseif (strlen($email) > 100) {
        $error = 'Email must be less than 100 characters';
    } elseif (!preg_match('/^[a-zA-Z0-9\s\.\-]+$/', $full_name)) {
        $error = 'Full name contains invalid characters';
    } elseif ($password !== $confirm_password) {
        $error = 'Passwords do not match';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters long';
    } else {
        try {
            // Check if email already exists
            $check_stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $check_stmt->execute([$email]);
            
            if ($check_stmt->fetch()) {
                $error = 'Email already registered';
            } else {
                // Generate unique username
                $base_username = preg_replace('/[^a-zA-Z0-9]/', '.', strtolower($full_name));
                $username = $base_username . '.' . uniqid();
                
                // Check if username already exists
                $username_check_stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
                $counter = 1;
                $max_attempts = 10;
                
                while ($counter <= $max_attempts) {
                    $username_check_stmt->execute([$username]);
                    if (!$username_check_stmt->fetch()) {
                        break;
                    }
                    $username = $base_username . '.' . uniqid() . $counter;
                    $counter++;
                }
                
                if ($counter > $max_attempts) {
                    throw new Exception("Could not generate unique username");
                }
                
                // Check if program_interest column exists in users table
                $column_check = $pdo->query("SHOW COLUMNS FROM users LIKE 'program_interest'");
                $has_program_interest = $column_check->rowCount() > 0;
                
                if ($has_program_interest) {
                    // Insert with program_interest
                    $stmt = $pdo->prepare("
                        INSERT INTO users (
                            username, email, password, role, full_name, program_interest,
                            status, is_active, email_verified, created_at, updated_at
                        ) VALUES (?, ?, ?, ?, ?, ?, 'active', 1, 0, NOW(), NOW())
                    ");
                    $stmt->execute([$username, $email, password_hash($password, PASSWORD_DEFAULT), $role, $full_name, $program_interest]);
                } else {
                    // Insert without program_interest
                    $stmt = $pdo->prepare("
                        INSERT INTO users (
                            username, email, password, role, full_name,
                            status, is_active, email_verified, created_at, updated_at
                        ) VALUES (?, ?, ?, ?, ?, 'active', 1, 0, NOW(), NOW())
                    ");
                    $stmt->execute([$username, $email, password_hash($password, PASSWORD_DEFAULT), $role, $full_name]);
                }
                
                $user_id = $pdo->lastInsertId();
                
                // Store in user_preferences if table exists
                try {
                    $pref_check = $pdo->query("SHOW TABLES LIKE 'user_preferences'");
                    if ($pref_check->rowCount() > 0) {
                        $pref_stmt = $pdo->prepare("
                            INSERT INTO user_preferences (user_id, preference_key, preference_value, created_at) 
                            VALUES (?, 'program_interest', ?, NOW())
                        ");
                        $pref_stmt->execute([$user_id, $program_interest]);
                    }
                } catch (Exception $e) {
                    // Log but continue
                    error_log("User preferences insertion failed: " . $e->getMessage());
                }
                
                // Get program name for success message
                $program_name = ucfirst($program_interest);
                foreach ($programs as $program) {
                    if ($program['type'] === $program_interest) {
                        $program_name = $program['name'];
                        break;
                    }
                }
                
                // Set success message and redirect to login
                $success = "Registration successful! You can now apply for the {$program_name} program.";
                
                // Clear form fields
                $full_name = $email = '';
                
                // Redirect to login page after 3 seconds with program context
                header("refresh:3;url=login.php?redirect=apply.php&program=" . urlencode($program_interest));
                exit;
            }
        } catch (PDOException $e) {
            error_log("Registration error: " . $e->getMessage());
            if ($e->getCode() == 23000) {
                $error = 'Email or username already exists. Please try a different email.';
            } else {
                $error = 'Registration failed. Please try again.';
            }
        } catch (Exception $e) {
            error_log("Registration error: " . $e->getMessage());
            $error = 'Registration failed. Please try again.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - REACH Organization | Transforming Lives</title>
    
    <!-- Advanced Meta Tags -->
    <meta name="description" content="Register for REACH Organization to apply for scholarships, housing, and community programs in Rwanda.">
    <meta name="keywords" content="REACH registration, student account, scholarship application, Rwanda education">
    <meta name="author" content="REACH Organization">
    
    <!-- Preload Critical Resources -->
    <link rel="preload" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" as="style">
    <link rel="preload" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" as="style">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    
    <style>
        :root {
            --primary: #3498db;
            --secondary: #2c3e50;
            --success: #27ae60;
            --light: #f8f9fa;
            --reach-accent: #ea4335;
            --gradient-primary: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            --shadow-sm: 0 2px 8px rgba(0,0,0,0.08);
            --shadow-md: 0 8px 30px rgba(0,0,0,0.12);
            --shadow-lg: 0 15px 35px rgba(0,0,0,0.15);
            --border-radius-sm: 12px;
            --border-radius-md: 20px;
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            line-height: 1.6;
            color: var(--secondary);
            background: var(--light);
            min-height: 100vh;
            display: flex;
            align-items: center;
            background: var(--gradient-primary);
            position: relative;
            overflow-x: hidden;
        }

        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 800" opacity="0.05"><polygon fill="white" points="0,800 1200,400 1200,800"/></svg>');
            background-size: cover;
            animation: float 20s ease-in-out infinite;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0px) rotate(0deg); }
            50% { transform: translateY(-20px) rotate(1deg); }
        }

        .auth-container {
            width: 100%;
            max-width: 500px;
            margin: 2rem auto;
            padding: 1rem;
            position: relative;
            z-index: 2;
        }

        .auth-card {
            background: white;
            border-radius: var(--border-radius-md);
            box-shadow: var(--shadow-lg);
            overflow: hidden;
            transition: var(--transition);
        }

        .auth-card:hover {
            box-shadow: 0 20px 40px rgba(0,0,0,0.2);
            transform: translateY(-5px);
        }

        .auth-header {
            background: var(--gradient-primary);
            color: white;
            padding: 2.5rem 2rem;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .auth-header::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            right: -50%;
            bottom: -50%;
            background: linear-gradient(45deg, transparent, rgba(255,255,255,0.1), transparent);
            animation: shimmer 3s infinite;
        }

        @keyframes shimmer {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(100%); }
        }

        .auth-icon {
            font-size: 3rem;
            margin-bottom: 1rem;
            display: block;
            color: rgba(255,255,255,0.9);
        }

        .auth-header h3 {
            font-size: 1.75rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            color: white;
        }

        .auth-header p {
            opacity: 0.9;
            font-size: 1rem;
        }

        .auth-body {
            padding: 2.5rem 2rem;
        }

        /* Form Styles */
        .form-label {
            font-weight: 600;
            color: var(--secondary);
            margin-bottom: 0.5rem;
            font-size: 0.95rem;
        }

        .form-control {
            border-radius: var(--border-radius-sm);
            border: 2px solid #e9ecef;
            padding: 0.75rem 1rem;
            transition: var(--transition);
            font-size: 1rem;
        }

        .form-control:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.2rem rgba(52, 152, 219, 0.25);
        }

        /* Program Cards */
        .program-selection {
            margin-bottom: 1.5rem;
        }

        .program-card {
            border: 2px solid #e9ecef;
            border-radius: var(--border-radius-sm);
            padding: 1.25rem;
            margin-bottom: 0.75rem;
            cursor: pointer;
            transition: var(--transition);
            background: white;
        }

        .program-card:hover {
            border-color: var(--primary);
            background-color: #f8f9fa;
            transform: translateY(-2px);
        }

        .program-card.selected {
            border-color: var(--primary);
            background-color: rgba(52, 152, 219, 0.1);
            box-shadow: var(--shadow-sm);
        }

        .program-icon {
            font-size: 1.5rem;
            margin-bottom: 0.75rem;
            color: var(--primary);
        }

        .program-card h6 {
            font-size: 1rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
            color: var(--secondary);
        }

        .program-card p {
            font-size: 0.875rem;
            color: #6c757d;
            margin-bottom: 0;
            line-height: 1.4;
        }

        /* Button Styles */
        .btn {
            border-radius: var(--border-radius-sm);
            font-weight: 500;
            transition: var(--transition);
            border: 2px solid transparent;
            padding: 0.75rem 1.5rem;
            font-size: 1rem;
        }

        .btn-reach {
            background: var(--primary);
            border-color: var(--primary);
            color: white;
            width: 100%;
        }

        .btn-reach:hover {
            background: #2980b9;
            border-color: #2980b9;
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
        }

        /* Alert Styles */
        .alert {
            border-radius: var(--border-radius-sm);
            border: none;
            padding: 1rem 1.25rem;
            margin-bottom: 1.5rem;
        }

        .alert-danger {
            background: rgba(220, 53, 69, 0.1);
            color: #dc3545;
            border-left: 4px solid #dc3545;
        }

        .alert-success {
            background: rgba(40, 167, 69, 0.1);
            color: #155724;
            border-left: 4px solid #28a745;
        }

        /* Password Strength */
        .password-strength {
            height: 4px;
            background: #e9ecef;
            border-radius: 2px;
            margin-top: 5px;
            overflow: hidden;
        }

        .password-strength-bar {
            height: 100%;
            width: 0%;
            transition: width 0.3s ease, background-color 0.3s ease;
        }

        /* Loading State */
        .btn-loading {
            position: relative;
            color: transparent !important;
        }

        .btn-loading::after {
            content: '';
            position: absolute;
            width: 20px;
            height: 20px;
            top: 50%;
            left: 50%;
            margin-left: -10px;
            margin-top: -10px;
            border: 2px solid transparent;
            border-top-color: currentColor;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        /* Responsive Design */
        @media (max-width: 576px) {
            .auth-container {
                margin: 1rem auto;
                padding: 0.5rem;
            }

            .auth-header {
                padding: 2rem 1.5rem;
            }

            .auth-body {
                padding: 2rem 1.5rem;
            }

            .auth-header h3 {
                font-size: 1.5rem;
            }

            .auth-icon {
                font-size: 2.5rem;
            }
        }

        /* Focus styles for accessibility */
        .btn:focus,
        .form-control:focus {
            outline: 2px solid var(--primary);
            outline-offset: 2px;
        }
    </style>
</head>
<body>
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-header">
                <i class="fas fa-hands-helping auth-icon"></i>
                <h3>Join REACH Programs</h3>
                <p class="mb-0">Create your account and select your program interest</p>
            </div>
            
            <div class="auth-body">
                <?php if ($error): ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <?php echo htmlspecialchars($error); ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($success): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle me-2"></i>
                        <?php echo htmlspecialchars($success); ?>
                        <div class="mt-2">
                            <small>Redirecting to login page...</small>
                        </div>
                    </div>
                <?php endif; ?>
                
                <form method="POST" id="registerForm" <?php echo $success ? 'style="display:none;"' : ''; ?>>
                    <div class="mb-3">
                        <label class="form-label">Full Name <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="full_name" 
                               value="<?php echo htmlspecialchars($full_name ?? ''); ?>" 
                               required maxlength="100" 
                               placeholder="Enter your full name">
                        <div class="form-text">Maximum 100 characters. Only letters, numbers, spaces, dots and hyphens allowed.</div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Email Address <span class="text-danger">*</span></label>
                        <input type="email" class="form-control" name="email" 
                               value="<?php echo htmlspecialchars($email ?? ''); ?>" 
                               required maxlength="100" 
                               placeholder="Enter your email address">
                        <div class="form-text">We'll never share your email with anyone else.</div>
                    </div>

                    <div class="mb-3 program-selection">
                        <label class="form-label">Program Interest <span class="text-danger">*</span></label>
                        <div id="programSelection">
                            <?php foreach ($programs as $program): ?>
                                <div class="program-card" data-program="<?php echo $program['type']; ?>">
                                    <div class="program-icon">
                                        <?php 
                                        $icons = [
                                            'scholarship' => 'fa-graduation-cap',
                                            'housing' => 'fa-home',
                                            'community' => 'fa-users',
                                            'mentorship' => 'fa-handshake'
                                        ];
                                        $icon = $icons[$program['type']] ?? 'fa-star';
                                        ?>
                                        <i class="fas <?php echo $icon; ?>"></i>
                                    </div>
                                    <h6><?php echo htmlspecialchars($program['name']); ?></h6>
                                    <p><?php echo htmlspecialchars($program['description']); ?></p>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <input type="hidden" name="program_interest" id="selectedProgram" required>
                        <div class="form-text">Select the program you're most interested in applying for.</div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Password <span class="text-danger">*</span></label>
                        <input type="password" class="form-control" name="password" 
                               id="password" required minlength="6" 
                               placeholder="Enter your password">
                        <div class="password-strength mt-2">
                            <div class="password-strength-bar" id="passwordStrengthBar"></div>
                        </div>
                        <div class="form-text">Password must be at least 6 characters long</div>
                    </div>
                    
                    <div class="mb-4">
                        <label class="form-label">Confirm Password <span class="text-danger">*</span></label>
                        <input type="password" class="form-control" name="confirm_password" 
                               id="confirmPassword" required 
                               placeholder="Confirm your password">
                        <div class="form-text" id="passwordMatchText"></div>
                    </div>
                    
                    <button type="submit" class="btn btn-reach mb-3" id="registerBtn">
                        <i class="fas fa-user-plus me-2"></i>Create Account & Continue to Application
                    </button>
                </form>
                
                <?php if (!$success): ?>
                <div class="text-center">
                    <p class="mb-0 text-muted">
                        Already have an account? 
                        <a href="login.php?redirect=<?php echo urlencode($redirect); ?>" class="text-decoration-none fw-semibold">
                            Login here
                        </a>
                    </p>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Program selection
        document.querySelectorAll('.program-card').forEach(card => {
            card.addEventListener('click', function() {
                // Remove selected class from all cards
                document.querySelectorAll('.program-card').forEach(c => {
                    c.classList.remove('selected');
                });
                
                // Add selected class to clicked card
                this.classList.add('selected');
                
                // Set hidden input value
                const programType = this.getAttribute('data-program');
                document.getElementById('selectedProgram').value = programType;
                
                // Update form validation
                validateForm();
            });
        });

        // Auto-select program if coming from specific program link
        const urlParams = new URLSearchParams(window.location.search);
        const programParam = urlParams.get('program');
        if (programParam) {
            const targetCard = document.querySelector(`[data-program="${programParam}"]`);
            if (targetCard) {
                targetCard.click();
            }
        }

        // Password strength indicator
        document.getElementById('password')?.addEventListener('input', function() {
            const password = this.value;
            const strengthBar = document.getElementById('passwordStrengthBar');
            let strength = 0;
            
            if (password.length >= 6) strength += 25;
            if (password.match(/[a-z]/) && password.match(/[A-Z]/)) strength += 25;
            if (password.match(/\d/)) strength += 25;
            if (password.match(/[^a-zA-Z\d]/)) strength += 25;
            
            strengthBar.style.width = strength + '%';
            
            if (strength < 50) {
                strengthBar.style.backgroundColor = '#e74c3c';
            } else if (strength < 75) {
                strengthBar.style.backgroundColor = '#f39c12';
            } else {
                strengthBar.style.backgroundColor = '#27ae60';
            }
        });
        
        // Password match validation
        document.getElementById('confirmPassword')?.addEventListener('input', function() {
            const password = document.getElementById('password').value;
            const confirmPassword = this.value;
            const matchText = document.getElementById('passwordMatchText');
            
            if (confirmPassword === '') {
                matchText.textContent = '';
                matchText.className = 'form-text';
            } else if (password === confirmPassword) {
                matchText.textContent = '✓ Passwords match';
                matchText.className = 'form-text text-success';
            } else {
                matchText.textContent = '✗ Passwords do not match';
                matchText.className = 'form-text text-danger';
            }
        });

        // Form validation
        function validateForm() {
            const selectedProgram = document.getElementById('selectedProgram').value;
            const registerBtn = document.getElementById('registerBtn');
            
            if (!selectedProgram) {
                registerBtn.disabled = true;
                registerBtn.innerHTML = '<i class="fas fa-exclamation-triangle me-2"></i>Select a Program';
            } else {
                registerBtn.disabled = false;
                registerBtn.innerHTML = '<i class="fas fa-user-plus me-2"></i>Create Account & Continue to Application';
            }
        }

        // Initial form validation
        validateForm();

        // Form submission enhancement
        document.getElementById('registerForm')?.addEventListener('submit', function(e) {
            const selectedProgram = document.getElementById('selectedProgram').value;
            if (!selectedProgram) {
                e.preventDefault();
                alert('Please select a program you are interested in.');
                return;
            }
            
            const submitBtn = this.querySelector('button[type="submit"]');
            submitBtn.classList.add('btn-loading');
            submitBtn.disabled = true;
        });

        // Additional form validation
        document.getElementById('registerForm')?.addEventListener('input', function(e) {
            if (e.target.name === 'full_name') {
                const fullName = e.target.value;
                const regex = /^[a-zA-Z0-9\s\.\-]*$/;
                if (!regex.test(fullName)) {
                    e.target.setCustomValidity('Only letters, numbers, spaces, dots and hyphens are allowed');
                } else {
                    e.target.setCustomValidity('');
                }
            }
        });
    </script>
</body>
</html>