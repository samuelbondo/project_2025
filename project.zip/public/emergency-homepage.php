<?php
// Emergency homepage without config.php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Define minimal constants
define('SITE_URL', 'https://reach.gt.tc');

// Manual database connection
$db_host = 'sql105.infinityfree.com';
$db_name = 'if0_39669901_reach';
$db_user = 'if0_39669901';
$db_pass = 'Quewon2025';

try {
    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8mb4", $db_user, $db_pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Get stats
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM users WHERE role = 'student' AND status = 'active'");
    $totalStudents = $stmt->fetch()['total'];
    
    echo "<h1>REACH Organization - Emergency Homepage</h1>";
    echo "<p>Students Supported: $totalStudents</p>";
    echo "<p>✅ Database is working!</p>";
    
} catch (Exception $e) {
    echo "<h1>Database Error</h1>";
    echo "<p>" . $e->getMessage() . "</p>";
}

// Minimal functions
function isLoggedIn() { return false; }
function getDashboardUrl($r) { return '/public/login.php'; }
?>