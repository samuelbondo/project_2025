<?php
// Debug version of your main homepage
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h3>Debugging Main Homepage</h3>";

// Step 1: Test basic PHP
echo "✅ PHP is working<br>";

// Step 2: Test session
session_start();
echo "✅ Session started<br>";

// Step 3: Test config.php inclusion
try {
    require_once '../includes/config.php';
    echo "✅ config.php loaded successfully<br>";
} catch (Exception $e) {
    echo "❌ config.php failed: " . $e->getMessage() . "<br>";
    exit;
}

// Step 4: Test functions.php inclusion  
try {
    require_once '../includes/functions.php';
    echo "✅ functions.php loaded successfully<br>";
} catch (Exception $e) {
    echo "❌ functions.php failed: " . $e->getMessage() . "<br>";
    exit;
}

// Step 5: Test database connection
try {
    global $pdo;
    $stmt = $pdo->query("SELECT 1");
    echo "✅ Database connection working<br>";
} catch (Exception $e) {
    echo "❌ Database query failed: " . $e->getMessage() . "<br>";
    exit;
}

// Step 6: Test the specific functions that might be causing issues
echo "Testing isLoggedIn: " . (isLoggedIn() ? 'true' : 'false') . "<br>";
echo "Testing getDashboardUrl: " . getDashboardUrl('student') . "<br>";

// Step 7: Test the actual homepage content
try {
    // Include your header
    require_once '../includes/header.php';
    echo "✅ Header loaded successfully<br>";
    
    // Test your actual homepage content here
    echo "<h4>Homepage content would load here</h4>";
    
} catch (Exception $e) {
    echo "❌ Header or content failed: " . $e->getMessage() . "<br>";
    echo "<pre>Stack trace: " . $e->getTraceAsString() . "</pre>";
}
?>