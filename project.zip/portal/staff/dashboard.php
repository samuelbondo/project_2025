<?php
session_start();
require_once '../../includes/config.php';
require_once '../../includes/database.php';

// Check if user is staff
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'staff') {
    header('Location: ../login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

class StaffDashboard {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    public function getDashboardData() {
        return [
            'stats' => $this->getStaffStats(),
            'pending_tasks' => $this->getPendingTasks(),
            'recent_applications' => $this->getRecentApplications(),
            'upcoming_events' => $this->getUpcomingEvents(),
            'system_alerts' => $this->getSystemAlerts()
        ];
    }
    
    private function getStaffStats() {
        try {
            // Total applications
            $stmt = $this->pdo->query("SELECT COUNT(*) as total_applications FROM applications");
            $total_applications = $stmt->fetchColumn();
            
            // Pending applications
            $stmt = $this->pdo->query("SELECT COUNT(*) as pending_applications FROM applications WHERE status IN ('submitted', 'under_review')");
            $pending_applications = $stmt->fetchColumn();
            
            // Total students
            $stmt = $this->pdo->query("SELECT COUNT(*) as total_students FROM users WHERE role = 'student'");
            $total_students = $stmt->fetchColumn();
            
            // Active projects
            $stmt = $this->pdo->query("SELECT COUNT(*) as active_projects FROM student_projects WHERE status = 'in_progress'");
            $active_projects = $stmt->fetchColumn();
            
            return [
                'total_applications' => $total_applications,
                'pending_applications' => $pending_applications,
                'total_students' => $total_students,
                'active_projects' => $active_projects
            ];
        } catch (Exception $e) {
            return [
                'total_applications' => 0,
                'pending_applications' => 0,
                'total_students' => 0,
                'active_projects' => 0
            ];
        }
    }
    
    private function getPendingTasks() {
        try {
            $sql = "SELECT 
                a.id, a.application_code, a.program_type, a.status,
                u.full_name, u.email,
                a.created_at
                FROM applications a
                JOIN users u ON a.user_id = u.id
                WHERE a.status IN ('submitted', 'under_review')
                ORDER BY a.created_at DESC
                LIMIT 10";
            
            $stmt = $this->pdo->query($sql);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            return [];
        }
    }
    
    private function getRecentApplications() {
        try {
            $sql = "SELECT 
                a.id, a.application_code, a.program_type, a.status,
                u.full_name, u.email,
                a.created_at
                FROM applications a
                JOIN users u ON a.user_id = u.id
                ORDER BY a.created_at DESC
                LIMIT 5";
            
            $stmt = $this->pdo->query($sql);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            return [];
        }
    }
    
    private function getUpcomingEvents() {
        try {
            // Check if events table exists
            $stmt = $this->pdo->query("SHOW TABLES LIKE 'events'");
            if ($stmt->fetch()) {
                $sql = "SELECT id, title, event_date, event_type, location
                        FROM events 
                        WHERE event_date >= CURDATE() 
                        ORDER BY event_date ASC 
                        LIMIT 5";
                $stmt = $this->pdo->query($sql);
                return $stmt->fetchAll(PDO::FETCH_ASSOC);
            }
            return [];
        } catch (Exception $e) {
            return [];
        }
    }
    
    private function getSystemAlerts() {
        $alerts = [];
        
        // Check for pending applications
        $stmt = $this->pdo->query("SELECT COUNT(*) FROM applications WHERE status IN ('submitted', 'under_review')");
        $pending_count = $stmt->fetchColumn();
        
        if ($pending_count > 0) {
            $alerts[] = [
                'type' => 'warning',
                'message' => "You have {$pending_count} applications pending review",
                'action' => 'applications/pending.php'
            ];
        }
        
        return $alerts;
    }
}

// Initialize dashboard
$staffDashboard = new StaffDashboard($pdo);
$dashboardData = $staffDashboard->getDashboardData();

function getApplicationStatusBadge($status) {
    $statuses = [
        'draft' => 'secondary',
        'submitted' => 'warning',
        'under_review' => 'info',
        'approved' => 'success',
        'rejected' => 'danger'
    ];
    return $statuses[$status] ?? 'secondary';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Dashboard - REACH Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary: #3498db;
            --secondary: #2c3e50;
            --success: #27ae60;
            --warning: #f39c12;
            --danger: #e74c3c;
        }
        
        .staff-dashboard {
            background: #f8f9fa;
            min-height: 100vh;
        }
        
        .navbar-brand {
            font-weight: 700;
        }
        
        .welcome-section {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            padding: 2rem 0;
            margin-bottom: 2rem;
        }
        
        .stat-card {
            background: white;
            border-radius: 10px;
            padding: 1.5rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-left: 4px solid var(--primary);
            margin-bottom: 1.5rem;
        }
        
        .stat-card.warning { border-left-color: var(--warning); }
        .stat-card.success { border-left-color: var(--success); }
        .stat-card.info { border-left-color: var(--primary); }
        
        .stat-icon {
            font-size: 2rem;
            margin-bottom: 1rem;
        }
        
        .stat-number {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
        }
        
        .portal-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 1.5rem;
        }
        
        .portal-card .card-header {
            background: white;
            border-bottom: 1px solid #dee2e6;
            padding: 1rem 1.5rem;
            font-weight: 600;
        }
        
        .task-item, .application-item {
            padding: 1rem;
            border-bottom: 1px solid #f8f9fa;
            transition: background-color 0.2s;
        }
        
        .task-item:hover, .application-item:hover {
            background-color: #f8f9fa;
        }
        
        .task-item:last-child, .application-item:last-child {
            border-bottom: none;
        }
        
        .alert-item {
            padding: 1rem;
            border-left: 4px solid;
            margin-bottom: 0.5rem;
            border-radius: 4px;
        }
        
        .alert-warning { border-left-color: var(--warning); background: #fff3cd; }
        .alert-info { border-left-color: var(--primary); background: #d1ecf1; }
    </style>
</head>
<body class="staff-dashboard">
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-hands-helping me-2"></i>
                REACH Staff Portal
            </a>
            <div class="navbar-nav ms-auto">
                <span class="navbar-text me-3">
                    Welcome, <?php echo htmlspecialchars($_SESSION['full_name'] ?? 'Staff'); ?>
                </span>
                <a class="nav-link" href="profile.php">Profile</a>
                <a class="nav-link" href="../../logout.php">Logout</a>
            </div>
        </div>
    </nav>

    <!-- Welcome Section -->
    <section class="welcome-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1>Staff Dashboard</h1>
                    <p class="lead mb-0">Manage applications, support students, and coordinate programs</p>
                </div>
                <div class="col-md-4 text-end">
                    <div class="btn-group">
                        <a href="applications/pending.php" class="btn btn-light">
                            <i class="fas fa-tasks me-2"></i>Pending Tasks
                        </a>
                        <a href="students/index.php" class="btn btn-outline-light">
                            <i class="fas fa-users me-2"></i>Student Management
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="container">
        <!-- System Alerts -->
        <?php if (!empty($dashboardData['system_alerts'])): ?>
        <div class="row mb-4">
            <div class="col-12">
                <div class="portal-card">
                    <div class="card-header">
                        <i class="fas fa-bell me-2"></i>System Alerts
                    </div>
                    <div class="card-body">
                        <?php foreach ($dashboardData['system_alerts'] as $alert): ?>
                        <div class="alert-item alert-<?php echo $alert['type']; ?>">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <i class="fas fa-exclamation-circle me-2"></i>
                                    <?php echo $alert['message']; ?>
                                </div>
                                <a href="<?php echo $alert['action']; ?>" class="btn btn-sm btn-<?php echo $alert['type']; ?>">
                                    Take Action
                                </a>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Quick Stats -->
        <div class="row mb-4">
            <div class="col-xl-3 col-md-6">
                <div class="stat-card info">
                    <div class="stat-icon text-primary">
                        <i class="fas fa-file-alt"></i>
                    </div>
                    <div class="stat-number text-primary">
                        <?php echo $dashboardData['stats']['total_applications']; ?>
                    </div>
                    <p class="text-muted mb-0">Total Applications</p>
                </div>
            </div>
            <div class="col-xl-3 col-md-6">
                <div class="stat-card warning">
                    <div class="stat-icon text-warning">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="stat-number text-warning">
                        <?php echo $dashboardData['stats']['pending_applications']; ?>
                    </div>
                    <p class="text-muted mb-0">Pending Review</p>
                </div>
            </div>
            <div class="col-xl-3 col-md-6">
                <div class="stat-card success">
                    <div class="stat-icon text-success">
                        <i class="fas fa-user-graduate"></i>
                    </div>
                    <div class="stat-number text-success">
                        <?php echo $dashboardData['stats']['total_students']; ?>
                    </div>
                    <p class="text-muted mb-0">Active Students</p>
                </div>
            </div>
            <div class="col-xl-3 col-md-6">
                <div class="stat-card">
                    <div class="stat-icon text-info">
                        <i class="fas fa-project-diagram"></i>
                    </div>
                    <div class="stat-number text-info">
                        <?php echo $dashboardData['stats']['active_projects']; ?>
                    </div>
                    <p class="text-muted mb-0">Active Projects</p>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- Pending Tasks -->
            <div class="col-lg-6">
                <div class="portal-card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <span><i class="fas fa-tasks me-2"></i>Pending Tasks</span>
                        <a href="applications/pending.php" class="btn btn-sm btn-primary">View All</a>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($dashboardData['pending_tasks'])): ?>
                            <?php foreach ($dashboardData['pending_tasks'] as $task): ?>
                            <div class="task-item">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <h6 class="mb-1"><?php echo htmlspecialchars($task['application_code']); ?></h6>
                                        <p class="mb-1"><?php echo htmlspecialchars($task['full_name']); ?></p>
                                        <small class="text-muted">
                                            <?php echo ucfirst($task['program_type']); ?> • 
                                            <?php echo date('M j, Y', strtotime($task['created_at'])); ?>
                                        </small>
                                    </div>
                                    <div class="text-end">
                                        <span class="badge bg-<?php echo getApplicationStatusBadge($task['status']); ?>">
                                            <?php echo ucfirst(str_replace('_', ' ', $task['status'])); ?>
                                        </span>
                                        <div class="mt-2">
                                            <a href="applications/review.php?id=<?php echo $task['id']; ?>" class="btn btn-sm btn-outline-primary">
                                                Review
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="text-center py-4 text-muted">
                                <i class="fas fa-check-circle fa-2x mb-3"></i>
                                <p>No pending tasks</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Recent Applications -->
            <div class="col-lg-6">
                <div class="portal-card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <span><i class="fas fa-clock-rotate-left me-2"></i>Recent Applications</span>
                        <a href="applications/index.php" class="btn btn-sm btn-primary">View All</a>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($dashboardData['recent_applications'])): ?>
                            <?php foreach ($dashboardData['recent_applications'] as $application): ?>
                            <div class="application-item">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <h6 class="mb-1"><?php echo htmlspecialchars($application['application_code']); ?></h6>
                                        <p class="mb-1"><?php echo htmlspecialchars($application['full_name']); ?></p>
                                        <small class="text-muted">
                                            <?php echo ucfirst($application['program_type']); ?>
                                        </small>
                                    </div>
                                    <div class="text-end">
                                        <span class="badge bg-<?php echo getApplicationStatusBadge($application['status']); ?>">
                                            <?php echo ucfirst(str_replace('_', ' ', $application['status'])); ?>
                                        </span>
                                        <div class="mt-2">
                                            <small class="text-muted">
                                                <?php echo date('M j', strtotime($application['created_at'])); ?>
                                            </small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="text-center py-4 text-muted">
                                <i class="fas fa-file-alt fa-2x mb-3"></i>
                                <p>No applications yet</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="portal-card">
                    <div class="card-header">
                        <i class="fas fa-bolt me-2"></i>Quick Actions
                    </div>
                    <div class="card-body">
                        <div class="row g-2">
                            <div class="col-md-6">
                                <a href="applications/pending.php" class="btn btn-outline-primary w-100 mb-2">
                                    <i class="fas fa-tasks me-2"></i>Review Applications
                                </a>
                            </div>
                            <div class="col-md-6">
                                <a href="students/index.php" class="btn btn-outline-success w-100 mb-2">
                                    <i class="fas fa-users me-2"></i>Manage Students
                                </a>
                            </div>
                            <div class="col-md-6">
                                <a href="reports/index.php" class="btn btn-outline-info w-100 mb-2">
                                    <i class="fas fa-chart-bar me-2"></i>View Reports
                                </a>
                            </div>
                            <div class="col-md-6">
                                <a href="communications/index.php" class="btn btn-outline-warning w-100 mb-2">
                                    <i class="fas fa-envelope me-2"></i>Send Messages
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>