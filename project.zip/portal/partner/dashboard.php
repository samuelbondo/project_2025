<?php
session_start();
require_once '../../includes/config.php';
require_once '../../includes/database.php';

// Check if user is partner
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'partner') {
    header('Location: ../login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

class PartnerDashboard {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    public function getDashboardData($partnerId) {
        return [
            'partner_info' => $this->getPartnerInfo($partnerId),
            'stats' => $this->getPartnerStats($partnerId),
            'collaborations' => $this->getActiveCollaborations($partnerId),
            'upcoming_events' => $this->getUpcomingEvents($partnerId)
        ];
    }
    
    private function getPartnerInfo($partnerId) {
        try {
            $sql = "SELECT p.*, u.email, u.full_name 
                    FROM partners p 
                    JOIN users u ON p.contact_user_id = u.id 
                    WHERE p.contact_user_id = ?";
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$partnerId]);
            return $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
        } catch (Exception $e) {
            return [];
        }
    }
    
    private function getPartnerStats($partnerId) {
        try {
            // Active collaborations
            $stmt = $this->pdo->prepare("SELECT COUNT(*) as active_collaborations FROM partner_collaborations WHERE partner_id = ? AND status = 'active'");
            $stmt->execute([$partnerId]);
            $active_collaborations = $stmt->fetchColumn();
            
            // Total students impacted
            $stmt = $this->pdo->prepare("SELECT COUNT(DISTINCT student_id) as students_impacted FROM collaboration_participants WHERE collaboration_id IN (SELECT id FROM partner_collaborations WHERE partner_id = ?)");
            $stmt->execute([$partnerId]);
            $students_impacted = $stmt->fetchColumn();
            
            // Upcoming events
            $stmt = $this->pdo->prepare("SELECT COUNT(*) as upcoming_events FROM partner_events WHERE partner_id = ? AND event_date >= CURDATE()");
            $stmt->execute([$partnerId]);
            $upcoming_events = $stmt->fetchColumn();
            
            return [
                'active_collaborations' => $active_collaborations,
                'students_impacted' => $students_impacted,
                'upcoming_events' => $upcoming_events
            ];
        } catch (Exception $e) {
            return [
                'active_collaborations' => 0,
                'students_impacted' => 0,
                'upcoming_events' => 0
            ];
        }
    }
    
    private function getActiveCollaborations($partnerId) {
        try {
            $sql = "SELECT 
                pc.id, pc.title, pc.description, pc.start_date, pc.end_date, pc.status,
                COUNT(cp.student_id) as participant_count
                FROM partner_collaborations pc
                LEFT JOIN collaboration_participants cp ON pc.id = cp.collaboration_id
                WHERE pc.partner_id = ? AND pc.status = 'active'
                GROUP BY pc.id
                ORDER BY pc.created_at DESC
                LIMIT 5";
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$partnerId]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            return [];
        }
    }
    
    private function getUpcomingEvents($partnerId) {
        try {
            $sql = "SELECT 
                id, title, event_date, event_type, location, description
                FROM partner_events 
                WHERE partner_id = ? AND event_date >= CURDATE()
                ORDER BY event_date ASC
                LIMIT 5";
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$partnerId]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            return [];
        }
    }
}

// Initialize dashboard
$partnerDashboard = new PartnerDashboard($pdo);
$dashboardData = $partnerDashboard->getDashboardData($user_id);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Partner Dashboard - REACH Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary: #3498db;
            --secondary: #2c3e50;
            --success: #27ae60;
            --warning: #f39c12;
        }
        
        .partner-dashboard {
            background: #f8f9fa;
            min-height: 100vh;
        }
        
        .welcome-section {
            background: linear-gradient(135deg, #9b59b6 0%, #8e44ad 100%);
            color: white;
            padding: 2rem 0;
            margin-bottom: 2rem;
        }
        
        .stat-card {
            background: white;
            border-radius: 10px;
            padding: 1.5rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-left: 4px solid #9b59b6;
            margin-bottom: 1.5rem;
        }
        
        .stat-card.primary { border-left-color: var(--primary); }
        .stat-card.success { border-left-color: var(--success); }
        
        .portal-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 1.5rem;
        }
        
        .collaboration-card {
            border: 1px solid #e9ecef;
            border-radius: 8px;
            padding: 1rem;
            margin-bottom: 1rem;
        }
    </style>
</head>
<body class="partner-dashboard">
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-hands-helping me-2"></i>
                REACH Partner Portal
            </a>
            <div class="navbar-nav ms-auto">
                <span class="navbar-text me-3">
                    Welcome, <?php echo htmlspecialchars($_SESSION['full_name'] ?? 'Partner'); ?>
                </span>
                <a class="nav-link" href="profile.php">Profile</a>
                <a class="nav-link" href="../../logout.php">Logout</a>
            </div>
        </div>
    </nav>

    <!-- Welcome Section -->
    <section class="welcome-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1>Partner Dashboard</h1>
                    <p class="lead mb-0">
                        <?php echo htmlspecialchars($dashboardData['partner_info']['name'] ?? 'Partner Organization'); ?> - 
                        Making an impact together
                    </p>
                </div>
                <div class="col-md-4 text-end">
                    <div class="btn-group">
                        <a href="collaborations.php" class="btn btn-light">
                            <i class="fas fa-handshake me-2"></i>Collaborations
                        </a>
                        <a href="events.php" class="btn btn-outline-light">
                            <i class="fas fa-calendar me-2"></i>Events
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="container">
        <!-- Quick Stats -->
        <div class="row mb-4">
            <div class="col-xl-4 col-md-6">
                <div class="stat-card">
                    <div class="stat-icon text-purple">
                        <i class="fas fa-handshake" style="color: #9b59b6;"></i>
                    </div>
                    <div class="stat-number" style="font-size: 2rem; font-weight: 700; color: #9b59b6;">
                        <?php echo $dashboardData['stats']['active_collaborations']; ?>
                    </div>
                    <p class="text-muted mb-0">Active Collaborations</p>
                </div>
            </div>
            <div class="col-xl-4 col-md-6">
                <div class="stat-card success">
                    <div class="stat-icon text-success">
                        <i class="fas fa-user-graduate"></i>
                    </div>
                    <div class="stat-number text-success" style="font-size: 2rem; font-weight: 700;">
                        <?php echo $dashboardData['stats']['students_impacted']; ?>
                    </div>
                    <p class="text-muted mb-0">Students Impacted</p>
                </div>
            </div>
            <div class="col-xl-4 col-md-6">
                <div class="stat-card primary">
                    <div class="stat-icon text-primary">
                        <i class="fas fa-calendar"></i>
                    </div>
                    <div class="stat-number text-primary" style="font-size: 2rem; font-weight: 700;">
                        <?php echo $dashboardData['stats']['upcoming_events']; ?>
                    </div>
                    <p class="text-muted mb-0">Upcoming Events</p>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- Active Collaborations -->
            <div class="col-lg-8">
                <div class="portal-card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <span><i class="fas fa-handshake me-2"></i>Active Collaborations</span>
                        <a href="collaborations.php" class="btn btn-sm btn-primary">View All</a>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($dashboardData['collaborations'])): ?>
                            <?php foreach ($dashboardData['collaborations'] as $collab): ?>
                            <div class="collaboration-card">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <h6 class="mb-1"><?php echo htmlspecialchars($collab['title']); ?></h6>
                                    <span class="badge bg-success">Active</span>
                                </div>
                                <p class="text-muted small mb-2">
                                    <?php echo htmlspecialchars(substr($collab['description'] ?? '', 0, 100)); ?>...
                                </p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <small class="text-muted">
                                        <i class="fas fa-users me-1"></i>
                                        <?php echo $collab['participant_count']; ?> participants
                                    </small>
                                    <small class="text-muted">
                                        <i class="fas fa-calendar me-1"></i>
                                        Until <?php echo date('M j, Y', strtotime($collab['end_date'])); ?>
                                    </small>
                                </div>
                                <div class="mt-2">
                                    <a href="collaboration-details.php?id=<?php echo $collab['id']; ?>" class="btn btn-sm btn-outline-primary">View Details</a>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="text-center py-4 text-muted">
                                <i class="fas fa-handshake fa-2x mb-3"></i>
                                <p>No active collaborations</p>
                                <a href="new-collaboration.php" class="btn btn-primary">Start New Collaboration</a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Sidebar -->
            <div class="col-lg-4">
                <!-- Upcoming Events -->
                <div class="portal-card">
                    <div class="card-header">
                        <i class="fas fa-calendar me-2"></i>Upcoming Events
                    </div>
                    <div class="card-body">
                        <?php if (!empty($dashboardData['upcoming_events'])): ?>
                            <?php foreach ($dashboardData['upcoming_events'] as $event): ?>
                            <div class="d-flex justify-content-between align-items-center mb-3 pb-3 border-bottom">
                                <div>
                                    <h6 class="mb-1"><?php echo htmlspecialchars($event['title']); ?></h6>
                                    <small class="text-muted">
                                        <i class="fas fa-map-marker-alt me-1"></i>
                                        <?php echo htmlspecialchars($event['location']); ?>
                                    </small>
                                    <br>
                                    <small class="text-muted">
                                        <i class="fas fa-clock me-1"></i>
                                        <?php echo date('M j, Y', strtotime($event['event_date'])); ?>
                                    </small>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="text-center py-3 text-muted">
                                <i class="fas fa-calendar fa-2x mb-2"></i>
                                <p>No upcoming events</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Partner Information -->
                <div class="portal-card">
                    <div class="card-header">
                        <i class="fas fa-building me-2"></i>Partner Information
                    </div>
                    <div class="card-body">
                        <?php if (!empty($dashboardData['partner_info'])): ?>
                            <h6><?php echo htmlspecialchars($dashboardData['partner_info']['name']); ?></h6>
                            <p class="text-muted small mb-2">
                                <?php echo htmlspecialchars($dashboardData['partner_info']['description'] ?? 'No description available'); ?>
                            </p>
                            <div class="partner-details">
                                <?php if (!empty($dashboardData['partner_info']['website'])): ?>
                                <small class="text-muted d-block">
                                    <i class="fas fa-globe me-1"></i>
                                    <a href="<?php echo htmlspecialchars($dashboardData['partner_info']['website']); ?>" target="_blank">
                                        Website
                                    </a>
                                </small>
                                <?php endif; ?>
                                <small class="text-muted d-block">
                                    <i class="fas fa-envelope me-1"></i>
                                    <?php echo htmlspecialchars($dashboardData['partner_info']['contact_email'] ?? $dashboardData['partner_info']['email']); ?>
                                </small>
                                <small class="text-muted d-block">
                                    <i class="fas fa-tag me-1"></i>
                                    <?php echo ucfirst($dashboardData['partner_info']['partnership_type'] ?? 'Not specified'); ?>
                                </small>
                            </div>
                        <?php else: ?>
                            <div class="text-center py-3 text-muted">
                                <i class="fas fa-building fa-2x mb-2"></i>
                                <p>Partner information not available</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="portal-card">
                    <div class="card-header">
                        <i class="fas fa-bolt me-2"></i>Quick Actions
                    </div>
                    <div class="card-body">
                        <div class="d-grid gap-2">
                            <a href="new-collaboration.php" class="btn btn-primary">
                                <i class="fas fa-plus me-2"></i>New Collaboration
                            </a>
                            <a href="events.php" class="btn btn-outline-primary">
                                <i class="fas fa-calendar me-2"></i>Manage Events
                            </a>
                            <a href="reports.php" class="btn btn-outline-info">
                                <i class="fas fa-chart-bar me-2"></i>Impact Reports
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>