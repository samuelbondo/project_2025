<?php
session_start();
require_once '../../includes/config.php';
require_once '../../includes/database.php';

// Check if user is volunteer
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'volunteer') {
    header('Location: ../login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

class VolunteerDashboard {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    public function getDashboardData($volunteerId) {
        return [
            'stats' => $this->getVolunteerStats($volunteerId),
            'upcoming_events' => $this->getUpcomingEvents($volunteerId),
            'active_assignments' => $this->getActiveAssignments($volunteerId),
            'volunteer_hours' => $this->getVolunteerHours($volunteerId)
        ];
    }
    
    private function getVolunteerStats($volunteerId) {
        try {
            // Total hours volunteered
            $stmt = $this->pdo->prepare("SELECT COALESCE(SUM(hours), 0) as total_hours FROM volunteer_hours WHERE volunteer_id = ? AND status = 'verified'");
            $stmt->execute([$volunteerId]);
            $total_hours = $stmt->fetchColumn();
            
            // Upcoming events
            $stmt = $this->pdo->prepare("SELECT COUNT(*) as upcoming_events FROM event_registrations WHERE volunteer_id = ? AND event_date >= CURDATE()");
            $stmt->execute([$volunteerId]);
            $upcoming_events = $stmt->fetchColumn();
            
            // Active assignments
            $stmt = $this->pdo->prepare("SELECT COUNT(*) as active_assignments FROM volunteer_assignments WHERE volunteer_id = ? AND status = 'active'");
            $stmt->execute([$volunteerId]);
            $active_assignments = $stmt->fetchColumn();
            
            return [
                'total_hours' => $total_hours,
                'upcoming_events' => $upcoming_events,
                'active_assignments' => $active_assignments
            ];
        } catch (Exception $e) {
            return [
                'total_hours' => 0,
                'upcoming_events' => 0,
                'active_assignments' => 0
            ];
        }
    }
    
    private function getUpcomingEvents($volunteerId) {
        try {
            $sql = "SELECT 
                er.id, e.title, e.event_date, e.event_type, e.location,
                e.description
                FROM event_registrations er
                JOIN events e ON er.event_id = e.id
                WHERE er.volunteer_id = ? AND e.event_date >= CURDATE()
                ORDER BY e.event_date ASC
                LIMIT 5";
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$volunteerId]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            return [];
        }
    }
    
    private function getActiveAssignments($volunteerId) {
        try {
            $sql = "SELECT 
                va.id, va.title, va.description, va.start_date, va.end_date,
                va.status, va.priority
                FROM volunteer_assignments va
                WHERE va.volunteer_id = ? AND va.status = 'active'
                ORDER BY va.priority DESC, va.start_date ASC
                LIMIT 5";
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$volunteerId]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            return [];
        }
    }
    
    private function getVolunteerHours($volunteerId) {
        try {
            $sql = "SELECT 
                DATE_FORMAT(date_worked, '%Y-%m') as month,
                SUM(hours) as total_hours
                FROM volunteer_hours 
                WHERE volunteer_id = ? AND status = 'verified'
                GROUP BY DATE_FORMAT(date_worked, '%Y-%m')
                ORDER BY month DESC
                LIMIT 6";
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$volunteerId]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            return [];
        }
    }
}

// Initialize dashboard
$volunteerDashboard = new VolunteerDashboard($pdo);
$dashboardData = $volunteerDashboard->getDashboardData($user_id);

function getPriorityBadge($priority) {
    $priorities = [
        'high' => 'danger',
        'medium' => 'warning',
        'low' => 'success'
    ];
    return $priorities[$priority] ?? 'secondary';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Volunteer Dashboard - REACH Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary: #3498db;
            --secondary: #2c3e50;
            --success: #27ae60;
            --warning: #f39c12;
        }
        
        .volunteer-dashboard {
            background: #f8f9fa;
            min-height: 100vh;
        }
        
        .welcome-section {
            background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);
            color: white;
            padding: 2rem 0;
            margin-bottom: 2rem;
        }
        
        .stat-card {
            background: white;
            border-radius: 10px;
            padding: 1.5rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-left: 4px solid #e74c3c;
            margin-bottom: 1.5rem;
        }
        
        .stat-card.primary { border-left-color: var(--primary); }
        .stat-card.success { border-left-color: var(--success); }
        
        .portal-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 1.5rem;
        }
        
        .event-card, .assignment-card {
            border: 1px solid #e9ecef;
            border-radius: 8px;
            padding: 1rem;
            margin-bottom: 1rem;
        }
    </style>
</head>
<body class="volunteer-dashboard">
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-hands-helping me-2"></i>
                REACH Volunteer Portal
            </a>
            <div class="navbar-nav ms-auto">
                <span class="navbar-text me-3">
                    Welcome, <?php echo htmlspecialchars($_SESSION['full_name'] ?? 'Volunteer'); ?>
                </span>
                <a class="nav-link" href="profile.php">Profile</a>
                <a class="nav-link" href="../../logout.php">Logout</a>
            </div>
        </div>
    </nav>

    <!-- Welcome Section -->
    <section class="welcome-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1>Volunteer Dashboard</h1>
                    <p class="lead mb-0">Thank you for your dedication to making a difference!</p>
                </div>
                <div class="col-md-4 text-end">
                    <div class="btn-group">
                        <a href="events.php" class="btn btn-light">
                            <i class="fas fa-calendar me-2"></i>Upcoming Events
                        </a>
                        <a href="log-hours.php" class="btn btn-outline-light">
                            <i class="fas fa-clock me-2"></i>Log Hours
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="container">
        <!-- Quick Stats -->
        <div class="row mb-4">
            <div class="col-xl-4 col-md-6">
                <div class="stat-card">
                    <div class="stat-icon text-danger">
                        <i class="fas fa-clock" style="color: #e74c3c;"></i>
                    </div>
                    <div class="stat-number" style="font-size: 2rem; font-weight: 700; color: #e74c3c;">
                        <?php echo $dashboardData['stats']['total_hours']; ?>
                    </div>
                    <p class="text-muted mb-0">Total Hours Volunteered</p>
                </div>
            </div>
            <div class="col-xl-4 col-md-6">
                <div class="stat-card primary">
                    <div class="stat-icon text-primary">
                        <i class="fas fa-calendar"></i>
                    </div>
                    <div class="stat-number text-primary" style="font-size: 2rem; font-weight: 700;">
                        <?php echo $dashboardData['stats']['upcoming_events']; ?>
                    </div>
                    <p class="text-muted mb-0">Upcoming Events</p>
                </div>
            </div>
            <div class="col-xl-4 col-md-6">
                <div class="stat-card success">
                    <div class="stat-icon text-success">
                        <i class="fas fa-tasks"></i>
                    </div>
                    <div class="stat-number text-success" style="font-size: 2rem; font-weight: 700;">
                        <?php echo $dashboardData['stats']['active_assignments']; ?>
                    </div>
                    <p class="text-muted mb-0">Active Assignments</p>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- Upcoming Events -->
            <div class="col-lg-6">
                <div class="portal-card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <span><i class="fas fa-calendar me-2"></i>Upcoming Events</span>
                        <a href="events.php" class="btn btn-sm btn-primary">View All</a>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($dashboardData['upcoming_events'])): ?>
                            <?php foreach ($dashboardData['upcoming_events'] as $event): ?>
                            <div class="event-card">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <h6 class="mb-1"><?php echo htmlspecialchars($event['title']); ?></h6>
                                    <span class="badge bg-info"><?php echo ucfirst($event['event_type']); ?></span>
                                </div>
                                <p class="text-muted small mb-2">
                                    <?php echo htmlspecialchars(substr($event['description'] ?? '', 0, 100)); ?>...
                                </p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <small class="text-muted">
                                        <i class="fas fa-map-marker-alt me-1"></i>
                                        <?php echo htmlspecialchars($event['location']); ?>
                                    </small>
                                    <small class="text-muted">
                                        <i class="fas fa-clock me-1"></i>
                                        <?php echo date('M j, Y', strtotime($event['event_date'])); ?>
                                    </small>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="text-center py-4 text-muted">
                                <i class="fas fa-calendar fa-2x mb-3"></i>
                                <p>No upcoming events</p>
                                <a href="events.php" class="btn btn-primary">Browse Events</a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Active Assignments -->
            <div class="col-lg-6">
                <div class="portal-card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <span><i class="fas fa-tasks me-2"></i>Active Assignments</span>
                        <a href="assignments.php" class="btn btn-sm btn-success">View All</a>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($dashboardData['active_assignments'])): ?>
                            <?php foreach ($dashboardData['active_assignments'] as $assignment): ?>
                            <div class="assignment-card">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <h6 class="mb-1"><?php echo htmlspecialchars($assignment['title']); ?></h6>
                                    <span class="badge bg-<?php echo getPriorityBadge($assignment['priority']); ?>">
                                        <?php echo ucfirst($assignment['priority']); ?>
                                    </span>
                                </div>
                                <p class="text-muted small mb-2">
                                    <?php echo htmlspecialchars(substr($assignment['description'] ?? '', 0, 100)); ?>...
                                </p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <small class="text-muted">
                                        Due: <?php echo date('M j, Y', strtotime($assignment['end_date'])); ?>
                                    </small>
                                    <a href="assignment-details.php?id=<?php echo $assignment['id']; ?>" class="btn btn-sm btn-outline-primary">
                                        View Details
                                    </a>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="text-center py-4 text-muted">
                                <i class="fas fa-tasks fa-2x mb-3"></i>
                                <p>No active assignments</p>
                                <a href="assignments.php" class="btn btn-success">Find Opportunities</a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Volunteer Hours -->
                <div class="portal-card">
                    <div class="card-header">
                        <i class="fas fa-chart-line me-2"></i>Volunteer Hours
                    </div>
                    <div class="card-body">
                        <?php if (!empty($dashboardData['volunteer_hours'])): ?>
                            <?php foreach ($dashboardData['volunteer_hours'] as $hours): ?>
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <span class="text-muted">
                                    <?php echo date('F Y', strtotime($hours['month'] . '-01')); ?>
                                </span>
                                <div class="text-end">
                                    <span class="fw-bold text-success">
                                        <?php echo $hours['total_hours']; ?> hours
                                    </span>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="text-center py-3 text-muted">
                                <i class="fas fa-chart-line fa-2x mb-2"></i>
                                <p>No hours logged yet</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="portal-card">
                    <div class="card-header">
                        <i class="fas fa-bolt me-2"></i>Quick Actions
                    </div>
                    <div class="card-body">
                        <div class="d-grid gap-2">
                            <a href="log-hours.php" class="btn btn-danger">
                                <i class="fas fa-clock me-2"></i>Log Volunteer Hours
                            </a>
                            <a href="events.php" class="btn btn-outline-primary">
                                <i class="fas fa-calendar me-2"></i>Browse Events
                            </a>
                            <a href="assignments.php" class="btn btn-outline-success">
                                <i class="fas fa-tasks me-2"></i>Find Assignments
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>