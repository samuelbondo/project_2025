<?php
session_start();
require_once '../../includes/config.php';
require_once '../../includes/database.php';

// Check if user is sponsor
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'sponsor') {
    header('Location: ../login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

class SponsorDashboard {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    public function getDashboardData($sponsorId) {
        return [
            'stats' => $this->getSponsorStats($sponsorId),
            'sponsored_students' => $this->getSponsoredStudents($sponsorId),
            'recent_activities' => $this->getRecentActivities($sponsorId),
            'investment_summary' => $this->getInvestmentSummary($sponsorId)
        ];
    }
    
    private function getSponsorStats($sponsorId) {
        try {
            // Total sponsored students
            $stmt = $this->pdo->prepare("SELECT COUNT(*) as total_students FROM student_sponsorships WHERE sponsor_id = ?");
            $stmt->execute([$sponsorId]);
            $total_students = $stmt->fetchColumn();
            
            // Total investment
            $stmt = $this->pdo->prepare("SELECT COALESCE(SUM(amount), 0) as total_investment FROM sponsor_transactions WHERE sponsor_id = ? AND status = 'completed'");
            $stmt->execute([$sponsorId]);
            $total_investment = $stmt->fetchColumn();
            
            // Active scholarships
            $stmt = $this->pdo->prepare("SELECT COUNT(*) as active_scholarships FROM student_sponsorships WHERE sponsor_id = ? AND status = 'active'");
            $stmt->execute([$sponsorId]);
            $active_scholarships = $stmt->fetchColumn();
            
            return [
                'total_students' => $total_students,
                'total_investment' => $total_investment,
                'active_scholarships' => $active_scholarships
            ];
        } catch (Exception $e) {
            return [
                'total_students' => 0,
                'total_investment' => 0,
                'active_scholarships' => 0
            ];
        }
    }
    
    private function getSponsoredStudents($sponsorId) {
        try {
            $sql = "SELECT 
                ss.id, ss.start_date, ss.end_date, ss.status, ss.amount,
                u.full_name, u.email, u.profile_picture,
                sp.university, sp.program, sp.current_gpa
                FROM student_sponsorships ss
                JOIN users u ON ss.student_id = u.id
                LEFT JOIN student_profiles sp ON u.id = sp.user_id
                WHERE ss.sponsor_id = ?
                ORDER BY ss.created_at DESC
                LIMIT 5";
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$sponsorId]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            return [];
        }
    }
    
    private function getRecentActivities($sponsorId) {
        try {
            // Get recent transactions
            $sql = "SELECT 
                id, transaction_type, amount, status, created_at
                FROM sponsor_transactions 
                WHERE sponsor_id = ?
                ORDER BY created_at DESC
                LIMIT 5";
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$sponsorId]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            return [];
        }
    }
    
    private function getInvestmentSummary($sponsorId) {
        try {
            $sql = "SELECT 
                transaction_type,
                COUNT(*) as count,
                COALESCE(SUM(amount), 0) as total_amount
                FROM sponsor_transactions 
                WHERE sponsor_id = ? AND status = 'completed'
                GROUP BY transaction_type";
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$sponsorId]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            return [];
        }
    }
}

// Initialize dashboard
$sponsorDashboard = new SponsorDashboard($pdo);
$dashboardData = $sponsorDashboard->getDashboardData($user_id);

function formatCurrency($amount) {
    return '$' . number_format($amount, 2);
}

function getSponsorshipStatusBadge($status) {
    $statuses = [
        'active' => 'success',
        'pending' => 'warning',
        'completed' => 'info',
        'cancelled' => 'danger'
    ];
    return $statuses[$status] ?? 'secondary';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sponsor Dashboard - REACH Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary: #3498db;
            --secondary: #2c3e50;
            --success: #27ae60;
            --warning: #f39c12;
        }
        
        .sponsor-dashboard {
            background: #f8f9fa;
            min-height: 100vh;
        }
        
        .welcome-section {
            background: linear-gradient(135deg, #2ecc71 0%, #27ae60 100%);
            color: white;
            padding: 2rem 0;
            margin-bottom: 2rem;
        }
        
        .stat-card {
            background: white;
            border-radius: 10px;
            padding: 1.5rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-left: 4px solid var(--success);
            margin-bottom: 1.5rem;
        }
        
        .stat-card.primary { border-left-color: var(--primary); }
        .stat-card.warning { border-left-color: var(--warning); }
        
        .stat-icon {
            font-size: 2rem;
            margin-bottom: 1rem;
        }
        
        .portal-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 1.5rem;
        }
        
        .student-card {
            border: 1px solid #e9ecef;
            border-radius: 8px;
            padding: 1rem;
            margin-bottom: 1rem;
            transition: transform 0.2s;
        }
        
        .student-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body class="sponsor-dashboard">
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-hands-helping me-2"></i>
                REACH Sponsor Portal
            </a>
            <div class="navbar-nav ms-auto">
                <span class="navbar-text me-3">
                    Welcome, <?php echo htmlspecialchars($_SESSION['full_name'] ?? 'Sponsor'); ?>
                </span>
                <a class="nav-link" href="profile.php">Profile</a>
                <a class="nav-link" href="../../logout.php">Logout</a>
            </div>
        </div>
    </nav>

    <!-- Welcome Section -->
    <section class="welcome-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1>Sponsor Dashboard</h1>
                    <p class="lead mb-0">Track your impact and manage your sponsored students</p>
                </div>
                <div class="col-md-4 text-end">
                    <div class="btn-group">
                        <a href="students.php" class="btn btn-light">
                            <i class="fas fa-user-graduate me-2"></i>My Students
                        </a>
                        <a href="invest.php" class="btn btn-outline-light">
                            <i class="fas fa-donate me-2"></i>Make Investment
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="container">
        <!-- Quick Stats -->
        <div class="row mb-4">
            <div class="col-xl-4 col-md-6">
                <div class="stat-card">
                    <div class="stat-icon text-success">
                        <i class="fas fa-user-graduate"></i>
                    </div>
                    <div class="stat-number text-success" style="font-size: 2rem; font-weight: 700;">
                        <?php echo $dashboardData['stats']['total_students']; ?>
                    </div>
                    <p class="text-muted mb-0">Sponsored Students</p>
                </div>
            </div>
            <div class="col-xl-4 col-md-6">
                <div class="stat-card primary">
                    <div class="stat-icon text-primary">
                        <i class="fas fa-donate"></i>
                    </div>
                    <div class="stat-number text-primary" style="font-size: 2rem; font-weight: 700;">
                        <?php echo formatCurrency($dashboardData['stats']['total_investment']); ?>
                    </div>
                    <p class="text-muted mb-0">Total Investment</p>
                </div>
            </div>
            <div class="col-xl-4 col-md-6">
                <div class="stat-card warning">
                    <div class="stat-icon text-warning">
                        <i class="fas fa-award"></i>
                    </div>
                    <div class="stat-number text-warning" style="font-size: 2rem; font-weight: 700;">
                        <?php echo $dashboardData['stats']['active_scholarships']; ?>
                    </div>
                    <p class="text-muted mb-0">Active Scholarships</p>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- Sponsored Students -->
            <div class="col-lg-8">
                <div class="portal-card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <span><i class="fas fa-user-graduate me-2"></i>Sponsored Students</span>
                        <a href="students.php" class="btn btn-sm btn-success">View All</a>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($dashboardData['sponsored_students'])): ?>
                            <div class="row">
                                <?php foreach ($dashboardData['sponsored_students'] as $student): ?>
                                <div class="col-md-6">
                                    <div class="student-card">
                                        <div class="d-flex align-items-center mb-2">
                                            <div class="flex-grow-1">
                                                <h6 class="mb-1"><?php echo htmlspecialchars($student['full_name']); ?></h6>
                                                <p class="text-muted mb-1 small">
                                                    <?php echo htmlspecialchars($student['program'] ?? 'Not specified'); ?>
                                                </p>
                                            </div>
                                            <span class="badge bg-<?php echo getSponsorshipStatusBadge($student['status']); ?>">
                                                <?php echo ucfirst($student['status']); ?>
                                            </span>
                                        </div>
                                        <div class="student-details">
                                            <small class="text-muted d-block">
                                                <i class="fas fa-university me-1"></i>
                                                <?php echo htmlspecialchars($student['university'] ?? 'University not specified'); ?>
                                            </small>
                                            <small class="text-muted d-block">
                                                <i class="fas fa-star me-1"></i>
                                                GPA: <?php echo $student['current_gpa'] ?? 'N/A'; ?>
                                            </small>
                                            <small class="text-success d-block">
                                                <i class="fas fa-donate me-1"></i>
                                                <?php echo formatCurrency($student['amount'] ?? 0); ?>
                                            </small>
                                        </div>
                                        <div class="mt-2">
                                            <a href="student-details.php?id=<?php echo $student['id']; ?>" class="btn btn-sm btn-outline-primary w-100">
                                                View Progress
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <div class="text-center py-4 text-muted">
                                <i class="fas fa-user-graduate fa-2x mb-3"></i>
                                <p>No sponsored students yet</p>
                                <a href="invest.php" class="btn btn-success">Sponsor a Student</a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Recent Activities & Quick Actions -->
            <div class="col-lg-4">
                <!-- Recent Activities -->
                <div class="portal-card">
                    <div class="card-header">
                        <i class="fas fa-history me-2"></i>Recent Activities
                    </div>
                    <div class="card-body">
                        <?php if (!empty($dashboardData['recent_activities'])): ?>
                            <?php foreach ($dashboardData['recent_activities'] as $activity): ?>
                            <div class="d-flex justify-content-between align-items-center mb-3 pb-3 border-bottom">
                                <div>
                                    <small class="text-muted d-block">
                                        <?php echo ucfirst(str_replace('_', ' ', $activity['transaction_type'])); ?>
                                    </small>
                                    <small class="text-success fw-bold">
                                        <?php echo formatCurrency($activity['amount']); ?>
                                    </small>
                                </div>
                                <div class="text-end">
                                    <small class="text-muted d-block">
                                        <?php echo date('M j', strtotime($activity['created_at'])); ?>
                                    </small>
                                    <span class="badge bg-<?php echo $activity['status'] === 'completed' ? 'success' : 'warning'; ?>">
                                        <?php echo ucfirst($activity['status']); ?>
                                    </span>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="text-center py-3 text-muted">
                                <i class="fas fa-clock fa-2x mb-2"></i>
                                <p>No recent activities</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Investment Summary -->
                <div class="portal-card">
                    <div class="card-header">
                        <i class="fas fa-chart-pie me-2"></i>Investment Summary
                    </div>
                    <div class="card-body">
                        <?php if (!empty($dashboardData['investment_summary'])): ?>
                            <?php foreach ($dashboardData['investment_summary'] as $summary): ?>
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <span class="text-muted">
                                    <?php echo ucfirst(str_replace('_', ' ', $summary['transaction_type'])); ?>
                                </span>
                                <div class="text-end">
                                    <div class="fw-bold text-success">
                                        <?php echo formatCurrency($summary['total_amount']); ?>
                                    </div>
                                    <small class="text-muted">
                                        <?php echo $summary['count']; ?> transactions
                                    </small>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="text-center py-3 text-muted">
                                <i class="fas fa-chart-pie fa-2x mb-2"></i>
                                <p>No investment data</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="portal-card">
                    <div class="card-header">
                        <i class="fas fa-bolt me-2"></i>Quick Actions
                    </div>
                    <div class="card-body">
                        <div class="d-grid gap-2">
                            <a href="invest.php" class="btn btn-success">
                                <i class="fas fa-donate me-2"></i>Make New Investment
                            </a>
                            <a href="students.php" class="btn btn-outline-primary">
                                <i class="fas fa-user-graduate me-2"></i>View All Students
                            </a>
                            <a href="reports.php" class="btn btn-outline-info">
                                <i class="fas fa-chart-line me-2"></i>View Impact Reports
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>