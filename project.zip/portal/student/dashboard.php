<?php
session_start();
require_once '../../includes/config.php';
require_once '../../includes/database.php';
require_once '../../includes/classes/StoryManager.php';

// Check if user is student
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header('Location: ../../public/login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$student_name = $_SESSION['full_name'] ?? 'Student';

// Fix the duplicate constant warning
if (!defined('MAX_FILE_SIZE')) {
    define('MAX_FILE_SIZE', 5242880); // 5MB
}

// Enhanced StudentDashboard class with all required methods
class StudentDashboard {
    private $pdo;
    private $storyManager;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
        $this->storyManager = new StoryManager($pdo);
    }
    
    public function getStudentDashboardData($userId) {
        try {
            // Get student info
            $student = $this->getStudentInfo($userId);
            
            // Get all stats
            $stats = [
                'projects' => $this->getProjectStats($userId),
                'stories' => $this->getStoryStats($userId),
                'achievements' => $this->getAchievementStats($userId),
                'applications' => $this->getApplicationStats($userId)
            ];
            
            return [
                'student' => $student,
                'stats' => $stats,
                'projects' => $this->getRecentProjects($userId),
                'stories' => $this->getRecentStories($userId),
                'achievements' => $this->getRecentAchievements($userId),
                'deadlines' => $this->getUpcomingDeadlines($userId),
                'applications' => $this->getRecentApplications($userId),
                'has_approved_application' => $this->hasApprovedApplication($userId),
                'can_apply_more' => $this->canApplyForMorePrograms($userId)
            ];
        } catch (Exception $e) {
            error_log("Dashboard data error: " . $e->getMessage());
            return $this->getFallbackData($userId);
        }
    }
    
    private function getStudentInfo($userId) {
        // First try to get from student_profiles table
        try {
            $sql = "SELECT 
                sp.full_name, 
                sp.university, 
                sp.program,
                sp.year_of_study,
                sp.expected_graduation,
                sp.current_gpa,
                sp.program_type,
                sp.scholarship_type,
                sp.bio,
                sp.student_id,
                u.email,
                u.profile_picture,
                u.created_at as member_since
            FROM student_profiles sp
            JOIN users u ON sp.user_id = u.id
            WHERE sp.user_id = ?";
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$userId]);
            $student = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($student) {
                return $student;
            }
        } catch (PDOException $e) {
            // Table might not exist, fall back to users table
            error_log("Student profiles table error: " . $e->getMessage());
        }
        
        // Fallback to users table with data from applications
        $sql = "SELECT 
            u.id as user_id,
            u.full_name,
            u.email,
            u.profile_picture,
            u.created_at as member_since,
            COALESCE(
                (SELECT institution_applying FROM applications WHERE user_id = u.id ORDER BY submitted_at DESC LIMIT 1),
                'University of Rwanda'
            ) as university,
            COALESCE(
                (SELECT intended_major FROM applications WHERE user_id = u.id ORDER BY submitted_at DESC LIMIT 1),
                'Computer Science'
            ) as program,
            '2nd Year' as year_of_study,
            '2026' as expected_graduation,
            '3.75' as current_gpa,
            'scholarship' as program_type,
            'Full Tuition Scholarship' as scholarship_type,
            COALESCE(u.bio, 'Dedicated student passionate about technology and community development.') as bio,
            CONCAT('STU', YEAR(NOW()), LPAD(?, 3, '0')) as student_id
        FROM users u 
        WHERE u.id = ? AND u.role = 'student'";
        
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$userId, $userId]);
        $student = $stmt->fetch(PDO::FETCH_ASSOC);
        
        return $student ?: $this->getDefaultStudentInfo($userId);
    }
    
    private function getApplicationStats($userId) {
        try {
            $sql = "SELECT 
                COUNT(*) as total_applications,
                SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved_applications,
                SUM(CASE WHEN status = 'submitted' THEN 1 ELSE 0 END) as submitted_applications,
                SUM(CASE WHEN status = 'under_review' THEN 1 ELSE 0 END) as under_review_applications,
                SUM(CASE WHEN status = 'draft' THEN 1 ELSE 0 END) as draft_applications,
                SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected_applications
            FROM applications 
            WHERE user_id = ?";
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$userId]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            return $result ?: [
                'total_applications' => 0,
                'approved_applications' => 0,
                'submitted_applications' => 0,
                'under_review_applications' => 0,
                'draft_applications' => 0,
                'rejected_applications' => 0
            ];
        } catch (PDOException $e) {
            error_log("Application stats error: " . $e->getMessage());
            return [
                'total_applications' => 0,
                'approved_applications' => 0,
                'submitted_applications' => 0,
                'under_review_applications' => 0,
                'draft_applications' => 0,
                'rejected_applications' => 0
            ];
        }
    }
    
    private function getRecentApplications($userId) {
        try {
            $sql = "SELECT 
                id,
                application_code,
                program_type,
                status,
                academic_level,
                institution_applying,
                intended_major,
                submitted_at,
                created_at
            FROM applications 
            WHERE user_id = ? 
            ORDER BY COALESCE(submitted_at, created_at) DESC 
            LIMIT 5";
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$userId]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Recent applications error: " . $e->getMessage());
            return [];
        }
    }
    
    private function hasApprovedApplication($userId) {
        try {
            $sql = "SELECT COUNT(*) as approved_count 
                    FROM applications 
                    WHERE user_id = ? AND status = 'approved'";
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$userId]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $approvedCount = $result['approved_count'] ?? 0;
            
            // Debug logging
            error_log("User ID: $userId - Approved applications count: $approvedCount");
            
            return $approvedCount > 0;
        } catch (PDOException $e) {
            error_log("Approved application check error: " . $e->getMessage());
            return false;
        }
    }
    
    private function canApplyForMorePrograms($userId) {
        // Students can always apply for more programs, regardless of current status
        return true;
    }
    
    private function getProjectStats($userId) {
        try {
            // Check if student_projects table exists
            $stmt = $this->pdo->query("SHOW TABLES LIKE 'student_projects'");
            if (!$stmt->fetch()) {
                return ['total_projects' => 0, 'completed_projects' => 0];
            }
            
            $sql = "SELECT 
                COUNT(*) as total_projects,
                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_projects
                FROM student_projects 
                WHERE student_id = ?";
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$userId]);
            return $stmt->fetch(PDO::FETCH_ASSOC) ?: ['total_projects' => 0, 'completed_projects' => 0];
        } catch (PDOException $e) {
            return ['total_projects' => 0, 'completed_projects' => 0];
        }
    }
    
    private function getStoryStats($userId) {
        try {
            // Use StoryManager to get story statistics
            return $this->storyManager->getStudentStoryStats($userId);
        } catch (PDOException $e) {
            return ['total_stories' => 0, 'total_views' => 0, 'total_likes' => 0];
        }
    }
    
    private function getAchievementStats($userId) {
        try {
            // Check if student_achievements table exists
            $stmt = $this->pdo->query("SHOW TABLES LIKE 'student_achievements'");
            if (!$stmt->fetch()) {
                return ['total_achievements' => 0, 'total_points' => 0];
            }
            
            $sql = "SELECT 
                COUNT(*) as total_achievements,
                COALESCE(SUM(points_awarded), 0) as total_points
                FROM student_achievements 
                WHERE student_id = ? AND verified = 1";
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$userId]);
            return $stmt->fetch(PDO::FETCH_ASSOC) ?: ['total_achievements' => 0, 'total_points' => 0];
        } catch (PDOException $e) {
            return ['total_achievements' => 0, 'total_points' => 0];
        }
    }
    
    private function getRecentProjects($userId) {
        try {
            // Check if student_projects table exists
            $stmt = $this->pdo->query("SHOW TABLES LIKE 'student_projects'");
            if (!$stmt->fetch()) {
                return [];
            }
            
            $sql = "SELECT id, title, status, start_date, end_date, created_at
                    FROM student_projects 
                    WHERE student_id = ? 
                    ORDER BY created_at DESC 
                    LIMIT 5";
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$userId]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return [];
        }
    }
    
    private function getRecentStories($userId) {
        try {
            // Use StoryManager to get recent stories
            return $this->storyManager->getRecentStudentStories($userId, 5);
        } catch (PDOException $e) {
            return [];
        }
    }
    
    private function getRecentAchievements($userId) {
        try {
            // Check if student_achievements table exists
            $stmt = $this->pdo->query("SHOW TABLES LIKE 'student_achievements'");
            if (!$stmt->fetch()) {
                return [];
            }
            
            $sql = "SELECT id, title, description, points_awarded, created_at
                    FROM student_achievements 
                    WHERE student_id = ? AND verified = 1
                    ORDER BY created_at DESC 
                    LIMIT 5";
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$userId]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return [];
        }
    }
    
    private function getUpcomingDeadlines($userId) {
        try {
            // Check if student_projects table exists
            $stmt = $this->pdo->query("SHOW TABLES LIKE 'student_projects'");
            if (!$stmt->fetch()) {
                return [];
            }
            
            $sql = "SELECT id, title, end_date
                    FROM student_projects 
                    WHERE student_id = ? 
                    AND end_date >= CURDATE() 
                    AND status IN ('planning', 'in_progress')
                    ORDER BY end_date ASC 
                    LIMIT 5";
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$userId]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return [];
        }
    }
    
    private function getDefaultStudentInfo($userId) {
        return [
            'full_name' => $_SESSION['full_name'] ?? 'Student',
            'university' => 'University of Rwanda',
            'program' => 'Computer Science',
            'year_of_study' => '2nd Year',
            'expected_graduation' => '2026',
            'current_gpa' => '3.75',
            'program_type' => 'scholarship',
            'scholarship_type' => 'Full Tuition Scholarship',
            'bio' => 'Dedicated student passionate about technology and community development.',
            'student_id' => 'STU' . date('Y') . str_pad($userId, 3, '0', STR_PAD_LEFT),
            'email' => $_SESSION['email'] ?? 'student@example.com',
            'member_since' => date('Y-m-d H:i:s')
        ];
    }
    
    private function getFallbackData($userId) {
        return [
            'student' => $this->getDefaultStudentInfo($userId),
            'stats' => [
                'projects' => ['total_projects' => 0, 'completed_projects' => 0],
                'stories' => ['total_stories' => 0, 'total_views' => 0, 'total_likes' => 0],
                'achievements' => ['total_achievements' => 0, 'total_points' => 0],
                'applications' => [
                    'total_applications' => 0,
                    'approved_applications' => 0,
                    'submitted_applications' => 0,
                    'under_review_applications' => 0,
                    'draft_applications' => 0,
                    'rejected_applications' => 0
                ]
            ],
            'projects' => [],
            'stories' => [],
            'achievements' => [],
            'deadlines' => [],
            'applications' => [],
            'has_approved_application' => false,
            'can_apply_more' => true
        ];
    }
}

// Helper functions
function getApplicationStatusColor($status) {
    $colors = [
        'draft' => 'secondary',
        'submitted' => 'info',
        'under_review' => 'warning',
        'approved' => 'success',
        'rejected' => 'danger'
    ];
    return $colors[$status] ?? 'secondary';
}

function getApplicationStatusIcon($status) {
    $icons = [
        'draft' => 'fa-edit',
        'submitted' => 'fa-paper-plane',
        'under_review' => 'fa-search',
        'approved' => 'fa-check-circle',
        'rejected' => 'fa-times-circle'
    ];
    return $icons[$status] ?? 'fa-file-alt';
}

function getProgramTypeIcon($programType) {
    $icons = [
        'scholarship' => 'fa-graduation-cap',
        'housing' => 'fa-home',
        'community' => 'fa-users',
        'mentorship' => 'fa-handshake'
    ];
    return $icons[$programType] ?? 'fa-file-alt';
}

function getProgramTypeColor($programType) {
    $colors = [
        'scholarship' => 'primary',
        'housing' => 'success',
        'community' => 'warning',
        'mentorship' => 'info'
    ];
    return $colors[$programType] ?? 'secondary';
}

function getProjectStatusColor($status) {
    $colors = [
        'planning' => 'secondary',
        'in_progress' => 'primary',
        'completed' => 'success',
        'on_hold' => 'warning',
        'cancelled' => 'danger'
    ];
    return $colors[$status] ?? 'secondary';
}

function getProjectProgress($project) {
    if ($project['status'] === 'completed') return 100;
    if ($project['status'] === 'cancelled') return 0;
    
    $progress = [
        'planning' => 25,
        'in_progress' => 60,
        'on_hold' => 40
    ];
    
    return $progress[$project['status']] ?? 0;
}

function isUrgent($deadline) {
    if (!isset($deadline['end_date'])) return false;
    $daysRemaining = getDaysRemaining($deadline['end_date']);
    return $daysRemaining <= 3 && $daysRemaining >= 0;
}

function getDaysRemaining($endDate) {
    try {
        $now = new DateTime();
        $end = new DateTime($endDate);
        $interval = $now->diff($end);
        $days = $interval->days;
        
        if ($interval->invert) {
            return -$days;
        } else {
            return $days;
        }
    } catch (Exception $e) {
        return 0;
    }
}

function formatDate($dateString) {
    if (empty($dateString)) return 'Not submitted';
    try {
        $date = new DateTime($dateString);
        return $date->format('M j, Y');
    } catch (Exception $e) {
        return 'Invalid Date';
    }
}

function sanitizeOutput($data) {
    return htmlspecialchars($data ?? '', ENT_QUOTES, 'UTF-8');
}

function getProfileCompletionPercentage($student) {
    $fields = ['full_name', 'university', 'program', 'year_of_study', 'bio', 'student_id'];
    $completed = 0;
    
    foreach ($fields as $field) {
        if (!empty($student[$field]) && $student[$field] !== 'University of Rwanda' && $student[$field] !== 'Computer Science') {
            $completed++;
        }
    }
    
    return round(($completed / count($fields)) * 100);
}

// Create dashboard instance and get data
$studentDashboard = new StudentDashboard($pdo);
$dashboardData = $studentDashboard->getStudentDashboardData($user_id);

// Extract data
$student = $dashboardData['student'];
$stats = $dashboardData['stats'];
$recentProjects = $dashboardData['projects'];
$recentStories = $dashboardData['stories'];
$recentAchievements = $dashboardData['achievements'];
$upcomingDeadlines = $dashboardData['deadlines'];
$recentApplications = $dashboardData['applications'];
$hasApprovedApplication = $dashboardData['has_approved_application'];
$canApplyMore = $dashboardData['can_apply_more'];

// Debug output
error_log("Final has_approved_application: " . ($hasApprovedApplication ? 'YES' : 'NO'));

// Calculate profile completion
$profileCompletion = getProfileCompletionPercentage($student);

// Check if user has any applications to show setup guidance
$hasApplications = !empty($recentApplications);
$hasProjects = !empty($recentProjects);
$hasStories = !empty($recentStories);
$showSetupAlert = !$hasApplications && !$hasProjects && !$hasStories;

// Get application status counts for better display
$applicationStats = $stats['applications'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard - REACH Portal</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css" rel="stylesheet">
    
    <style>
        :root {
            --primary: #3498db;
            --secondary: #2c3e50;
            --success: #27ae60;
            --warning: #f39c12;
            --danger: #e74c3c;
            --info: #17a2b8;
            --light: #f8f9fa;
            --dark: #343a40;
        }

        body {
            background: #f5f7fa;
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
        }

        /* Welcome Section */
        .welcome-section {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            padding: 3rem 0;
            margin-bottom: 2rem;
            border-radius: 0 0 30px 30px;
        }

        .welcome-title {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
        }

        .welcome-subtitle {
            font-size: 1.2rem;
            opacity: 0.9;
            margin-bottom: 1.5rem;
        }

        .welcome-stats {
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
        }

        .stat-badge {
            background: rgba(255,255,255,0.2);
            padding: 0.5rem 1rem;
            border-radius: 50px;
            font-size: 0.9rem;
            backdrop-filter: blur(10px);
        }

        .stat-badge i {
            margin-right: 0.5rem;
        }

        .profile-completion {
            background: rgba(255,255,255,0.15);
            border-radius: 10px;
            padding: 1rem;
            margin-top: 1rem;
        }

        /* Stats Section */
        .stat-card {
            background: white;
            border-radius: 15px;
            padding: 1.5rem;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            border-left: 4px solid var(--primary);
            height: 100%;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }

        .stat-card.primary { border-left-color: var(--primary); }
        .stat-card.success { border-left-color: var(--success); }
        .stat-card.warning { border-left-color: var(--warning); }
        .stat-card.info { border-left-color: var(--info); }

        .stat-icon {
            font-size: 2.5rem;
            margin-bottom: 1rem;
            opacity: 0.8;
        }

        .stat-card.primary .stat-icon { color: var(--primary); }
        .stat-card.success .stat-icon { color: var(--success); }
        .stat-card.warning .stat-icon { color: var(--warning); }
        .stat-card.info .stat-icon { color: var(--info); }

        .stat-content h3 {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
        }

        .stat-content p {
            color: #6c757d;
            font-weight: 600;
            margin-bottom: 1rem;
        }

        /* Portal Cards */
        .portal-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            margin-bottom: 1.5rem;
            height: 100%;
        }

        .portal-card .card-header {
            background: white;
            border-bottom: 1px solid #e9ecef;
            padding: 1.25rem 1.5rem;
            border-radius: 15px 15px 0 0 !important;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .portal-card .card-header h5 {
            margin: 0;
            font-weight: 600;
            color: var(--secondary);
        }

        .portal-card .card-body {
            padding: 1.5rem;
        }

        /* Application Items */
        .application-item {
            border-left: 4px solid var(--primary);
            padding: 1rem;
            margin-bottom: 1rem;
            border-radius: 8px;
            background: white;
            transition: all 0.3s ease;
        }

        .application-item:hover {
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
        }

        /* Quick Actions */
        .quick-action-card {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
            border: 2px solid transparent;
            height: 100%;
        }

        .quick-action-card:hover {
            transform: translateY(-5px);
            border-color: var(--primary);
        }

        /* Project List */
        .project-item, .story-item, .achievement-item, .deadline-item {
            display: flex;
            align-items: center;
            padding: 1rem 0;
            border-bottom: 1px solid #f1f3f4;
        }

        .project-item:last-child, .story-item:last-child, 
        .achievement-item:last-child, .deadline-item:last-child {
            border-bottom: none;
        }

        /* Empty States */
        .empty-state {
            text-align: center;
            padding: 3rem 1rem;
            color: #6c757d;
        }

        .empty-state i {
            margin-bottom: 1rem;
        }

        /* Status Badges */
        .status-badge {
            font-size: 0.75rem;
            padding: 0.35em 0.65em;
        }

        .application-code {
            font-family: 'Courier New', monospace;
            font-weight: 600;
        }

        /* Portal Access Notice */
        .portal-access-notice {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 10px;
            padding: 1rem;
            margin-bottom: 2rem;
            border: none;
        }

        /* Future Opportunities Section */
        .future-opportunities {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
            border-radius: 15px;
            padding: 2rem;
            margin-bottom: 2rem;
        }

        /* Restricted Access Notice */
        .restricted-access {
            background: linear-gradient(135deg, #ff6b6b 0%, #ee5a24 100%);
            color: white;
            border-radius: 15px;
            padding: 2rem;
            margin-bottom: 2rem;
        }

        .restricted-feature {
            opacity: 0.6;
            position: relative;
        }

        .restricted-feature::after {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(255,255,255,0.8);
            border-radius: 15px;
        }

        .restricted-badge {
            position: absolute;
            top: 10px;
            right: 10px;
            z-index: 10;
        }

        @media (max-width: 768px) {
            .welcome-title {
                font-size: 2rem;
            }
            
            .welcome-stats {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .stat-badge {
                width: 100%;
                text-align: center;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-hands-helping me-2"></i>
                REACH Student Portal
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="applications.php">My Applications</a>
                <?php if ($hasApprovedApplication): ?>
                <a class="nav-link" href="projects.php">Projects</a>
                <a class="nav-link" href="stories.php">Stories</a>
                <a class="nav-link" href="achievements.php">Achievements</a>
                <?php else: ?>
                <span class="nav-link disabled" title="Available after application approval">
                    <i class="fas fa-lock me-1"></i>Projects
                </span>
                <span class="nav-link disabled" title="Available after application approval">
                    <i class="fas fa-lock me-1"></i>Stories
                </span>
                <span class="nav-link disabled" title="Available after application approval">
                    <i class="fas fa-lock me-1"></i>Achievements
                </span>
                <?php endif; ?>
                <a class="nav-link" href="profile.php">Profile</a>
                <a class="nav-link" href="../../logout.php">Logout</a>
            </div>
        </div>
    </nav>

    <main class="container-fluid px-4">
        <!-- Restricted Access Notice for Non-Approved Students -->
        <?php if (!$hasApprovedApplication): ?>
        <div class="restricted-access" data-aos="fade-down">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h4><i class="fas fa-info-circle me-2"></i>Application Pending Approval</h4>
                    <p class="mb-0">Your application is currently under review. Once approved, you'll gain access to additional features like Projects, Stories, and Achievements. In the meantime, you can continue to apply for other programs.</p>
                </div>
                <div class="col-md-4 text-end">
                    <a href="../../public/apply.php" class="btn btn-light btn-lg">
                        <i class="fas fa-plus me-2"></i>Apply for Programs
                    </a>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Portal Access Notice for Approved Students -->
        <?php if ($hasApprovedApplication): ?>
        <div class="portal-access-notice" data-aos="fade-down">
            <div class="d-flex align-items-center">
                <i class="fas fa-unlock-alt fa-2x me-3"></i>
                <div class="flex-grow-1">
                    <h5 class="mb-1">Welcome to the Full Student Portal! 🎉</h5>
                    <p class="mb-0">Your application has been approved. You now have full access to all student portal features while maintaining the ability to apply for future opportunities.</p>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Future Opportunities Notice -->
        <?php if ($hasApprovedApplication && $canApplyMore): ?>
        <div class="future-opportunities" data-aos="fade-down">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h4><i class="fas fa-graduation-cap me-2"></i>Future Opportunities Await!</h4>
                    <p class="mb-0">As an approved student, you can still apply for additional programs, mentorship opportunities, or future scholarships to continue your educational journey.</p>
                </div>
                <div class="col-md-4 text-end">
                    <a href="../../public/apply.php" class="btn btn-light btn-lg">
                        <i class="fas fa-plus me-2"></i>Apply for More Programs
                    </a>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Setup Alert for New Users -->
        <?php if ($showSetupAlert): ?>
        <div class="alert alert-warning mt-3" data-aos="fade-down">
            <div class="d-flex align-items-center">
                <i class="fas fa-rocket fa-2x me-3"></i>
                <div class="flex-grow-1">
                    <h5 class="mb-1">Welcome to REACH Student Portal! 🎉</h5>
                    <p class="mb-0">Get started by creating your first application or exploring available programs.</p>
                </div>
                <div class="setup-actions">
                    <a href="../../public/apply.php" class="btn btn-primary me-2">
                        <i class="fas fa-plus me-1"></i>Start Application
                    </a>
                    <a href="../../public/programs.php" class="btn btn-outline-primary">
                        <i class="fas fa-search me-1"></i>Explore Programs
                    </a>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Welcome Section -->
        <section class="welcome-section">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h1 class="welcome-title">
                            Welcome back, <?php echo sanitizeOutput($student['full_name']); ?>! 👋
                        </h1>
                        <p class="welcome-subtitle"><?php echo sanitizeOutput($student['bio']); ?></p>
                        <div class="welcome-stats">
                            <span class="stat-badge">
                                <i class="fas fa-graduation-cap"></i>
                                <?php echo sanitizeOutput($student['program']); ?>
                            </span>
                            <span class="stat-badge">
                                <i class="fas fa-university"></i>
                                <?php echo sanitizeOutput($student['university']); ?>
                            </span>
                            <span class="stat-badge">
                                <i class="fas fa-calendar"></i>
                                Class of <?php echo sanitizeOutput($student['expected_graduation']); ?>
                            </span>
                            <?php if (!empty($student['current_gpa'])): ?>
                            <span class="stat-badge">
                                <i class="fas fa-chart-line"></i>
                                GPA: <?php echo sanitizeOutput($student['current_gpa']); ?>
                            </span>
                            <?php endif; ?>
                            <?php if ($hasApprovedApplication): ?>
                            <span class="stat-badge bg-success">
                                <i class="fas fa-check-circle"></i>
                                Approved Student
                            </span>
                            <?php else: ?>
                            <span class="stat-badge bg-warning">
                                <i class="fas fa-clock"></i>
                                Pending Approval
                            </span>
                            <?php endif; ?>
                        </div>
                        
                        <!-- Profile Completion -->
                        <div class="profile-completion">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <small>Profile Completion</small>
                                <small><?php echo $profileCompletion; ?>%</small>
                            </div>
                            <div class="progress" style="height: 6px;">
                                <div class="progress-bar 
                                    <?php echo $profileCompletion >= 80 ? 'bg-success' : ($profileCompletion >= 50 ? 'bg-warning' : 'bg-danger'); ?>" 
                                    style="width: <?php echo $profileCompletion; ?>%">
                                </div>
                            </div>
                            <?php if ($profileCompletion < 100): ?>
                                <small class="text-warning mt-2">
                                    <i class="fas fa-info-circle me-1"></i>
                                    Complete your profile to access all features
                                </small>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-4 text-center">
                        <div class="bg-light rounded-circle d-inline-flex align-items-center justify-content-center" 
                             style="width: 120px; height: 120px;">
                            <?php if (!empty($student['profile_picture']) && $student['profile_picture'] !== 'default.jpg'): ?>
                                <img src="../../uploads/profiles/<?php echo sanitizeOutput($student['profile_picture']); ?>" 
                                     alt="Profile" class="rounded-circle" style="width: 100%; height: 100%; object-fit: cover;">
                            <?php else: ?>
                                <i class="fas fa-user-graduate fa-3x text-primary"></i>
                            <?php endif; ?>
                        </div>
                        <div class="mt-3">
                            <small class="text-light opacity-75">
                                <i class="fas fa-calendar me-1"></i>
                                Member since <?php echo formatDate($student['member_since']); ?>
                            </small>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Quick Actions -->
        <section class="mb-5">
            <div class="container">
                <h3 class="mb-4">Quick Actions</h3>
                <div class="row g-4">
                    <!-- Application Actions (Always Available) -->
                    <div class="col-md-3">
                        <a href="../../public/apply.php" class="text-decoration-none">
                            <div class="quick-action-card">
                                <i class="fas fa-edit fa-3x text-primary mb-3"></i>
                                <h5>New Application</h5>
                                <p class="text-muted">Apply for programs & opportunities</p>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-3">
                        <a href="applications.php" class="text-decoration-none">
                            <div class="quick-action-card">
                                <i class="fas fa-list fa-3x text-success mb-3"></i>
                                <h5>My Applications</h5>
                                <p class="text-muted">View and manage applications</p>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-3">
                        <a href="profile.php" class="text-decoration-none">
                            <div class="quick-action-card">
                                <i class="fas fa-user-edit fa-3x text-warning mb-3"></i>
                                <h5>Update Profile</h5>
                                <p class="text-muted">Complete your student profile</p>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-3">
                        <a href="../../public/programs.php" class="text-decoration-none">
                            <div class="quick-action-card">
                                <i class="fas fa-search fa-3x text-info mb-3"></i>
                                <h5>Find Programs</h5>
                                <p class="text-muted">Explore available opportunities</p>
                            </div>
                        </a>
                    </div>

                    <!-- Portal Actions (Only for Approved Students) -->
                    <?php if ($hasApprovedApplication): ?>
                    <div class="col-md-3">
                        <a href="create-project.php" class="text-decoration-none">
                            <div class="quick-action-card">
                                <i class="fas fa-project-diagram fa-3x text-success mb-3"></i>
                                <h5>Create Project</h5>
                                <p class="text-muted">Start a new student project</p>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-3">
                        <a href="create-story.php" class="text-decoration-none">
                            <div class="quick-action-card">
                                <i class="fas fa-pen fa-3x text-info mb-3"></i>
                                <h5>Write Story</h5>
                                <p class="text-muted">Share your experience</p>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-3">
                        <a href="projects.php" class="text-decoration-none">
                            <div class="quick-action-card">
                                <i class="fas fa-tasks fa-3x text-warning mb-3"></i>
                                <h5>My Projects</h5>
                                <p class="text-muted">Manage your projects</p>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-3">
                        <a href="stories.php" class="text-decoration-none">
                            <div class="quick-action-card">
                                <i class="fas fa-book-open fa-3x text-primary mb-3"></i>
                                <h5>My Stories</h5>
                                <p class="text-muted">View published stories</p>
                            </div>
                        </a>
                    </div>
                    <?php else: ?>
                    <!-- Restricted Portal Actions for Non-Approved Students -->
                    <div class="col-md-3">
                        <div class="quick-action-card restricted-feature">
                            <span class="restricted-badge badge bg-warning">
                                <i class="fas fa-lock me-1"></i>Approval Required
                            </span>
                            <i class="fas fa-project-diagram fa-3x text-muted mb-3"></i>
                            <h5 class="text-muted">Create Project</h5>
                            <p class="text-muted">Available after application approval</p>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="quick-action-card restricted-feature">
                            <span class="restricted-badge badge bg-warning">
                                <i class="fas fa-lock me-1"></i>Approval Required
                            </span>
                            <i class="fas fa-pen fa-3x text-muted mb-3"></i>
                            <h5 class="text-muted">Write Story</h5>
                            <p class="text-muted">Available after application approval</p>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="quick-action-card restricted-feature">
                            <span class="restricted-badge badge bg-warning">
                                <i class="fas fa-lock me-1"></i>Approval Required
                            </span>
                            <i class="fas fa-tasks fa-3x text-muted mb-3"></i>
                            <h5 class="text-muted">My Projects</h5>
                            <p class="text-muted">Available after application approval</p>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="quick-action-card restricted-feature">
                            <span class="restricted-badge badge bg-warning">
                                <i class="fas fa-lock me-1"></i>Approval Required
                            </span>
                            <i class="fas fa-book-open fa-3x text-muted mb-3"></i>
                            <h5 class="text-muted">My Stories</h5>
                            <p class="text-muted">Available after application approval</p>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>

        <!-- Statistics Section -->
        <section class="mb-5">
            <div class="container">
                <h3 class="mb-4">Your Dashboard Overview</h3>
                <div class="row g-4">
                    <!-- Applications Stat -->
                    <div class="col-xl-3 col-md-6">
                        <div class="stat-card primary" data-aos="fade-up">
                            <div class="stat-icon">
                                <i class="fas fa-file-alt"></i>
                            </div>
                            <div class="stat-content">
                                <h3><?php echo $stats['applications']['total_applications']; ?></h3>
                                <p>Total Applications</p>
                                <div class="d-flex flex-wrap gap-1">
                                    <?php if ($stats['applications']['approved_applications'] > 0): ?>
                                        <span class="badge bg-success status-badge"><?php echo $stats['applications']['approved_applications']; ?> Approved</span>
                                    <?php endif; ?>
                                    <?php if ($stats['applications']['submitted_applications'] > 0): ?>
                                        <span class="badge bg-info status-badge"><?php echo $stats['applications']['submitted_applications']; ?> Submitted</span>
                                    <?php endif; ?>
                                    <?php if ($stats['applications']['under_review_applications'] > 0): ?>
                                        <span class="badge bg-warning status-badge"><?php echo $stats['applications']['under_review_applications']; ?> In Review</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Projects Stat -->
                    <div class="col-xl-3 col-md-6">
                        <?php if ($hasApprovedApplication): ?>
                        <div class="stat-card success" data-aos="fade-up" data-aos-delay="100">
                            <div class="stat-icon">
                                <i class="fas fa-project-diagram"></i>
                            </div>
                            <div class="stat-content">
                                <h3><?php echo $stats['projects']['total_projects']; ?></h3>
                                <p>Projects</p>
                                <?php if ($stats['projects']['total_projects'] > 0): ?>
                                    <small class="text-success">
                                        <?php echo $stats['projects']['completed_projects']; ?> completed
                                    </small>
                                <?php else: ?>
                                    <small class="text-muted">
                                        Start your first project
                                    </small>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php else: ?>
                        <div class="stat-card secondary restricted-feature" data-aos="fade-up" data-aos-delay="100">
                            <span class="restricted-badge badge bg-warning">
                                <i class="fas fa-lock me-1"></i>Locked
                            </span>
                            <div class="stat-icon">
                                <i class="fas fa-project-diagram text-muted"></i>
                            </div>
                            <div class="stat-content">
                                <h3 class="text-muted">0</h3>
                                <p class="text-muted">Projects</p>
                                <small class="text-muted">
                                    Available after approval
                                </small>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>

                    <!-- Stories Stat -->
                    <div class="col-xl-3 col-md-6">
                        <?php if ($hasApprovedApplication): ?>
                        <div class="stat-card warning" data-aos="fade-up" data-aos-delay="200">
                            <div class="stat-icon">
                                <i class="fas fa-book-open"></i>
                            </div>
                            <div class="stat-content">
                                <h3><?php echo $stats['stories']['total_stories'] ?? 0; ?></h3>
                                <p>Published Stories</p>
                                <?php if (($stats['stories']['total_views'] ?? 0) > 0): ?>
                                    <small class="text-warning">
                                        <?php echo number_format($stats['stories']['total_views']); ?> views
                                    </small>
                                <?php else: ?>
                                    <small class="text-muted">
                                        Share your story
                                    </small>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php else: ?>
                        <div class="stat-card secondary restricted-feature" data-aos="fade-up" data-aos-delay="200">
                            <span class="restricted-badge badge bg-warning">
                                <i class="fas fa-lock me-1"></i>Locked
                            </span>
                            <div class="stat-icon">
                                <i class="fas fa-book-open text-muted"></i>
                            </div>
                            <div class="stat-content">
                                <h3 class="text-muted">0</h3>
                                <p class="text-muted">Published Stories</p>
                                <small class="text-muted">
                                    Available after approval
                                </small>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>

                    <!-- Achievements Stat -->
                    <div class="col-xl-3 col-md-6">
                        <?php if ($hasApprovedApplication): ?>
                        <div class="stat-card info" data-aos="fade-up" data-aos-delay="300">
                            <div class="stat-icon">
                                <i class="fas fa-trophy"></i>
                            </div>
                            <div class="stat-content">
                                <h3><?php echo $stats['achievements']['total_achievements']; ?></h3>
                                <p>Achievements</p>
                                <?php if ($stats['achievements']['total_points'] > 0): ?>
                                    <small class="text-info">
                                        <?php echo number_format($stats['achievements']['total_points']); ?> points
                                    </small>
                                <?php else: ?>
                                    <small class="text-muted">
                                        Earn achievements
                                    </small>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php else: ?>
                        <div class="stat-card secondary restricted-feature" data-aos="fade-up" data-aos-delay="300">
                            <span class="restricted-badge badge bg-warning">
                                <i class="fas fa-lock me-1"></i>Locked
                            </span>
                            <div class="stat-icon">
                                <i class="fas fa-trophy text-muted"></i>
                            </div>
                            <div class="stat-content">
                                <h3 class="text-muted">0</h3>
                                <p class="text-muted">Achievements</p>
                                <small class="text-muted">
                                    Available after approval
                                </small>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </section>

        <div class="container">
            <div class="row g-4">
                <!-- Recent Applications (Always Visible) -->
                <div class="col-lg-6">
                    <div class="portal-card" data-aos="fade-up">
                        <div class="card-header">
                            <h5><i class="fas fa-file-alt me-2"></i>Recent Applications</h5>
                            <a href="applications.php" class="btn btn-sm btn-outline-primary">View All</a>
                        </div>
                        <div class="card-body">
                            <?php if (!empty($recentApplications)): ?>
                                <?php foreach ($recentApplications as $application): ?>
                                <div class="application-item">
                                    <div class="d-flex justify-content-between align-items-start mb-2">
                                        <div>
                                            <h6 class="mb-1">
                                                <i class="fas <?php echo getProgramTypeIcon($application['program_type']); ?> me-2 text-<?php echo getProgramTypeColor($application['program_type']); ?>"></i>
                                                <?php echo ucfirst($application['program_type']); ?> Application
                                            </h6>
                                            <small class="text-muted application-code">
                                                #<?php echo sanitizeOutput($application['application_code']); ?>
                                            </small>
                                        </div>
                                        <span class="badge bg-<?php echo getApplicationStatusColor($application['status']); ?> status-badge">
                                            <i class="fas <?php echo getApplicationStatusIcon($application['status']); ?> me-1"></i>
                                            <?php echo ucfirst(str_replace('_', ' ', $application['status'])); ?>
                                        </span>
                                    </div>
                                    
                                    <?php if (!empty($application['institution_applying'])): ?>
                                        <p class="mb-2 small">
                                            <strong>Institution:</strong> <?php echo sanitizeOutput($application['institution_applying']); ?>
                                        </p>
                                    <?php endif; ?>
                                    
                                    <?php if (!empty($application['intended_major'])): ?>
                                        <p class="mb-2 small">
                                            <strong>Major:</strong> <?php echo sanitizeOutput($application['intended_major']); ?>
                                        </p>
                                    <?php endif; ?>
                                    
                                    <div class="d-flex justify-content-between align-items-center">
                                        <small class="text-muted">
                                            <i class="fas fa-calendar me-1"></i>
                                            <?php echo formatDate($application['submitted_at'] ?? $application['created_at']); ?>
                                        </small>
                                        <a href="application-details.php?id=<?php echo $application['id']; ?>" class="btn btn-sm btn-outline-primary">
                                            <i class="fas fa-eye me-1"></i>View Details
                                        </a>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <div class="empty-state">
                                    <i class="fas fa-file-alt fa-3x text-muted mb-3"></i>
                                    <h5>No Applications Yet</h5>
                                    <p class="text-muted mb-3">Start your journey by applying to one of our programs</p>
                                    <a href="../../public/apply.php" class="btn btn-primary">
                                        <i class="fas fa-plus me-2"></i>Create First Application
                                    </a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Recent Projects (only show if approved) -->
                    <?php if ($hasApprovedApplication && !empty($recentProjects)): ?>
                    <div class="portal-card" data-aos="fade-up" data-aos-delay="100">
                        <div class="card-header">
                            <h5><i class="fas fa-project-diagram me-2"></i>Recent Projects</h5>
                            <a href="projects.php" class="btn btn-sm btn-outline-success">View All</a>
                        </div>
                        <div class="card-body">
                            <?php foreach ($recentProjects as $project): ?>
                            <div class="project-item">
                                <div class="project-info">
                                    <h6 class="project-title">
                                        <a href="project-details.php?id=<?php echo $project['id']; ?>">
                                            <?php echo sanitizeOutput($project['title']); ?>
                                        </a>
                                    </h6>
                                    <div class="project-meta">
                                        <span class="badge bg-<?php echo getProjectStatusColor($project['status']); ?>">
                                            <?php echo ucfirst(str_replace('_', ' ', $project['status'])); ?>
                                        </span>
                                        <small class="text-muted">
                                            <i class="fas fa-calendar me-1"></i>
                                            <?php echo date('M j, Y', strtotime($project['created_at'])); ?>
                                        </small>
                                    </div>
                                </div>
                                <div class="project-actions">
                                    <div class="progress" style="width: 100px;">
                                        <div class="progress-bar" style="width: <?php echo getProjectProgress($project); ?>%"></div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Right Column -->
                <div class="col-lg-6">
                    <div class="row g-4">
                        <!-- Profile Completion -->
                        <div class="col-12">
                            <div class="portal-card" data-aos="fade-up" data-aos-delay="100">
                                <div class="card-header">
                                    <h5><i class="fas fa-user-check me-2"></i>Profile Completion</h5>
                                </div>
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-center mb-2">
                                        <span>Complete your profile</span>
                                        <span class="fw-bold"><?php echo $profileCompletion; ?>%</span>
                                    </div>
                                    <div class="progress mb-3" style="height: 8px;">
                                        <div class="progress-bar 
                                            <?php echo $profileCompletion >= 80 ? 'bg-success' : ($profileCompletion >= 50 ? 'bg-warning' : 'bg-danger'); ?>" 
                                            style="width: <?php echo $profileCompletion; ?>%">
                                        </div>
                                    </div>
                                    <?php if ($profileCompletion < 100): ?>
                                        <a href="profile.php" class="btn btn-primary btn-sm w-100">
                                            <i class="fas fa-edit me-1"></i>Complete Profile
                                        </a>
                                    <?php else: ?>
                                        <div class="text-center">
                                            <span class="badge bg-success">
                                                <i class="fas fa-check me-1"></i>Profile Complete
                                            </span>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <!-- Quick Program Links (Always Available) -->
                        <div class="col-12">
                            <div class="portal-card" data-aos="fade-up" data-aos-delay="200">
                                <div class="card-header">
                                    <h5><i class="fas fa-rocket me-2"></i>Quick Apply</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row g-2">
                                        <div class="col-6">
                                            <a href="../../public/apply.php?program=scholarship" class="btn btn-outline-primary w-100 mb-2">
                                                <i class="fas fa-graduation-cap me-1"></i>Scholarship
                                            </a>
                                        </div>
                                        <div class="col-6">
                                            <a href="../../public/apply.php?program=housing" class="btn btn-outline-success w-100 mb-2">
                                                <i class="fas fa-home me-1"></i>Housing
                                            </a>
                                        </div>
                                        <div class="col-6">
                                            <a href="../../public/apply.php?program=mentorship" class="btn btn-outline-info w-100 mb-2">
                                                <i class="fas fa-handshake me-1"></i>Mentorship
                                            </a>
                                        </div>
                                        <div class="col-6">
                                            <a href="../../public/apply.php?program=community" class="btn btn-outline-warning w-100 mb-2">
                                                <i class="fas fa-users me-1"></i>Community
                                            </a>
                                        </div>
                                    </div>
                                    <?php if ($hasApprovedApplication): ?>
                                    <div class="mt-3 p-3 bg-light rounded">
                                        <small class="text-muted">
                                            <i class="fas fa-info-circle me-1"></i>
                                            As an approved student, you can apply for additional programs to expand your opportunities.
                                        </small>
                                    </div>
                                    <?php else: ?>
                                    <div class="mt-3 p-3 bg-light rounded">
                                        <small class="text-muted">
                                            <i class="fas fa-info-circle me-1"></i>
                                            Continue applying for programs while your applications are under review.
                                        </small>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <!-- Recent Stories (only show if approved) -->
                        <?php if ($hasApprovedApplication && !empty($recentStories)): ?>
                        <div class="col-12">
                            <div class="portal-card" data-aos="fade-up" data-aos-delay="300">
                                <div class="card-header">
                                    <h5><i class="fas fa-book-open me-2"></i>Recent Stories</h5>
                                    <a href="stories.php" class="btn btn-sm btn-outline-primary">View All</a>
                                </div>
                                <div class="card-body">
                                    <?php foreach ($recentStories as $story): ?>
                                    <div class="story-item">
                                        <div class="story-image me-3">
                                            <?php if (!empty($story['featured_image']) && $story['featured_image'] !== 'default.jpg'): ?>
                                                <img src="../../assets/uploads/stories/<?php echo $story['featured_image']; ?>" 
                                                     alt="<?php echo sanitizeOutput($story['title']); ?>" 
                                                     style="width: 60px; height: 60px; object-fit: cover; border-radius: 8px;">
                                            <?php else: ?>
                                                <div class="bg-light d-flex align-items-center justify-content-center" style="width: 60px; height: 60px; border-radius: 8px;">
                                                    <i class="fas fa-image text-muted"></i>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="story-content flex-grow-1">
                                            <h6 class="story-title mb-1">
                                                <a href="story-details.php?id=<?php echo $story['id']; ?>">
                                                    <?php echo sanitizeOutput($story['title']); ?>
                                                </a>
                                            </h6>
                                            <div class="story-stats">
                                                <small class="text-muted me-3">
                                                    <i class="fas fa-eye me-1"></i><?php echo number_format($story['view_count'] ?? 0); ?>
                                                </small>
                                                <small class="text-muted">
                                                    <i class="fas fa-heart me-1"></i><?php echo number_format($story['like_count'] ?? 0); ?>
                                                </small>
                                            </div>
                                        </div>
                                        <div class="story-status">
                                            <span class="badge bg-<?php echo ($story['status'] ?? 'draft') === 'published' ? 'success' : 'warning'; ?>">
                                                <?php echo ucfirst($story['status'] ?? 'draft'); ?>
                                            </span>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>

                        <!-- Upcoming Deadlines (only show if approved) -->
                        <?php if ($hasApprovedApplication && !empty($upcomingDeadlines)): ?>
                        <div class="col-12">
                            <div class="portal-card" data-aos="fade-up" data-aos-delay="400">
                                <div class="card-header">
                                    <h5><i class="fas fa-clock me-2"></i>Upcoming Deadlines</h5>
                                    <a href="projects.php" class="btn btn-sm btn-outline-primary">View All</a>
                                </div>
                                <div class="card-body">
                                    <?php foreach ($upcomingDeadlines as $deadline): ?>
                                    <div class="deadline-item <?php echo isUrgent($deadline) ? 'urgent' : ''; ?>">
                                        <div class="deadline-date me-3">
                                            <div class="date-badge text-center bg-light rounded p-2" style="min-width: 60px;">
                                                <div class="day fw-bold"><?php echo date('j', strtotime($deadline['end_date'])); ?></div>
                                                <div class="month text-muted small"><?php echo date('M', strtotime($deadline['end_date'])); ?></div>
                                            </div>
                                        </div>
                                        <div class="deadline-content flex-grow-1">
                                            <h6 class="mb-1"><?php echo sanitizeOutput($deadline['title']); ?></h6>
                                            <p class="text-muted mb-1 small">Project Deadline</p>
                                            <small class="<?php echo isUrgent($deadline) ? 'text-danger' : 'text-warning'; ?>">
                                                <i class="fas fa-clock me-1"></i>
                                                <?php echo getDaysRemaining($deadline['end_date']); ?> days remaining
                                            </small>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <footer class="bg-dark text-light py-4 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h5>REACH Student Portal</h5>
                    <p class="mb-0">Empowering students through education and opportunity.</p>
                </div>
                <div class="col-md-6 text-md-end">
                    <p class="mb-0">&copy; <?php echo date('Y'); ?> REACH Organization. All rights reserved.</p>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    <script>
        // Initialize animations
        AOS.init({
            duration: 800,
            once: true
        });

        // Add loading states to buttons
        document.addEventListener('DOMContentLoaded', function() {
            const buttons = document.querySelectorAll('a.btn');
            buttons.forEach(button => {
                button.addEventListener('click', function(e) {
                    if (this.getAttribute('href') && !this.classList.contains('disabled')) {
                        const originalText = this.innerHTML;
                        this.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Loading...';
                        this.classList.add('disabled');
                        
                        setTimeout(() => {
                            this.innerHTML = originalText;
                            this.classList.remove('disabled');
                        }, 2000);
                    }
                });
            });
        });
    </script>
</body>
</html>