<?php
session_start();
require_once '../../includes/config.php';
require_once '../../includes/auth.php';

$auth->checkRole(['student']);

// Generate CSRF token
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Initialize classes with enhanced error handling
$templates = [];
$systemMessage = '';
$classesAvailable = true;

// Simple ProjectWizard class if file doesn't exist
if (!file_exists('../../includes/classes/ProjectWizard.php')) {
    class ProjectWizard {
        public function getProjectTemplates() {
            return [
                'academic_research' => [
                    'name' => 'Academic Research',
                    'description' => 'Structured research project with academic rigor',
                    'type' => 'academic',
                    'title' => 'Academic Research Project',
                    'description' => 'A comprehensive research project following academic standards and methodologies to contribute new knowledge.',
                    'full_description' => '<p>This research project employs rigorous academic methodologies to investigate key questions in the field. The study will include systematic literature review, robust data collection, and evidence-based analysis.</p>',
                    'skills' => 'research methodology, critical analysis, academic writing, data interpretation',
                    'technologies' => 'reference managers, statistical software, academic databases',
                    'target_audience' => 'Academic community, researchers, policymakers',
                    'success_metrics' => 'Publication in peer-reviewed journal, conference presentation, citations',
                    'budget' => '500'
                ],
                'community_service' => [
                    'name' => 'Community Service',
                    'description' => 'Project focused on community impact and engagement',
                    'type' => 'community',
                    'title' => 'Community Development Initiative',
                    'description' => 'A project designed to address community needs and create positive social impact through collaborative action.',
                    'full_description' => '<p>This community service project engages local stakeholders to identify needs and implement sustainable solutions. The initiative focuses on capacity building, community participation, and measurable social impact.</p>',
                    'skills' => 'community engagement, communication, project management, stakeholder relations',
                    'technologies' => 'survey tools, communication platforms, project management software',
                    'target_audience' => 'Local community members, community organizations, local government',
                    'success_metrics' => 'Community satisfaction, participation rates, measurable impact indicators',
                    'budget' => '300'
                ],
                'technical_development' => [
                    'name' => 'Technical Development',
                    'description' => 'Hands-on technical implementation project',
                    'type' => 'technical',
                    'title' => 'Software Development Project',
                    'description' => 'A practical technical project involving software development and implementation using modern technologies.',
                    'full_description' => '<p>This technical project follows software development lifecycle principles to create a functional solution. The project includes requirements analysis, system design, development, testing, and deployment phases.</p>',
                    'skills' => 'programming, system design, testing, documentation, version control',
                    'technologies' => 'Python/JavaScript, React/Node.js, Git, Docker, databases',
                    'target_audience' => 'End users, technical community, potential customers',
                    'success_metrics' => 'Functionality completeness, performance metrics, user adoption',
                    'budget' => '200'
                ]
            ];
        }
    }
    $projectWizard = new ProjectWizard();
    $templates = $projectWizard->getProjectTemplates();
    $classesAvailable = false;
    $systemMessage = "Using built-in project templates. Advanced features are available when classes are installed.";
} else {
    require_once '../../includes/classes/ProjectWizard.php';
    $projectWizard = new ProjectWizard($pdo);
    $templates = $projectWizard->getProjectTemplates();
}

// Simple AIAssistant class if file doesn't exist
if (!file_exists('../../includes/classes/AIAssistant.php')) {
    class AIAssistant {
        public function generateProjectSuggestions($title, $description, $projectType = '') {
            return [
                'title' => $title ? "Enhanced: $title" : "Consider a specific, action-oriented title",
                'description' => $description ? "Build on your idea by focusing on measurable outcomes" : "Describe your project's goals, methodology, and expected impact",
                'skills' => ['Research', 'Planning', 'Communication', 'Documentation'],
                'tips' => ['Set clear objectives', 'Break into manageable tasks', 'Document your progress']
            ];
        }
    }
    $aiAssistant = new AIAssistant();
    if (empty($systemMessage)) {
        $systemMessage = "Basic suggestion features enabled. Install AIAssistant for advanced features.";
    }
} else {
    require_once '../../includes/classes/AIAssistant.php';
    $aiAssistant = new AIAssistant($pdo);
}

// Check if template is being applied
$appliedTemplate = null;
if (isset($_GET['template']) && array_key_exists($_GET['template'], $templates)) {
    $appliedTemplate = $templates[$_GET['template']];
}

// Calculate default dates
$defaultStartDate = date('Y-m-d');
$defaultEndDate = date('Y-m-d', strtotime('+3 months'));

// Get current user info for form
$currentUser = $auth->getCurrentUser();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create New Project - REACH Student Portal</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flatpickr/4.6.13/flatpickr.min.css" rel="stylesheet">
    
    <style>
        :root {
            --primary: #2c5aa0;
            --secondary: #6c757d;
            --success: #198754;
            --warning: #ffc107;
            --danger: #dc3545;
            --info: #0dcaf0;
            --light: #f8f9fa;
            --dark: #212529;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .portal-container {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            margin: 20px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            min-height: calc(100vh - 40px);
        }

        .navigation-header {
            background: linear-gradient(135deg, var(--primary), #3a6bc7);
            color: white;
            padding: 1.5rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-radius: 20px 20px 0 0;
        }

        .navigation-header .brand {
            font-size: 1.5rem;
            font-weight: 700;
        }

        .user-menu {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .portal-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.08);
            border: none;
            overflow: hidden;
            margin-bottom: 2rem;
        }

        .portal-card .card-body {
            padding: 2.5rem;
        }

        .wizard-progress {
            margin-bottom: 3rem;
            padding: 0 1rem;
        }

        .wizard-steps {
            display: flex;
            justify-content: space-between;
            margin-top: 1.5rem;
            position: relative;
        }

        .wizard-step {
            text-align: center;
            flex: 1;
            position: relative;
            z-index: 2;
        }

        .wizard-step::before {
            content: '';
            position: absolute;
            top: 24px;
            left: -50%;
            right: 50%;
            height: 3px;
            background: #e9ecef;
            z-index: 1;
            transition: all 0.3s ease;
        }

        .wizard-step:first-child::before {
            display: none;
        }

        .wizard-step.active::before,
        .wizard-step.completed::before {
            background: var(--primary);
        }

        .step-number {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: #e9ecef;
            color: #6c757d;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 0.75rem;
            position: relative;
            z-index: 2;
            font-weight: 700;
            font-size: 1.1rem;
            transition: all 0.3s ease;
            border: 3px solid transparent;
        }

        .wizard-step.active .step-number {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
            transform: scale(1.1);
            box-shadow: 0 5px 15px rgba(44, 90, 160, 0.3);
        }

        .wizard-step.completed .step-number {
            background: var(--success);
            color: white;
            border-color: var(--success);
        }

        .step-label {
            font-size: 0.9rem;
            font-weight: 600;
            color: #6c757d;
            transition: all 0.3s ease;
        }

        .wizard-step.active .step-label {
            color: var(--primary);
            font-weight: 700;
        }

        .wizard-step-content {
            display: none;
            opacity: 0;
            transform: translateY(20px);
            transition: all 0.5s ease;
        }

        .wizard-step-content.active {
            display: block;
            opacity: 1;
            transform: translateY(0);
        }

        .step-header {
            margin-bottom: 2.5rem;
            padding-bottom: 1.5rem;
            border-bottom: 2px solid #f1f3f4;
            text-align: center;
        }

        .step-header h5 {
            color: var(--primary);
            margin-bottom: 0.75rem;
            font-weight: 700;
            font-size: 1.5rem;
        }

        .step-header p {
            color: #6c757d;
            margin: 0;
            font-size: 1.1rem;
        }

        .wizard-actions {
            display: flex;
            justify-content: space-between;
            margin-top: 3rem;
            padding-top: 2rem;
            border-top: 2px solid #f1f3f4;
        }

        .btn {
            border-radius: 10px;
            font-weight: 600;
            padding: 0.75rem 1.5rem;
            transition: all 0.3s ease;
            border: 2px solid transparent;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary), #3a6bc7);
            border-color: var(--primary);
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(44, 90, 160, 0.3);
        }

        .btn-success {
            background: linear-gradient(135deg, var(--success), #20c997);
            border-color: var(--success);
        }

        .form-control, .form-select {
            border-radius: 10px;
            border: 2px solid #e9ecef;
            padding: 0.75rem 1rem;
            transition: all 0.3s ease;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.2rem rgba(44, 90, 160, 0.1);
        }

        .form-control-lg {
            font-size: 1.1rem;
            font-weight: 600;
        }

        .upload-area {
            border: 3px dashed #dee2e6;
            border-radius: 15px;
            padding: 2.5rem;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
            background: #fafbfc;
        }

        .upload-area:hover {
            border-color: var(--primary);
            background: #f8f9fa;
            transform: translateY(-2px);
        }

        .upload-area i {
            color: #6c757d;
            margin-bottom: 1rem;
            font-size: 3rem;
        }

        .image-preview {
            text-align: center;
            padding: 1rem;
        }

        .image-preview img {
            max-width: 100%;
            max-height: 200px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .ai-suggestions-card {
            border: 2px solid #e9ecef;
            border-radius: 15px;
            overflow: hidden;
            background: linear-gradient(135deg, #f8f9fa, #e9ecef);
        }

        .ai-suggestions-card .card-header {
            background: linear-gradient(135deg, #6c757d, #868e96);
            color: white;
            padding: 1rem 1.5rem;
            font-weight: 700;
            font-size: 1.1rem;
        }

        .ai-suggestions-card .card-body {
            padding: 1.5rem;
            max-height: 300px;
            overflow-y: auto;
        }

        .milestone-card, .review-card {
            border: 2px solid #e9ecef;
            border-radius: 15px;
            padding: 2rem;
            margin-bottom: 1.5rem;
            background: #fafbfc;
            transition: all 0.3s ease;
        }

        .milestone-card:hover, .review-card:hover {
            border-color: var(--primary);
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }

        .milestone-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid #e9ecef;
        }

        .milestone-header h6 {
            color: var(--primary);
            font-weight: 700;
            margin: 0;
        }

        .tasks-section {
            margin-top: 1.5rem;
            padding-top: 1.5rem;
            border-top: 2px solid #e9ecef;
        }

        .task-item .input-group {
            margin-bottom: 0.75rem;
            border-radius: 10px;
            overflow: hidden;
        }

        .resource-type {
            padding: 1.5rem;
            border: 2px solid #e9ecef;
            border-radius: 15px;
            margin-bottom: 1.5rem;
            background: #fafbfc;
        }

        .resource-type h6 {
            color: var(--primary);
            font-weight: 700;
            margin-bottom: 1rem;
        }

        .loading-spinner {
            width: 4rem;
            height: 4rem;
            border: 4px solid #f3f3f3;
            border-top: 4px solid var(--primary);
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 0 auto;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .template-option {
            border: 3px solid #e9ecef;
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 1rem;
            cursor: pointer;
            transition: all 0.3s ease;
            background: white;
        }

        .template-option:hover {
            border-color: var(--primary);
            transform: translateY(-3px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }

        .template-option.selected {
            border-color: var(--primary);
            background: linear-gradient(135deg, #e7f1ff, #f0f7ff);
            transform: translateY(-2px);
        }

        .template-option h6 {
            color: var(--primary);
            font-weight: 700;
            margin-bottom: 0.5rem;
        }

        .form-control:invalid {
            border-color: var(--danger);
        }

        .error-message {
            color: var(--danger);
            font-size: 0.875rem;
            margin-top: 0.5rem;
            font-weight: 500;
        }

        .deliverable-item, .resource-item {
            margin-bottom: 0.75rem;
        }

        .suggestion-item {
            padding: 0.75rem;
            margin-bottom: 0.5rem;
            background: white;
            border-radius: 10px;
            border-left: 4px solid var(--primary);
        }

        .system-alert {
            background: linear-gradient(135deg, #fff3cd, #ffeaa7);
            border: 2px solid #ffc107;
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 2rem;
        }

        .template-applied-alert {
            background: linear-gradient(135deg, #d1ecf1, #bee5eb);
            border: 2px solid var(--info);
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 2rem;
        }

        .review-section .badge {
            font-size: 0.75rem;
        }

        .empty-state {
            text-align: center;
            padding: 3rem 1rem;
            color: #6c757d;
        }

        .empty-state i {
            font-size: 4rem;
            margin-bottom: 1rem;
            opacity: 0.5;
        }

        @media (max-width: 768px) {
            .portal-container {
                margin: 10px;
                border-radius: 15px;
            }
            
            .portal-card .card-body {
                padding: 1.5rem;
            }
            
            .wizard-steps {
                flex-direction: column;
                gap: 1rem;
            }
            
            .wizard-step::before {
                display: none;
            }
            
            .step-number {
                width: 40px;
                height: 40px;
            }
            
            .navigation-header {
                flex-direction: column;
                gap: 1rem;
                text-align: center;
            }
            
            .user-menu {
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation Header -->
    <div class="portal-container">
        <div class="navigation-header">
            <div class="brand">
                <i class="fas fa-hands-helping me-2"></i>
                REACH Student Portal
            </div>
            <div class="user-menu">
                <span class="me-3">Welcome, <?php echo htmlspecialchars($currentUser['full_name'] ?? 'Student'); ?></span>
                <a href="dashboard.php" class="btn btn-outline-light btn-sm">
                    <i class="fas fa-tachometer-alt me-1"></i>Dashboard
                </a>
                <a href="../../logout.php" class="btn btn-outline-light btn-sm">
                    <i class="fas fa-sign-out-alt me-1"></i>Logout
                </a>
            </div>
        </div>

        <div class="container-fluid py-4">
            <div class="row">
                <div class="col-12">
                    <div class="portal-card">
                        <div class="card-body">
                            <?php if ($systemMessage): ?>
                            <div class="system-alert">
                                <i class="fas fa-info-circle me-2"></i>
                                <?php echo htmlspecialchars($systemMessage); ?>
                            </div>
                            <?php endif; ?>

                            <!-- Project Wizard -->
                            <form id="projectWizardForm" enctype="multipart/form-data" action="../../api/create-project.php" method="POST">
                                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                <input type="hidden" name="student_id" value="<?php echo $currentUser['id']; ?>">
                                
                                <!-- Progress Bar -->
                                <div class="wizard-progress">
                                    <div class="progress" style="height: 8px; border-radius: 10px;">
                                        <div class="progress-bar" role="progressbar" style="width: 0%; border-radius: 10px;" 
                                             aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                    <div class="wizard-steps">
                                        <?php 
                                        $stepLabels = ['Project Setup', 'Planning', 'Timeline', 'Resources', 'Review'];
                                        for ($i = 1; $i <= 5; $i++): 
                                        ?>
                                        <div class="wizard-step <?php echo $i === 1 ? 'active' : ''; ?>" data-step="<?php echo $i; ?>">
                                            <div class="step-number"><?php echo $i; ?></div>
                                            <div class="step-label"><?php echo $stepLabels[$i-1]; ?></div>
                                        </div>
                                        <?php endfor; ?>
                                    </div>
                                </div>

                                <!-- Step 1: Basic Information -->
                                <div class="wizard-step-content active" data-step="1">
                                    <div class="step-header">
                                        <h5><i class="fas fa-info-circle me-2"></i>Project Foundation</h5>
                                        <p>Lay the groundwork for your amazing project</p>
                                    </div>
                                    
                                    <?php if ($appliedTemplate): ?>
                                    <div class="template-applied-alert">
                                        <i class="fas fa-check-circle me-2"></i>
                                        Template "<strong><?php echo htmlspecialchars($appliedTemplate['name']); ?></strong>" applied. Customize the fields below to match your vision.
                                    </div>
                                    <?php endif; ?>
                                    
                                    <div class="row">
                                        <div class="col-lg-8">
                                            <div class="mb-4">
                                                <label for="projectTitle" class="form-label fw-bold">Project Title *</label>
                                                <input type="text" id="projectTitle" class="form-control form-control-lg" 
                                                       name="title" placeholder="Enter a compelling and descriptive project title" 
                                                       value="<?php echo htmlspecialchars($appliedTemplate['title'] ?? ''); ?>" required>
                                                <div class="form-text text-muted">Make it engaging and specific to attract attention</div>
                                                <div class="error-message" id="title-error"></div>
                                            </div>
                                            
                                            <div class="mb-4">
                                                <label for="projectDescription" class="form-label fw-bold">Project Summary *</label>
                                                <textarea class="form-control" id="projectDescription" name="description" rows="4" 
                                                          placeholder="Describe your project's purpose, goals, and expected impact..." required><?php echo htmlspecialchars($appliedTemplate['description'] ?? ''); ?></textarea>
                                                <div class="error-message" id="description-error"></div>
                                            </div>
                                            
                                            <div class="mb-4">
                                                <label class="form-label fw-bold">Detailed Description</label>
                                                <div id="fullDescriptionEditor" style="height: 250px; border-radius: 10px;"><?php echo $appliedTemplate['full_description'] ?? ''; ?></div>
                                                <textarea name="full_description" id="fullDescription" hidden><?php echo $appliedTemplate['full_description'] ?? ''; ?></textarea>
                                                <div class="form-text text-muted">Provide comprehensive details about your project methodology and approach</div>
                                            </div>
                                        </div>
                                        
                                        <div class="col-lg-4">
                                            <!-- Project Template Selector -->
                                            <div class="template-selector mb-4">
                                                <label class="form-label fw-bold">Quick Start Templates</label>
                                                <div class="template-options">
                                                    <div class="template-option <?php echo !$appliedTemplate ? 'selected' : ''; ?>" data-template="">
                                                        <h6><i class="fas fa-plus-circle me-2"></i>Custom Project</h6>
                                                        <p class="text-muted mb-0">Build from scratch with complete flexibility</p>
                                                    </div>
                                                    <?php foreach ($templates as $key => $template): ?>
                                                    <div class="template-option <?php echo ($appliedTemplate && $appliedTemplate['name'] === $template['name']) ? 'selected' : ''; ?>" 
                                                         data-template="<?php echo $key; ?>">
                                                        <h6><i class="fas fa-file-alt me-2"></i><?php echo htmlspecialchars($template['name']); ?></h6>
                                                        <p class="text-muted mb-0"><?php echo htmlspecialchars($template['description']); ?></p>
                                                    </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            </div>
                                            
                                            <!-- Featured Image Upload -->
                                            <div class="featured-image-upload mb-4">
                                                <label class="form-label fw-bold">Featured Image</label>
                                                <div class="upload-area" id="featuredImageUpload" role="button" 
                                                     aria-label="Upload featured image" tabindex="0">
                                                    <i class="fas fa-cloud-upload-alt"></i>
                                                    <p class="fw-bold mb-1">Upload Project Image</p>
                                                    <p class="text-muted mb-1">Drag & drop or click to browse</p>
                                                    <small class="text-muted">Recommended: 1200x600px • Max: 5MB</small>
                                                </div>
                                                <input type="file" name="featured_image" id="featuredImageInput" 
                                                       accept="image/jpeg,image/png,image/gif" hidden>
                                                <div class="image-preview mt-3 d-none" id="imagePreview"></div>
                                                <div class="error-message" id="image-error"></div>
                                            </div>
                                            
                                            <!-- Smart Suggestions Box -->
                                            <div class="ai-suggestions-card">
                                                <div class="card-header">
                                                    <i class="fas fa-lightbulb me-2"></i>
                                                    <span>Smart Suggestions</span>
                                                </div>
                                                <div class="card-body">
                                                    <div id="aiSuggestions">
                                                        <p class="text-muted mb-2"><i class="fas fa-sparkles me-1"></i>Enter project details to get tailored suggestions</p>
                                                        <small class="text-muted">We'll help you refine your project idea with industry best practices</small>
                                                    </div>
                                                    <button type="button" class="btn btn-sm btn-primary w-100 mt-3" id="generateSuggestions">
                                                        <i class="fas fa-wand-magic-sparkles me-1"></i>Get Smart Suggestions
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="projectType" class="form-label fw-bold">Project Category *</label>
                                                <select class="form-select" id="projectType" name="project_type" required>
                                                    <option value="">Select project category</option>
                                                    <option value="academic" <?php echo ($appliedTemplate['type'] ?? '') === 'academic' ? 'selected' : ''; ?>>Academic Research</option>
                                                    <option value="research" <?php echo ($appliedTemplate['type'] ?? '') === 'research' ? 'selected' : ''; ?>>Scientific Research</option>
                                                    <option value="community" <?php echo ($appliedTemplate['type'] ?? '') === 'community' ? 'selected' : ''; ?>>Community Service</option>
                                                    <option value="entrepreneurial" <?php echo ($appliedTemplate['type'] ?? '') === 'entrepreneurial' ? 'selected' : ''; ?>>Entrepreneurial Venture</option>
                                                    <option value="personal" <?php echo ($appliedTemplate['type'] ?? '') === 'personal' ? 'selected' : ''; ?>>Personal Development</option>
                                                    <option value="technical" <?php echo ($appliedTemplate['type'] ?? '') === 'technical' ? 'selected' : ''; ?>>Technical Project</option>
                                                </select>
                                                <div class="error-message" id="project-type-error"></div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="priorityLevel" class="form-label fw-bold">Priority Level</label>
                                                <select class="form-select" id="priorityLevel" name="priority">
                                                    <option value="low">📅 Low Priority</option>
                                                    <option value="medium" selected>⚡ Medium Priority</option>
                                                    <option value="high">🔥 High Priority</option>
                                                    <option value="urgent">🚨 Urgent Priority</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="startDate" class="form-label fw-bold">Start Date *</label>
                                                <input type="text" class="form-control datepicker" id="startDate" name="start_date" 
                                                       value="<?php echo $defaultStartDate; ?>" required>
                                                <div class="error-message" id="start-date-error"></div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="endDate" class="form-label fw-bold">End Date *</label>
                                                <input type="text" class="form-control datepicker" id="endDate" name="end_date" 
                                                       value="<?php echo $defaultEndDate; ?>" required>
                                                <div class="error-message" id="end-date-error"></div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="wizard-actions">
                                        <div></div>
                                        <button type="button" class="btn btn-primary next-step" data-next="2">
                                            Continue to Planning <i class="fas fa-arrow-right ms-2"></i>
                                        </button>
                                    </div>
                                </div>

                                <!-- Step 2: Project Planning -->
                                <div class="wizard-step-content" data-step="2">
                                    <div class="step-header">
                                        <h5><i class="fas fa-tasks me-2"></i>Project Strategy & Requirements</h5>
                                        <p>Define your project's scope, skills, and success criteria</p>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-4">
                                                <label class="form-label fw-bold">Required Skills & Expertise</label>
                                                <input type="text" class="form-control" name="skills_used" 
                                                       value="<?php echo htmlspecialchars($appliedTemplate['skills'] ?? ''); ?>"
                                                       placeholder="e.g., research methodology, data analysis, community engagement">
                                                <div class="form-text text-muted">List the key skills needed for this project</div>
                                            </div>
                                            
                                            <div class="mb-4">
                                                <label class="form-label fw-bold">Technologies & Tools</label>
                                                <input type="text" class="form-control" name="technologies" 
                                                       value="<?php echo htmlspecialchars($appliedTemplate['technologies'] ?? ''); ?>"
                                                       placeholder="e.g., Python, React, SPSS, SurveyMonkey">
                                                <div class="form-text text-muted">Technologies, software, and tools you'll use</div>
                                            </div>
                                            
                                            <div class="mb-4">
                                                <label class="form-label fw-bold">Estimated Budget ($)</label>
                                                <input type="number" class="form-control" name="budget" 
                                                       value="<?php echo htmlspecialchars($appliedTemplate['budget'] ?? '0'); ?>"
                                                       placeholder="0.00" step="0.01" min="0">
                                                <div class="form-text text-muted">Total estimated project budget</div>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <div class="mb-4">
                                                <label class="form-label fw-bold">Target Audience</label>
                                                <textarea class="form-control" name="target_audience" rows="3" 
                                                          placeholder="Who will benefit from or use your project outcomes?"><?php echo htmlspecialchars($appliedTemplate['target_audience'] ?? ''); ?></textarea>
                                                <div class="form-text text-muted">Describe your primary stakeholders and beneficiaries</div>
                                            </div>
                                            
                                            <div class="mb-4">
                                                <label class="form-label fw-bold">Success Metrics</label>
                                                <textarea class="form-control" name="success_metrics" rows="3" 
                                                          placeholder="How will you measure project success and impact?"><?php echo htmlspecialchars($appliedTemplate['success_metrics'] ?? ''); ?></textarea>
                                                <div class="form-text text-muted">Define clear, measurable success criteria</div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="mb-4">
                                        <label class="form-label fw-bold">Project Deliverables</label>
                                        <div id="deliverablesContainer">
                                            <div class="deliverable-item mb-2">
                                                <div class="input-group">
                                                    <input type="text" class="form-control" name="deliverables[]" 
                                                           placeholder="e.g., Research paper, Mobile application, Community workshop">
                                                    <button type="button" class="btn btn-outline-danger remove-deliverable">
                                                        <i class="fas fa-times"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                        <button type="button" class="btn btn-outline-primary mt-2" id="addDeliverable">
                                            <i class="fas fa-plus me-1"></i>Add Another Deliverable
                                        </button>
                                        <div class="form-text text-muted">List all tangible outcomes and results</div>
                                    </div>
                                    
                                    <div class="mb-4">
                                        <label class="form-label fw-bold">Potential Challenges & Risks</label>
                                        <textarea class="form-control" name="challenges" rows="3" 
                                                  placeholder="What obstacles do you anticipate and how will you address them?"></textarea>
                                        <div class="form-text text-muted">Identify risks and your mitigation strategies</div>
                                    </div>
                                    
                                    <div class="form-check form-switch mb-4 p-3 bg-light rounded">
                                        <input class="form-check-input" type="checkbox" name="is_public" id="isPublic" value="1" checked>
                                        <label class="form-check-label fw-bold" for="isPublic">
                                            <i class="fas fa-globe me-1"></i>Make this project public on REACH platform
                                        </label>
                                        <div class="form-text text-muted">Public projects can inspire others and attract collaborators</div>
                                    </div>
                                    
                                    <div class="wizard-actions">
                                        <button type="button" class="btn btn-outline-secondary prev-step" data-prev="1">
                                            <i class="fas fa-arrow-left me-2"></i>Back
                                        </button>
                                        <button type="button" class="btn btn-primary next-step" data-next="3">
                                            Continue to Timeline <i class="fas fa-arrow-right ms-2"></i>
                                        </button>
                                    </div>
                                </div>

                                <!-- Step 3: Milestones & Tasks -->
                                <div class="wizard-step-content" data-step="3">
                                    <div class="step-header">
                                        <h5><i class="fas fa-road me-2"></i>Project Timeline & Milestones</h5>
                                        <p>Break down your project into manageable phases and tasks</p>
                                    </div>
                                    
                                    <div id="milestonesContainer">
                                        <div class="milestone-card" data-milestone-index="0">
                                            <div class="milestone-header">
                                                <h6>Milestone 1</h6>
                                                <button type="button" class="btn btn-sm btn-outline-danger remove-milestone">
                                                    <i class="fas fa-times"></i>
                                                </button>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label class="form-label fw-bold">Milestone Title *</label>
                                                        <input type="text" class="form-control milestone-title" 
                                                               name="milestones[0][title]" placeholder="e.g., Project Planning & Research" required>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label class="form-label fw-bold">Due Date *</label>
                                                        <input type="text" class="form-control datepicker milestone-due-date" 
                                                               name="milestones[0][due_date]" value="<?php echo date('Y-m-d', strtotime('+2 weeks')); ?>" required>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label fw-bold">Description</label>
                                                <textarea class="form-control milestone-description" 
                                                          name="milestones[0][description]" rows="2" placeholder="Describe what this milestone involves..."></textarea>
                                            </div>
                                            
                                            <!-- Tasks for this milestone -->
                                            <div class="tasks-section">
                                                <label class="form-label fw-bold">Tasks</label>
                                                <div class="tasks-container" data-milestone-index="0">
                                                    <div class="task-item mb-2">
                                                        <div class="input-group">
                                                            <input type="text" class="form-control task-title" 
                                                                   name="milestones[0][tasks][0][title]" 
                                                                   placeholder="Task description">
                                                            <input type="text" class="form-control task-due-date datepicker" 
                                                                   name="milestones[0][tasks][0][due_date]" 
                                                                   placeholder="Due date">
                                                            <select class="form-select task-priority" 
                                                                    name="milestones[0][tasks][0][priority]">
                                                                <option value="low">Low</option>
                                                                <option value="medium" selected>Medium</option>
                                                                <option value="high">High</option>
                                                            </select>
                                                            <button type="button" class="btn btn-outline-danger remove-task">
                                                                <i class="fas fa-times"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                                <button type="button" class="btn btn-outline-primary btn-sm add-task" 
                                                        data-milestone-index="0">
                                                    <i class="fas fa-plus me-1"></i>Add Task
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="text-center mt-4">
                                        <button type="button" class="btn btn-outline-primary" id="addMilestone">
                                            <i class="fas fa-plus me-2"></i>Add Another Milestone
                                        </button>
                                    </div>
                                    
                                    <div class="wizard-actions mt-4">
                                        <button type="button" class="btn btn-outline-secondary prev-step" data-prev="2">
                                            <i class="fas fa-arrow-left me-2"></i>Back
                                        </button>
                                        <button type="button" class="btn btn-primary next-step" data-next="4">
                                            Continue to Resources <i class="fas fa-arrow-right ms-2"></i>
                                        </button>
                                    </div>
                                </div>

                                <!-- Step 4: Resources & Support -->
                                <div class="wizard-step-content" data-step="4">
                                    <div class="step-header">
                                        <h5><i class="fas fa-tools me-2"></i>Resources & Support Needed</h5>
                                        <p>Identify what you need to succeed</p>
                                    </div>
                                    
                                    <div class="resources-section">
                                        <div class="resource-type mb-4">
                                            <h6>💰 Financial Resources</h6>
                                            <div class="resource-items" data-type="financial">
                                                <div class="resource-item mb-2">
                                                    <div class="input-group">
                                                        <input type="text" class="form-control" 
                                                               name="resources[financial][0][title]" 
                                                               placeholder="e.g., Equipment purchase, Travel expenses">
                                                        <input type="number" class="form-control" 
                                                               name="resources[financial][0][amount]" 
                                                               placeholder="Amount" step="0.01" min="0">
                                                        <button type="button" class="btn btn-outline-danger remove-resource">
                                                            <i class="fas fa-times"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                            <button type="button" class="btn btn-outline-primary btn-sm add-resource" data-type="financial">
                                                <i class="fas fa-plus me-1"></i>Add Financial Need
                                            </button>
                                        </div>
                                        
                                        <div class="resource-type mb-4">
                                            <h6>🛠️ Material Resources</h6>
                                            <div class="resource-items" data-type="material">
                                                <div class="resource-item mb-2">
                                                    <div class="input-group">
                                                        <input type="text" class="form-control" 
                                                               name="resources[material][0][title]" 
                                                               placeholder="e.g., Laptop, Books, Lab equipment">
                                                        <button type="button" class="btn btn-outline-danger remove-resource">
                                                            <i class="fas fa-times"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                            <button type="button" class="btn btn-outline-primary btn-sm add-resource" data-type="material">
                                                <i class="fas fa-plus me-1"></i>Add Material Need
                                            </button>
                                        </div>
                                        
                                        <div class="resource-type mb-4">
                                            <h6>👥 Human Resources</h6>
                                            <div class="resource-items" data-type="human">
                                                <div class="resource-item mb-2">
                                                    <div class="input-group">
                                                        <input type="text" class="form-control" 
                                                               name="resources[human][0][title]" 
                                                               placeholder="e.g., Mentor, Research assistant, Technical expert">
                                                        <button type="button" class="btn btn-outline-danger remove-resource">
                                                            <i class="fas fa-times"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                            <button type="button" class="btn btn-outline-primary btn-sm add-resource" data-type="human">
                                                <i class="fas fa-plus me-1"></i>Add Human Resource Need
                                            </button>
                                        </div>
                                    </div>
                                    
                                    <div class="wizard-actions">
                                        <button type="button" class="btn btn-outline-secondary prev-step" data-prev="3">
                                            <i class="fas fa-arrow-left me-2"></i>Back
                                        </button>
                                        <button type="button" class="btn btn-primary next-step" data-next="5">
                                            Review & Submit <i class="fas fa-arrow-right ms-2"></i>
                                        </button>
                                    </div>
                                </div>

                                <!-- Step 5: Review & Submit -->
                                <div class="wizard-step-content" data-step="5">
                                    <div class="step-header">
                                        <h5><i class="fas fa-clipboard-check me-2"></i>Review Your Project</h5>
                                        <p>Double-check everything before submitting</p>
                                    </div>
                                    
                                    <div class="review-section">
                                        <div class="review-card mb-4">
                                            <h6>📋 Basic Information</h6>
                                            <div id="review-basic-info">
                                                <p class="text-muted">Project information will appear here after you complete the previous steps...</p>
                                            </div>
                                        </div>
                                        
                                        <div class="review-card mb-4">
                                            <h6>🎯 Project Plan</h6>
                                            <div id="review-planning">
                                                <p class="text-muted">Planning details will appear here...</p>
                                            </div>
                                        </div>
                                        
                                        <div class="review-card mb-4">
                                            <h6>📅 Timeline & Milestones</h6>
                                            <div id="review-milestones">
                                                <p class="text-muted">Milestones and timeline will appear here...</p>
                                            </div>
                                        </div>
                                        
                                        <div class="review-card mb-4">
                                            <h6>🛠️ Resources Needed</h6>
                                            <div id="review-resources">
                                                <p class="text-muted">Resource requirements will appear here...</p>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="alert alert-info">
                                        <i class="fas fa-info-circle me-2"></i>
                                        Your project will be submitted for admin approval before becoming active. You'll be able to track its status in your dashboard.
                                    </div>
                                    
                                    <div class="wizard-actions">
                                        <button type="button" class="btn btn-outline-secondary prev-step" data-prev="4">
                                            <i class="fas fa-arrow-left me-2"></i>Back
                                        </button>
                                        <button type="submit" class="btn btn-success" id="submitProject">
                                            <i class="fas fa-paper-plane me-2"></i>Submit Project
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Loading Modal -->
    <div class="modal fade" id="loadingModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-body text-center py-4">
                    <div class="loading-spinner mb-3"></div>
                    <h5>Creating Your Project</h5>
                    <p class="text-muted mb-0">Please wait while we set up your project...</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Success Modal -->
    <div class="modal fade" id="successModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body text-center py-5">
                    <i class="fas fa-check-circle text-success fa-5x mb-4"></i>
                    <h3>Project Created Successfully!</h3>
                    <p class="text-muted mb-4">Your project has been submitted for admin approval and is now in the review queue.</p>
                    <div class="mt-4">
                        <a href="projects.php" class="btn btn-primary btn-lg me-3">
                            <i class="fas fa-folder-open me-2"></i>View My Projects
                        </a>
                        <a href="dashboard.php" class="btn btn-outline-primary btn-lg">
                            <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.quilljs.com/1.3.6/quill.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/flatpickr/4.6.13/flatpickr.min.js"></script>
    
    <script>
    // Professional JavaScript implementation
    class ProjectWizard {
        constructor() {
            this.currentStep = 1;
            this.totalSteps = 5;
            this.milestoneCount = 1;
            this.init();
        }

        init() {
            this.initDatePickers();
            this.initRichTextEditor();
            this.initEventListeners();
            this.updateProgress();
        }

        initDatePickers() {
            flatpickr('.datepicker', {
                dateFormat: 'Y-m-d',
                minDate: 'today',
                enableTime: false,
                static: true
            });
        }

        initRichTextEditor() {
            this.editor = new Quill('#fullDescriptionEditor', {
                theme: 'snow',
                modules: {
                    toolbar: [
                        [{ 'header': [1, 2, 3, false] }],
                        ['bold', 'italic', 'underline'],
                        ['link', 'blockquote', 'code-block'],
                        [{ 'list': 'ordered'}, { 'list': 'bullet' }],
                        ['clean']
                    ]
                },
                placeholder: 'Provide detailed information about your project methodology, approach, and implementation plan...'
            });

            this.editor.on('text-change', () => {
                document.getElementById('fullDescription').value = this.editor.root.innerHTML;
            });
        }

        initEventListeners() {
            // Step navigation
            document.querySelectorAll('.next-step').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    const nextStep = parseInt(e.target.dataset.next);
                    if (this.validateStep(this.currentStep)) {
                        this.goToStep(nextStep);
                    }
                });
            });

            document.querySelectorAll('.prev-step').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    const prevStep = parseInt(e.target.dataset.prev);
                    this.goToStep(prevStep);
                });
            });

            // Template selection
            document.querySelectorAll('.template-option').forEach(option => {
                option.addEventListener('click', (e) => {
                    const template = e.currentTarget.dataset.template;
                    this.selectTemplate(template);
                });
            });

            // Image upload
            document.getElementById('featuredImageUpload').addEventListener('click', () => {
                document.getElementById('featuredImageInput').click();
            });

            document.getElementById('featuredImageInput').addEventListener('change', (e) => {
                this.handleImageUpload(e.target.files[0]);
            });

            // Form submission
            document.getElementById('projectWizardForm').addEventListener('submit', (e) => {
                e.preventDefault();
                this.submitProject();
            });

            // AI suggestions
            document.getElementById('generateSuggestions').addEventListener('click', () => {
                this.generateAISuggestions();
            });

            // Dynamic elements
            this.initDynamicElements();

            // Real-time validation
            document.getElementById('projectTitle').addEventListener('input', () => {
                this.validateField('projectTitle', 'title');
            });

            document.getElementById('projectDescription').addEventListener('input', () => {
                this.validateField('projectDescription', 'description');
            });
        }

        initDynamicElements() {
            // Deliverables
            document.getElementById('addDeliverable').addEventListener('click', () => {
                this.addDeliverable();
            });

            // Milestones
            document.getElementById('addMilestone').addEventListener('click', () => {
                this.addMilestone();
            });

            // Resources
            document.querySelectorAll('.add-resource').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    const type = e.target.dataset.type;
                    this.addResource(type);
                });
            });

            // Event delegation for remove buttons
            document.addEventListener('click', (e) => {
                if (e.target.closest('.remove-deliverable')) {
                    this.removeDeliverable(e.target.closest('.deliverable-item'));
                } else if (e.target.closest('.remove-milestone')) {
                    this.removeMilestone(e.target.closest('.milestone-card'));
                } else if (e.target.closest('.remove-task')) {
                    this.removeTask(e.target.closest('.task-item'));
                } else if (e.target.closest('.remove-resource')) {
                    this.removeResource(e.target.closest('.resource-item'));
                } else if (e.target.closest('.add-task')) {
                    const milestoneIndex = e.target.dataset.milestoneIndex;
                    this.addTask(milestoneIndex);
                }
            });
        }

        addDeliverable() {
            const container = document.getElementById('deliverablesContainer');
            const index = container.children.length;
            const deliverableHTML = `
                <div class="deliverable-item mb-2">
                    <div class="input-group">
                        <input type="text" class="form-control" name="deliverables[]" 
                               placeholder="e.g., Research paper, Mobile application, Community workshop">
                        <button type="button" class="btn btn-outline-danger remove-deliverable">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                </div>
            `;
            container.insertAdjacentHTML('beforeend', deliverableHTML);
        }

        removeDeliverable(element) {
            if (document.querySelectorAll('.deliverable-item').length > 1) {
                element.remove();
            }
        }

        addMilestone() {
            const index = this.milestoneCount++;
            const milestoneHTML = `
                <div class="milestone-card" data-milestone-index="${index}">
                    <div class="milestone-header">
                        <h6>Milestone ${index + 1}</h6>
                        <button type="button" class="btn btn-sm btn-outline-danger remove-milestone">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label fw-bold">Milestone Title *</label>
                                <input type="text" class="form-control milestone-title" 
                                       name="milestones[${index}][title]" placeholder="e.g., Project Planning & Research" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label fw-bold">Due Date *</label>
                                <input type="text" class="form-control datepicker milestone-due-date" 
                                       name="milestones[${index}][due_date]" value="<?php echo date('Y-m-d', strtotime('+' . ($index + 2) . ' weeks')); ?>" required>
                            </div>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Description</label>
                        <textarea class="form-control milestone-description" 
                                  name="milestones[${index}][description]" rows="2" placeholder="Describe what this milestone involves..."></textarea>
                    </div>
                    <div class="tasks-section">
                        <label class="form-label fw-bold">Tasks</label>
                        <div class="tasks-container" data-milestone-index="${index}">
                            <div class="task-item mb-2">
                                <div class="input-group">
                                    <input type="text" class="form-control task-title" 
                                           name="milestones[${index}][tasks][0][title]" 
                                           placeholder="Task description">
                                    <input type="text" class="form-control task-due-date datepicker" 
                                           name="milestones[${index}][tasks][0][due_date]" 
                                           placeholder="Due date">
                                    <select class="form-select task-priority" 
                                            name="milestones[${index}][tasks][0][priority]">
                                        <option value="low">Low</option>
                                        <option value="medium" selected>Medium</option>
                                        <option value="high">High</option>
                                    </select>
                                    <button type="button" class="btn btn-outline-danger remove-task">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <button type="button" class="btn btn-outline-primary btn-sm add-task" 
                                data-milestone-index="${index}">
                            <i class="fas fa-plus me-1"></i>Add Task
                        </button>
                    </div>
                </div>
            `;
            document.getElementById('milestonesContainer').insertAdjacentHTML('beforeend', milestoneHTML);
            
            // Reinitialize date pickers for new elements
            this.initDatePickers();
        }

        removeMilestone(element) {
            if (document.querySelectorAll('.milestone-card').length > 1) {
                element.remove();
                this.renumberMilestones();
            }
        }

        renumberMilestones() {
            const milestones = document.querySelectorAll('.milestone-card');
            milestones.forEach((milestone, index) => {
                milestone.querySelector('h6').textContent = `Milestone ${index + 1}`;
                milestone.dataset.milestoneIndex = index;
            });
            this.milestoneCount = milestones.length;
        }

        addTask(milestoneIndex) {
            const container = document.querySelector(`.tasks-container[data-milestone-index="${milestoneIndex}"]`);
            const taskCount = container.children.length;
            const taskHTML = `
                <div class="task-item mb-2">
                    <div class="input-group">
                        <input type="text" class="form-control task-title" 
                               name="milestones[${milestoneIndex}][tasks][${taskCount}][title]" 
                               placeholder="Task description">
                        <input type="text" class="form-control task-due-date datepicker" 
                               name="milestones[${milestoneIndex}][tasks][${taskCount}][due_date]" 
                               placeholder="Due date">
                        <select class="form-select task-priority" 
                                name="milestones[${milestoneIndex}][tasks][${taskCount}][priority]">
                            <option value="low">Low</option>
                            <option value="medium" selected>Medium</option>
                            <option value="high">High</option>
                        </select>
                        <button type="button" class="btn btn-outline-danger remove-task">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                </div>
            `;
            container.insertAdjacentHTML('beforeend', taskHTML);
            this.initDatePickers();
        }

        removeTask(element) {
            const container = element.parentElement;
            if (container.children.length > 1) {
                element.remove();
            }
        }

        addResource(type) {
            const container = document.querySelector(`.resource-items[data-type="${type}"]`);
            const index = container.children.length;
            let resourceHTML = '';
            
            if (type === 'financial') {
                resourceHTML = `
                    <div class="resource-item mb-2">
                        <div class="input-group">
                            <input type="text" class="form-control" 
                                   name="resources[${type}][${index}][title]" 
                                   placeholder="e.g., Equipment purchase, Travel expenses">
                            <input type="number" class="form-control" 
                                   name="resources[${type}][${index}][amount]" 
                                   placeholder="Amount" step="0.01" min="0">
                            <button type="button" class="btn btn-outline-danger remove-resource">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                    </div>
                `;
            } else {
                resourceHTML = `
                    <div class="resource-item mb-2">
                        <div class="input-group">
                            <input type="text" class="form-control" 
                                   name="resources[${type}][${index}][title]" 
                                   placeholder="e.g., ${type === 'material' ? 'Laptop, Books, Lab equipment' : 'Mentor, Research assistant, Technical expert'}">
                            <button type="button" class="btn btn-outline-danger remove-resource">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                    </div>
                `;
            }
            
            container.insertAdjacentHTML('beforeend', resourceHTML);
        }

        removeResource(element) {
            const container = element.parentElement;
            if (container.children.length > 1) {
                element.remove();
            }
        }

        validateStep(step) {
            switch(step) {
                case 1:
                    return this.validateStep1();
                case 2:
                    return this.validateStep2();
                case 3:
                    return this.validateStep3();
                case 4:
                    return true; // Resources are optional
                default:
                    return true;
            }
        }

        validateStep1() {
            let isValid = true;
            
            if (!this.validateField('projectTitle', 'title')) isValid = false;
            if (!this.validateField('projectDescription', 'description')) isValid = false;
            if (!this.validateField('projectType', 'project_type')) isValid = false;
            if (!this.validateDates()) isValid = false;
            
            return isValid;
        }

        validateStep2() {
            // Basic validation for step 2 - most fields are optional
            return true;
        }

        validateStep3() {
            // Validate milestones
            const milestones = document.querySelectorAll('.milestone-card');
            let isValid = true;

            milestones.forEach((milestone, index) => {
                const title = milestone.querySelector('.milestone-title').value.trim();
                const dueDate = milestone.querySelector('.milestone-due-date').value.trim();
                
                if (!title) {
                    isValid = false;
                    this.showFieldError(milestone.querySelector('.milestone-title'), 'Milestone title is required');
                }
                
                if (!dueDate) {
                    isValid = false;
                    this.showFieldError(milestone.querySelector('.milestone-due-date'), 'Due date is required');
                }
            });

            return isValid;
        }

        validateField(fieldId, fieldName) {
            const field = document.getElementById(fieldId);
            const errorElement = document.getElementById(`${fieldName}-error`);
            let isValid = true;
            let message = '';

            switch(fieldName) {
                case 'title':
                    if (!field.value.trim()) {
                        message = 'Project title is required';
                        isValid = false;
                    } else if (field.value.trim().length < 5) {
                        message = 'Title must be at least 5 characters long';
                        isValid = false;
                    }
                    break;
                case 'description':
                    if (!field.value.trim()) {
                        message = 'Project description is required';
                        isValid = false;
                    } else if (field.value.trim().length < 20) {
                        message = 'Description must be at least 20 characters long';
                        isValid = false;
                    }
                    break;
                case 'project_type':
                    if (!field.value) {
                        message = 'Please select a project type';
                        isValid = false;
                    }
                    break;
                case 'start_date':
                case 'end_date':
                    if (!field.value) {
                        message = `${fieldName.replace('_', ' ')} is required`;
                        isValid = false;
                    }
                    break;
            }

            if (errorElement) {
                errorElement.textContent = message;
                this.toggleFieldValidation(field, isValid);
            }

            return isValid;
        }

        showFieldError(field, message) {
            field.classList.add('is-invalid');
            // Create error message if it doesn't exist
            if (!field.nextElementSibling || !field.nextElementSibling.classList.contains('error-message')) {
                const errorElement = document.createElement('div');
                errorElement.className = 'error-message';
                errorElement.textContent = message;
                field.parentNode.insertBefore(errorElement, field.nextSibling);
            }
        }

        toggleFieldValidation(field, isValid) {
            field.classList.toggle('is-invalid', !isValid);
            field.classList.toggle('is-valid', isValid && field.value.trim() !== '');
        }

        validateDates() {
            const startDate = document.getElementById('startDate').value;
            const endDate = document.getElementById('endDate').value;
            let isValid = true;

            if (startDate && endDate) {
                const start = new Date(startDate);
                const end = new Date(endDate);
                
                if (end <= start) {
                    document.getElementById('end-date-error').textContent = 'End date must be after start date';
                    isValid = false;
                } else {
                    document.getElementById('end-date-error').textContent = '';
                }
            }

            return isValid;
        }

        goToStep(step) {
            // Hide current step
            document.querySelector(`.wizard-step-content[data-step="${this.currentStep}"]`).classList.remove('active');
            document.querySelector(`.wizard-step[data-step="${this.currentStep}"]`).classList.remove('active');
            
            // Show new step
            document.querySelector(`.wizard-step-content[data-step="${step}"]`).classList.add('active');
            document.querySelector(`.wizard-step[data-step="${step}"]`).classList.add('active');
            
            // Mark previous steps as completed
            for (let i = 1; i < step; i++) {
                document.querySelector(`.wizard-step[data-step="${i}"]`).classList.add('completed');
            }
            
            this.currentStep = step;
            this.updateProgress();
            
            // Update review section if we're on the last step
            if (step === 5) {
                this.updateReviewSection();
            }
        }

        updateProgress() {
            const progress = ((this.currentStep - 1) / (this.totalSteps - 1)) * 100;
            document.querySelector('.progress-bar').style.width = `${progress}%`;
            document.querySelector('.progress-bar').setAttribute('aria-valuenow', progress);
        }

        selectTemplate(templateKey) {
            // Update UI
            document.querySelectorAll('.template-option').forEach(option => {
                option.classList.remove('selected');
            });
            document.querySelector(`.template-option[data-template="${templateKey}"]`).classList.add('selected');
            
            if (templateKey) {
                // Redirect to apply template
                window.location.href = `create-project.php?template=${templateKey}`;
            } else {
                // Clear template data
                window.location.href = 'create-project.php';
            }
        }

        handleImageUpload(file) {
            if (file) {
                // Validate file
                const validTypes = ['image/jpeg', 'image/png', 'image/gif'];
                const maxSize = 5 * 1024 * 1024; // 5MB
                
                if (!validTypes.includes(file.type)) {
                    document.getElementById('image-error').textContent = 'Please select a valid image (JPEG, PNG, GIF)';
                    return;
                }
                
                if (file.size > maxSize) {
                    document.getElementById('image-error').textContent = 'Image must be less than 5MB';
                    return;
                }
                
                // Show preview
                const reader = new FileReader();
                reader.onload = (e) => {
                    const preview = document.getElementById('imagePreview');
                    preview.innerHTML = `<img src="${e.target.result}" alt="Preview">`;
                    preview.classList.remove('d-none');
                    document.getElementById('image-error').textContent = '';
                };
                reader.readAsDataURL(file);
            }
        }

        async generateAISuggestions() {
            const title = document.getElementById('projectTitle').value;
            const description = document.getElementById('projectDescription').value;
            const projectType = document.getElementById('projectType').value;
            
            if (!title && !description) {
                document.getElementById('aiSuggestions').innerHTML = 
                    '<p class="text-muted">Please enter some project details first.</p>';
                return;
            }
            
            document.getElementById('aiSuggestions').innerHTML = 
                '<div class="text-center"><div class="spinner-border spinner-border-sm me-2"></div>Generating suggestions...</div>';
            
            try {
                const response = await fetch('../../api/ai-suggestions.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        title: title,
                        description: description,
                        project_type: projectType,
                        csrf_token: '<?php echo $_SESSION['csrf_token']; ?>'
                    })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    document.getElementById('aiSuggestions').innerHTML = 
                        `<div class="suggestion-item">
                            <strong>Title Suggestion:</strong> ${data.suggestions.title}
                         </div>
                         <div class="suggestion-item mt-2">
                            <strong>Description Ideas:</strong> ${data.suggestions.description}
                         </div>
                         <div class="suggestion-item mt-2">
                            <strong>Suggested Skills:</strong> ${data.suggestions.skills.join(', ')}
                         </div>`;
                } else {
                    // Fallback to basic suggestions
                    this.generateBasicSuggestions(title, description, projectType);
                }
            } catch (error) {
                // Fallback to basic suggestions on network error
                this.generateBasicSuggestions(title, description, projectType);
            }
        }

        generateBasicSuggestions(title, description, projectType) {
            const basicSuggestions = {
                title: title ? `Enhanced: ${title}` : 'Consider a specific, action-oriented title',
                description: description ? `Build on: "${description.substring(0, 100)}..."` : 'Add detailed goals and methodology',
                skills: ['Research', 'Planning', 'Communication', 'Documentation']
            };
            
            document.getElementById('aiSuggestions').innerHTML = 
                `<div class="suggestion-item">
                    <strong>Title Idea:</strong> ${basicSuggestions.title}
                 </div>
                 <div class="suggestion-item mt-2">
                    <strong>Description Focus:</strong> ${basicSuggestions.description}
                 </div>
                 <div class="suggestion-item mt-2">
                    <strong>Key Skills:</strong> ${basicSuggestions.skills.join(', ')}
                 </div>`;
        }

        updateReviewSection() {
            // Basic Information
            const basicInfo = `
                <p><strong>Title:</strong> ${document.getElementById('projectTitle').value}</p>
                <p><strong>Description:</strong> ${document.getElementById('projectDescription').value.substring(0, 100)}...</p>
                <p><strong>Type:</strong> ${document.getElementById('projectType').options[document.getElementById('projectType').selectedIndex].text}</p>
                <p><strong>Priority:</strong> ${document.getElementById('priorityLevel').options[document.getElementById('priorityLevel').selectedIndex].text}</p>
                <p><strong>Timeline:</strong> ${document.getElementById('startDate').value} to ${document.getElementById('endDate').value}</p>
            `;
            document.getElementById('review-basic-info').innerHTML = basicInfo;
            
            // Planning
            const skills = document.querySelector('input[name="skills_used"]').value;
            const technologies = document.querySelector('input[name="technologies"]').value;
            const budget = document.querySelector('input[name="budget"]').value;
            const planningInfo = `
                <p><strong>Skills:</strong> ${skills || 'Not specified'}</p>
                <p><strong>Technologies:</strong> ${technologies || 'Not specified'}</p>
                <p><strong>Budget:</strong> $${budget || '0'}</p>
                <p><strong>Public:</strong> ${document.getElementById('isPublic').checked ? 'Yes' : 'No'}</p>
            `;
            document.getElementById('review-planning').innerHTML = planningInfo;
            
            // Milestones
            const milestones = document.querySelectorAll('.milestone-card');
            let milestonesHTML = '';
            milestones.forEach(milestone => {
                const title = milestone.querySelector('.milestone-title').value;
                const dueDate = milestone.querySelector('.milestone-due-date').value;
                const taskCount = milestone.querySelectorAll('.task-item').length;
                milestonesHTML += `<p><strong>${title}:</strong> Due ${dueDate} (${taskCount} tasks)</p>`;
            });
            document.getElementById('review-milestones').innerHTML = milestonesHTML || '<p>No milestones added</p>';
            
            // Resources
            let resourcesHTML = '';
            const resourceTypes = ['financial', 'material', 'human'];
            resourceTypes.forEach(type => {
                const resources = document.querySelectorAll(`.resource-items[data-type="${type}"] .resource-item`);
                if (resources.length > 0) {
                    resourcesHTML += `<p><strong>${type.charAt(0).toUpperCase() + type.slice(1)}:</strong> ${resources.length} item(s)</p>`;
                }
            });
            document.getElementById('review-resources').innerHTML = resourcesHTML || '<p>No resources specified</p>';
        }

        async submitProject() {
            if (!this.validateStep(5)) {
                alert('Please fix validation errors before submitting.');
                return;
            }
            
            const loadingModal = new bootstrap.Modal(document.getElementById('loadingModal'));
            loadingModal.show();
            
            try {
                const formData = new FormData(document.getElementById('projectWizardForm'));
                
                const response = await fetch('../../api/create-project.php', {
                    method: 'POST',
                    body: formData
                });
                
                const result = await response.json();
                
                loadingModal.hide();
                
                if (result.success) {
                    const successModal = new bootstrap.Modal(document.getElementById('successModal'));
                    successModal.show();
                } else {
                    alert('Error: ' + (result.message || 'Failed to create project'));
                }
            } catch (error) {
                loadingModal.hide();
                alert('Network error. Please try again.');
                console.error('Submission error:', error);
            }
        }
    }

    // Initialize when DOM is ready
    document.addEventListener('DOMContentLoaded', () => {
        new ProjectWizard();
    });
    </script>
</body>
</html>