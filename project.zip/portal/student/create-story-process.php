<?php
session_start();
require_once '../../includes/config.php';
require_once '../../includes/database.php';
require_once '../../includes/classes/StoryManager.php';

// Check if user is logged in and is a student
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'student') {
    header('HTTP/1.1 403 Forbidden');
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit;
}

$storyManager = new StoryManager($pdo);
$user_id = $_SESSION['user_id'];

// Handle file upload
function handleFileUpload($file, $user_id) {
    $uploadDir = '../../assets/uploads/stories/';
    
    // Create directory if it doesn't exist
    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }
    
    // Validate file
    $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    $maxSize = 5 * 1024 * 1024; // 5MB
    
    if (!in_array($file['type'], $allowedTypes)) {
        throw new Exception('Invalid file type. Only JPG, PNG, GIF, and WebP are allowed.');
    }
    
    if ($file['size'] > $maxSize) {
        throw new Exception('File size too large. Maximum size is 5MB.');
    }
    
    // Generate unique filename
    $fileExtension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = 'story_' . $user_id . '_' . time() . '_' . uniqid() . '.' . $fileExtension;
    $filePath = $uploadDir . $filename;
    
    if (move_uploaded_file($file['tmp_name'], $filePath)) {
        return $filename;
    } else {
        throw new Exception('Failed to upload file.');
    }
}

// Handle different actions
$action = $_POST['action'] ?? '';

try {
    switch ($action) {
        case 'save_draft':
            $storyData = [
                'title' => trim($_POST['title'] ?? ''),
                'excerpt' => trim($_POST['excerpt'] ?? ''),
                'content' => $_POST['content'] ?? '',
                'story_type' => $_POST['story_type'] ?? 'student',
                'tags' => $_POST['tags'] ?? '',
                'is_public' => isset($_POST['is_public']) ? 1 : 0,
                'allow_comments' => isset($_POST['allow_comments']) ? 1 : 0,
                'status' => 'draft',
                'author_id' => $user_id
            ];
            
            // Handle featured image upload
            if (isset($_FILES['featured_image']) && $_FILES['featured_image']['error'] === UPLOAD_ERR_OK) {
                $storyData['featured_image'] = handleFileUpload($_FILES['featured_image'], $user_id);
            } else {
                $storyData['featured_image'] = 'default.jpg';
            }
            
            // Handle gallery images
            $galleryImages = [];
            if (isset($_FILES['gallery_images'])) {
                foreach ($_FILES['gallery_images']['tmp_name'] as $key => $tmp_name) {
                    if ($_FILES['gallery_images']['error'][$key] === UPLOAD_ERR_OK) {
                        $galleryImages[] = handleFileUpload([
                            'name' => $_FILES['gallery_images']['name'][$key],
                            'type' => $_FILES['gallery_images']['type'][$key],
                            'tmp_name' => $tmp_name,
                            'error' => $_FILES['gallery_images']['error'][$key],
                            'size' => $_FILES['gallery_images']['size'][$key]
                        ], $user_id);
                    }
                }
            }
            $storyData['gallery'] = !empty($galleryImages) ? json_encode($galleryImages) : '';
            
            if ($storyManager->createStory($storyData)) {
                echo json_encode(['success' => true, 'message' => 'Draft saved successfully!']);
            } else {
                throw new Exception('Failed to save draft.');
            }
            break;
            
        case 'submit_review':
            $storyData = [
                'title' => trim($_POST['title'] ?? ''),
                'excerpt' => trim($_POST['excerpt'] ?? ''),
                'content' => $_POST['content'] ?? '',
                'story_type' => $_POST['story_type'] ?? 'student',
                'tags' => $_POST['tags'] ?? '',
                'is_public' => isset($_POST['is_public']) ? 1 : 0,
                'allow_comments' => isset($_POST['allow_comments']) ? 1 : 0,
                'status' => 'pending',
                'author_id' => $user_id
            ];
            
            // Handle featured image upload
            if (isset($_FILES['featured_image']) && $_FILES['featured_image']['error'] === UPLOAD_ERR_OK) {
                $storyData['featured_image'] = handleFileUpload($_FILES['featured_image'], $user_id);
            } else {
                $storyData['featured_image'] = 'default.jpg';
            }
            
            // Validate required fields
            if (empty($storyData['title'])) {
                throw new Exception('Story title is required.');
            }
            
            if (empty(strip_tags($storyData['content'])) || strlen(strip_tags($storyData['content'])) < 100) {
                throw new Exception('Story content must be at least 100 characters long.');
            }
            
            if ($storyManager->createStory($storyData)) {
                echo json_encode(['success' => true, 'message' => 'Story submitted for review successfully!']);
            } else {
                throw new Exception('Failed to submit story for review.');
            }
            break;
            
        case 'auto_save':
            // For auto-save, we might want to update an existing draft
            // This is a simplified version - you might want to implement proper draft handling
            echo json_encode(['success' => true, 'message' => 'Auto-saved successfully']);
            break;
            
        case 'upload_image':
            if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                $filename = handleFileUpload($_FILES['image'], $user_id);
                echo json_encode([
                    'success' => true, 
                    'url' => '../../assets/uploads/stories/' . $filename,
                    'message' => 'Image uploaded successfully'
                ]);
            } else {
                throw new Exception('No image file provided or upload error.');
            }
            break;
            
        default:
            throw new Exception('Invalid action.');
    }
} catch (Exception $e) {
    error_log("Story creation error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>