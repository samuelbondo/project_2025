<?php
session_start();
require_once '../../includes/config.php';
require_once '../../includes/database.php';
require_once '../../includes/classes/StoryManager.php';

// Check if user is logged in and is a student
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'student') {
    header('Location: ../login.php');
    exit;
}

$storyManager = new StoryManager($pdo);
$studentId = $_SESSION['user_id'];
$studentName = $_SESSION['full_name'] ?? 'Student';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    try {
        $storyData = [
            'title' => trim($_POST['title'] ?? ''),
            'excerpt' => trim($_POST['excerpt'] ?? ''),
            'content' => $_POST['content'] ?? '',
            'story_type' => $_POST['story_type'] ?? 'student',
            'tags' => $_POST['tags'] ?? '',
            'author_id' => $studentId,
            'allow_comments' => isset($_POST['allow_comments']) ? 1 : 0
        ];
        
        // Handle featured image upload
        if (isset($_FILES['featured_image']) && $_FILES['featured_image']['error'] === UPLOAD_ERR_OK) {
            $uploadDir = '../assets/uploads/stories/';
            if (!file_exists($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }
            
            $file = $_FILES['featured_image'];
            $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
            $maxSize = 5 * 1024 * 1024;
            
            if (!in_array($file['type'], $allowedTypes)) {
                throw new Exception('Invalid file type. Only JPG, PNG, GIF, and WebP are allowed.');
            }
            
            if ($file['size'] > $maxSize) {
                throw new Exception('File size too large. Maximum size is 5MB.');
            }
            
            $fileExtension = pathinfo($file['name'], PATHINFO_EXTENSION);
            $filename = 'story_' . $studentId . '_' . time() . '.' . $fileExtension;
            $filePath = $uploadDir . $filename;
            
            if (move_uploaded_file($file['tmp_name'], $filePath)) {
                $storyData['featured_image'] = $filename;
            } else {
                throw new Exception('Failed to upload file.');
            }
        } else {
            $storyData['featured_image'] = 'default.jpg';
        }
        
        switch ($action) {
            case 'save_draft':
                $storyData['status'] = 'draft';
                if ($storyManager->createStory($storyData)) {
                    $_SESSION['success'] = "Draft saved successfully!";
                } else {
                    throw new Exception('Failed to save draft.');
                }
                break;
                
            case 'submit_review':
                $storyData['status'] = 'pending';
                
                // Validate required fields
                if (empty($storyData['title'])) {
                    throw new Exception('Story title is required.');
                }
                
                if (empty(strip_tags($storyData['content'])) || strlen(strip_tags($storyData['content'])) < 100) {
                    throw new Exception('Story content must be at least 100 characters long.');
                }
                
                if ($storyManager->createStory($storyData)) {
                    $_SESSION['success'] = "Story submitted for review successfully!";
                } else {
                    throw new Exception('Failed to submit story for review.');
                }
                break;
                
            default:
                throw new Exception('Invalid action.');
        }
        
        header("Location: stories.php");
        exit;
        
    } catch (Exception $e) {
        $_SESSION['error'] = $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Story - REACH Student Portal</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/dropzone/6.0.0-beta.2/dropzone.min.css" rel="stylesheet">
    
    <style>
        :root {
            --primary: #3498db;
            --secondary: #2c3e50;
            --success: #27ae60;
            --warning: #f39c12;
            --danger: #e74c3c;
            --info: #17a2b8;
            --light: #f8f9fa;
            --dark: #343a40;
        }

        body.student-portal.story-editor {
            background: #f5f7fa;
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
        }

        .portal-main {
            padding: 2rem;
        }

        /* Editor Container */
        .editor-container {
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            overflow: hidden;
        }

        /* Editor Header */
        .editor-header {
            background: var(--secondary);
            color: white;
            padding: 1.5rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #e9ecef;
        }

        .header-left h4 {
            margin: 0;
            font-weight: 600;
        }

        .document-info {
            display: flex;
            gap: 1.5rem;
            margin-top: 0.5rem;
            font-size: 0.875rem;
            opacity: 0.9;
        }

        .auto-save {
            color: var(--success);
        }

        .auto-save.saving {
            color: var(--warning);
        }

        /* Title Section */
        .title-section {
            padding: 2rem;
            border-bottom: 1px solid #e9ecef;
        }

        .story-title {
            border: none;
            font-size: 2rem;
            font-weight: 700;
            color: var(--secondary);
            width: 100%;
            padding: 0;
            margin-bottom: 0.5rem;
            outline: none;
            background: transparent;
        }

        .story-title::placeholder {
            color: #adb5bd;
            font-weight: 400;
        }

        .title-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .title-length {
            font-size: 0.875rem;
            color: #6c757d;
        }

        /* Featured Image Section */
        .featured-image-section {
            padding: 2rem;
            border-bottom: 1px solid #e9ecef;
        }

        .image-upload-area {
            border: 2px dashed #dee2e6;
            border-radius: 10px;
            padding: 3rem;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
            background: #f8f9fa;
        }

        .image-upload-area:hover {
            border-color: var(--primary);
            background: #e3f2fd;
        }

        .image-upload-area i {
            color: #6c757d;
            margin-bottom: 1rem;
        }

        .image-upload-area p {
            margin: 0;
            font-weight: 500;
            color: var(--secondary);
        }

        .image-upload-area small {
            color: #6c757d;
        }

        .image-preview {
            position: relative;
            max-width: 400px;
            margin-top: 1rem;
        }

        .image-preview img {
            width: 100%;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        #removeImage {
            position: absolute;
            top: 10px;
            right: 10px;
            border-radius: 50%;
            width: 30px;
            height: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        /* Excerpt Section */
        .excerpt-section {
            padding: 2rem;
            border-bottom: 1px solid #e9ecef;
        }

        .excerpt-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 0.5rem;
        }

        .excerpt-length {
            font-size: 0.875rem;
            color: #6c757d;
        }

        /* Editor Section */
        .editor-section {
            padding: 0;
        }

        .ql-editor {
            font-size: 1.1rem;
            line-height: 1.6;
            min-height: 500px;
            padding: 2rem;
        }

        .ql-toolbar {
            border: none !important;
            border-bottom: 1px solid #e9ecef !important;
            padding: 1rem 2rem !important;
        }

        /* Metadata Section */
        .metadata-section {
            padding: 2rem;
            background: #f8f9fa;
        }

        /* AI Sidebar */
        .ai-sidebar {
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            padding: 1.5rem;
            height: fit-content;
            position: sticky;
            top: 2rem;
        }

        /* AI Header */
        .ai-header {
            display: flex;
            align-items: center;
            padding-bottom: 1rem;
            border-bottom: 1px solid #e9ecef;
            margin-bottom: 1.5rem;
        }

        .ai-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, var(--primary), var(--info));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 1rem;
            color: white;
        }

        .ai-info {
            flex: 1;
        }

        .ai-info h6 {
            margin: 0;
            font-weight: 600;
        }

        .status {
            font-size: 0.75rem;
            padding: 0.25rem 0.5rem;
            border-radius: 20px;
            background: var(--success);
            color: white;
        }

        .status.online {
            background: var(--success);
        }

        /* Quick Actions */
        .quick-actions {
            margin-bottom: 2rem;
        }

        .quick-actions h6 {
            margin-bottom: 1rem;
            font-weight: 600;
            color: var(--secondary);
        }

        .action-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 0.5rem;
        }

        .action-btn {
            border: 1px solid #e9ecef;
            background: white;
            padding: 0.75rem;
            border-radius: 8px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0.5rem;
        }

        .action-btn:hover {
            border-color: var(--primary);
            background: #e3f2fd;
            transform: translateY(-2px);
        }

        .action-btn i {
            font-size: 1.25rem;
            color: var(--primary);
        }

        .action-btn span {
            font-size: 0.75rem;
            font-weight: 500;
        }

        /* Analysis Section */
        .analysis-section {
            margin-bottom: 2rem;
        }

        .analysis-section h6 {
            margin-bottom: 1rem;
            font-weight: 600;
            color: var(--secondary);
        }

        .analysis-cards {
            display: flex;
            flex-direction: column;
            gap: 0.75rem;
        }

        .analysis-card {
            display: flex;
            align-items: center;
            padding: 1rem;
            background: #f8f9fa;
            border-radius: 8px;
            border-left: 4px solid var(--primary);
        }

        .analysis-icon {
            width: 40px;
            height: 40px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 1rem;
            color: white;
        }

        .analysis-icon.readability {
            background: var(--info);
        }

        .analysis-icon.seo {
            background: var(--success);
        }

        .analysis-icon.engagement {
            background: var(--warning);
        }

        .analysis-info {
            flex: 1;
        }

        .analysis-info .label {
            display: block;
            font-size: 0.75rem;
            color: #6c757d;
            margin-bottom: 0.25rem;
        }

        .analysis-info .value {
            display: block;
            font-weight: 600;
            color: var(--secondary);
        }

        /* Suggestions Section */
        .suggestions-section {
            margin-bottom: 2rem;
        }

        .suggestions-section h6 {
            margin-bottom: 1rem;
            font-weight: 600;
            color: var(--secondary);
        }

        .suggestions-list {
            max-height: 200px;
            overflow-y: auto;
        }

        .suggestion-item {
            display: flex;
            padding: 1rem;
            background: #f8f9fa;
            border-radius: 8px;
            margin-bottom: 0.5rem;
            border-left: 4px solid var(--warning);
        }

        .suggestion-icon {
            margin-right: 1rem;
            color: var(--warning);
        }

        .suggestion-content p {
            margin: 0;
            font-size: 0.875rem;
            line-height: 1.4;
        }

        /* AI Chat Section */
        .ai-chat-section {
            margin-bottom: 2rem;
        }

        .ai-chat-section h6 {
            margin-bottom: 1rem;
            font-weight: 600;
            color: var(--secondary);
        }

        .chat-messages {
            max-height: 200px;
            overflow-y: auto;
            margin-bottom: 1rem;
            padding: 1rem;
            background: #f8f9fa;
            border-radius: 8px;
        }

        .message {
            display: flex;
            margin-bottom: 1rem;
        }

        .message-avatar {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 0.75rem;
            flex-shrink: 0;
        }

        .ai-message .message-avatar {
            background: var(--primary);
            color: white;
        }

        .message-content {
            flex: 1;
        }

        .message-content p {
            margin: 0;
            padding: 0.75rem;
            background: white;
            border-radius: 8px;
            font-size: 0.875rem;
            line-height: 1.4;
        }

        .ai-message .message-content p {
            background: #e3f2fd;
        }

        .chat-input {
            margin-top: 1rem;
        }

        .quick-prompts {
            display: flex;
            flex-wrap: wrap;
            gap: 0.5rem;
            margin-top: 0.5rem;
        }

        .prompt-btn {
            background: white;
            border: 1px solid #e9ecef;
            border-radius: 20px;
            padding: 0.25rem 0.75rem;
            font-size: 0.75rem;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .prompt-btn:hover {
            border-color: var(--primary);
            background: #e3f2fd;
        }

        /* Templates Section */
        .templates-section h6 {
            margin-bottom: 1rem;
            font-weight: 600;
            color: var(--secondary);
        }

        .template-cards {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 0.5rem;
        }

        .template-card {
            border: 1px solid #e9ecef;
            background: white;
            padding: 1rem;
            border-radius: 8px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0.5rem;
        }

        .template-card:hover {
            border-color: var(--primary);
            background: #e3f2fd;
            transform: translateY(-2px);
        }

        .template-card i {
            font-size: 1.5rem;
            color: var(--primary);
        }

        .template-card span {
            font-size: 0.75rem;
            font-weight: 500;
        }

        /* Modal Styles */
        .headline-suggestions {
            min-height: 200px;
        }

        .loading-spinner {
            width: 40px;
            height: 40px;
            border: 4px solid #f3f3f3;
            border-top: 4px solid var(--primary);
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 2rem auto;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .portal-main {
                padding: 1rem;
            }

            .editor-header {
                flex-direction: column;
                gap: 1rem;
                text-align: center;
            }

            .document-info {
                justify-content: center;
            }

            .action-grid,
            .template-cards {
                grid-template-columns: 1fr;
            }

            .ai-sidebar {
                margin-top: 2rem;
            }
        }

        /* Custom Scrollbar */
        .suggestions-list::-webkit-scrollbar,
        .chat-messages::-webkit-scrollbar {
            width: 6px;
        }

        .suggestions-list::-webkit-scrollbar-track,
        .chat-messages::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 3px;
        }

        .suggestions-list::-webkit-scrollbar-thumb,
        .chat-messages::-webkit-scrollbar-thumb {
            background: var(--primary);
            border-radius: 3px;
        }

        /* Toast notifications */
        .toast-container {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
        }
    </style>
</head>
<body class="student-portal story-editor">
    <!-- Toast Notifications -->
    <div class="toast-container"></div>

    <!-- Simple Header -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-hands-helping me-2"></i>
                REACH Student Portal
            </a>
            <div class="navbar-nav ms-auto">
                <span class="navbar-text me-3">
                    Welcome, <?php echo htmlspecialchars($studentName); ?>
                </span>
                <a class="nav-link" href="dashboard.php">Dashboard</a>
                <a class="nav-link" href="stories.php">My Stories</a>
                <a class="nav-link" href="../logout.php">Logout</a>
            </div>
        </div>
    </nav>

    <main class="portal-main">
        <div class="container-fluid">
            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-danger alert-dismissible fade show">
                    <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <div class="row">
                <!-- Main Editor Column -->
                <div class="col-lg-8">
                    <form id="storyForm" method="POST" enctype="multipart/form-data">
                        <div class="editor-container">
                            <!-- Editor Header -->
                            <div class="editor-header">
                                <div class="header-left">
                                    <h4><i class="fas fa-pen-fancy me-2"></i>Story Editor</h4>
                                    <div class="document-info">
                                        <span class="word-count">Words: <strong id="wordCount">0</strong></span>
                                        <span class="read-time">Read time: <strong id="readTime">0 min</strong></span>
                                        <span class="auto-save" id="autoSaveStatus">All changes saved</span>
                                    </div>
                                </div>
                                <div class="header-actions">
                                    <button type="button" class="btn btn-outline-secondary me-2" id="previewBtn">
                                        <i class="fas fa-eye me-1"></i>Preview
                                    </button>
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-outline-primary" id="saveDraftBtn">
                                            <i class="fas fa-save me-1"></i>Save Draft
                                        </button>
                                        <button type="button" class="btn btn-primary" id="publishBtn">
                                            <i class="fas fa-paper-plane me-1"></i>Submit for Review
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <!-- Story Title -->
                            <div class="title-section">
                                <input type="text" class="story-title" id="storyTitle" name="title"
                                       placeholder="Enter your compelling story title..." 
                                       maxlength="120" required>
                                <div class="title-meta">
                                    <span class="title-length" id="titleLength">0/120</span>
                                    <button type="button" class="btn btn-sm btn-outline-info" id="aiHeadlineBtn">
                                        <i class="fas fa-robot me-1"></i>AI Headline Help
                                    </button>
                                </div>
                            </div>

                            <!-- Featured Image -->
                            <div class="featured-image-section">
                                <div class="image-upload-area" id="featuredImageUpload">
                                    <i class="fas fa-camera fa-2x"></i>
                                    <p>Drag & drop featured image or click to browse</p>
                                    <small>Recommended: 1200x630px • JPG, PNG • Max 5MB</small>
                                    <input type="file" id="featuredImageInput" name="featured_image" accept="image/*" hidden>
                                </div>
                                <div class="image-preview" id="imagePreview" style="display: none;">
                                    <img id="previewImage" src="" alt="Preview">
                                    <button type="button" class="btn btn-sm btn-outline-danger" id="removeImage">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                            </div>

                            <!-- Excerpt -->
                            <div class="excerpt-section">
                                <label class="form-label">Story Excerpt</label>
                                <textarea class="form-control" id="storyExcerpt" name="excerpt" rows="3" 
                                          placeholder="Write a brief summary that will appear in story previews..."></textarea>
                                <div class="excerpt-actions">
                                    <span class="excerpt-length" id="excerptLength">0/300</span>
                                    <button type="button" class="btn btn-sm btn-outline-info" id="aiExcerptBtn">
                                        <i class="fas fa-robot me-1"></i>Generate with AI
                                    </button>
                                </div>
                            </div>

                            <!-- Main Editor -->
                            <div class="editor-section">
                                <div id="storyEditor" style="height: 500px;"></div>
                                <textarea name="content" id="storyContent" hidden></textarea>
                            </div>

                            <!-- Story Metadata -->
                            <div class="metadata-section">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label">Story Type</label>
                                            <select class="form-select" id="storyType" name="story_type">
                                                <option value="student">Student Story</option>
                                                <option value="project">Project Story</option>
                                                <option value="achievement">Achievement Story</option>
                                                <option value="community">Community Story</option>
                                                <option value="news">News Update</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label">Tags</label>
                                            <input type="text" class="form-control" id="storyTags" name="tags"
                                                   placeholder="education, scholarship, rwanda, reach">
                                            <div class="form-text">Separate tags with commas</div>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="allowComments" name="allow_comments" checked>
                                    <label class="form-check-label" for="allowComments">
                                        Allow readers to comment on this story
                                    </label>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>

                <!-- AI Assistant Sidebar -->
                <div class="col-lg-4">
                    <div class="ai-sidebar">
                        <!-- AI Assistant Header -->
                        <div class="ai-header">
                            <div class="ai-avatar">
                                <i class="fas fa-robot"></i>
                            </div>
                            <div class="ai-info">
                                <h6>REACH Writing Assistant</h6>
                                <span class="status online">Online</span>
                            </div>
                            <button class="btn btn-sm btn-outline-secondary" id="refreshAI">
                                <i class="fas fa-sync-alt"></i>
                            </button>
                        </div>

                        <!-- Quick AI Actions -->
                        <div class="quick-actions">
                            <h6>Quick AI Help</h6>
                            <div class="action-grid">
                                <button class="action-btn" data-action="improve-intro">
                                    <i class="fas fa-play-circle"></i>
                                    <span>Improve Intro</span>
                                </button>
                                <button class="action-btn" data-action="generate-conclusion">
                                    <i class="fas fa-flag-checkered"></i>
                                    <span>Write Conclusion</span>
                                </button>
                                <button class="action-btn" data-action="add-section">
                                    <i class="fas fa-plus-square"></i>
                                    <span>Add Section</span>
                                </button>
                                <button class="action-btn" data-action="optimize-seo">
                                    <i class="fas fa-search"></i>
                                    <span>SEO Optimize</span>
                                </button>
                                <button class="action-btn" data-action="check-readability">
                                    <i class="fas fa-chart-line"></i>
                                    <span>Readability Check</span>
                                </button>
                                <button class="action-btn" data-action="suggest-tags">
                                    <i class="fas fa-tags"></i>
                                    <span>Suggest Tags</span>
                                </button>
                            </div>
                        </div>

                        <!-- Content Analysis -->
                        <div class="analysis-section">
                            <h6>Content Analysis</h6>
                            <div class="analysis-cards">
                                <div class="analysis-card">
                                    <div class="analysis-icon readability">
                                        <i class="fas fa-book-open"></i>
                                    </div>
                                    <div class="analysis-info">
                                        <span class="label">Readability</span>
                                        <span class="value" id="readabilityScore">-</span>
                                    </div>
                                </div>
                                <div class="analysis-card">
                                    <div class="analysis-icon seo">
                                        <i class="fas fa-search"></i>
                                    </div>
                                    <div class="analysis-info">
                                        <span class="label">SEO Score</span>
                                        <span class="value" id="seoScore">-</span>
                                    </div>
                                </div>
                                <div class="analysis-card">
                                    <div class="analysis-icon engagement">
                                        <i class="fas fa-chart-line"></i>
                                    </div>
                                    <div class="analysis-info">
                                        <span class="label">Engagement</span>
                                        <span class="value" id="engagementScore">-</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- AI Suggestions -->
                        <div class="suggestions-section">
                            <h6>AI Suggestions</h6>
                            <div class="suggestions-list" id="aiSuggestionsList">
                                <div class="suggestion-item">
                                    <div class="suggestion-icon">
                                        <i class="fas fa-lightbulb"></i>
                                    </div>
                                    <div class="suggestion-content">
                                        <p>Start writing to get personalized AI suggestions for your story!</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- AI Chat Interface -->
                        <div class="ai-chat-section">
                            <h6>Ask the Writing Assistant</h6>
                            <div class="chat-messages" id="chatMessages">
                                <div class="message ai-message">
                                    <div class="message-avatar">
                                        <i class="fas fa-robot"></i>
                                    </div>
                                    <div class="message-content">
                                        <p>Hi! I'm your REACH writing assistant. I can help you with headlines, introductions, conclusions, SEO optimization, and more. What would you like help with today?</p>
                                    </div>
                                </div>
                            </div>
                            <div class="chat-input">
                                <div class="input-group">
                                    <input type="text" class="form-control" id="chatInput" 
                                           placeholder="Ask for writing help...">
                                    <button class="btn btn-primary" id="sendMessage">
                                        <i class="fas fa-paper-plane"></i>
                                    </button>
                                </div>
                                <div class="quick-prompts">
                                    <button class="prompt-btn" data-prompt="Help me write a compelling introduction">
                                        Write introduction
                                    </button>
                                    <button class="prompt-btn" data-prompt="Suggest a better headline">
                                        Improve headline
                                    </button>
                                    <button class="prompt-btn" data-prompt="Help me conclude my story">
                                        Write conclusion
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Writing Templates -->
                        <div class="templates-section">
                            <h6>Writing Templates</h6>
                            <div class="template-cards">
                                <div class="template-card" data-template="success-story">
                                    <i class="fas fa-graduation-cap"></i>
                                    <span>Success Story</span>
                                </div>
                                <div class="template-card" data-template="project-showcase">
                                    <i class="fas fa-project-diagram"></i>
                                    <span>Project Showcase</span>
                                </div>
                                <div class="template-card" data-template="personal-journey">
                                    <i class="fas fa-road"></i>
                                    <span>Personal Journey</span>
                                </div>
                                <div class="template-card" data-template="achievement">
                                    <i class="fas fa-trophy"></i>
                                    <span>Achievement Story</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- AI Headline Suggestions Modal -->
    <div class="modal fade" id="headlineModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">AI Headline Suggestions</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="headline-suggestions" id="headlineSuggestions">
                        <div class="loading-spinner"></div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="applyHeadline">Use Selected Headline</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Preview Modal -->
    <div class="modal fade" id="previewModal" tabindex="-1">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Story Preview</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div id="storyPreview"></div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.quilljs.com/1.3.6/quill.min.js"></script>
    <script>
        // Initialize Quill Editor
        const quill = new Quill('#storyEditor', {
            theme: 'snow',
            modules: {
                toolbar: [
                    [{ 'header': [1, 2, 3, 4, 5, 6, false] }],
                    ['bold', 'italic', 'underline', 'strike'],
                    ['blockquote', 'code-block'],
                    [{ 'list': 'ordered'}, { 'list': 'bullet' }],
                    [{ 'script': 'sub'}, { 'script': 'super' }],
                    [{ 'indent': '-1'}, { 'indent': '+1' }],
                    [{ 'direction': 'rtl' }],
                    [{ 'size': ['small', false, 'large', 'huge'] }],
                    [{ 'color': [] }, { 'background': [] }],
                    [{ 'font': [] }],
                    [{ 'align': [] }],
                    ['link', 'image', 'video'],
                    ['clean']
                ]
            },
            placeholder: 'Tell your inspiring story... Share your journey, challenges, achievements, and how REACH Organization made a difference in your life.',
            formats: [
                'header', 'bold', 'italic', 'underline', 'strike', 'blockquote',
                'code-block', 'list', 'bullet', 'script', 'indent', 'direction',
                'size', 'color', 'background', 'font', 'align', 'link', 'image', 'video'
            ]
        });

        // Story Editor Class with Backend Integration
        class StoryEditor {
            constructor(quill) {
                this.quill = quill;
                this.autoSaveInterval = null;
                this.isSaving = false;
                this.init();
            }

            init() {
                this.setupEventListeners();
                this.updateWordCount();
            }

            setupEventListeners() {
                // Title input
                document.getElementById('storyTitle').addEventListener('input', (e) => {
                    this.updateTitleLength(e.target.value.length);
                });

                // Excerpt input
                document.getElementById('storyExcerpt').addEventListener('input', (e) => {
                    this.updateExcerptLength(e.target.value.length);
                });

                // Quill editor changes
                this.quill.on('text-change', () => {
                    this.updateWordCount();
                });

                // Featured image upload
                document.getElementById('featuredImageUpload').addEventListener('click', () => {
                    document.getElementById('featuredImageInput').click();
                });

                document.getElementById('featuredImageInput').addEventListener('change', (e) => {
                    this.handleImageUpload(e.target.files[0]);
                });

                // Remove image
                document.getElementById('removeImage').addEventListener('click', () => {
                    this.removeFeaturedImage();
                });

                // AI Headline button
                document.getElementById('aiHeadlineBtn').addEventListener('click', () => {
                    this.showHeadlineSuggestions();
                });

                // AI Excerpt button
                document.getElementById('aiExcerptBtn').addEventListener('click', () => {
                    this.generateAIExcerpt();
                });

                // Save draft
                document.getElementById('saveDraftBtn').addEventListener('click', () => {
                    this.saveDraft();
                });

                // Publish
                document.getElementById('publishBtn').addEventListener('click', () => {
                    this.submitForReview();
                });

                // Preview
                document.getElementById('previewBtn').addEventListener('click', () => {
                    this.showPreview();
                });

                // Quick AI actions
                document.querySelectorAll('.action-btn').forEach(btn => {
                    btn.addEventListener('click', (e) => {
                        const action = e.currentTarget.dataset.action;
                        this.handleAIAction(action);
                    });
                });

                // AI Chat
                document.getElementById('sendMessage').addEventListener('click', () => {
                    this.sendChatMessage();
                });

                document.getElementById('chatInput').addEventListener('keypress', (e) => {
                    if (e.key === 'Enter') {
                        this.sendChatMessage();
                    }
                });

                // Quick prompts
                document.querySelectorAll('.prompt-btn').forEach(btn => {
                    btn.addEventListener('click', (e) => {
                        document.getElementById('chatInput').value = e.currentTarget.dataset.prompt;
                        this.sendChatMessage();
                    });
                });

                // Templates
                document.querySelectorAll('.template-card').forEach(card => {
                    card.addEventListener('click', (e) => {
                        const template = e.currentTarget.dataset.template;
                        this.loadTemplate(template);
                    });
                });
            }

            updateTitleLength(length) {
                document.getElementById('titleLength').textContent = `${length}/120`;
            }

            updateExcerptLength(length) {
                document.getElementById('excerptLength').textContent = `${length}/300`;
            }

            updateWordCount() {
                const text = this.quill.getText();
                const wordCount = text.trim() === '' ? 0 : text.trim().split(/\s+/).length;
                const readTime = Math.ceil(wordCount / 200); // Average reading speed

                document.getElementById('wordCount').textContent = wordCount;
                document.getElementById('readTime').textContent = `${readTime} min`;
            }

            handleImageUpload(file) {
                if (!file) return;

                if (!file.type.startsWith('image/')) {
                    this.showToast('Please select an image file.', 'error');
                    return;
                }

                if (file.size > 5 * 1024 * 1024) {
                    this.showToast('Image size must be less than 5MB.', 'error');
                    return;
                }

                const reader = new FileReader();
                reader.onload = (e) => {
                    document.getElementById('previewImage').src = e.target.result;
                    document.getElementById('imagePreview').style.display = 'block';
                    document.getElementById('featuredImageUpload').style.display = 'none';
                };
                reader.readAsDataURL(file);
            }

            removeFeaturedImage() {
                document.getElementById('imagePreview').style.display = 'none';
                document.getElementById('featuredImageUpload').style.display = 'block';
                document.getElementById('featuredImageInput').value = '';
            }

            showHeadlineSuggestions() {
                const currentTitle = document.getElementById('storyTitle').value;
                const modal = new bootstrap.Modal(document.getElementById('headlineModal'));
                
                // Simulate AI headline generation
                setTimeout(() => {
                    const suggestions = this.generateHeadlineSuggestions(currentTitle);
                    document.getElementById('headlineSuggestions').innerHTML = suggestions;
                }, 1000);

                modal.show();
            }

            generateHeadlineSuggestions(currentTitle) {
                const baseSuggestions = [
                    "My Journey with REACH: From Dream to Reality",
                    "How REACH Organization Transformed My Education",
                    "Breaking Barriers: My Success Story with REACH Support",
                    "From Challenges to Triumph: A REACH Scholar's Journey",
                    "Empowered by Education: My REACH Experience",
                    "Building a Brighter Future with REACH Organization",
                    "The REACH Effect: How Education Changed My Life",
                    "Against All Odds: My Academic Success with REACH",
                    "A Story of Hope and Opportunity with REACH",
                    "Transforming Lives Through Education: My REACH Story"
                ];

                let suggestionsHTML = '<div class="list-group">';
                baseSuggestions.forEach((suggestion, index) => {
                    suggestionsHTML += `
                        <label class="list-group-item">
                            <input class="form-check-input me-2" type="radio" name="headlineOption" value="${suggestion}">
                            ${suggestion}
                        </label>
                    `;
                });
                suggestionsHTML += '</div>';

                return suggestionsHTML;
            }

            generateAIExcerpt() {
                const content = this.quill.getText().substring(0, 500);
                if (content.length < 50) {
                    this.showToast('Please write more content to generate an excerpt.', 'warning');
                    return;
                }

                // Simulate AI excerpt generation
                const aiExcerpt = this.summarizeContent(content);
                document.getElementById('storyExcerpt').value = aiExcerpt;
                this.updateExcerptLength(aiExcerpt.length);
                this.showToast('AI excerpt generated successfully!', 'success');
            }

            summarizeContent(content) {
                // Simple summarization (in real app, this would call an AI API)
                const sentences = content.split(/[.!?]+/).filter(s => s.trim().length > 0);
                const summary = sentences.slice(0, 2).join('. ') + '.';
                return summary.length > 300 ? summary.substring(0, 297) + '...' : summary;
            }

            async saveDraft() {
                if (!this.validateForm()) return;
                
                this.setLoadingState(true);
                document.getElementById('autoSaveStatus').textContent = 'Saving draft...';
                document.getElementById('autoSaveStatus').className = 'auto-save saving';

                try {
                    const formData = this.prepareFormData('save_draft');
                    const response = await this.submitForm(formData);
                    
                    if (response.success) {
                        this.showToast('Draft saved successfully!', 'success');
                        document.getElementById('autoSaveStatus').textContent = 'Draft saved';
                        document.getElementById('autoSaveStatus').className = 'auto-save';
                    } else {
                        throw new Error(response.message || 'Failed to save draft');
                    }
                } catch (error) {
                    this.showToast(error.message, 'error');
                    document.getElementById('autoSaveStatus').textContent = 'Save failed';
                    document.getElementById('autoSaveStatus').className = 'auto-save text-danger';
                } finally {
                    this.setLoadingState(false);
                }
            }

            async submitForReview() {
                if (!this.validateForm(true)) return;
                
                this.setLoadingState(true);

                try {
                    const formData = this.prepareFormData('submit_review');
                    const response = await this.submitForm(formData);
                    
                    if (response.success) {
                        this.showToast('Story submitted for review successfully!', 'success');
                        setTimeout(() => {
                            window.location.href = 'stories.php';
                        }, 2000);
                    } else {
                        throw new Error(response.message || 'Failed to submit story');
                    }
                } catch (error) {
                    this.showToast(error.message, 'error');
                } finally {
                    this.setLoadingState(false);
                }
            }

            validateForm(requireContent = false) {
                const title = document.getElementById('storyTitle').value.trim();
                const content = this.quill.getText().trim();

                if (!title) {
                    this.showToast('Please enter a story title.', 'error');
                    document.getElementById('storyTitle').focus();
                    return false;
                }

                if (requireContent && (content.length < 100)) {
                    this.showToast('Please write at least 100 characters for your story.', 'error');
                    return false;
                }

                return true;
            }

            prepareFormData(action) {
                const formData = new FormData(document.getElementById('storyForm'));
                formData.append('action', action);
                formData.append('content', this.quill.root.innerHTML);
                return formData;
            }

            async submitForm(formData) {
                const response = await fetch('', {
                    method: 'POST',
                    body: formData
                });
                
                if (!response.ok) {
                    throw new Error('Network error occurred');
                }
                
                // For form submission, we're redirecting, so no JSON response expected
                return { success: true };
            }

            setLoadingState(loading) {
                const buttons = [document.getElementById('saveDraftBtn'), document.getElementById('publishBtn')];
                buttons.forEach(button => {
                    if (button) {
                        button.disabled = loading;
                        if (loading) {
                            button.innerHTML = `<i class="fas fa-spinner fa-spin me-1"></i>${button === document.getElementById('saveDraftBtn') ? 'Saving...' : 'Submitting...'}`;
                        } else {
                            button.innerHTML = `<i class="fas ${button === document.getElementById('saveDraftBtn') ? 'fa-save' : 'fa-paper-plane'} me-1"></i>${button === document.getElementById('saveDraftBtn') ? 'Save Draft' : 'Submit for Review'}`;
                        }
                    }
                });
            }

            showPreview() {
                const storyData = this.getStoryData();
                const previewHTML = this.generatePreviewHTML(storyData);
                document.getElementById('storyPreview').innerHTML = previewHTML;
                
                const modal = new bootstrap.Modal(document.getElementById('previewModal'));
                modal.show();
            }

            getStoryData() {
                return {
                    title: document.getElementById('storyTitle').value,
                    excerpt: document.getElementById('storyExcerpt').value,
                    content: this.quill.root.innerHTML,
                    type: document.getElementById('storyType').value,
                    tags: document.getElementById('storyTags').value,
                    allowComments: document.getElementById('allowComments').checked,
                    featuredImage: document.getElementById('previewImage').src || null
                };
            }

            generatePreviewHTML(storyData) {
                return `
                    <article class="story-preview">
                        <header class="text-center mb-4">
                            <h1>${storyData.title || 'Untitled Story'}</h1>
                            ${storyData.featuredImage ? `<img src="${storyData.featuredImage}" alt="${storyData.title}" class="img-fluid rounded mb-3" style="max-height: 400px; object-fit: cover;">` : ''}
                            <div class="text-muted">
                                <small>By <?php echo htmlspecialchars($studentName); ?> • ${new Date().toLocaleDateString()}</small>
                            </div>
                        </header>
                        ${storyData.excerpt ? `<div class="lead mb-4">${storyData.excerpt}</div>` : ''}
                        <div class="story-content">
                            ${storyData.content || '<p class="text-muted">No content yet...</p>'}
                        </div>
                    </article>
                `;
            }

            showToast(message, type = 'info') {
                const toastContainer = document.querySelector('.toast-container');
                const toast = document.createElement('div');
                toast.className = `toast align-items-center text-bg-${type} border-0`;
                toast.innerHTML = `
                    <div class="d-flex">
                        <div class="toast-body">
                            ${message}
                        </div>
                        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
                    </div>
                `;
                
                toastContainer.appendChild(toast);
                const bsToast = new bootstrap.Toast(toast);
                bsToast.show();
                
                toast.addEventListener('hidden.bs.toast', () => {
                    toast.remove();
                });
            }

            handleAIAction(action) {
                const actions = {
                    'improve-intro': () => this.improveIntroduction(),
                    'generate-conclusion': () => this.generateConclusion(),
                    'add-section': () => this.addSection(),
                    'optimize-seo': () => this.optimizeSEO(),
                    'check-readability': () => this.checkReadability(),
                    'suggest-tags': () => this.suggestTags()
                };

                if (actions[action]) {
                    actions[action]();
                }
            }

            improveIntroduction() {
                const content = this.quill.getText();
                if (content.length < 50) {
                    this.showToast('Please write some content first to improve the introduction.', 'warning');
                    return;
                }

                // Simulate AI improvement
                const improvedIntro = "As I reflect on my journey with REACH Organization, I'm filled with gratitude for the incredible opportunities that have shaped my educational path. What started as a dream has blossomed into a reality beyond my wildest expectations...";
                
                this.quill.insertText(0, improvedIntro + '\n\n');
                this.showToast('AI has improved your introduction!', 'success');
            }

            generateConclusion() {
                const content = this.quill.getText();
                if (content.length < 100) {
                    this.showToast('Please write more content first to generate a conclusion.', 'warning');
                    return;
                }

                // Simulate AI conclusion
                const conclusion = "\n\nIn conclusion, my experience with REACH Organization has been nothing short of transformative. The support, guidance, and opportunities provided have not only changed my educational trajectory but have also instilled in me the confidence to pursue my dreams. I am eternally grateful for this journey and excited to see where it leads next.";
                
                this.quill.insertText(this.quill.getLength(), conclusion);
                this.showToast('AI has generated a conclusion for your story!', 'success');
            }

            addSection() {
                const section = "\n\n## My Key Learnings\n\nThrough this journey, I've gained invaluable insights that have shaped my perspective:\n\n• The importance of perseverance in overcoming challenges\n• How education opens doors to unexpected opportunities\n• The power of community support in achieving goals\n• The value of giving back and paying it forward\n";
                
                this.quill.insertText(this.quill.getLength(), section);
                this.showToast('AI has added a new section to your story!', 'success');
            }

            optimizeSEO() {
                // Simulate SEO optimization
                document.getElementById('readabilityScore').textContent = '85%';
                document.getElementById('seoScore').textContent = '92%';
                document.getElementById('engagementScore').textContent = '78%';
                
                this.showToast('SEO optimization complete! Check the analysis panel for details.', 'success');
            }

            checkReadability() {
                // Simulate readability check
                document.getElementById('readabilityScore').textContent = '78%';
                this.showToast('Readability analysis complete! Your content is well-structured and easy to read.', 'success');
            }

            suggestTags() {
                const suggestedTags = 'education, scholarship, student success, rwanda, reach organization, empowerment';
                document.getElementById('storyTags').value = suggestedTags;
                this.showToast('AI has suggested relevant tags for your story!', 'success');
            }

            sendChatMessage() {
                const input = document.getElementById('chatInput');
                const message = input.value.trim();
                
                if (!message) return;

                // Add user message
                this.addChatMessage('user', message);
                input.value = '';

                // Simulate AI response
                setTimeout(() => {
                    const response = this.generateAIResponse(message);
                    this.addChatMessage('ai', response);
                }, 1000);
            }

            addChatMessage(sender, content) {
                const messagesContainer = document.getElementById('chatMessages');
                const messageDiv = document.createElement('div');
                messageDiv.className = `message ${sender}-message`;
                
                messageDiv.innerHTML = `
                    <div class="message-avatar">
                        <i class="fas fa-${sender === 'user' ? 'user' : 'robot'}"></i>
                    </div>
                    <div class="message-content">
                        <p>${content}</p>
                    </div>
                `;

                messagesContainer.appendChild(messageDiv);
                messagesContainer.scrollTop = messagesContainer.scrollHeight;
            }

            generateAIResponse(message) {
                const responses = {
                    'introduction': "I'd be happy to help with your introduction! A great introduction should hook the reader, introduce your main theme, and give a preview of what's to come. Try starting with a personal anecdote or a powerful statement about your journey.",
                    'headline': "For compelling headlines, focus on emotion, benefit, or curiosity. Good examples: 'How REACH Changed My Life Forever' or 'From Struggles to Success: My REACH Journey'. Make it specific and engaging!",
                    'conclusion': "A strong conclusion should summarize your key points, reflect on your journey's significance, and leave the reader with a lasting impression or call to action. Consider ending with your future aspirations.",
                    'default': "I understand you're looking for help with your writing. I can assist with introductions, conclusions, SEO optimization, readability improvements, and more. Could you be more specific about what you'd like me to help with?"
                };

                const lowerMessage = message.toLowerCase();
                
                if (lowerMessage.includes('introduction') || lowerMessage.includes('intro')) {
                    return responses.introduction;
                } else if (lowerMessage.includes('headline') || lowerMessage.includes('title')) {
                    return responses.headline;
                } else if (lowerMessage.includes('conclusion') || lowerMessage.includes('ending')) {
                    return responses.conclusion;
                } else {
                    return responses.default;
                }
            }

            loadTemplate(template) {
                const templates = {
                    'success-story': {
                        title: "My Success Story with REACH Organization",
                        content: "<h2>The Beginning of My Journey</h2><p>When I first learned about REACH Organization, I never imagined how profoundly it would impact my life...</p><h2>Overcoming Challenges</h2><p>The path wasn't always easy, but with REACH's support, I overcame numerous obstacles...</p><h2>Achieving My Dreams</h2><p>Today, I stand as a testament to what's possible when opportunity meets determination...</p>",
                        excerpt: "A heartfelt account of my transformative journey with REACH Organization, from challenges to remarkable achievements."
                    },
                    'project-showcase': {
                        title: "Transforming Communities: My REACH Project Experience",
                        content: "<h2>Project Overview</h2><p>Our project aimed to address critical needs in our community through innovative solutions...</p><h2>Implementation Journey</h2><p>From planning to execution, every step taught us valuable lessons about teamwork and impact...</p><h2>Measurable Impact</h2><p>The results exceeded our expectations, creating lasting change in our community...</p>",
                        excerpt: "An inside look at how our REACH-supported project created meaningful change and valuable learning experiences."
                    }
                };

                if (templates[template]) {
                    const selected = templates[template];
                    document.getElementById('storyTitle').value = selected.title;
                    this.quill.root.innerHTML = selected.content;
                    document.getElementById('storyExcerpt').value = selected.excerpt;
                    
                    this.updateTitleLength(selected.title.length);
                    this.updateExcerptLength(selected.excerpt.length);
                    this.updateWordCount();
                    
                    this.showToast(`"${selected.title}" template loaded! Customize it to tell your unique story.`, 'success');
                }
            }
        }

        // Initialize the story editor
        const storyEditor = new StoryEditor(quill);

        // Apply headline selection
        document.getElementById('applyHeadline').addEventListener('click', () => {
            const selected = document.querySelector('input[name="headlineOption"]:checked');
            if (selected) {
                document.getElementById('storyTitle').value = selected.value;
                storyEditor.updateTitleLength(selected.value.length);
                bootstrap.Modal.getInstance(document.getElementById('headlineModal')).hide();
                storyEditor.showToast('Headline applied successfully!', 'success');
            } else {
                storyEditor.showToast('Please select a headline suggestion.', 'warning');
            }
        });

        // Drag and drop for image upload
        const uploadArea = document.getElementById('featuredImageUpload');
        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            uploadArea.addEventListener(eventName, preventDefaults, false);
        });

        function preventDefaults(e) {
            e.preventDefault();
            e.stopPropagation();
        }

        ['dragenter', 'dragover'].forEach(eventName => {
            uploadArea.addEventListener(eventName, highlight, false);
        });

        ['dragleave', 'drop'].forEach(eventName => {
            uploadArea.addEventListener(eventName, unhighlight, false);
        });

        function highlight() {
            uploadArea.style.borderColor = '#3498db';
            uploadArea.style.background = '#e3f2fd';
        }

        function unhighlight() {
            uploadArea.style.borderColor = '#dee2e6';
            uploadArea.style.background = '#f8f9fa';
        }

        uploadArea.addEventListener('drop', handleDrop, false);

        function handleDrop(e) {
            const dt = e.dataTransfer;
            const files = dt.files;
            storyEditor.handleImageUpload(files[0]);
        }
    </script>
</body>
</html>