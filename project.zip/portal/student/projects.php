<?php
session_start();
require_once '../../includes/config.php';
require_once '../../includes/database.php';
require_once '../../includes/classes/ProjectManager.php';

// Check if user is logged in and is a student
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'student') {
    header('Location: ../../login.php');
    exit;
}

$projectManager = new ProjectManager($pdo);
$studentId = $_SESSION['user_id'];

// Get filters
$statusFilter = $_GET['status'] ?? 'all';
$typeFilter = $_GET['type'] ?? 'all';
$searchQuery = $_GET['search'] ?? '';
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$perPage = 9;
$offset = ($page - 1) * $perPage;

// Build filters
$filters = [];
if ($statusFilter !== 'all') {
    $filters['status'] = $statusFilter;
}
if ($typeFilter !== 'all') {
    $filters['project_type'] = $typeFilter;
}
if (!empty($searchQuery)) {
    $filters['search'] = $searchQuery;
}

// Get student's projects and statistics
$projects = $projectManager->getStudentProjects($studentId, $filters, $perPage, $offset);
$totalProjects = $projectManager->getTotalProjects(array_merge($filters, ['student_id' => $studentId]));
$totalPages = ceil($totalProjects / $perPage);
$stats = $projectManager->getStudentProjectStats($studentId);

function getStatusColor($status) {
    switch ($status) {
        case 'active': return 'success';
        case 'completed': return 'primary';
        case 'planning': return 'warning';
        case 'cancelled': return 'danger';
        default: return 'secondary';
    }
}

function getStatusIcon($status) {
    switch ($status) {
        case 'active': return 'fa-play-circle';
        case 'completed': return 'fa-check-circle';
        case 'planning': return 'fa-clock';
        case 'cancelled': return 'fa-times-circle';
        default: return 'fa-folder';
    }
}

function getTypeColor($type) {
    switch ($type) {
        case 'academic': return 'info';
        case 'community': return 'success';
        case 'research': return 'warning';
        case 'entrepreneurial': return 'primary';
        default: return 'secondary';
    }
}

function formatBudget($budget) {
    if ($budget === null || $budget == 0) return 'Not set';
    return '$' . number_format($budget, 2);
}

function getProgressPercentage($startDate, $endDate, $status) {
    if ($status === 'completed') return 100;
    if ($status === 'cancelled' || $status === 'planning') return 0;
    
    if ($startDate && $endDate) {
        $start = new DateTime($startDate);
        $end = new DateTime($endDate);
        $now = new DateTime();
        
        if ($now < $start) return 0;
        if ($now > $end) return 100;
        
        $total = $end->getTimestamp() - $start->getTimestamp();
        $passed = $now->getTimestamp() - $start->getTimestamp();
        
        return min(100, max(0, round(($passed / $total) * 100)));
    }
    
    return 0;
}

// Handle null values in stats
$stats = array_merge([
    'total' => 0,
    'active' => 0,
    'completed' => 0,
    'planning' => 0,
    'cancelled' => 0,
    'featured' => 0,
    'total_budget' => 0,
    'total_views' => 0
], $stats ?? []);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Projects - REACH Student Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .stat-card {
            transition: transform 0.2s;
            border: none;
            border-radius: 10px;
        }
        .stat-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .project-card {
            transition: all 0.3s ease;
            border: none;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
        }
        .project-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }
        .progress {
            height: 8px;
            border-radius: 4px;
        }
        .status-badge {
            font-size: 0.75rem;
        }
        .type-badge {
            font-size: 0.7rem;
        }
        .featured-badge {
            position: absolute;
            top: 10px;
            right: 10px;
            z-index: 1;
        }
        .project-image {
            height: 200px;
            object-fit: cover;
            border-radius: 12px 12px 0 0;
        }
        .card-body {
            padding: 1.5rem;
        }
        .deliverable-stats {
            font-size: 0.8rem;
        }
    </style>
</head>
<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-hands-helping me-2"></i>
                REACH Student Portal
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="dashboard.php">Dashboard</a>
                <a class="nav-link" href="stories.php">My Stories</a>
                <a class="nav-link active" href="projects.php">My Projects</a>
                <a class="nav-link" href="../logout.php">Logout</a>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <!-- Header -->
        <div class="row mb-4">
            <div class="col">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h1><i class="fas fa-rocket me-2"></i>My Projects</h1>
                        <p class="text-muted">Manage and track your academic and community projects</p>
                    </div>
                    <a href="create-project.php" class="btn btn-primary">
                        <i class="fas fa-plus me-2"></i>Start New Project
                    </a>
                </div>
            </div>
        </div>

        <!-- Statistics -->
        <div class="row mb-4">
            <div class="col-xl-2 col-md-4 col-6 mb-3">
                <div class="stat-card card bg-primary text-white">
                    <div class="card-body text-center">
                        <h3><?php echo $stats['total']; ?></h3>
                        <p class="mb-0">Total Projects</p>
                    </div>
                </div>
            </div>
            <div class="col-xl-2 col-md-4 col-6 mb-3">
                <div class="stat-card card bg-success text-white">
                    <div class="card-body text-center">
                        <h3><?php echo $stats['active']; ?></h3>
                        <p class="mb-0">Active</p>
                    </div>
                </div>
            </div>
            <div class="col-xl-2 col-md-4 col-6 mb-3">
                <div class="stat-card card bg-info text-white">
                    <div class="card-body text-center">
                        <h3><?php echo $stats['completed']; ?></h3>
                        <p class="mb-0">Completed</p>
                    </div>
                </div>
            </div>
            <div class="col-xl-2 col-md-4 col-6 mb-3">
                <div class="stat-card card bg-warning text-dark">
                    <div class="card-body text-center">
                        <h3><?php echo $stats['planning']; ?></h3>
                        <p class="mb-0">Planning</p>
                    </div>
                </div>
            </div>
            <div class="col-xl-2 col-md-4 col-6 mb-3">
                <div class="stat-card card bg-secondary text-white">
                    <div class="card-body text-center">
                        <h3><?php echo formatBudget($stats['total_budget']); ?></h3>
                        <p class="mb-0">Total Budget</p>
                    </div>
                </div>
            </div>
            <div class="col-xl-2 col-md-4 col-6 mb-3">
                <div class="stat-card card bg-dark text-white">
                    <div class="card-body text-center">
                        <h3><?php echo $stats['featured']; ?></h3>
                        <p class="mb-0">Featured</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Filters -->
        <div class="card mb-4">
            <div class="card-body">
                <form method="GET" class="row g-3">
                    <div class="col-md-3">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-select">
                            <option value="all" <?php echo $statusFilter === 'all' ? 'selected' : ''; ?>>All Statuses</option>
                            <option value="planning" <?php echo $statusFilter === 'planning' ? 'selected' : ''; ?>>Planning</option>
                            <option value="active" <?php echo $statusFilter === 'active' ? 'selected' : ''; ?>>Active</option>
                            <option value="completed" <?php echo $statusFilter === 'completed' ? 'selected' : ''; ?>>Completed</option>
                            <option value="cancelled" <?php echo $statusFilter === 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Project Type</label>
                        <select name="type" class="form-select">
                            <option value="all" <?php echo $typeFilter === 'all' ? 'selected' : ''; ?>>All Types</option>
                            <option value="academic" <?php echo $typeFilter === 'academic' ? 'selected' : ''; ?>>Academic</option>
                            <option value="community" <?php echo $typeFilter === 'community' ? 'selected' : ''; ?>>Community</option>
                            <option value="research" <?php echo $typeFilter === 'research' ? 'selected' : ''; ?>>Research</option>
                            <option value="entrepreneurial" <?php echo $typeFilter === 'entrepreneurial' ? 'selected' : ''; ?>>Entrepreneurial</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Search Projects</label>
                        <input type="text" name="search" class="form-control" placeholder="Search by title or description..." value="<?php echo htmlspecialchars($searchQuery); ?>">
                    </div>
                    <div class="col-md-2 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-filter me-2"></i>Filter
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Projects Grid -->
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">My Projects (<?php echo $totalProjects; ?>)</h5>
                <div class="text-muted small">
                    Page <?php echo $page; ?> of <?php echo $totalPages; ?>
                </div>
            </div>
            <div class="card-body">
                <?php if (empty($projects)): ?>
                    <div class="text-center py-5">
                        <i class="fas fa-rocket fa-4x text-muted mb-3"></i>
                        <h4>No Projects Found</h4>
                        <p class="text-muted mb-4"><?php echo empty($filters) ? 'You haven\'t created any projects yet.' : 'No projects match your filters.'; ?></p>
                        <?php if (empty($filters)): ?>
                            <a href="create-project.php" class="btn btn-primary">
                                <i class="fas fa-plus me-2"></i>Start Your First Project
                            </a>
                        <?php else: ?>
                            <a href="projects.php" class="btn btn-outline-primary">
                                <i class="fas fa-times me-2"></i>Clear Filters
                            </a>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <div class="row">
                        <?php foreach ($projects as $project): 
                            $progress = getProgressPercentage($project['start_date'], $project['end_date'], $project['status']);
                            $deliverableCount = $project['deliverable_count'] ?? 0;
                            $approvedDeliverables = $project['approved_deliverables'] ?? 0;
                        ?>
                        <div class="col-lg-4 col-md-6 mb-4">
                            <div class="card project-card h-100">
                                <?php if ($project['featured']): ?>
                                    <span class="featured-badge badge bg-warning text-dark">
                                        <i class="fas fa-star me-1"></i>Featured
                                    </span>
                                <?php endif; ?>
                                
                                <?php if ($project['featured_image']): ?>
                                    <img src="../../uploads/projects/<?php echo htmlspecialchars($project['featured_image']); ?>" 
                                         class="card-img-top project-image" 
                                         alt="<?php echo htmlspecialchars($project['title']); ?>"
                                         onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                                    <div class="project-image bg-light d-flex align-items-center justify-content-center" style="display: none;">
                                        <i class="fas fa-project-diagram fa-3x text-muted"></i>
                                    </div>
                                <?php else: ?>
                                    <div class="project-image bg-light d-flex align-items-center justify-content-center">
                                        <i class="fas fa-project-diagram fa-3x text-muted"></i>
                                    </div>
                                <?php endif; ?>
                                
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-start mb-2">
                                        <h5 class="card-title"><?php echo htmlspecialchars($project['title']); ?></h5>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <span class="badge bg-<?php echo getTypeColor($project['project_type']); ?> type-badge me-1">
                                            <?php echo ucfirst($project['project_type']); ?>
                                        </span>
                                        <span class="badge bg-<?php echo getStatusColor($project['status']); ?> status-badge">
                                            <i class="fas <?php echo getStatusIcon($project['status']); ?> me-1"></i>
                                            <?php echo ucfirst($project['status']); ?>
                                        </span>
                                    </div>
                                    
                                    <?php if (!empty($project['description'])): ?>
                                        <p class="card-text text-muted small"><?php echo htmlspecialchars(substr($project['description'], 0, 100)); ?>...</p>
                                    <?php endif; ?>
                                    
                                    <!-- Deliverables Stats -->
                                    <?php if ($deliverableCount > 0): ?>
                                        <div class="deliverable-stats mb-3">
                                            <small class="text-muted">
                                                <i class="fas fa-tasks me-1"></i>
                                                Deliverables: <?php echo $approvedDeliverables; ?>/<?php echo $deliverableCount; ?> approved
                                            </small>
                                            <div class="progress mt-1" style="height: 4px;">
                                                <div class="progress-bar bg-success" 
                                                     role="progressbar" 
                                                     style="width: <?php echo $deliverableCount > 0 ? ($approvedDeliverables / $deliverableCount) * 100 : 0; ?>%"
                                                     aria-valuenow="<?php echo $approvedDeliverables; ?>" 
                                                     aria-valuemin="0" 
                                                     aria-valuemax="<?php echo $deliverableCount; ?>">
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <!-- Progress Bar -->
                                    <?php if ($project['status'] === 'active' || $project['status'] === 'completed'): ?>
                                        <div class="mb-3">
                                            <div class="d-flex justify-content-between small text-muted mb-1">
                                                <span>Progress</span>
                                                <span><?php echo $progress; ?>%</span>
                                            </div>
                                            <div class="progress">
                                                <div class="progress-bar bg-<?php echo getStatusColor($project['status']); ?>" 
                                                     role="progressbar" 
                                                     style="width: <?php echo $progress; ?>%"
                                                     aria-valuenow="<?php echo $progress; ?>" 
                                                     aria-valuemin="0" 
                                                     aria-valuemax="100">
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <!-- Project Meta -->
                                    <div class="project-meta">
                                        <div class="row small text-muted">
                                            <?php if ($project['start_date']): ?>
                                                <div class="col-6">
                                                    <i class="fas fa-calendar-start me-1"></i>
                                                    <?php echo date('M Y', strtotime($project['start_date'])); ?>
                                                </div>
                                            <?php endif; ?>
                                            <?php if ($project['budget'] && $project['budget'] > 0): ?>
                                                <div class="col-6 text-end">
                                                    <i class="fas fa-dollar-sign me-1"></i>
                                                    <?php echo formatBudget($project['budget']); ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="row small text-muted mt-1">
                                            <div class="col-6">
                                                <i class="fas fa-eye me-1"></i>
                                                <?php echo $project['view_count'] ?? 0; ?> views
                                            </div>
                                            <?php if ($project['supervisor_name']): ?>
                                                <div class="col-6 text-end" title="Supervisor: <?php echo htmlspecialchars($project['supervisor_name']); ?>">
                                                    <i class="fas fa-user-tie me-1"></i>
                                                    Supervised
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="card-footer bg-transparent">
                                    <div class="btn-group w-100">
                                        <a href="view-project.php?id=<?php echo $project['id']; ?>" 
                                           class="btn btn-outline-primary btn-sm">
                                            <i class="fas fa-eye me-1"></i>View
                                        </a>
                                        <a href="edit-project.php?id=<?php echo $project['id']; ?>" 
                                           class="btn btn-outline-warning btn-sm">
                                            <i class="fas fa-edit me-1"></i>Edit
                                        </a>
                                        <button class="btn btn-outline-danger btn-sm delete-project" 
                                                data-project-id="<?php echo $project['id']; ?>"
                                                data-project-title="<?php echo htmlspecialchars($project['title']); ?>">
                                            <i class="fas fa-trash me-1"></i>Delete
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>

                    <!-- Pagination -->
                    <?php if ($totalPages > 1): ?>
                    <nav aria-label="Projects pagination" class="mt-4">
                        <ul class="pagination justify-content-center">
                            <?php if ($page > 1): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page - 1])); ?>">
                                        <i class="fas fa-chevron-left me-1"></i> Previous
                                    </a>
                                </li>
                            <?php endif; ?>
                            
                            <?php 
                            $startPage = max(1, $page - 2);
                            $endPage = min($totalPages, $page + 2);
                            
                            for ($i = $startPage; $i <= $endPage; $i++): ?>
                                <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                    <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $i])); ?>">
                                        <?php echo $i; ?>
                                    </a>
                                </li>
                            <?php endfor; ?>
                            
                            <?php if ($page < $totalPages): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page + 1])); ?>">
                                        Next <i class="fas fa-chevron-right ms-1"></i>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Delete project confirmation
        document.querySelectorAll('.delete-project').forEach(button => {
            button.addEventListener('click', function() {
                const projectId = this.dataset.projectId;
                const projectTitle = this.dataset.projectTitle;
                
                if (confirm(`Are you sure you want to delete "${projectTitle}"? This action cannot be undone.`)) {
                    fetch('delete-project.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({ project_id: projectId })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            location.reload();
                        } else {
                            alert('Error: ' + data.message);
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('An error occurred while deleting the project.');
                    });
                }
            });
        });

        // Image error handling
        document.querySelectorAll('.project-image').forEach(img => {
            img.addEventListener('error', function() {
                this.style.display = 'none';
                const fallback = this.nextElementSibling;
                if (fallback && fallback.classList.contains('project-image')) {
                    fallback.style.display = 'flex';
                }
            });
        });
    </script>
</body>
</html>