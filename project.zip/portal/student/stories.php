<?php
session_start();
require_once '../../includes/config.php';
require_once '../../includes/database.php';
require_once '../../includes/classes/StoryManager.php';

// Check if user is logged in and is a student
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'student') {
    header('Location: ../../login.php');
    exit;
}

$storyManager = new StoryManager($pdo);
$studentId = $_SESSION['user_id'];

// Get filters
$statusFilter = $_GET['status'] ?? 'all';
$searchQuery = $_GET['search'] ?? '';
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$perPage = 10;
$offset = ($page - 1) * $perPage;

// Build filters
$filters = [];
if ($statusFilter !== 'all') {
    $filters['status'] = $statusFilter;
}
if (!empty($searchQuery)) {
    $filters['search'] = $searchQuery;
}

// Get student's stories and statistics
$stories = $storyManager->getStudentStories($studentId, $filters, $perPage, $offset);
$totalStories = $storyManager->getTotalStories(array_merge($filters, ['author_id' => $studentId]));
$totalPages = ceil($totalStories / $perPage);
$stats = $storyManager->getStudentStoryStats($studentId);

function getStatusColor($status) {
    switch ($status) {
        case 'published': return 'success';
        case 'draft': return 'secondary';
        case 'pending': return 'warning';
        case 'rejected': return 'danger';
        default: return 'light';
    }
}

function getStatusIcon($status) {
    switch ($status) {
        case 'published': return 'fa-check-circle';
        case 'draft': return 'fa-edit';
        case 'pending': return 'fa-clock';
        case 'rejected': return 'fa-times-circle';
        default: return 'fa-file';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Stories - REACH Student Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .stat-card {
            transition: transform 0.2s;
        }
        .stat-card:hover {
            transform: translateY(-2px);
        }
        .story-card {
            border-left: 4px solid;
            transition: all 0.3s ease;
        }
        .story-card:hover {
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        .status-published { border-left-color: #28a745; }
        .status-draft { border-left-color: #6c757d; }
        .status-pending { border-left-color: #ffc107; }
        .status-rejected { border-left-color: #dc3545; }
    </style>
</head>
<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-hands-helping me-2"></i>
                REACH Student Portal
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="dashboard.php">Dashboard</a>
                <a class="nav-link active" href="stories.php">My Stories</a>
                <a class="nav-link" href="../logout.php">Logout</a>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <!-- Header -->
        <div class="row mb-4">
            <div class="col">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h1><i class="fas fa-book-open me-2"></i>My Stories</h1>
                        <p class="text-muted">Manage and track your published stories</p>
                    </div>
                    <a href="create-story.php" class="btn btn-primary">
                        <i class="fas fa-plus me-2"></i>Write New Story
                    </a>
                </div>
            </div>
        </div>

        <!-- Statistics -->
        <div class="row mb-4">
            <div class="col-xl-2 col-md-4 col-6 mb-3">
                <div class="stat-card card border-0 bg-primary text-white">
                    <div class="card-body text-center">
                        <h3><?php echo $stats['total']; ?></h3>
                        <p class="mb-0">Total Stories</p>
                    </div>
                </div>
            </div>
            <div class="col-xl-2 col-md-4 col-6 mb-3">
                <div class="stat-card card border-0 bg-success text-white">
                    <div class="card-body text-center">
                        <h3><?php echo $stats['published']; ?></h3>
                        <p class="mb-0">Published</p>
                    </div>
                </div>
            </div>
            <div class="col-xl-2 col-md-4 col-6 mb-3">
                <div class="stat-card card border-0 bg-warning text-dark">
                    <div class="card-body text-center">
                        <h3><?php echo $stats['pending']; ?></h3>
                        <p class="mb-0">Pending</p>
                    </div>
                </div>
            </div>
            <div class="col-xl-2 col-md-4 col-6 mb-3">
                <div class="stat-card card border-0 bg-info text-white">
                    <div class="card-body text-center">
                        <h3><?php echo $stats['total_views']; ?></h3>
                        <p class="mb-0">Total Views</p>
                    </div>
                </div>
            </div>
            <div class="col-xl-2 col-md-4 col-6 mb-3">
                <div class="stat-card card border-0 bg-secondary text-white">
                    <div class="card-body text-center">
                        <h3><?php echo $stats['total_comments']; ?></h3>
                        <p class="mb-0">Comments</p>
                    </div>
                </div>
            </div>
            <div class="col-xl-2 col-md-4 col-6 mb-3">
                <div class="stat-card card border-0 bg-dark text-white">
                    <div class="card-body text-center">
                        <h3><?php echo $stats['total_likes']; ?></h3>
                        <p class="mb-0">Likes</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Filters -->
        <div class="card mb-4">
            <div class="card-body">
                <form method="GET" class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-select">
                            <option value="all" <?php echo $statusFilter === 'all' ? 'selected' : ''; ?>>All Statuses</option>
                            <option value="published" <?php echo $statusFilter === 'published' ? 'selected' : ''; ?>>Published</option>
                            <option value="draft" <?php echo $statusFilter === 'draft' ? 'selected' : ''; ?>>Draft</option>
                            <option value="pending" <?php echo $statusFilter === 'pending' ? 'selected' : ''; ?>>Pending Review</option>
                            <option value="rejected" <?php echo $statusFilter === 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Search Stories</label>
                        <input type="text" name="search" class="form-control" placeholder="Search by title or content..." value="<?php echo htmlspecialchars($searchQuery); ?>">
                    </div>
                    <div class="col-md-2 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-filter me-2"></i>Filter
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Stories List -->
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">My Stories (<?php echo $totalStories; ?>)</h5>
                <div class="text-muted small">
                    Page <?php echo $page; ?> of <?php echo $totalPages; ?>
                </div>
            </div>
            <div class="card-body">
                <?php if (empty($stories)): ?>
                    <div class="text-center py-5">
                        <i class="fas fa-book-open fa-4x text-muted mb-3"></i>
                        <h4>No Stories Found</h4>
                        <p class="text-muted mb-4"><?php echo empty($filters) ? 'You haven\'t written any stories yet.' : 'No stories match your filters.'; ?></p>
                        <?php if (empty($filters)): ?>
                            <a href="create-story.php" class="btn btn-primary">
                                <i class="fas fa-plus me-2"></i>Write Your First Story
                            </a>
                        <?php else: ?>
                            <a href="stories.php" class="btn btn-outline-primary">
                                <i class="fas fa-times me-2"></i>Clear Filters
                            </a>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <div class="row">
                        <?php foreach ($stories as $story): ?>
                        <div class="col-lg-6 mb-4">
                            <div class="card story-card h-100 status-<?php echo $story['status']; ?>">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-start mb-2">
                                        <h5 class="card-title"><?php echo htmlspecialchars($story['title']); ?></h5>
                                        <span class="badge bg-<?php echo getStatusColor($story['status']); ?>">
                                            <i class="fas <?php echo getStatusIcon($story['status']); ?> me-1"></i>
                                            <?php echo ucfirst($story['status']); ?>
                                        </span>
                                    </div>
                                    
                                    <?php if (!empty($story['excerpt'])): ?>
                                        <p class="card-text text-muted"><?php echo htmlspecialchars(substr($story['excerpt'], 0, 150)); ?>...</p>
                                    <?php endif; ?>
                                    
                                    <div class="story-meta d-flex justify-content-between align-items-center mt-3">
                                        <div class="text-muted small">
                                            <i class="fas fa-calendar me-1"></i>
                                            <?php echo date('M j, Y', strtotime($story['created_at'])); ?>
                                        </div>
                                        <div class="story-stats">
                                            <span class="badge bg-light text-dark me-1">
                                                <i class="fas fa-eye me-1"></i><?php echo $story['view_count']; ?>
                                            </span>
                                            <span class="badge bg-light text-dark me-1">
                                                <i class="fas fa-comment me-1"></i><?php echo $story['comment_count']; ?>
                                            </span>
                                            <span class="badge bg-light text-dark">
                                                <i class="fas fa-heart me-1"></i><?php echo $story['like_count']; ?>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-footer bg-transparent">
                                    <div class="btn-group w-100">
                                        <?php if ($story['status'] === 'published'): ?>
                                            <a href="../story.php?slug=<?php echo urlencode($story['slug']); ?>" 
                                               class="btn btn-outline-primary btn-sm" target="_blank">
                                                <i class="fas fa-external-link-alt me-1"></i>View
                                            </a>
                                        <?php endif; ?>
                                        <a href="edit-story.php?id=<?php echo $story['id']; ?>" 
                                           class="btn btn-outline-warning btn-sm">
                                            <i class="fas fa-edit me-1"></i>Edit
                                        </a>
                                        <button class="btn btn-outline-danger btn-sm delete-story" 
                                                data-story-id="<?php echo $story['id']; ?>"
                                                data-story-title="<?php echo htmlspecialchars($story['title']); ?>">
                                            <i class="fas fa-trash me-1"></i>Delete
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>

                    <!-- Pagination -->
                    <?php if ($totalPages > 1): ?>
                    <nav aria-label="Stories pagination" class="mt-4">
                        <ul class="pagination justify-content-center">
                            <?php if ($page > 1): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page - 1])); ?>">
                                        <i class="fas fa-chevron-left me-1"></i> Previous
                                    </a>
                                </li>
                            <?php endif; ?>
                            
                            <?php 
                            $startPage = max(1, $page - 2);
                            $endPage = min($totalPages, $page + 2);
                            
                            for ($i = $startPage; $i <= $endPage; $i++): ?>
                                <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                    <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $i])); ?>">
                                        <?php echo $i; ?>
                                    </a>
                                </li>
                            <?php endfor; ?>
                            
                            <?php if ($page < $totalPages): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page + 1])); ?>">
                                        Next <i class="fas fa-chevron-right ms-1"></i>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Delete story confirmation
        document.querySelectorAll('.delete-story').forEach(button => {
            button.addEventListener('click', function() {
                const storyId = this.dataset.storyId;
                const storyTitle = this.dataset.storyTitle;
                
                if (confirm(`Are you sure you want to delete "${storyTitle}"? This action cannot be undone.`)) {
                    fetch('delete-story.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({ story_id: storyId })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            location.reload();
                        } else {
                            alert('Error: ' + data.message);
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('An error occurred while deleting the story.');
                    });
                }
            });
        });
    </script>
</body>
</html>