<?php
session_start();
require_once '../../includes/config.php';
require_once '../../includes/auth.php';
$auth->checkRole(['student']);

// Student Profile Class
class StudentProfile {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    public function getStudentProfile($userId) {
        try {
            // Try to get from student_profiles table first
            $sql = "SELECT 
                sp.*, 
                u.email as primary_email,
                u.phone as primary_phone,
                u.profile_picture as user_profile_picture
            FROM student_profiles sp
            JOIN users u ON sp.user_id = u.id
            WHERE sp.user_id = ?";
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$userId]);
            $profile = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($profile) {
                return $profile;
            }
        } catch (PDOException $e) {
            // Table might not exist, fall back to users table
        }
        
        // Fallback to users table
        $sql = "SELECT 
            id as user_id,
            full_name,
            email as primary_email,
            phone as primary_phone,
            profile_picture as user_profile_picture,
            NULL as student_id,
            NULL as university,
            NULL as program,
            NULL as year_of_study,
            NULL as expected_graduation,
            NULL as current_gpa,
            NULL as program_type,
            NULL as scholarship_type,
            NULL as bio,
            NULL as address,
            NULL as city,
            NULL as country
        FROM users 
        WHERE id = ? AND role = 'student'";
        
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$userId]);
        $profile = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Add default values
        if ($profile) {
            $profile['student_id'] = $profile['student_id'] ?? 'STU' . date('Y') . str_pad($userId, 4, '0', STR_PAD_LEFT);
            $profile['university'] = $profile['university'] ?? 'University of Rwanda';
            $profile['program'] = $profile['program'] ?? 'Computer Science';
            $profile['year_of_study'] = $profile['year_of_study'] ?? 2;
            $profile['expected_graduation'] = $profile['expected_graduation'] ?? '2026';
            $profile['current_gpa'] = $profile['current_gpa'] ?? '3.75';
            $profile['program_type'] = $profile['program_type'] ?? 'scholarship';
            $profile['scholarship_type'] = $profile['scholarship_type'] ?? 'Full Tuition Scholarship';
            $profile['bio'] = $profile['bio'] ?? 'Dedicated student passionate about technology and community development.';
        }
        
        return $profile ?: [];
    }
    
    public function updateStudentProfile($userId, $data) {
        try {
            // Check if profile exists
            $checkSql = "SELECT id FROM student_profiles WHERE user_id = ?";
            $checkStmt = $this->pdo->prepare($checkSql);
            $checkStmt->execute([$userId]);
            $exists = $checkStmt->fetch();
            
            if ($exists) {
                // Update existing profile
                $sql = "UPDATE student_profiles SET 
                    full_name = ?, phone = ?, email = ?, university = ?, program = ?,
                    year_of_study = ?, expected_graduation = ?, current_gpa = ?, bio = ?,
                    address = ?, city = ?, country = ?, interests = ?, skills = ?, career_goals = ?,
                    updated_at = CURRENT_TIMESTAMP
                    WHERE user_id = ?";
                
                $stmt = $this->pdo->prepare($sql);
                return $stmt->execute([
                    $data['full_name'], $data['phone'], $data['email'], $data['university'], $data['program'],
                    $data['year_of_study'], $data['expected_graduation'], $data['current_gpa'], $data['bio'],
                    $data['address'], $data['city'], $data['country'], $data['interests'], $data['skills'], $data['career_goals'],
                    $userId
                ]);
            } else {
                // Insert new profile
                $sql = "INSERT INTO student_profiles (
                    user_id, student_id, full_name, phone, email, university, program,
                    year_of_study, expected_graduation, current_gpa, bio, address, city, country,
                    interests, skills, career_goals, program_type, scholarship_type, enrollment_date
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                
                $stmt = $this->pdo->prepare($sql);
                return $stmt->execute([
                    $userId, 
                    'STU' . date('Y') . str_pad($userId, 4, '0', STR_PAD_LEFT),
                    $data['full_name'], $data['phone'], $data['email'], $data['university'], $data['program'],
                    $data['year_of_study'], $data['expected_graduation'], $data['current_gpa'], $data['bio'],
                    $data['address'], $data['city'], $data['country'], $data['interests'], $data['skills'], $data['career_goals'],
                    $data['program_type'] ?? 'scholarship', $data['scholarship_type'] ?? 'Full Tuition Scholarship', date('Y-m-d')
                ]);
            }
        } catch (PDOException $e) {
            error_log("Profile update error: " . $e->getMessage());
            return false;
        }
    }
}

// Initialize profile manager
$profileManager = new StudentProfile($pdo);
$student = $profileManager->getStudentProfile($_SESSION['user_id']);

// Handle form submission
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $updateData = [
        'full_name' => $_POST['full_name'] ?? '',
        'phone' => $_POST['phone'] ?? '',
        'email' => $_POST['email'] ?? '',
        'university' => $_POST['university'] ?? '',
        'program' => $_POST['program'] ?? '',
        'year_of_study' => $_POST['year_of_study'] ?? '',
        'expected_graduation' => $_POST['expected_graduation'] ?? '',
        'current_gpa' => $_POST['current_gpa'] ?? '',
        'bio' => $_POST['bio'] ?? '',
        'address' => $_POST['address'] ?? '',
        'city' => $_POST['city'] ?? '',
        'country' => $_POST['country'] ?? '',
        'interests' => $_POST['interests'] ?? '',
        'skills' => $_POST['skills'] ?? '',
        'career_goals' => $_POST['career_goals'] ?? ''
    ];
    
    if ($profileManager->updateStudentProfile($_SESSION['user_id'], $updateData)) {
        $message = 'Profile updated successfully!';
        $messageType = 'success';
        // Refresh student data
        $student = $profileManager->getStudentProfile($_SESSION['user_id']);
    } else {
        $message = 'Error updating profile. Please try again.';
        $messageType = 'danger';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - REACH Student Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary: #3498db;
            --secondary: #2c3e50;
            --success: #27ae60;
            --warning: #f39c12;
            --danger: #e74c3c;
        }
        
        .profile-header {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            padding: 3rem 0;
            margin-bottom: 2rem;
        }
        
        .profile-picture {
            width: 150px;
            height: 150px;
            border: 5px solid white;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        }
        
        .stats-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }
        
        .stats-card:hover {
            transform: translateY(-5px);
        }
        
        .nav-pills .nav-link.active {
            background: var(--primary);
            color: white;
        }
        
        .section-card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            margin-bottom: 1.5rem;
        }
        
        .badge-complete {
            background: var(--success);
        }
        
        .badge-pending {
            background: var(--warning);
        }
        
        .progress {
            height: 8px;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-hands-helping me-2"></i>
                REACH Student Portal
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="dashboard.php">Dashboard</a>
                <a class="nav-link active" href="profile.php">Profile</a>
                <a class="nav-link" href="../../logout.php">Logout</a>
            </div>
        </div>
    </nav>

    <!-- Profile Header -->
    <div class="profile-header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-2 text-center">
                    <img src="../../assets/images/profiles/<?php echo $student['user_profile_picture'] ?? ($student['profile_picture'] ?? 'default.jpg'); ?>" 
                         class="profile-picture rounded-circle" alt="Profile Picture">
                </div>
                <div class="col-md-8">
                    <h1 class="display-5 fw-bold"><?php echo htmlspecialchars($student['full_name']); ?></h1>
                    <p class="lead mb-2"><?php echo $student['program'] ?? 'Computer Science'; ?> Student</p>
                    <p class="mb-0">
                        <i class="fas fa-university me-2"></i><?php echo $student['university'] ?? 'University of Rwanda'; ?> 
                        | <i class="fas fa-id-card me-2"></i><?php echo $student['student_id'] ?? 'STU2025001'; ?>
                    </p>
                </div>
                <div class="col-md-2 text-end">
                    <button class="btn btn-light" data-bs-toggle="modal" data-bs-target="#editProfileModal">
                        <i class="fas fa-edit me-2"></i>Edit Profile
                    </button>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <!-- Alert Messages -->
        <?php if ($message): ?>
        <div class="alert alert-<?php echo $messageType; ?> alert-dismissible fade show" role="alert">
            <?php echo $message; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-4">
                <!-- Quick Stats -->
                <div class="stats-card p-4 mb-4">
                    <h5 class="mb-3"><i class="fas fa-chart-line me-2 text-primary"></i>Profile Completion</h5>
                    <div class="progress mb-3">
                        <div class="progress-bar bg-success" style="width: 75%"></div>
                    </div>
                    <p class="text-muted small">Complete your profile to unlock all features</p>
                    
                    <div class="mt-4">
                        <div class="d-flex justify-content-between mb-2">
                            <span>Basic Info</span>
                            <span class="badge bg-success">Complete</span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span>Academic Info</span>
                            <span class="badge bg-warning">Pending</span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span>Documents</span>
                            <span class="badge bg-danger">Missing</span>
                        </div>
                    </div>
                </div>

                <!-- Quick Info -->
                <div class="stats-card p-4">
                    <h5 class="mb-3"><i class="fas fa-info-circle me-2 text-primary"></i>Quick Info</h5>
                    <div class="mb-3">
                        <strong>Student ID:</strong><br>
                        <span class="text-muted"><?php echo $student['student_id'] ?? 'STU2025001'; ?></span>
                    </div>
                    <div class="mb-3">
                        <strong>Program Type:</strong><br>
                        <span class="text-muted"><?php echo $student['program_type'] ?? 'Scholarship'; ?></span>
                    </div>
                    <div class="mb-3">
                        <strong>Scholarship:</strong><br>
                        <span class="text-muted"><?php echo $student['scholarship_type'] ?? 'Full Tuition'; ?></span>
                    </div>
                    <div class="mb-3">
                        <strong>Status:</strong><br>
                        <span class="badge bg-success">Active</span>
                    </div>
                    <div class="mb-3">
                        <strong>Member Since:</strong><br>
                        <span class="text-muted"><?php echo date('M Y', strtotime($student['created_at'] ?? '2024-09-01')); ?></span>
                    </div>
                </div>
            </div>

            <!-- Main Content -->
            <div class="col-md-8">
                <!-- Navigation Tabs -->
                <ul class="nav nav-pills mb-4" id="profileTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="academic-tab" data-bs-toggle="pill" data-bs-target="#academic" type="button">
                            <i class="fas fa-graduation-cap me-2"></i>Academic
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="personal-tab" data-bs-toggle="pill" data-bs-target="#personal" type="button">
                            <i class="fas fa-user me-2"></i>Personal
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="documents-tab" data-bs-toggle="pill" data-bs-target="#documents" type="button">
                            <i class="fas fa-file-alt me-2"></i>Documents
                        </button>
                    </li>
                </ul>

                <!-- Tab Content -->
                <div class="tab-content" id="profileTabsContent">
                    <!-- Academic Tab -->
                    <div class="tab-pane fade show active" id="academic" role="tabpanel">
                        <div class="section-card">
                            <div class="card-body">
                                <h5 class="card-title mb-4"><i class="fas fa-university me-2 text-primary"></i>Academic Information</h5>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <strong>University:</strong><br>
                                        <span class="text-muted"><?php echo $student['university'] ?? 'University of Rwanda'; ?></span>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <strong>Program:</strong><br>
                                        <span class="text-muted"><?php echo $student['program'] ?? 'Computer Science'; ?></span>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <strong>Year of Study:</strong><br>
                                        <span class="text-muted"><?php echo $student['year_of_study'] ?? '2nd'; ?> Year</span>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <strong>Expected Graduation:</strong><br>
                                        <span class="text-muted"><?php echo $student['expected_graduation'] ?? '2026'; ?></span>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <strong>Current GPA:</strong><br>
                                        <span class="text-muted"><?php echo $student['current_gpa'] ?? '3.75'; ?> / 4.0</span>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <strong>Academic Status:</strong><br>
                                        <span class="badge bg-success">Good Standing</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="section-card">
                            <div class="card-body">
                                <h5 class="card-title mb-4"><i class="fas fa-book me-2 text-primary"></i>Skills & Interests</h5>
                                <div class="mb-3">
                                    <strong>Skills:</strong><br>
                                    <div class="mt-2">
                                        <?php if (!empty($student['skills'])): ?>
                                            <?php 
                                            $skills = explode(',', $student['skills']);
                                            foreach ($skills as $skill): ?>
                                                <span class="badge bg-primary me-1 mb-1"><?php echo trim($skill); ?></span>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <span class="text-muted">No skills listed</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <strong>Interests:</strong><br>
                                    <div class="mt-2">
                                        <?php if (!empty($student['interests'])): ?>
                                            <?php 
                                            $interests = explode(',', $student['interests']);
                                            foreach ($interests as $interest): ?>
                                                <span class="badge bg-info me-1 mb-1"><?php echo trim($interest); ?></span>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <span class="text-muted">No interests listed</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <strong>Career Goals:</strong><br>
                                    <p class="text-muted mt-2"><?php echo $student['career_goals'] ?? 'Not specified'; ?></p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Personal Tab -->
                    <div class="tab-pane fade" id="personal" role="tabpanel">
                        <div class="section-card">
                            <div class="card-body">
                                <h5 class="card-title mb-4"><i class="fas fa-user-circle me-2 text-primary"></i>Personal Information</h5>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <strong>Full Name:</strong><br>
                                        <span class="text-muted"><?php echo htmlspecialchars($student['full_name']); ?></span>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <strong>Email:</strong><br>
                                        <span class="text-muted"><?php echo $student['email'] ?? ($student['primary_email'] ?? 'Not set'); ?></span>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <strong>Phone:</strong><br>
                                        <span class="text-muted"><?php echo $student['phone'] ?? ($student['primary_phone'] ?? 'Not set'); ?></span>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <strong>Location:</strong><br>
                                        <span class="text-muted">
                                            <?php 
                                            $location = [];
                                            if (!empty($student['city'])) $location[] = $student['city'];
                                            if (!empty($student['country'])) $location[] = $student['country'];
                                            echo $location ? implode(', ', $location) : 'Not specified';
                                            ?>
                                        </span>
                                    </div>
                                    <div class="col-12 mb-3">
                                        <strong>Bio:</strong><br>
                                        <p class="text-muted mt-2"><?php echo nl2br(htmlspecialchars($student['bio'] ?? 'No bio available.')); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="section-card">
                            <div class="card-body">
                                <h5 class="card-title mb-4"><i class="fas fa-home me-2 text-primary"></i>Contact Information</h5>
                                <div class="row">
                                    <div class="col-12 mb-3">
                                        <strong>Address:</strong><br>
                                        <span class="text-muted"><?php echo $student['address'] ?? 'Not specified'; ?></span>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <strong>City:</strong><br>
                                        <span class="text-muted"><?php echo $student['city'] ?? 'Not specified'; ?></span>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <strong>Country:</strong><br>
                                        <span class="text-muted"><?php echo $student['country'] ?? 'Rwanda'; ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Documents Tab -->
                    <div class="tab-pane fade" id="documents" role="tabpanel">
                        <div class="section-card">
                            <div class="card-body">
                                <h5 class="card-title mb-4"><i class="fas fa-file-upload me-2 text-primary"></i>Required Documents</h5>
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>Document</th>
                                                <th>Status</th>
                                                <th>Upload Date</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>ID Document</td>
                                                <td><span class="badge bg-<?php echo !empty($student['id_document']) ? 'success' : 'danger'; ?>">
                                                    <?php echo !empty($student['id_document']) ? 'Uploaded' : 'Missing'; ?>
                                                </span></td>
                                                <td><?php echo !empty($student['id_document']) ? '2024-09-15' : '-'; ?></td>
                                                <td><button class="btn btn-sm btn-outline-primary"><?php echo !empty($student['id_document']) ? 'Update' : 'Upload'; ?></button></td>
                                            </tr>
                                            <tr>
                                                <td>Academic Transcript</td>
                                                <td><span class="badge bg-<?php echo !empty($student['academic_transcript']) ? 'success' : 'warning'; ?>">
                                                    <?php echo !empty($student['academic_transcript']) ? 'Uploaded' : 'Pending'; ?>
                                                </span></td>
                                                <td><?php echo !empty($student['academic_transcript']) ? '2024-09-10' : '-'; ?></td>
                                                <td><button class="btn btn-sm btn-outline-primary"><?php echo !empty($student['academic_transcript']) ? 'Update' : 'Upload'; ?></button></td>
                                            </tr>
                                            <tr>
                                                <td>Recommendation Letter</td>
                                                <td><span class="badge bg-danger">Missing</span></td>
                                                <td>-</td>
                                                <td><button class="btn btn-sm btn-outline-primary">Upload</button></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Profile Modal -->
    <div class="modal fade" id="editProfileModal" tabindex="-1" aria-labelledby="editProfileModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editProfileModalLabel">Edit Profile</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="POST" action="">
                    <div class="modal-body">
                        <input type="hidden" name="update_profile" value="1">
                        
                        <ul class="nav nav-pills mb-3" id="editTabs" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active" id="edit-basic-tab" data-bs-toggle="pill" data-bs-target="#edit-basic" type="button">Basic Info</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="edit-academic-tab" data-bs-toggle="pill" data-bs-target="#edit-academic" type="button">Academic</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="edit-personal-tab" data-bs-toggle="pill" data-bs-target="#edit-personal" type="button">Personal</button>
                            </li>
                        </ul>

                        <div class="tab-content" id="editTabsContent">
                            <!-- Basic Info Tab -->
                            <div class="tab-pane fade show active" id="edit-basic" role="tabpanel">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Full Name *</label>
                                        <input type="text" class="form-control" name="full_name" value="<?php echo htmlspecialchars($student['full_name']); ?>" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Email *</label>
                                        <input type="email" class="form-control" name="email" value="<?php echo $student['email'] ?? ($student['primary_email'] ?? ''); ?>" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Phone</label>
                                        <input type="tel" class="form-control" name="phone" value="<?php echo $student['phone'] ?? ($student['primary_phone'] ?? ''); ?>">
                                    </div>
                                </div>
                            </div>

                            <!-- Academic Tab -->
                            <div class="tab-pane fade" id="edit-academic" role="tabpanel">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">University *</label>
                                        <input type="text" class="form-control" name="university" value="<?php echo $student['university'] ?? 'University of Rwanda'; ?>" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Program *</label>
                                        <input type="text" class="form-control" name="program" value="<?php echo $student['program'] ?? 'Computer Science'; ?>" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Year of Study *</label>
                                        <select class="form-select" name="year_of_study" required>
                                            <?php for ($i = 1; $i <= 6; $i++): ?>
                                                <option value="<?php echo $i; ?>" <?php echo ($student['year_of_study'] ?? 2) == $i ? 'selected' : ''; ?>>
                                                    Year <?php echo $i; ?>
                                                </option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Expected Graduation *</label>
                                        <select class="form-select" name="expected_graduation" required>
                                            <?php for ($year = date('Y'); $year <= date('Y') + 5; $year++): ?>
                                                <option value="<?php echo $year; ?>" <?php echo ($student['expected_graduation'] ?? 2026) == $year ? 'selected' : ''; ?>>
                                                    <?php echo $year; ?>
                                                </option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Current GPA</label>
                                        <input type="number" class="form-control" name="current_gpa" step="0.01" min="0" max="4.0" 
                                               value="<?php echo $student['current_gpa'] ?? '3.75'; ?>">
                                    </div>
                                </div>
                            </div>

                            <!-- Personal Tab -->
                            <div class="tab-pane fade" id="edit-personal" role="tabpanel">
                                <div class="mb-3">
                                    <label class="form-label">Bio</label>
                                    <textarea class="form-control" name="bio" rows="4"><?php echo htmlspecialchars($student['bio'] ?? ''); ?></textarea>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Address</label>
                                        <input type="text" class="form-control" name="address" value="<?php echo $student['address'] ?? ''; ?>">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">City</label>
                                        <input type="text" class="form-control" name="city" value="<?php echo $student['city'] ?? ''; ?>">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Country</label>
                                        <input type="text" class="form-control" name="country" value="<?php echo $student['country'] ?? 'Rwanda'; ?>">
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Skills (comma separated)</label>
                                    <input type="text" class="form-control" name="skills" value="<?php echo $student['skills'] ?? ''; ?>" 
                                           placeholder="e.g., Programming, Design, Leadership">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Interests (comma separated)</label>
                                    <input type="text" class="form-control" name="interests" value="<?php echo $student['interests'] ?? ''; ?>" 
                                           placeholder="e.g., Technology, Sports, Music">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Career Goals</label>
                                    <textarea class="form-control" name="career_goals" rows="3"><?php echo htmlspecialchars($student['career_goals'] ?? ''); ?></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Initialize tooltips
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl)
        });
    </script>
</body>
</html>