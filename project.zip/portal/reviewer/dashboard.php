<?php
session_start();
require_once '../../includes/config.php';
require_once '../../includes/database.php';

// Check if user is reviewer
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'reviewer') {
    header('Location: ../login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

class ReviewerDashboard {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    public function getDashboardData($reviewerId) {
        return [
            'stats' => $this->getReviewerStats($reviewerId),
            'pending_reviews' => $this->getPendingReviews($reviewerId),
            'recent_reviews' => $this->getRecentReviews($reviewerId),
            'review_metrics' => $this->getReviewMetrics($reviewerId)
        ];
    }
    
    private function getReviewerStats($reviewerId) {
        try {
            // Pending reviews
            $stmt = $this->pdo->prepare("SELECT COUNT(*) as pending_reviews FROM applications WHERE reviewer_id = ? AND status = 'under_review'");
            $stmt->execute([$reviewerId]);
            $pending_reviews = $stmt->fetchColumn();
            
            // Total reviewed
            $stmt = $this->pdo->prepare("SELECT COUNT(*) as total_reviewed FROM applications WHERE reviewer_id = ? AND status IN ('approved', 'rejected')");
            $stmt->execute([$reviewerId]);
            $total_reviewed = $stmt->fetchColumn();
            
            // Average review time (in days)
            $stmt = $this->pdo->prepare("SELECT AVG(DATEDIFF(reviewed_at, created_at)) as avg_review_time FROM applications WHERE reviewer_id = ? AND reviewed_at IS NOT NULL");
            $stmt->execute([$reviewerId]);
            $avg_review_time = $stmt->fetchColumn();
            
            return [
                'pending_reviews' => $pending_reviews,
                'total_reviewed' => $total_reviewed,
                'avg_review_time' => round($avg_review_time, 1)
            ];
        } catch (Exception $e) {
            return [
                'pending_reviews' => 0,
                'total_reviewed' => 0,
                'avg_review_time' => 0
            ];
        }
    }
    
    private function getPendingReviews($reviewerId) {
        try {
            $sql = "SELECT 
                a.id, a.application_code, a.program_type, a.created_at,
                u.full_name, u.email,
                DATEDIFF(CURDATE(), a.created_at) as days_waiting
                FROM applications a
                JOIN users u ON a.user_id = u.id
                WHERE a.reviewer_id = ? AND a.status = 'under_review'
                ORDER BY a.created_at ASC
                LIMIT 10";
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$reviewerId]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            return [];
        }
    }
    
    private function getRecentReviews($reviewerId) {
        try {
            $sql = "SELECT 
                a.id, a.application_code, a.program_type, a.status, a.reviewed_at,
                u.full_name,
                a.review_notes
                FROM applications a
                JOIN users u ON a.user_id = u.id
                WHERE a.reviewer_id = ? AND a.reviewed_at IS NOT NULL
                ORDER BY a.reviewed_at DESC
                LIMIT 5";
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$reviewerId]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            return [];
        }
    }
    
    private function getReviewMetrics($reviewerId) {
        try {
            $sql = "SELECT 
                status,
                COUNT(*) as count,
                AVG(DATEDIFF(reviewed_at, created_at)) as avg_days
                FROM applications 
                WHERE reviewer_id = ? AND reviewed_at IS NOT NULL
                GROUP BY status";
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$reviewerId]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            return [];
        }
    }
}

// Initialize dashboard
$reviewerDashboard = new ReviewerDashboard($pdo);
$dashboardData = $reviewerDashboard->getDashboardData($user_id);

function getReviewStatusBadge($status) {
    $statuses = [
        'approved' => 'success',
        'rejected' => 'danger',
        'under_review' => 'warning'
    ];
    return $statuses[$status] ?? 'secondary';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reviewer Dashboard - REACH Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary: #3498db;
            --secondary: #2c3e50;
            --success: #27ae60;
            --warning: #f39c12;
            --danger: #e74c3c;
        }
        
        .reviewer-dashboard {
            background: #f8f9fa;
            min-height: 100vh;
        }
        
        .welcome-section {
            background: linear-gradient(135deg, #e67e22 0%, #d35400 100%);
            color: white;
            padding: 2rem 0;
            margin-bottom: 2rem;
        }
        
        .stat-card {
            background: white;
            border-radius: 10px;
            padding: 1.5rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-left: 4px solid #e67e22;
            margin-bottom: 1.5rem;
        }
        
        .stat-card.warning { border-left-color: var(--warning); }
        .stat-card.success { border-left-color: var(--success); }
        .stat-card.info { border-left-color: var(--primary); }
        
        .portal-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 1.5rem;
        }
        
        .review-item {
            padding: 1rem;
            border-bottom: 1px solid #f8f9fa;
            transition: background-color 0.2s;
        }
        
        .review-item:hover {
            background-color: #f8f9fa;
        }
        
        .urgency-high { border-left: 4px solid var(--danger); }
        .urgency-medium { border-left: 4px solid var(--warning); }
        .urgency-low { border-left: 4px solid var(--success); }
    </style>
</head>
<body class="reviewer-dashboard">
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-hands-helping me-2"></i>
                REACH Reviewer Portal
            </a>
            <div class="navbar-nav ms-auto">
                <span class="navbar-text me-3">
                    Welcome, <?php echo htmlspecialchars($_SESSION['full_name'] ?? 'Reviewer'); ?>
                </span>
                <a class="nav-link" href="profile.php">Profile</a>
                <a class="nav-link" href="../../logout.php">Logout</a>
            </div>
        </div>
    </nav>

    <!-- Welcome Section -->
    <section class="welcome-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1>Reviewer Dashboard</h1>
                    <p class="lead mb-0">Review applications and help shape student futures</p>
                </div>
                <div class="col-md-4 text-end">
                    <div class="btn-group">
                        <a href="reviews/pending.php" class="btn btn-light">
                            <i class="fas fa-tasks me-2"></i>Pending Reviews
                        </a>
                        <a href="guidelines.php" class="btn btn-outline-light">
                            <i class="fas fa-book me-2"></i>Guidelines
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="container">
        <!-- Quick Stats -->
        <div class="row mb-4">
            <div class="col-xl-4 col-md-6">
                <div class="stat-card warning">
                    <div class="stat-icon text-warning">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="stat-number text-warning" style="font-size: 2rem; font-weight: 700;">
                        <?php echo $dashboardData['stats']['pending_reviews']; ?>
                    </div>
                    <p class="text-muted mb-0">Pending Reviews</p>
                </div>
            </div>
            <div class="col-xl-4 col-md-6">
                <div class="stat-card success">
                    <div class="stat-icon text-success">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="stat-number text-success" style="font-size: 2rem; font-weight: 700;">
                        <?php echo $dashboardData['stats']['total_reviewed']; ?>
                    </div>
                    <p class="text-muted mb-0">Total Reviewed</p>
                </div>
            </div>
            <div class="col-xl-4 col-md-6">
                <div class="stat-card info">
                    <div class="stat-icon text-primary">
                        <i class="fas fa-hourglass-half"></i>
                    </div>
                    <div class="stat-number text-primary" style="font-size: 2rem; font-weight: 700;">
                        <?php echo $dashboardData['stats']['avg_review_time']; ?>d
                    </div>
                    <p class="text-muted mb-0">Avg. Review Time</p>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- Pending Reviews -->
            <div class="col-lg-8">
                <div class="portal-card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <span><i class="fas fa-tasks me-2"></i>Pending Reviews</span>
                        <a href="reviews/pending.php" class="btn btn-sm btn-warning">View All</a>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($dashboardData['pending_reviews'])): ?>
                            <?php foreach ($dashboardData['pending_reviews'] as $review): ?>
                            <?php
                            $urgency = 'low';
                            if ($review['days_waiting'] > 7) $urgency = 'high';
                            elseif ($review['days_waiting'] > 3) $urgency = 'medium';
                            ?>
                            <div class="review-item urgency-<?php echo $urgency; ?>">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <h6 class="mb-1"><?php echo htmlspecialchars($review['application_code']); ?></h6>
                                        <p class="mb-1"><?php echo htmlspecialchars($review['full_name']); ?></p>
                                        <small class="text-muted">
                                            <?php echo ucfirst($review['program_type']); ?> • 
                                            Waiting for <?php echo $review['days_waiting']; ?> days
                                        </small>
                                    </div>
                                    <div class="text-end">
                                        <span class="badge bg-<?php echo $urgency === 'high' ? 'danger' : ($urgency === 'medium' ? 'warning' : 'success'); ?>">
                                            <?php echo ucfirst($urgency); ?> priority
                                        </span>
                                        <div class="mt-2">
                                            <a href="reviews/review.php?id=<?php echo $review['id']; ?>" class="btn btn-sm btn-warning">
                                                Start Review
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="text-center py-4 text-muted">
                                <i class="fas fa-check-circle fa-2x mb-3"></i>
                                <p>No pending reviews</p>
                                <p class="small">All assigned applications have been reviewed.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Sidebar -->
            <div class="col-lg-4">
                <!-- Recent Reviews -->
                <div class="portal-card">
                    <div class="card-header">
                        <i class="fas fa-history me-2"></i>Recent Reviews
                    </div>
                    <div class="card-body">
                        <?php if (!empty($dashboardData['recent_reviews'])): ?>
                            <?php foreach ($dashboardData['recent_reviews'] as $review): ?>
                            <div class="d-flex justify-content-between align-items-center mb-3 pb-3 border-bottom">
                                <div>
                                    <small class="text-muted d-block">
                                        <?php echo htmlspecialchars($review['application_code']); ?>
                                    </small>
                                    <small class="text-muted">
                                        <?php echo htmlspecialchars($review['full_name']); ?>
                                    </small>
                                </div>
                                <div class="text-end">
                                    <span class="badge bg-<?php echo getReviewStatusBadge($review['status']); ?>">
                                        <?php echo ucfirst($review['status']); ?>
                                    </span>
                                    <br>
                                    <small class="text-muted">
                                        <?php echo date('M j', strtotime($review['reviewed_at'])); ?>
                                    </small>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="text-center py-3 text-muted">
                                <i class="fas fa-history fa-2x mb-2"></i>
                                <p>No recent reviews</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Review Metrics -->
                <div class="portal-card">
                    <div class="card-header">
                        <i class="fas fa-chart-bar me-2"></i>Review Metrics
                    </div>
                    <div class="card-body">
                        <?php if (!empty($dashboardData['review_metrics'])): ?>
                            <?php foreach ($dashboardData['review_metrics'] as $metric): ?>
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <span class="text-muted">
                                    <?php echo ucfirst($metric['status']); ?>
                                </span>
                                <div class="text-end">
                                    <div class="fw-bold">
                                        <?php echo $metric['count']; ?>
                                    </div>
                                    <small class="text-muted">
                                        <?php echo round($metric['avg_days'], 1); ?> days avg.
                                    </small>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="text-center py-3 text-muted">
                                <i class="fas fa-chart-bar fa-2x mb-2"></i>
                                <p>No review metrics available</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="portal-card">
                    <div class="card-header">
                        <i class="fas fa-bolt me-2"></i>Quick Actions
                    </div>
                    <div class="card-body">
                        <div class="d-grid gap-2">
                            <a href="reviews/pending.php" class="btn btn-warning">
                                <i class="fas fa-tasks me-2"></i>Start Reviewing
                            </a>
                            <a href="guidelines.php" class="btn btn-outline-primary">
                                <i class="fas fa-book me-2"></i>Review Guidelines
                            </a>
                            <a href="reports.php" class="btn btn-outline-info">
                                <i class="fas fa-chart-line me-2"></i>Performance Reports
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>