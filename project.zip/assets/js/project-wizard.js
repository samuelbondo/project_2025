class ProjectWizard {
    constructor() {
        this.currentStep = 1;
        this.totalSteps = 5;
        this.formData = new FormData();
        this.init();
    }
    
    init() {
        this.bindEvents();
        this.updateProgress();
        this.initializeTemplateSelector();
    }
    
    bindEvents() {
        // Next step buttons
        document.querySelectorAll('.next-step').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const nextStep = parseInt(e.target.dataset.next);
                if (this.validateStep(this.currentStep)) {
                    this.goToStep(nextStep);
                }
            });
        });
        
        // Previous step buttons
        document.querySelectorAll('.prev-step').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const prevStep = parseInt(e.target.dataset.prev);
                this.goToStep(prevStep);
            });
        });
        
        // Image upload
        this.setupImageUpload();
        
        // Dynamic elements
        this.setupDynamicElements();
        
        // Form submission
        document.getElementById('submitProject').addEventListener('click', () => {
            this.submitProject();
        });
    }
    
    goToStep(step) {
        // Hide current step
        document.querySelector(`.wizard-step-content[data-step="${this.currentStep}"]`).classList.remove('active');
        document.querySelector(`.wizard-step[data-step="${this.currentStep}"]`).classList.remove('active');
        
        // Show new step
        document.querySelector(`.wizard-step-content[data-step="${step}"]`).classList.add('active');
        document.querySelector(`.wizard-step[data-step="${step}"]`).classList.add('active');
        
        // Update completed steps
        for (let i = 1; i < step; i++) {
            document.querySelector(`.wizard-step[data-step="${i}"]`).classList.add('completed');
        }
        
        this.currentStep = step;
        this.updateProgress();
        
        // Update review section if we're on the last step
        if (step === 5) {
            this.updateReviewSection();
        }
    }
    
    updateProgress() {
        const progress = ((this.currentStep - 1) / (this.totalSteps - 1)) * 100;
        document.querySelector('.progress-bar').style.width = `${progress}%`;
    }
    
    validateStep(step) {
        let isValid = true;
        const currentStepElement = document.querySelector(`.wizard-step-content[data-step="${step}"]`);
        
        // Get all required fields in current step
        const requiredFields = currentStepElement.querySelectorAll('[required]');
        
        requiredFields.forEach(field => {
            if (!field.value.trim()) {
                this.showFieldError(field, 'This field is required');
                isValid = false;
            } else {
                this.clearFieldError(field);
            }
        });
        
        // Step-specific validations
        if (step === 1) {
            isValid = this.validateStep1() && isValid;
        } else if (step === 3) {
            isValid = this.validateStep3() && isValid;
        }
        
        return isValid;
    }
    
    validateStep1() {
        const title = document.querySelector('input[name="title"]').value;
        const description = document.querySelector('textarea[name="description"]').value;
        const startDate = document.querySelector('input[name="start_date"]').value;
        const endDate = document.querySelector('input[name="end_date"]').value;
        
        if (title.length < 5) {
            this.showAlert('Project title should be at least 5 characters long', 'warning');
            return false;
        }
        
        if (description.length < 20) {
            this.showAlert('Project description should be at least 20 characters long', 'warning');
            return false;
        }
        
        if (new Date(endDate) <= new Date(startDate)) {
            this.showAlert('End date must be after start date', 'warning');
            return false;
        }
        
        return true;
    }
    
    validateStep3() {
        const milestones = document.querySelectorAll('.milestone-card');
        
        if (milestones.length === 0) {
            this.showAlert('Please add at least one milestone', 'warning');
            return false;
        }
        
        let hasTasks = false;
        milestones.forEach(milestone => {
            const tasks = milestone.querySelectorAll('.task-item');
            if (tasks.length > 0) {
                hasTasks = true;
            }
        });
        
        if (!hasTasks) {
            this.showAlert('Consider adding tasks to your milestones for better planning', 'info');
        }
        
        return true;
    }
    
    setupImageUpload() {
        const uploadArea = document.getElementById('featuredImageUpload');
        const fileInput = document.getElementById('featuredImageInput');
        const preview = document.getElementById('imagePreview');
        
        uploadArea.addEventListener('click', () => fileInput.click());
        
        fileInput.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                if (file.type.startsWith('image/')) {
                    const reader = new FileReader();
                    reader.onload = (e) => {
                        preview.innerHTML = `<img src="${e.target.result}" alt="Preview">`;
                        preview.classList.remove('d-none');
                        uploadArea.style.display = 'none';
                    };
                    reader.readAsDataURL(file);
                } else {
                    this.showAlert('Please select an image file', 'error');
                }
            }
        });
        
        // Drag and drop support
        uploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadArea.style.borderColor = 'var(--reach-primary)';
            uploadArea.style.background = '#f0f4ff';
        });
        
        uploadArea.addEventListener('dragleave', (e) => {
            e.preventDefault();
            uploadArea.style.borderColor = '#dee2e6';
            uploadArea.style.background = '#f8f9fa';
        });
        
        uploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadArea.style.borderColor = '#dee2e6';
            uploadArea.style.background = '#f8f9fa';
            
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                fileInput.files = files;
                fileInput.dispatchEvent(new Event('change'));
            }
        });
    }
    
    setupDynamicElements() {
        // Add/Remove deliverables
        this.setupDeliverables();
        
        // Add/Remove milestones
        this.setupMilestones();
        
        // Add/Remove tasks
        this.setupTasks();
        
        // Add/Remove resources
        this.setupResources();
    }
    
    setupDeliverables() {
        let deliverableCount = 1;
        
        document.getElementById('addDeliverable').addEventListener('click', () => {
            const container = document.getElementById('deliverablesContainer');
            const newItem = document.createElement('div');
            newItem.className = 'deliverable-item mb-2';
            newItem.innerHTML = `
                <div class="input-group">
                    <input type="text" class="form-control" name="deliverables[]" 
                           placeholder="e.g., Research paper, Mobile app, Community event">
                    <button type="button" class="btn btn-outline-danger remove-deliverable">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            `;
            container.appendChild(newItem);
            
            // Add remove event
            newItem.querySelector('.remove-deliverable').addEventListener('click', () => {
                newItem.remove();
            });
        });
        
        // Initial remove buttons
        document.querySelectorAll('.remove-deliverable').forEach(btn => {
            btn.addEventListener('click', function() {
                this.closest('.deliverable-item').remove();
            });
        });
    }
    
    setupMilestones() {
        let milestoneCount = 1;
        
        document.getElementById('addMilestone').addEventListener('click', () => {
            const container = document.getElementById('milestonesContainer');
            const newMilestone = document.createElement('div');
            newMilestone.className = 'milestone-card';
            newMilestone.setAttribute('data-milestone-index', milestoneCount);
            newMilestone.innerHTML = this.getMilestoneHTML(milestoneCount);
            container.appendChild(newMilestone);
            
            // Initialize date picker for new milestone
            this.initializeDatePickers(newMilestone);
            
            // Setup task management for new milestone
            this.setupTaskManagement(newMilestone, milestoneCount);
            
            milestoneCount++;
        });
    }
    
    getMilestoneHTML(index) {
        return `
            <div class="milestone-header">
                <h6>Milestone ${index + 1}</h6>
                <button type="button" class="btn btn-sm btn-outline-danger remove-milestone">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label class="form-label">Milestone Title *</label>
                        <input type="text" class="form-control milestone-title" 
                               name="milestones[${index}][title]" placeholder="e.g., Project Planning" required>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label class="form-label">Due Date *</label>
                        <input type="text" class="form-control datepicker milestone-due-date" 
                               name="milestones[${index}][due_date]" required>
                    </div>
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label">Description</label>
                <textarea class="form-control milestone-description" 
                          name="milestones[${index}][description]" rows="2"></textarea>
            </div>
            
            <div class="tasks-section">
                <label class="form-label">Tasks</label>
                <div class="tasks-container" data-milestone-index="${index}">
                    <div class="task-item mb-2">
                        <div class="input-group">
                            <input type="text" class="form-control task-title" 
                                   name="milestones[${index}][tasks][0][title]" 
                                   placeholder="Task description">
                            <input type="text" class="form-control task-due-date datepicker" 
                                   name="milestones[${index}][tasks][0][due_date]" 
                                   placeholder="Due date">
                            <select class="form-select task-priority" 
                                    name="milestones[${index}][tasks][0][priority]">
                                <option value="low">Low</option>
                                <option value="medium">Medium</option>
                                <option value="high">High</option>
                            </select>
                            <button type="button" class="btn btn-outline-danger remove-task">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                    </div>
                </div>
                <button type="button" class="btn btn-outline-primary btn-sm add-task" 
                        data-milestone-index="${index}">
                    <i class="fas fa-plus me-1"></i>Add Task
                </button>
            </div>
        `;
    }
    
    setupTaskManagement(milestoneElement, milestoneIndex) {
        let taskCount = 1;
        
        const addTaskBtn = milestoneElement.querySelector('.add-task');
        const tasksContainer = milestoneElement.querySelector('.tasks-container');
        
        addTaskBtn.addEventListener('click', () => {
            const newTask = document.createElement('div');
            newTask.className = 'task-item mb-2';
            newTask.innerHTML = `
                <div class="input-group">
                    <input type="text" class="form-control task-title" 
                           name="milestones[${milestoneIndex}][tasks][${taskCount}][title]" 
                           placeholder="Task description">
                    <input type="text" class="form-control task-due-date datepicker" 
                           name="milestones[${milestoneIndex}][tasks][${taskCount}][due_date]" 
                           placeholder="Due date">
                    <select class="form-select task-priority" 
                            name="milestones[${milestoneIndex}][tasks][${taskCount}][priority]">
                        <option value="low">Low</option>
                        <option value="medium">Medium</option>
                        <option value="high">High</option>
                    </select>
                    <button type="button" class="btn btn-outline-danger remove-task">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            `;
            tasksContainer.appendChild(newTask);
            
            // Initialize date picker
            this.initializeDatePickers(newTask);
            
            // Add remove event
            newTask.querySelector('.remove-task').addEventListener('click', function() {
                this.closest('.task-item').remove();
            });
            
            taskCount++;
        });
        
        // Initial remove buttons
        milestoneElement.querySelectorAll('.remove-task').forEach(btn => {
            btn.addEventListener('click', function() {
                this.closest('.task-item').remove();
            });
        });
        
        // Remove milestone button
        milestoneElement.querySelector('.remove-milestone').addEventListener('click', function() {
            if (document.querySelectorAll('.milestone-card').length > 1) {
                this.closest('.milestone-card').remove();
            } else {
                window.projectWizard.showAlert('You need at least one milestone', 'warning');
            }
        });
    }
    
    initializeTemplateSelector() {
        const templateSelect = document.getElementById('projectTemplate');
        
        templateSelect.addEventListener('change', (e) => {
            const templateKey = e.target.value;
            if (templateKey) {
                this.applyTemplate(templateKey);
            }
        });
    }
    
    applyTemplate(templateKey) {
        // This would be populated with actual template data
        const templates = {
            'research': {
                skills: 'research, data analysis, academic writing, critical thinking',
                technologies: 'Microsoft Word, Excel, SPSS, Reference Manager',
                description: 'A comprehensive academic research project template'
            },
            'community': {
                skills: 'community engagement, project management, communication, leadership',
                technologies: 'Survey Tools, Social Media, Project Management Software',
                description: 'Community development and engagement project template'
            }
        };
        
        const template = templates[templateKey];
        if (template) {
            document.querySelector('input[name="skills_used"]').value = template.skills;
            document.querySelector('input[name="technologies"]').value = template.technologies;
            document.querySelector('textarea[name="description"]').value = template.description;
            
            this.showAlert(`Applied ${templateKey} template successfully!`, 'success');
        }
    }
    
    updateReviewSection() {
        // Basic Info
        const basicInfoHTML = `
            <div class="review-item">
                <span class="review-label">Project Title:</span>
                <span class="review-value">${document.querySelector('input[name="title"]').value}</span>
            </div>
            <div class="review-item">
                <span class="review-label">Project Type:</span>
                <span class="review-value">${document.querySelector('select[name="project_type"]').value}</span>
            </div>
            <div class="review-item">
                <span class="review-label">Timeline:</span>
                <span class="review-value">${document.querySelector('input[name="start_date"]').value} to ${document.querySelector('input[name="end_date"]').value}</span>
            </div>
        `;
        document.getElementById('review-basic-info').innerHTML = basicInfoHTML;
        
        // Add more review sections for other steps...
    }
    
    async submitProject() {
        if (this.validateStep(5)) {
            const loadingModal = new bootstrap.Modal(document.getElementById('loadingModal'));
            loadingModal.show();
            
            try {
                const formData = new FormData();
                
                // Collect all form data
                const formElements = document.querySelectorAll('input, select, textarea');
                formElements.forEach(element => {
                    if (element.name && element.value) {
                        if (element.type === 'file') {
                            if (element.files[0]) {
                                formData.append(element.name, element.files[0]);
                            }
                        } else {
                            formData.append(element.name, element.value);
                        }
                    }
                });
                
                // Add the rich text editor content
                const fullDescription = document.getElementById('fullDescription').value;
                formData.append('full_description', fullDescription);
                
                const response = await fetch('../../api/project-save.php', {
                    method: 'POST',
                    body: formData
                });
                
                const result = await response.json();
                
                loadingModal.hide();
                
                if (result.success) {
                    this.showAlert('Project created successfully! Redirecting...', 'success');
                    setTimeout(() => {
                        window.location.href = `project-detail.php?id=${result.projectId}`;
                    }, 2000);
                } else {
                    this.showAlert(result.message || 'Error creating project', 'error');
                }
                
            } catch (error) {
                loadingModal.hide();
                this.showAlert('Network error: ' + error.message, 'error');
            }
        }
    }
    
    showAlert(message, type = 'info') {
        const alertClass = {
            'success': 'alert-success',
            'error': 'alert-danger',
            'warning': 'alert-warning',
            'info': 'alert-info'
        }[type];
        
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert ${alertClass} alert-dismissible fade show`;
        alertDiv.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        // Insert at the top of the wizard
        const wizard = document.getElementById('projectWizard');
        wizard.insertBefore(alertDiv, wizard.firstChild);
        
        // Auto remove after 5 seconds
        setTimeout(() => {
            if (alertDiv.parentNode) {
                alertDiv.remove();
            }
        }, 5000);
    }
    
    showFieldError(field, message) {
        this.clearFieldError(field);
        field.classList.add('is-invalid');
        
        const errorDiv = document.createElement('div');
        errorDiv.className = 'invalid-feedback';
        errorDiv.textContent = message;
        field.parentNode.appendChild(errorDiv);
    }
    
    clearFieldError(field) {
        field.classList.remove('is-invalid');
        const existingError = field.parentNode.querySelector('.invalid-feedback');
        if (existingError) {
            existingError.remove();
        }
    }
    
    initializeDatePickers(container) {
        const datePickers = container.querySelectorAll('.datepicker');
        datePickers.forEach(picker => {
            flatpickr(picker, {
                dateFormat: 'Y-m-d',
                minDate: 'today'
            });
        });
    }
}

// Initialize the wizard when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.projectWizard = new ProjectWizard();
});