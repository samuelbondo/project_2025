class StoryEditor {
    constructor(quill) {
        this.quill = quill;
        this.storyId = null;
        this.autoSaveInterval = null;
        this.isSaving = false;
        this.lastContent = '';
        
        this.init();
    }
    
    init() {
        this.bindEvents();
        this.startAutoSave();
        this.setupWordCount();
        this.setupImageUpload();
    }
    
    bindEvents() {
        // Title input events
        document.getElementById('storyTitle').addEventListener('input', (e) => {
            this.updateTitleLength(e.target.value.length);
            this.debouncedSave();
        });
        
        // Excerpt events
        document.getElementById('storyExcerpt').addEventListener('input', (e) => {
            this.updateExcerptLength(e.target.value.length);
            this.debouncedSave();
        });
        
        // Quill editor events
        this.quill.on('text-change', () => {
            this.updateWordCount();
            this.debouncedSave();
            this.analyzeContent();
        });
        
        // Save buttons
        document.getElementById('saveDraftBtn').addEventListener('click', () => {
            this.saveStory('draft');
        });
        
        document.getElementById('publishBtn').addEventListener('click', () => {
            this.saveStory('pending');
        });
        
        // Preview button
        document.getElementById('previewBtn').addEventListener('click', () => {
            this.showPreview();
        });
        
        // AI assistance buttons
        this.setupAIAssistance();
        
        // Form field changes
        document.querySelectorAll('#storyType, #storyTags, #isPublic, #allowComments').forEach(element => {
            element.addEventListener('change', () => {
                this.debouncedSave();
            });
        });
    }
    
    startAutoSave() {
        this.autoSaveInterval = setInterval(() => {
            if (this.hasUnsavedChanges()) {
                this.saveStory('draft', true);
            }
        }, 30000); // Auto-save every 30 seconds
    }
    
    debouncedSave() {
        clearTimeout(this.debounceTimer);
        this.debounceTimer = setTimeout(() => {
            if (this.hasUnsavedChanges()) {
                this.saveStory('draft', true);
            }
        }, 2000);
    }
    
    hasUnsavedChanges() {
        const currentContent = this.getStoryData();
        return JSON.stringify(currentContent) !== JSON.stringify(this.lastContent);
    }
    
    async saveStory(status = 'draft', isAutoSave = false) {
        if (this.isSaving) return;
        
        this.isSaving = true;
        this.updateSaveStatus('Saving...');
        
        try {
            const storyData = this.getStoryData();
            storyData.status = status;
            
            const formData = new FormData();
            Object.keys(storyData).forEach(key => {
                if (key === 'featured_image' && storyData[key] instanceof File) {
                    formData.append(key, storyData[key]);
                } else {
                    formData.append(key, typeof storyData[key] === 'object' ? 
                                   JSON.stringify(storyData[key]) : storyData[key]);
                }
            });
            
            const response = await fetch('../../api/story-save.php', {
                method: 'POST',
                body: formData
            });
            
            const result = await response.json();
            
            if (result.success) {
                this.storyId = result.story_id;
                this.lastContent = this.getStoryData();
                this.updateSaveStatus(isAutoSave ? 'Auto-saved' : 'All changes saved');
                
                if (!isAutoSave) {
                    this.showNotification(
                        status === 'draft' ? 'Draft saved successfully!' : 'Story submitted for review!',
                        'success'
                    );
                    
                    if (status === 'pending') {
                        setTimeout(() => {
                            window.location.href = 'my-stories.php';
                        }, 1500);
                    }
                }
            } else {
                throw new Error(result.message || 'Failed to save story');
            }
            
        } catch (error) {
            console.error('Save error:', error);
            this.updateSaveStatus('Failed to save');
            this.showNotification('Error saving story: ' + error.message, 'error');
        } finally {
            this.isSaving = false;
        }
    }
    
    getStoryData() {
        return {
            title: document.getElementById('storyTitle').value,
            excerpt: document.getElementById('storyExcerpt').value,
            content: this.quill.root.innerHTML,
            story_type: document.getElementById('storyType').value,
            tags: document.getElementById('storyTags').value,
            is_public: document.getElementById('isPublic').checked,
            allow_comments: document.getElementById('allowComments').checked,
            featured_image: this.featuredImageFile || null
        };
    }
    
    updateWordCount() {
        const text = this.quill.getText();
        const wordCount = text.trim() === '' ? 0 : text.trim().split(/\s+/).length;
        const readTime = Math.ceil(wordCount / 200); // 200 wpm
        
        document.getElementById('wordCount').textContent = wordCount.toLocaleString();
        document.getElementById('readTime').textContent = `${readTime} min`;
    }
    
    updateTitleLength(length) {
        document.getElementById('titleLength').textContent = `${length}/120`;
        
        // Update color based on length
        const titleLength = document.getElementById('titleLength');
        if (length < 40) {
            titleLength.style.color = '#dc3545';
        } else if (length > 80) {
            titleLength.style.color = '#fd7e14';
        } else {
            titleLength.style.color = '#28a745';
        }
    }
    
    updateExcerptLength(length) {
        document.getElementById('excerptLength').textContent = `${length}/300`;
    }
    
    updateSaveStatus(status) {
        const saveStatus = document.getElementById('autoSaveStatus');
        saveStatus.textContent = status;
        
        if (status === 'Saving...') {
            saveStatus.classList.add('saving');
            saveStatus.classList.remove('success');
        } else if (status === 'All changes saved' || status === 'Auto-saved') {
            saveStatus.classList.remove('saving');
            saveStatus.classList.add('success');
        } else {
            saveStatus.classList.remove('saving', 'success');
        }
    }
    
    setupImageUpload() {
        const uploadArea = document.getElementById('featuredImageUpload');
        const fileInput = document.getElementById('featuredImageInput');
        const preview = document.getElementById('imagePreview');
        const previewImage = document.getElementById('previewImage');
        const removeBtn = document.getElementById('removeImage');
        
        uploadArea.addEventListener('click', () => fileInput.click());
        
        fileInput.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                if (this.validateImage(file)) {
                    this.featuredImageFile = file;
                    const reader = new FileReader();
                    reader.onload = (e) => {
                        previewImage.src = e.target.result;
                        preview.style.display = 'block';
                        uploadArea.style.display = 'none';
                    };
                    reader.readAsDataURL(file);
                }
            }
        });
        
        removeBtn.addEventListener('click', () => {
            this.featuredImageFile = null;
            fileInput.value = '';
            preview.style.display = 'none';
            uploadArea.style.display = 'block';
        });
        
        // Drag and drop
        uploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadArea.style.borderColor = 'var(--reach-primary)';
            uploadArea.style.background = '#f0f4ff';
        });
        
        uploadArea.addEventListener('dragleave', (e) => {
            e.preventDefault();
            uploadArea.style.borderColor = '#dee2e6';
            uploadArea.style.background = '#f8f9fa';
        });
        
        uploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadArea.style.borderColor = '#dee2e6';
            uploadArea.style.background = '#f8f9fa';
            
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                fileInput.files = files;
                fileInput.dispatchEvent(new Event('change'));
            }
        });
    }
    
    validateImage(file) {
        const validTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        const maxSize = 5 * 1024 * 1024; // 5MB
        
        if (!validTypes.includes(file.type)) {
            this.showNotification('Please select a valid image file (JPEG, PNG, GIF, WebP)', 'error');
            return false;
        }
        
        if (file.size > maxSize) {
            this.showNotification('Image size must be less than 5MB', 'error');
            return false;
        }
        
        return true;
    }
    
    setupAIAssistance() {
        // AI Headline Help
        document.getElementById('aiHeadlineBtn').addEventListener('click', () => {
            this.getAIHeadlineSuggestions();
        });
        
        // AI Excerpt Help
        document.getElementById('aiExcerptBtn').addEventListener('click', () => {
            this.generateAIExcerpt();
        });
        
        // Quick AI Actions
        document.querySelectorAll('.action-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const action = e.currentTarget.dataset.action;
                this.handleAIAction(action);
            });
        });
        
        // AI Chat
        this.setupAIChat();
        
        // Writing Templates
        this.setupWritingTemplates();
    }
    
    async getAIHeadlineSuggestions() {
        const title = document.getElementById('storyTitle').value;
        const excerpt = document.getElementById('storyExcerpt').value;
        const content = this.quill.getText().substring(0, 500);
        
        if (!title && !content) {
            this.showNotification('Please write some content first to get AI headline suggestions', 'warning');
            return;
        }
        
        const modal = new bootstrap.Modal(document.getElementById('headlineModal'));
        modal.show();
        
        try {
            const response = await fetch('../../api/ai-generate.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    action: 'headline_suggestions',
                    title: title,
                    excerpt: excerpt,
                    content: content,
                    story_type: document.getElementById('storyType').value
                })
            });
            
            const result = await response.json();
            
            if (result.success) {
                this.displayHeadlineSuggestions(result.suggestions);
            } else {
                throw new Error(result.message);
            }
            
        } catch (error) {
            console.error('AI Headline error:', error);
            this.showNotification('Error getting AI suggestions: ' + error.message, 'error');
        }
    }
    
    displayHeadlineSuggestions(suggestions) {
        const container = document.getElementById('headlineSuggestions');
        container.innerHTML = '';
        
        suggestions.forEach((suggestion, index) => {
            const suggestionDiv = document.createElement('div');
            suggestionDiv.className = 'suggestion-option';
            suggestionDiv.innerHTML = `
                <h6>${suggestion.headline}</h6>
                <p>${suggestion.reason}</p>
            `;
            
            suggestionDiv.addEventListener('click', () => {
                // Remove selected class from all options
                container.querySelectorAll('.suggestion-option').forEach(opt => {
                    opt.classList.remove('selected');
                });
                // Add selected class to clicked option
                suggestionDiv.classList.add('selected');
                // Update apply button
                document.getElementById('applyHeadline').dataset.selectedIndex = index;
            });
            
            container.appendChild(suggestionDiv);
        });
        
        // Update apply button event
        document.getElementById('applyHeadline').onclick = () => {
            const selectedIndex = document.getElementById('applyHeadline').dataset.selectedIndex;
            if (selectedIndex !== undefined) {
                const selectedSuggestion = suggestions[selectedIndex];
                document.getElementById('storyTitle').value = selectedSuggestion.headline;
                this.updateTitleLength(selectedSuggestion.headline.length);
                bootstrap.Modal.getInstance(document.getElementById('headlineModal')).hide();
                this.showNotification('Headline applied successfully!', 'success');
            } else {
                this.showNotification('Please select a headline first', 'warning');
            }
        };
    }
    
    async generateAIExcerpt() {
        const title = document.getElementById('storyTitle').value;
        const content = this.quill.getText().substring(0, 1000);
        
        if (!content) {
            this.showNotification('Please write some content first to generate an excerpt', 'warning');
            return;
        }
        
        try {
            const response = await fetch('../../api/ai-generate.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    action: 'generate_excerpt',
                    title: title,
                    content: content,
                    story_type: document.getElementById('storyType').value
                })
            });
            
            const result = await response.json();
            
            if (result.success) {
                document.getElementById('storyExcerpt').value = result.excerpt;
                this.updateExcerptLength(result.excerpt.length);
                this.showNotification('AI excerpt generated successfully!', 'success');
            } else {
                throw new Error(result.message);
            }
            
        } catch (error) {
            console.error('AI Excerpt error:', error);
            this.showNotification('Error generating excerpt: ' + error.message, 'error');
        }
    }
    
    handleAIAction(action) {
        const content = this.quill.getText();
        
        if (!content && action !== 'suggest-tags') {
            this.showNotification('Please write some content first to use AI assistance', 'warning');
            return;
        }
        
        switch (action) {
            case 'improve-intro':
                this.improveIntroduction();
                break;
            case 'generate-conclusion':
                this.generateConclusion();
                break;
            case 'add-section':
                this.addAISection();
                break;
            case 'optimize-seo':
                this.optimizeSEO();
                break;
            case 'check-readability':
                this.checkReadability();
                break;
            case 'suggest-tags':
                this.suggestTags();
                break;
        }
    }
    
    setupAIChat() {
        const chatInput = document.getElementById('chatInput');
        const sendBtn = document.getElementById('sendMessage');
        const chatMessages = document.getElementById('chatMessages');
        
        const sendMessage = async () => {
            const message = chatInput.value.trim();
            if (!message) return;
            
            // Add user message
            this.addChatMessage('user', message);
            chatInput.value = '';
            
            try {
                const response = await fetch('../../api/ai-generate.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        action: 'chat',
                        message: message,
                        context: {
                            title: document.getElementById('storyTitle').value,
                            content: this.quill.getText(),
                            story_type: document.getElementById('storyType').value
                        }
                    })
                });
                
                const result = await response.json();
                
                if (result.success) {
                    this.addChatMessage('ai', result.response);
                } else {
                    throw new Error(result.message);
                }
                
            } catch (error) {
                console.error('AI Chat error:', error);
                this.addChatMessage('ai', 'Sorry, I encountered an error. Please try again.');
            }
        };
        
        sendBtn.addEventListener('click', sendMessage);
        chatInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                sendMessage();
            }
        });
        
        // Quick prompts
        document.querySelectorAll('.prompt-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                chatInput.value = e.currentTarget.dataset.prompt;
                sendMessage();
            });
        });
    }
    
    addChatMessage(sender, message) {
        const chatMessages = document.getElementById('chatMessages');
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${sender}-message`;
        
        messageDiv.innerHTML = `
            <div class="message-avatar">
                <i class="fas fa-${sender === 'user' ? 'user' : 'robot'}"></i>
            </div>
            <div class="message-content">
                <p>${this.escapeHtml(message)}</p>
            </div>
        `;
        
        chatMessages.appendChild(messageDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
    
    setupWritingTemplates() {
        document.querySelectorAll('.template-card').forEach(card => {
            card.addEventListener('click', (e) => {
                const template = e.currentTarget.dataset.template;
                this.applyWritingTemplate(template);
            });
        });
    }
    
    applyWritingTemplate(template) {
        const templates = {
            'success-story': {
                title: "My Journey to Success with REACH Organization",
                structure: [
                    "Introduction: Share your background and initial challenges",
                    "The Turning Point: How REACH Organization entered your life",
                    "The Journey: Specific support and opportunities received",
                    "Achievements: Concrete results and accomplishments",
                    "Impact: How this changed your life and future plans",
                    "Gratitude: Express appreciation and future aspirations"
                ]
            },
            'project-showcase': {
                title: "Transforming Communities: My REACH Project Story",
                structure: [
                    "Project Overview: What we set out to achieve",
                    "The Challenge: Problem we aimed to solve",
                    "Our Approach: Methodology and process",
                    "Implementation: How we executed the project",
                    "Results: Measurable outcomes and impact",
                    "Lessons Learned: Key takeaways and future improvements"
                ]
            }
            // Add more templates...
        };
        
        const selectedTemplate = templates[template];
        if (selectedTemplate) {
            // Apply template structure to the editor
            const templateContent = selectedTemplate.structure.map(section => 
                `<h3>${section.split(':')[0]}</h3><p>${section.split(':')[1] || 'Share your experience here...'}</p>`
            ).join('');
            
            this.quill.root.innerHTML = templateContent;
            document.getElementById('storyTitle').value = selectedTemplate.title;
            this.updateTitleLength(selectedTemplate.title.length);
            
            this.showNotification(`${template.replace('-', ' ')} template applied!`, 'success');
        }
    }
    
    analyzeContent() {
        const content = this.quill.getText();
        if (content.length < 50) return;
        
        // Simulate content analysis
        setTimeout(() => {
            const readabilityScore = Math.floor(Math.random() * 30) + 70; // 70-100
            const seoScore = Math.floor(Math.random() * 25) + 75; // 75-100
            const engagementScore = Math.floor(Math.random() * 20) + 80; // 80-100
            
            document.getElementById('readabilityScore').textContent = readabilityScore;
            document.getElementById('seoScore').textContent = seoScore;
            document.getElementById('engagementScore').textContent = engagementScore;
            
            // Update AI suggestions based on content
            this.updateAISuggestions(content);
        }, 1000);
    }
    
    updateAISuggestions(content) {
        const suggestions = [
            "Consider adding a personal anecdote to make your story more relatable.",
            "Your introduction could be more engaging. Try starting with a question or surprising fact.",
            "Add specific numbers and statistics to strengthen your achievements.",
            "Consider breaking up long paragraphs for better readability.",
            "Include a call-to-action at the end to engage your readers."
        ];
        
        const suggestionsList = document.getElementById('aiSuggestionsList');
        suggestionsList.innerHTML = '';
        
        suggestions.slice(0, 3).forEach(suggestion => {
            const suggestionItem = document.createElement('div');
            suggestionItem.className = 'suggestion-item';
            suggestionItem.innerHTML = `
                <div class="suggestion-icon">
                    <i class="fas fa-lightbulb"></i>
                </div>
                <div class="suggestion-content">
                    <p>${suggestion}</p>
                </div>
            `;
            suggestionsList.appendChild(suggestionItem);
        });
    }
    
    showPreview() {
        const storyData = this.getStoryData();
        const preview = document.getElementById('storyPreview');
        
        preview.innerHTML = `
            <article class="story-preview">
                <h1>${this.escapeHtml(storyData.title) || 'Untitled Story'}</h1>
                ${storyData.featured_image ? `<img src="${URL.createObjectURL(storyData.featured_image)}" alt="Featured" style="max-width: 100%; border-radius: 8px; margin: 20px 0;">` : ''}
                ${storyData.excerpt ? `<div class="excerpt" style="font-style: italic; color: #666; margin: 20px 0; padding: 15px; background: #f8f9fa; border-radius: 8px;">${this.escapeHtml(storyData.excerpt)}</div>` : ''}
                <div class="content">${storyData.content}</div>
            </article>
        `;
        
        const modal = new bootstrap.Modal(document.getElementById('previewModal'));
        modal.show();
    }
    
    showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `alert alert-${type} alert-dismissible fade show`;
        notification.style.cssText = 'position: fixed; top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
        notification.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        document.body.appendChild(notification);
        
        // Auto remove after 5 seconds
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 5000);
    }
    
    escapeHtml(unsafe) {
        return unsafe
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }
}

// Make it globally available
window.StoryEditor = StoryEditor;